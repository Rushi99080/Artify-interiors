/* eslint-disable no-console */
// Seed script — run with `npm run db:seed` (or automatically after `prisma migrate reset`).
// Always: workflow stages + admin account.
// SEED_DEMO_DATA=true: demo materials, suppliers, team, sample website content and a demo customer project.
import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";
import { DEFAULT_STAGES } from "../src/lib/workflow/stages";
import { BOQ_SECTIONS, DEFAULT_CHARGES, generateProjectExtras, generateRoomLines, type MaterialContext } from "../src/lib/boq/engine";
import { computeBOQTotals } from "../src/lib/calc/boq";
import { representativeByTier, type RecMaterial } from "../src/lib/materials/recommend";
import { buildQuotationSnapshot } from "../src/lib/quotation/snapshot";
import { DEFAULT_SETTINGS } from "../src/lib/settings-defaults";

const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) });

const U = (id: string, w = 1600) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;

type MatSeed = [category: string, name: string, brand: string, unit: string, rate: number, tier: string, finish: string | null, color: string | null, durability: number, maintenance: number, styles: string[], specs: string];

const MATERIALS: MatSeed[] = [
  ["PLYWOOD", "Sainik 710 BWR Plywood 18mm", "CenturyPly", "sqft", 78, "ECONOMY", null, null, 3, 3, [], "Boiling water resistant, IS:303 BWR grade. For dry-area carcasses."],
  ["PLYWOOD", "Green Club 700 BWP Plywood 18mm", "Greenply", "sqft", 125, "STANDARD", null, null, 4, 4, [], "IS:710 BWP marine grade, termite & borer resistant. Recommended for wardrobes and kitchens."],
  ["PLYWOOD", "Club Prime BWP 710 Plywood 18mm", "CenturyPly", "sqft", 165, "PREMIUM", null, null, 5, 4, [], "Calibrated BWP 710 plywood with fire-retardant treatment. Lifetime warranty against borers."],
  ["PLYWOOD", "Green Club Plus 700 Gurjan Plywood 19mm", "Greenply", "sqft", 210, "LUXURY", null, null, 5, 5, [], "Gurjan face veneer, E-0 emission, IS:710. For bespoke joinery and veneer finishes."],
  ["MDF", "Pre-laminated MDF 18mm", "Action Tesa", "sqft", 70, "ECONOMY", "Matte", "White", 2, 3, ["MINIMALIST", "MODERN"], "Interior grade MDF, both sides pre-laminated. Dry areas only."],
  ["MDF", "Exterior Grade MDF 18mm", "Greenpanel", "sqft", 88, "STANDARD", null, null, 3, 3, ["MODERN", "CONTEMPORARY"], "Moisture-resistant MDF, ideal for CNC shutters and paneling."],
  ["HDHMR", "HDHMR Pro 18mm", "Action Tesa", "sqft", 105, "STANDARD", null, null, 4, 4, ["MODERN", "CONTEMPORARY", "MINIMALIST"], "High density high moisture resistant board — excellent screw holding, termite proof."],
  ["HDHMR", "Boilo HDHMR 18mm", "Action Tesa", "sqft", 132, "PREMIUM", null, null, 5, 4, ["MODERN", "LUXURY"], "Boiling-water-proof HDHMR for kitchen carcasses and wet areas."],
  ["LAMINATE", "1mm Matte Laminate — Ash Grey", "Merino", "sheet", 1450, "ECONOMY", "Matte", "Ash Grey", 3, 4, ["MODERN", "MINIMALIST", "SCANDINAVIAN"], "8×4 ft, 1mm, anti-fingerprint matte surface."],
  ["LAMINATE", "1mm Suede Laminate — Walnut Mood", "Greenlam", "sheet", 1850, "STANDARD", "Suede", "Walnut", 4, 4, ["JAPANDI", "CONTEMPORARY", "TRADITIONAL"], "8×4 ft, 1mm, realistic wood-grain texture."],
  ["LAMINATE", "1mm Textured Laminate — Linen Oak", "Royale Touche", "sheet", 2200, "STANDARD", "Textured", "Light Oak", 4, 4, ["SCANDINAVIAN", "JAPANDI", "MINIMALIST"], "8×4 ft, synchronised wood texture."],
  ["LAMINATE", "1mm Anti-fingerprint Laminate — Charcoal", "Merino", "sheet", 2600, "PREMIUM", "Super matte AFP", "Charcoal", 4, 5, ["MODERN", "INDUSTRIAL", "LUXURY"], "Nano-tech anti-fingerprint, thermal healing of micro scratches."],
  ["ACRYLIC", "High Gloss Acrylic — Ivory", "Merino", "sheet", 5200, "PREMIUM", "High gloss", "Ivory", 4, 3, ["MODERN", "CONTEMPORARY", "LUXURY"], "Mirror-finish acrylic, UV stable, edge-banded."],
  ["ACRYLIC", "Matte Acrylic — Sage Green", "Senosan", "sheet", 6800, "LUXURY", "Matte", "Sage", 4, 4, ["CONTEMPORARY", "JAPANDI", "SCANDINAVIAN"], "German matte acrylic with soft-touch finish."],
  ["VENEER", "Natural Teak Veneer", "Greenlam Decowood", "sqft", 185, "PREMIUM", "Natural", "Teak", 4, 3, ["TRADITIONAL", "NEO_CLASSICAL", "JAPANDI"], "0.5mm natural teak veneer, finished with PU lacquer on site."],
  ["VENEER", "Smoked Oak Veneer", "Century Veneers", "sqft", 320, "LUXURY", "Smoked", "Dark Oak", 4, 3, ["LUXURY", "CONTEMPORARY", "INDUSTRIAL"], "Fumed oak veneer, book-matched, PU matte lacquer."],
  ["VENEER", "Fluted Walnut Veneer Panel", "Greenlam", "sqft", 410, "LUXURY", "Fluted", "Walnut", 4, 3, ["LUXURY", "JAPANDI", "CONTEMPORARY"], "Pre-finished fluted panels for TV and bed-back walls."],
  ["PAINT", "Tractor Emulsion", "Asian Paints", "litre", 180, "ECONOMY", "Matte", null, 3, 2, [], "Interior emulsion, good coverage, economical."],
  ["PAINT", "Apcolite Premium Emulsion", "Asian Paints", "litre", 330, "STANDARD", "Smooth", null, 4, 3, [], "Washable interior emulsion with low VOC."],
  ["PAINT", "Royale Luxury Emulsion", "Asian Paints", "litre", 520, "PREMIUM", "Sheen", null, 4, 4, ["LUXURY", "CONTEMPORARY"], "Teflon surface protector, highly washable, anti-bacterial."],
  ["PAINT", "Velvet Touch Diamond Glo", "Dulux", "litre", 610, "LUXURY", "Soft sheen", null, 5, 4, ["LUXURY", "NEO_CLASSICAL"], "Premium stain-resistant finish with diamond glo sheen."],
  ["WALLPAPER", "Kids Collection — Starry Night", "Excel Wallcoverings", "roll", 1900, "ECONOMY", null, "Navy", 3, 3, [], "57 sqft roll, washable vinyl."],
  ["WALLPAPER", "Linen Texture Wallcovering", "Marshalls", "roll", 2400, "STANDARD", "Textured", "Beige", 3, 3, ["SCANDINAVIAN", "JAPANDI", "MINIMALIST"], "57 sqft roll, fabric-backed vinyl."],
  ["WALLPAPER", "Botanica Designer Wallpaper", "Nilaya by Asian Paints", "roll", 5500, "LUXURY", null, "Green", 3, 3, ["LUXURY", "TRADITIONAL", "NEO_CLASSICAL"], "Designer print on non-woven base."],
  ["FLOORING", "Laminate Flooring 8mm — Natural Oak", "Action Tesa", "sqft", 95, "ECONOMY", "Matte", "Natural Oak", 3, 4, ["SCANDINAVIAN", "MINIMALIST"], "AC3 rated, click-lock, with underlay."],
  ["FLOORING", "WPC Outdoor Deck Tiles", "Greenlam", "sqft", 160, "STANDARD", "Textured", "Teak", 4, 5, [], "UV-stable WPC, interlocking — for balconies."],
  ["FLOORING", "Laminate Flooring 10mm — Smoked Oak", "Pergo", "sqft", 210, "PREMIUM", "Brushed", "Smoked Oak", 4, 4, ["CONTEMPORARY", "INDUSTRIAL", "MODERN"], "AC4 rated, water-resistant core."],
  ["FLOORING", "Engineered Wood — American Walnut", "Squarefoot", "sqft", 420, "LUXURY", "Oiled", "Walnut", 4, 3, ["LUXURY", "JAPANDI", "NEO_CLASSICAL"], "3-layer engineered, 4mm wear layer, oil finish."],
  ["TILES", "Vitrified Tile 600×600 — Ivory Matte", "Kajaria", "sqft", 65, "ECONOMY", "Matte", "Ivory", 4, 4, [], "Double-charged vitrified tile."],
  ["TILES", "Anti-skid Floor Tile 300×300", "Johnson Endura", "sqft", 75, "ECONOMY", "Anti-skid", "Grey", 5, 4, [], "R11 slip resistance — bathrooms & balconies."],
  ["TILES", "Subway Backsplash Tile — White Gloss", "Nitco", "sqft", 110, "STANDARD", "Gloss", "White", 4, 4, ["MODERN", "SCANDINAVIAN", "INDUSTRIAL"], "75×150mm ceramic subway tile."],
  ["TILES", "GVT 800×1600 — Statuario", "Somany Duragres", "sqft", 130, "STANDARD", "Glossy", "White marble look", 4, 4, ["MODERN", "CONTEMPORARY", "LUXURY"], "Glazed vitrified, large format."],
  ["TILES", "Slab Tile 1200×2400 — Calacatta", "Kajaria Eternity", "sqft", 210, "PREMIUM", "Satin", "Calacatta", 5, 4, ["LUXURY", "CONTEMPORARY", "NEO_CLASSICAL"], "Large-format porcelain slab, minimal grout lines."],
  ["MARBLE", "Katni Beige Marble", "Indian Marble", "sqft", 160, "STANDARD", "Polished", "Beige", 4, 2, ["TRADITIONAL", "NEO_CLASSICAL"], "Indian marble, diamond polished on site."],
  ["MARBLE", "Makrana White Marble", "Indian Marble", "sqft", 350, "PREMIUM", "Polished", "White", 5, 2, ["TRADITIONAL", "NEO_CLASSICAL", "LUXURY"], "Premium Makrana albeta, low porosity."],
  ["MARBLE", "Statuario Italian Marble", "Imported", "sqft", 1100, "LUXURY", "Polished", "White with grey veins", 4, 2, ["LUXURY", "NEO_CLASSICAL"], "Italian Statuario, book-matched slabs."],
  ["QUARTZ", "Quartz 15mm — Pure White", "Kalinga Stone", "sqft", 320, "STANDARD", "Polished", "White", 5, 5, ["MODERN", "MINIMALIST", "SCANDINAVIAN"], "93% quartz, non-porous, stain resistant."],
  ["QUARTZ", "Quartz 15mm — Calacatta Gold", "AGL", "sqft", 520, "PREMIUM", "Polished", "Calacatta", 5, 5, ["LUXURY", "CONTEMPORARY", "NEO_CLASSICAL"], "Marble-look engineered quartz."],
  ["QUARTZ", "Quartz 20mm — Empira White", "Caesarstone", "sqft", 950, "LUXURY", "Honed", "White", 5, 5, ["LUXURY", "MINIMALIST", "JAPANDI"], "Premium imported quartz, 20mm with mitred edge."],
  ["QUARTZ", "Quartz 15mm — Concrete Grey", "Kalinga Stone", "sqft", 290, "ECONOMY", "Matte", "Grey", 5, 5, ["INDUSTRIAL", "MODERN"], "Concrete-look quartz for industrial kitchens."],
  ["HARDWARE", "Tall Unit Pantry Pull-out", "Ebco", "nos", 14500, "STANDARD", "Chrome", null, 4, 4, [], "6-tier pantry pull-out for 450mm tall unit."],
  ["HARDWARE", "Magic Corner Unit", "Hafele", "nos", 28000, "LUXURY", "Anthracite", null, 5, 4, [], "Blind corner solution with soft-close."],
  ["HARDWARE", "Wardrobe Lift-up Mechanism", "Hafele", "nos", 4800, "PREMIUM", null, null, 4, 4, [], "Gas-lift mechanism for loft shutters."],
  ["HINGES", "Auto-close Hinge", "Ebco", "nos", 95, "ECONOMY", "Nickel", null, 3, 3, [], "Auto-close concealed hinge, 110°."],
  ["HINGES", "Onsys Soft-close Hinge", "Hettich", "nos", 220, "STANDARD", "Nickel", null, 4, 4, [], "Integrated soft-close, 110°, 3D adjustment."],
  ["HINGES", "Sensys Soft-close Hinge", "Hettich", "nos", 420, "PREMIUM", "Nickel", null, 5, 5, [], "Silent System damping, tested for 80,000 cycles."],
  ["HINGES", "Clip Top Blumotion Hinge", "Blum", "nos", 780, "LUXURY", "Nickel", null, 5, 5, [], "Austrian hinge with integrated Blumotion soft close."],
  ["CHANNELS", "Telescopic Channel 450mm", "Ebco", "pair", 420, "ECONOMY", "Zinc", null, 3, 3, [], "Ball-bearing, full extension, 35kg."],
  ["CHANNELS", "Quadro Soft-close Runner", "Hettich", "pair", 950, "STANDARD", "Zinc", null, 4, 4, [], "Concealed runner with Silent System."],
  ["CHANNELS", "InnoTech Atira Drawer System", "Hettich", "pair", 2100, "PREMIUM", "Anthracite", null, 5, 5, [], "Double-wall tandem drawer, 40kg, soft-close."],
  ["CHANNELS", "Legrabox Drawer System", "Blum", "pair", 5200, "LUXURY", "Stainless", null, 5, 5, [], "Slim-wall premium drawer, 70kg, Blumotion."],
  ["HANDLES", "Aluminium Profile Handle", "Generic", "nos", 140, "ECONOMY", "Anodised", "Silver", 4, 4, ["MODERN", "MINIMALIST"], "Edge-mounted G-profile handle."],
  ["HANDLES", "Ozone Bar Handle 160mm", "Ozone", "nos", 260, "STANDARD", "Brushed", "Black", 4, 4, ["MODERN", "INDUSTRIAL", "CONTEMPORARY"], "Solid aluminium, powder coated."],
  ["HANDLES", "Brushed Brass Bar Handle 224mm", "Hafele", "nos", 480, "PREMIUM", "Brushed brass", "Gold", 4, 3, ["LUXURY", "NEO_CLASSICAL", "CONTEMPORARY"], "Solid brass, lacquered."],
  ["HANDLES", "Leather Pull Handle", "Bespoke", "nos", 1200, "LUXURY", "Saddle leather", "Tan", 3, 3, ["JAPANDI", "LUXURY", "SCANDINAVIAN"], "Hand-stitched leather with brass fixings."],
  ["LIGHTING", "LED Downlight 12W", "Philips", "nos", 420, "ECONOMY", null, "Warm white", 4, 5, [], "3000K, IP20, 5-year warranty."],
  ["LIGHTING", "Garnet COB Spotlight 10W", "Wipro", "nos", 780, "STANDARD", null, "Warm white", 4, 5, [], "Anti-glare COB, CRI 90, 3000K."],
  ["LIGHTING", "Endura Trimless COB 12W", "Havells", "nos", 1250, "PREMIUM", null, "Warm white", 5, 5, ["MINIMALIST", "MODERN", "LUXURY"], "Plaster-in trimless spot, CRI 95."],
  ["LIGHTING", "Designer Brass COB Spot", "Jainsons", "nos", 3200, "LUXURY", "Brushed brass", "Gold", 4, 4, ["LUXURY", "NEO_CLASSICAL", "TRADITIONAL"], "Machined brass housing, 2700K, dimmable."],
  ["FALSE_CEILING", "Gyproc Gypsum Board 12.5mm", "Saint-Gobain", "sqft", 38, "STANDARD", null, null, 4, 4, [], "Gypsum board on GI framing; price is board only, installation in rate card."],
  ["FALSE_CEILING", "Moisture Resistant Gypsum Board", "Saint-Gobain", "sqft", 52, "PREMIUM", null, null, 5, 4, [], "For kitchens and bathrooms."],
  ["GLASS", "Toughened Clear Glass 10mm", "Saint-Gobain", "sqft", 220, "STANDARD", "Clear", null, 4, 3, [], "Tempered safety glass, polished edges."],
  ["GLASS", "Lacquered Glass 6mm", "Saint-Gobain", "sqft", 260, "STANDARD", "Back-painted", "Beige", 4, 4, ["MODERN", "CONTEMPORARY"], "For shutters and backsplashes."],
  ["GLASS", "Fluted Glass 8mm", "Saint-Gobain", "sqft", 340, "PREMIUM", "Fluted", "Clear", 4, 3, ["CONTEMPORARY", "LUXURY", "JAPANDI"], "Reeded glass for crockery shutters and partitions."],
  ["UPHOLSTERY", "Linen Blend Fabric", "D'Decor", "rmt", 950, "STANDARD", "Woven", "Oatmeal", 3, 3, ["SCANDINAVIAN", "JAPANDI", "MINIMALIST"], "Upholstery grade, 50,000 rubs."],
  ["UPHOLSTERY", "Performance Velvet", "D'Decor", "rmt", 1600, "PREMIUM", "Velvet", "Emerald", 4, 4, ["LUXURY", "NEO_CLASSICAL", "CONTEMPORARY"], "Stain-resistant velvet, 80,000 rubs."],
  ["UPHOLSTERY", "Boucle Fabric", "Sarom", "rmt", 2400, "LUXURY", "Boucle", "Ivory", 3, 3, ["JAPANDI", "LUXURY", "CONTEMPORARY"], "Textured boucle, upholstery weight."],
];

async function main() {
  console.log("Seeding workflow stages…");
  for (const [i, s] of DEFAULT_STAGES.entries()) {
    await prisma.workflowStage.upsert({
      where: { key: s.key },
      create: { key: s.key, name: s.name, sortOrder: i + 1, defaultDurationDays: s.defaultDurationDays, customerVisible: s.customerVisible },
      update: {},
    });
  }

  const adminEmail = (process.env.SEED_ADMIN_EMAIL || "admin@artifyinteriors.in").toLowerCase();
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || "Artify@Admin2026";
  console.log(`Ensuring admin account ${adminEmail}…`);
  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    create: { email: adminEmail, name: "Artify Admin", role: "ADMIN", passwordHash: await bcrypt.hash(adminPassword, 12) },
    update: { role: "ADMIN", isActive: true },
  });
  await prisma.teamMember.upsert({
    where: { userId: admin.id },
    create: { userId: admin.id, name: admin.name, designation: "Principal Designer", department: "Management", email: admin.email },
    update: {},
  });

  if (process.env.SEED_DEMO_DATA !== "true") {
    console.log("SEED_DEMO_DATA is not 'true' — skipping demo data.");
    return;
  }

  // ── Suppliers ──
  console.log("Seeding demo suppliers & materials…");
  const supplierDefs = [
    { name: "Shree Plywood & Laminates (demo)", contactPerson: "Supplier contact", phone: "", categories: ["PLYWOOD", "MDF", "HDHMR", "LAMINATE", "ACRYLIC", "VENEER"] },
    { name: "Pune Hardware House (demo)", contactPerson: "Supplier contact", phone: "", categories: ["HARDWARE", "HINGES", "CHANNELS", "HANDLES"] },
    { name: "Stone & Tile Gallery (demo)", contactPerson: "Supplier contact", phone: "", categories: ["TILES", "MARBLE", "QUARTZ", "FLOORING"] },
    { name: "Lumen Lighting Co. (demo)", contactPerson: "Supplier contact", phone: "", categories: ["LIGHTING", "FALSE_CEILING", "GLASS", "PAINT", "WALLPAPER", "UPHOLSTERY"] },
  ];
  const suppliers: { id: string; categories: string[] }[] = [];
  for (const s of supplierDefs) {
    const existing = await prisma.supplier.findFirst({ where: { name: s.name } });
    suppliers.push(existing ?? (await prisma.supplier.create({ data: { ...s, notes: "Demo supplier created by the seed script — edit or delete." } })));
  }
  const supplierFor = (cat: string) => suppliers.find((s) => s.categories.includes(cat))?.id ?? null;

  const counters: Record<string, number> = {};
  for (const m of MATERIALS) {
    const [category, name, brand, unit, rate, tier, finish, color, durability, maintenance, styles, specs] = m;
    counters[category] = (counters[category] ?? 0) + 1;
    const productCode = `${category.slice(0, 3)}-${String(counters[category]).padStart(3, "0")}`;
    await prisma.material.upsert({
      where: { productCode },
      create: {
        productCode,
        category: category as never,
        name,
        brand,
        unit,
        rate,
        tier: tier as never,
        finish,
        color,
        durability,
        maintenance,
        styles: styles as never,
        specifications: `${specs} (Demo rate — update before quoting.)`,
        supplierId: supplierFor(category),
        availability: "IN_STOCK",
      },
      update: {},
    });
  }

  // ── Team ──
  const team = [
    { name: "Lead Designer (demo)", designation: "Senior Interior Designer", department: "Design" },
    { name: "Site Supervisor (demo)", designation: "Site Supervisor", department: "Execution" },
    { name: "Production Manager (demo)", designation: "Production Manager", department: "Factory" },
  ];
  const teamMembers: { id: string }[] = [];
  for (const t of team) {
    teamMembers.push((await prisma.teamMember.findFirst({ where: { name: t.name } })) ?? (await prisma.teamMember.create({ data: t })));
  }

  // ── Website content (clearly marked samples) ──
  console.log("Seeding sample website content…");
  const portfolio = [
    { slug: "sample-warm-minimal-living", title: "Warm Minimal Living Room", roomType: "LIVING_ROOM", style: "CONTEMPORARY", location: "Baner, Pune", areaSqft: 320, cover: U("photo-1600210492486-724fe5c67fb0"), featured: true, description: "A calm family living room layered in oatmeal textures, fluted wood and soft cove lighting, with a floating media wall that hides every cable." },
    { slug: "sample-japandi-bedroom", title: "Japandi Master Suite", roomType: "MASTER_BEDROOM", style: "JAPANDI", location: "Kharadi, Pune", areaSqft: 210, cover: U("photo-1616594039964-ae9021a400a0"), featured: true, description: "Low-profile bed, slatted oak headboard and a full-height wardrobe in matte linen laminate — designed around morning light." },
    { slug: "sample-modular-kitchen", title: "Sage Modular Kitchen", roomType: "KITCHEN", style: "MODERN", location: "Wakad, Pune", areaSqft: 110, cover: U("photo-1556909114-f6e7ad7d3136"), featured: true, description: "An L-shaped kitchen with quartz counters, tandem drawers and a tall pantry unit planned around the work triangle." },
    { slug: "sample-serene-bedroom", title: "Serene Guest Bedroom", roomType: "GUEST_BEDROOM", style: "SCANDINAVIAN", location: "Aundh, Pune", areaSqft: 160, cover: U("photo-1505693416388-ac5ce068fe85"), featured: false, description: "Soft whites, natural linen and light oak for a guest room that feels like a boutique hotel." },
    { slug: "sample-family-lounge", title: "Family Lounge", roomType: "LIVING_ROOM", style: "MODERN", location: "Hinjewadi, Pune", areaSqft: 280, cover: U("photo-1586023492125-27b2c045efd7"), featured: false, description: "A relaxed lounge with a modular sofa, statement rug and layered lighting for movie nights." },
    { slug: "sample-studio-office", title: "Creative Studio Office", roomType: "OFFICE", style: "INDUSTRIAL", location: "Koregaon Park, Pune", areaSqft: 1400, cover: U("photo-1497366216548-37526070297c"), featured: true, description: "Open workstations, glass cabins and acoustic ceiling clouds for a 24-seat creative team." },
  ];
  for (const [i, p] of portfolio.entries()) {
    await prisma.portfolioProject.upsert({
      where: { slug: p.slug },
      create: { slug: p.slug, title: p.title, roomType: p.roomType as never, style: p.style as never, location: p.location, areaSqft: p.areaSqft, description: p.description, coverImageUrl: p.cover, images: [p.cover], isFeatured: p.featured, isSample: true, sortOrder: i },
      update: {},
    });
  }
  if ((await prisma.testimonial.count()) === 0) {
    await prisma.testimonial.createMany({
      data: [
        { name: "Sample Client", location: "Pune", projectType: "3 BHK Apartment", quote: "Sample testimonial — replace this with a real client review from Admin → Website Content.", rating: 5, isSample: true, sortOrder: 1 },
        { name: "Sample Client", location: "Pune", projectType: "Villa", quote: "Sample testimonial — add genuine feedback from your completed projects here.", rating: 5, isSample: true, sortOrder: 2 },
        { name: "Sample Client", location: "Pune", projectType: "Office", quote: "Sample testimonial — testimonials marked as samples show a 'Sample' label on the website.", rating: 5, isSample: true, sortOrder: 3 },
      ],
    });
  }

  // ── Demo customer project ──
  const demoEmail = "demo.customer@example.com";
  if (await prisma.user.findUnique({ where: { email: demoEmail } })) {
    console.log("Demo customer already exists — done.");
    return;
  }
  console.log("Creating demo customer project…");
  const demoUser = await prisma.user.create({
    data: { email: demoEmail, name: "Demo Customer", phone: "9000000000", role: "CUSTOMER", passwordHash: await bcrypt.hash("Demo@12345", 12) },
  });
  const customer = await prisma.customer.create({ data: { userId: demoUser.id, fullName: "Demo Customer", email: demoEmail, phone: "9000000000", city: "Pune", address: "Baner, Pune 411045" } });
  const year = new Date().getFullYear();
  const pc = await prisma.counter.upsert({ where: { key: `project:${year}` }, create: { key: `project:${year}`, value: 1 }, update: { value: { increment: 1 } } });
  const project = await prisma.project.create({
    data: {
      code: `ART-${year}-${String(pc.value).padStart(4, "0")}`,
      name: "Demo 2BHK — Baner",
      customerId: customer.id,
      location: "Baner, Pune",
      address: "Demo address, Baner, Pune 411045",
      propertyType: "APARTMENT",
      carpetAreaSqft: 850,
      numberOfRooms: 4,
      designStyle: "JAPANDI",
      budgetMin: 600000,
      budgetMax: 1000000,
      colorPalette: "Warm neutrals, oak, sage accents",
      materialPreferences: "Matte finishes, light oak, no high gloss",
      timeline: "1 – 3 months",
      status: "QUOTATION",
      rooms: {
        create: [
          { name: "Living Room", type: "LIVING_ROOM", lengthFt: 15, widthFt: 11, heightFt: 10, sortOrder: 0 },
          { name: "Master Bedroom", type: "MASTER_BEDROOM", lengthFt: 13, widthFt: 11, heightFt: 10, sortOrder: 1 },
          { name: "Kitchen", type: "KITCHEN", lengthFt: 9, widthFt: 8, heightFt: 10, sortOrder: 2 },
          { name: "Bathroom", type: "BATHROOM", lengthFt: 7, widthFt: 5, heightFt: 9, sortOrder: 3 },
        ],
      },
    },
    include: { rooms: true },
  });

  const stages = await prisma.workflowStage.findMany({ orderBy: { sortOrder: "asc" } });
  await prisma.projectMilestone.createMany({
    data: stages.map((s) => ({
      projectId: project.id,
      stageKey: s.key,
      name: s.name,
      sortOrder: s.sortOrder,
      customerVisible: s.customerVisible,
      status: s.sortOrder <= 4 ? "COMPLETED" : s.sortOrder === 5 ? "IN_PROGRESS" : "PENDING",
      completedAt: s.sortOrder <= 4 ? new Date() : null,
      startedAt: s.sortOrder <= 5 ? new Date() : null,
      assigneeId: s.sortOrder <= 9 ? teamMembers[0]!.id : teamMembers[1]!.id,
    })),
  });

  // BOQ from the same engine the app uses
  const allMats = (await prisma.material.findMany()) as unknown as RecMaterial[];
  const ctx: MaterialContext = { byTier: representativeByTier(allMats) };
  const tier = "STANDARD" as const;
  const lines = project.rooms.flatMap((r) => generateRoomLines({ name: r.name, type: r.type as never, lengthFt: r.lengthFt, widthFt: r.widthFt, heightFt: r.heightFt }, tier, undefined, ctx));
  lines.push(...generateProjectExtras(850, tier));
  const order = (s: string) => (BOQ_SECTIONS as readonly string[]).indexOf(s);
  lines.sort((a, b) => order(a.section) - order(b.section));
  const charges = { ...DEFAULT_CHARGES, discountAmount: 25000 };
  const totals = computeBOQTotals(lines, charges, [...BOQ_SECTIONS]);
  const boq = await prisma.bOQ.create({
    data: {
      projectId: project.id,
      version: 1,
      title: `BOQ v1 — ${project.name}`,
      status: "PRELIMINARY",
      tier,
      ...charges,
      subtotal: totals.subtotal,
      grandTotal: totals.grandTotal,
      notes: "Demo BOQ generated by the seed script.",
      items: { create: lines.map((l, i) => ({ sortOrder: i, section: l.section, item: l.item, dimensions: l.dimensions, primaryMaterial: l.primaryMaterial, finishBrand: l.finishBrand, hardware: l.hardware, accessories: l.accessories, quantity: l.quantity, unit: l.unit, rate: l.rate, amount: l.amount, itemType: l.itemType, materialId: l.materialId, isEstimated: true })) },
    },
    include: { items: true },
  });

  const fy = (() => {
    const d = new Date();
    const start = d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
    return `${start}-${String((start + 1) % 100).padStart(2, "0")}`;
  })();
  const qc = await prisma.counter.upsert({ where: { key: `quotation:${fy}` }, create: { key: `quotation:${fy}`, value: 1 }, update: { value: { increment: 1 } } });
  const number = `${DEFAULT_SETTINGS.quotation.prefix}/${fy}/${String(qc.value).padStart(4, "0")}`;
  const snapshot = buildQuotationSnapshot({
    company: { ...DEFAULT_SETTINGS.company },
    client: { name: customer.fullName, email: customer.email, phone: customer.phone, address: customer.address },
    project: { name: project.name, code: project.code, location: project.location, address: project.address, propertyType: project.propertyType, carpetAreaSqft: project.carpetAreaSqft },
    marginLabel: DEFAULT_SETTINGS.boqDefaults.marginLabel,
    boq,
  });
  await prisma.quotation.create({
    data: {
      number,
      baseNumber: number,
      revision: 0,
      projectId: project.id,
      boqId: boq.id,
      status: "SENT",
      sentAt: new Date(),
      isPreliminary: true,
      snapshot: snapshot as never,
      subtotal: snapshot.totals.subtotal,
      taxableAmount: snapshot.totals.taxableAmount,
      gstAmount: snapshot.totals.gstAmount,
      grandTotal: snapshot.totals.grandTotal,
      validUntil: new Date(Date.now() + 15 * 86400000),
      scopeOfWork: DEFAULT_SETTINGS.quotation.scopeOfWork,
      paymentTerms: DEFAULT_SETTINGS.quotation.paymentTerms,
      timelineText: DEFAULT_SETTINGS.quotation.timelineText,
      terms: DEFAULT_SETTINGS.quotation.terms,
      createdById: admin.id,
    },
  });

  const lc = await prisma.counter.upsert({ where: { key: `lead:${year}` }, create: { key: `lead:${year}`, value: 1 }, update: { value: { increment: 1 } } });
  await prisma.lead.create({
    data: { leadCode: `LD-${year}-${String(lc.value).padStart(4, "0")}`, name: customer.fullName, phone: customer.phone, email: customer.email, city: "Pune", projectType: "APARTMENT", budget: "₹6 – 10 Lakh", source: "AI_DESIGNER", status: "QUOTATION_SENT", customerId: customer.id, projectId: project.id, message: "Demo lead created by the seed script." },
  });
  const lc2 = await prisma.counter.upsert({ where: { key: `lead:${year}` }, create: { key: `lead:${year}`, value: 1 }, update: { value: { increment: 1 } } });
  await prisma.lead.create({
    data: { leadCode: `LD-${year}-${String(lc2.value).padStart(4, "0")}`, name: "Website Visitor (demo)", phone: "9111111111", email: "visitor@example.com", city: "Pune", projectType: "VILLA", budget: "₹20 – 40 Lakh", source: "WEBSITE", status: "NEW", followUpDate: new Date(Date.now() + 86400000), message: "Looking for full home interiors for a 4BHK villa. (Demo lead)" },
  });

  await prisma.message.createMany({
    data: [
      { projectId: project.id, kind: "SYSTEM", body: "Project created. Welcome to Artify Interiors!", fromTeam: true },
      { projectId: project.id, senderId: admin.id, kind: "MESSAGE", body: "Hi! Your preliminary quotation is ready. Please review it and request a site measurement when you are ready.", fromTeam: true },
    ],
  });

  console.log(`Demo customer login: ${demoEmail} / Demo@12345`);
}

main()
  .then(async () => {
    console.log("Seed complete.");
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
