/**
 * Create (or reset) an admin login from the command line.
 *
 *   npm run admin:create -- --email owner@studio.in --name "Studio Owner" --password "S0me-long-passphrase"
 *
 * If the email already exists, the user is promoted to ADMIN, re-activated and the password is reset.
 */
import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";
import { passwordProblem } from "../src/lib/auth/password";

function arg(name: string) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : undefined;
}

async function main() {
  const email = arg("email")?.trim().toLowerCase();
  const name = arg("name")?.trim() || "Studio Admin";
  const password = arg("password") ?? "";
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Pass a valid --email");
  const problem = passwordProblem(password);
  if (problem) throw new Error(`--password: ${problem}`);
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is not set (check your .env)");

  const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }) });
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.upsert({
      where: { email },
      create: { email, name, role: "ADMIN", passwordHash },
      update: { role: "ADMIN", isActive: true, passwordHash, name },
    });
    const member = await prisma.teamMember.findUnique({ where: { userId: user.id } });
    if (!member) await prisma.teamMember.create({ data: { userId: user.id, name, designation: "Administrator", email } });
    console.log(`✓ Admin ready: ${email} — sign in at ${process.env.APP_URL ?? "http://localhost:3000"}/login`);
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((err) => {
  console.error(`✗ ${(err as Error).message}`);
  process.exit(1);
});
