import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE, isTeamRole, verifySession } from "@/lib/auth/token";

// Route protection runs before rendering. Pages and API routes still re-check access on the
// server (defence in depth) — this layer gives fast redirects for signed-out users.

export async function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl;
  const session = await verifySession(request.cookies.get(SESSION_COOKIE)?.value);

  const needsLogin = pathname.startsWith("/dashboard") || pathname.startsWith("/admin");
  if (needsLogin && !session) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.search = `?next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }

  if (pathname.startsWith("/admin") && session && !isTeamRole(session.role)) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*"],
};
