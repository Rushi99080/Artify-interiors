import { cn } from "@/lib/format";

/** Artify mark: an arch (a doorway in plan) holding the letter A. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("size-8", className)} fill="none" aria-hidden>
      <path d="M4 38V18a16 16 0 0 1 32 0v20" stroke="var(--color-brass)" strokeWidth="1.6" />
      <path d="M12 34 20 12l8 22M15 27h10" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  );
}

export function Logo({ className, compact, tone = "dark" }: { className?: string; compact?: boolean; tone?: "dark" | "light" }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", tone === "light" ? "text-paper" : "text-charcoal", className)}>
      <LogoMark />
      {!compact ? (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[1.15rem] font-semibold tracking-[0.24em]">ARTIFY</span>
          <span className={cn("mt-1 text-[0.58rem] font-semibold tracking-[0.42em]", tone === "light" ? "text-sand" : "text-brass-deep")}>INTERIORS</span>
        </span>
      ) : null}
    </span>
  );
}
