"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { CheckCircle2, Download, Eye, Mail, Printer, RefreshCw, Send, Workflow } from "lucide-react";
import { QUOTATION_STATUS_LABELS } from "@/lib/constants";
import { formatDate, formatINR } from "@/lib/format";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Checkbox, Field, Input, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/notice";
import { EmptyState } from "@/components/ui/panel";
import { useToast } from "@/components/ui/toast";

export type QuotationRow = {
  id: string;
  number: string;
  revision: number;
  status: string;
  isPreliminary: boolean;
  grandTotal: number;
  gstAmount: number;
  subtotal: number;
  createdAt: string;
  validUntil: string;
  sentAt: string | null;
  emailedAt: string | null;
  approvedAt: string | null;
  approvedByName: string | null;
  clientComment: string | null;
  boqVersion: number | null;
};

export function QuotationsPanel({ quotations, mode, projectActive, customerName }: { quotations: QuotationRow[]; mode: "customer" | "team"; projectActive: boolean; customerName: string }) {
  const [showHistory, setShowHistory] = useState(false);
  const current = quotations.filter((q) => q.status !== "SUPERSEDED");
  const history = quotations.filter((q) => q.status === "SUPERSEDED");
  if (!quotations.length) return <EmptyState title="No quotations yet" description={mode === "customer" ? "Generate your estimate from the Estimate (BOQ) tab to receive a preliminary quotation instantly." : "Generate a quotation from a BOQ."} />;
  return (
    <div className="space-y-4">
      {current.map((q) => (
        <QuotationCard key={q.id} q={q} mode={mode} projectActive={projectActive} customerName={customerName} />
      ))}
      {history.length ? (
        <div>
          <button type="button" onClick={() => setShowHistory((s) => !s)} className="text-sm text-smoke underline underline-offset-4 hover:text-charcoal">
            {showHistory ? "Hide" : "Show"} quotation history ({history.length})
          </button>
          {showHistory ? (
            <div className="mt-3 space-y-3 opacity-80">
              {history.map((q) => (
                <QuotationCard key={q.id} q={q} mode={mode} projectActive={projectActive} customerName={customerName} />
              ))}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function QuotationCard({ q, mode, projectActive, customerName }: { q: QuotationRow; mode: "customer" | "team"; projectActive: boolean; customerName: string }) {
  const router = useRouter();
  const { toast } = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const [approveOpen, setApproveOpen] = useState(false);
  const [changesOpen, setChangesOpen] = useState(false);
  const expired = new Date(q.validUntil).getTime() < Date.now();
  const open = ["SENT", "CHANGES_REQUESTED"].includes(q.status);

  async function post(path: string, label: string, body: unknown = {}) {
    setBusy(label);
    try {
      const res = await api<{ status?: string; error?: string; to?: string }>(`/api/quotations/${q.id}/${path}`, { body });
      if (path === "email") {
        if (res.status === "SENT") toast(`Quotation emailed to ${res.to}`);
        else toast(`Email not sent: ${res.error ?? res.status}`, "error");
      } else toast(label);
      router.refresh();
      return true;
    } catch (err) {
      toast(errorMessage(err), "error");
      return false;
    } finally {
      setBusy(null);
    }
  }

  return (
    <article className="rounded-[var(--radius-md)] border border-line bg-paper p-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-2xl text-charcoal">{q.number}</h3>
            <StatusBadge status={q.status} label={QUOTATION_STATUS_LABELS[q.status as keyof typeof QUOTATION_STATUS_LABELS]} />
            {q.isPreliminary ? <Badge tone="amber">Preliminary</Badge> : <Badge tone="moss">Final</Badge>}
            {expired && open ? <Badge tone="brick">Expired</Badge> : null}
          </div>
          <p className="mt-1 text-xs text-smoke">
            Issued {formatDate(q.createdAt)} · valid until {formatDate(q.validUntil)}
            {q.boqVersion ? ` · BOQ v${q.boqVersion}` : ""}
            {q.emailedAt ? ` · emailed ${formatDate(q.emailedAt)}` : ""}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-smoke">Total incl. GST</p>
          <p className="font-display text-3xl text-charcoal tabular-nums">{formatINR(q.grandTotal)}</p>
          <p className="text-xs text-smoke">GST {formatINR(q.gstAmount)}</p>
        </div>
      </div>

      {q.approvedAt ? (
        <Notice kind="success" className="mt-4">
          Approved by {q.approvedByName} on {formatDate(q.approvedAt, true)}.
        </Notice>
      ) : null}
      {q.clientComment && !q.approvedAt ? <p className="mt-4 rounded-[var(--radius-sm)] bg-plaster px-3 py-2 text-sm text-ink">Client: “{q.clientComment}”</p> : null}
      {mode === "customer" && q.isPreliminary && open ? (
        <p className="mt-4 text-sm text-smoke">This is a preliminary estimate. To approve, request a final quotation — our team will measure your site and confirm quantities.</p>
      ) : null}

      <div className="mt-5 flex flex-wrap gap-2">
        <a href={`/api/quotations/${q.id}/pdf`} target="_blank" rel="noopener noreferrer" className="inline-flex h-8 items-center gap-1.5 rounded-[var(--radius-sm)] border border-line bg-paper px-3 text-[0.8rem] text-charcoal hover:border-sand">
          <Eye className="size-3.5" /> View PDF
        </a>
        <a href={`/api/quotations/${q.id}/pdf?download=1`} className="inline-flex h-8 items-center gap-1.5 rounded-[var(--radius-sm)] border border-line bg-paper px-3 text-[0.8rem] text-charcoal hover:border-sand">
          <Download className="size-3.5" /> Download
        </a>
        <a href={`/api/quotations/${q.id}/pdf`} target="_blank" rel="noopener noreferrer" title="Opens the PDF — use your viewer's print button" className="inline-flex h-8 items-center gap-1.5 rounded-[var(--radius-sm)] border border-line bg-paper px-3 text-[0.8rem] text-charcoal hover:border-sand">
          <Printer className="size-3.5" /> Print
        </a>

        {mode === "customer" && open ? (
          <>
            {q.isPreliminary ? (
              <Button size="sm" onClick={() => setChangesOpen(true)}>
                Request final quotation
              </Button>
            ) : (
              <>
                <Button size="sm" variant="secondary" onClick={() => setChangesOpen(true)}>
                  Request changes
                </Button>
                <Button size="sm" onClick={() => setApproveOpen(true)} disabled={expired}>
                  <CheckCircle2 className="size-3.5" /> Approve quotation
                </Button>
              </>
            )}
          </>
        ) : null}

        {mode === "team" ? (
          <>
            {["DRAFT", "CHANGES_REQUESTED"].includes(q.status) ? (
              <Button size="sm" onClick={() => post("send", "Quotation sent to client")} loading={busy === "Quotation sent to client"}>
                <Send className="size-3.5" /> Send to client
              </Button>
            ) : null}
            {q.status !== "SUPERSEDED" ? (
              <Button size="sm" variant="secondary" onClick={() => post("email", "email")} loading={busy === "email"}>
                <Mail className="size-3.5" /> Email PDF
              </Button>
            ) : null}
            {q.status !== "APPROVED" && q.status !== "SUPERSEDED" ? (
              <>
                <Button size="sm" variant="secondary" onClick={() => post("revise", "Revised quotation created")} loading={busy === "Revised quotation created"}>
                  <RefreshCw className="size-3.5" /> Revise
                </Button>
                <Button size="sm" variant="secondary" onClick={() => setApproveOpen(true)}>
                  <CheckCircle2 className="size-3.5" /> Mark approved
                </Button>
              </>
            ) : null}
            {q.status === "APPROVED" && !projectActive ? (
              <Button size="sm" onClick={() => post("convert", "Project activated")} loading={busy === "Project activated"}>
                <Workflow className="size-3.5" /> Convert to active project
              </Button>
            ) : null}
          </>
        ) : null}
      </div>

      <ApproveModal open={approveOpen} onClose={() => setApproveOpen(false)} q={q} mode={mode} customerName={customerName} onDone={() => router.refresh()} />
      <ChangesModal open={changesOpen} onClose={() => setChangesOpen(false)} preliminary={q.isPreliminary} onSubmit={async (comment) => (await post("request-changes", q.isPreliminary ? "Final quotation requested — we'll contact you to schedule a site measurement" : "Change request sent", { comment })) && setChangesOpen(false)} busy={!!busy} />
    </article>
  );
}

function ApproveModal({ open, onClose, q, mode, customerName, onDone }: { open: boolean; onClose: () => void; q: QuotationRow; mode: "customer" | "team"; customerName: string; onDone: () => void }) {
  const { toast } = useToast();
  const [name, setName] = useState(customerName);
  const [accept, setAccept] = useState(false);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  async function submit() {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/quotations/${q.id}/approve`, { body: { approvedByName: mode === "team" ? `${name} (recorded by team)` : name, comment: comment || undefined, accept } });
      toast("Quotation approved — your project is now active");
      onClose();
      onDone();
    } catch (err) {
      setError(err instanceof ApiClientError && err.fields?.accept ? err.fields.accept : errorMessage(err));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`Approve ${q.number}`}
      description={`Total project cost ${formatINR(q.grandTotal)} including GST.`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit} loading={busy} disabled={!accept || name.trim().length < 2}>
            Approve quotation
          </Button>
        </>
      }
    >
      <div className="grid gap-4">
        {mode === "team" ? <Notice kind="info">Use this when the client has approved offline (signed copy, email or WhatsApp). The approval is recorded in the audit log.</Notice> : null}
        <Field label={mode === "team" ? "Client name" : "Your full name"} htmlFor="ap-name">
          <Input id="ap-name" value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Comment (optional)" htmlFor="ap-c">
          <Textarea id="ap-c" value={comment} onChange={(e) => setComment(e.target.value)} rows={2} />
        </Field>
        <Checkbox label="I accept the quotation, payment terms, timeline and terms & conditions." checked={accept} onChange={(e) => setAccept(e.target.checked)} />
        {error ? <Notice kind="error">{error}</Notice> : null}
      </div>
    </Modal>
  );
}

function ChangesModal({ open, onClose, preliminary, onSubmit, busy }: { open: boolean; onClose: () => void; preliminary: boolean; onSubmit: (c: string) => void; busy: boolean }) {
  const [text, setText] = useState(preliminary ? "Please schedule a site measurement and send the final quotation." : "");
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={preliminary ? "Request final quotation" : "Request changes"}
      description={preliminary ? "We'll call to schedule a site measurement, verify quantities and send the final quotation." : "Tell us what you'd like to change — we'll send a revised quotation."}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={() => onSubmit(text)} loading={busy} disabled={text.trim().length < 3}>
            Send request
          </Button>
        </>
      }
    >
      <Field label={preliminary ? "Preferred dates / notes" : "Changes"} htmlFor="ch-t">
        <Textarea id="ch-t" value={text} onChange={(e) => setText(e.target.value)} rows={4} />
      </Field>
    </Modal>
  );
}
