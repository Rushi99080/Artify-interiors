"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Bell, LogOut, User } from "lucide-react";
import { api } from "@/lib/client/api";
import { cn, formatRelative, initials } from "@/lib/format";

type Item = { id: string; title: string; body: string; link: string | null; readAt: string | null; createdAt: string };

function useOutside(ref: React.RefObject<HTMLElement | null>, onOut: () => void) {
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && onOut();
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [ref, onOut]);
}

export function NotificationBell({ tone = "light" }: { tone?: "light" | "dark" }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [unread, setUnread] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useOutside(ref, () => setOpen(false));

  const load = () =>
    api<{ items: Item[]; unread: number }>("/api/notifications")
      .then((r) => {
        setItems(r.items);
        setUnread(r.unread);
      })
      .catch(() => {});

  useEffect(() => {
    void load();
    const t = setInterval(load, 60_000);
    return () => clearInterval(t);
  }, []);

  async function markAll() {
    await api("/api/notifications/read", { body: {} }).catch(() => {});
    setUnread(0);
    setItems((l) => l.map((i) => ({ ...i, readAt: i.readAt ?? new Date().toISOString() })));
  }

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => {
          setOpen((o) => !o);
          if (!open) void load();
        }}
        className={cn("relative rounded-full p-2 transition-colors", tone === "dark" ? "text-sand hover:bg-white/10 hover:text-paper" : "text-ink hover:bg-travertine/60")}
        aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
        aria-expanded={open}
      >
        <Bell className="size-5" />
        {unread ? <span className="absolute right-1 top-1 flex min-w-4 items-center justify-center rounded-full bg-brass px-1 text-[0.6rem] font-bold leading-4 text-white">{unread > 9 ? "9+" : unread}</span> : null}
      </button>
      {open ? (
        <div className="absolute right-0 z-50 mt-2 w-[min(92vw,360px)] overflow-hidden rounded-[var(--radius-md)] border border-line bg-paper text-ink shadow-xl">
          <div className="flex items-center justify-between border-b border-line-soft px-4 py-2.5">
            <p className="text-sm font-semibold text-charcoal">Notifications</p>
            {unread ? (
              <button type="button" onClick={markAll} className="text-xs text-smoke hover:text-charcoal">
                Mark all read
              </button>
            ) : null}
          </div>
          <ul className="max-h-[60vh] divide-y divide-line-soft overflow-y-auto">
            {items.length === 0 ? <li className="px-4 py-8 text-center text-sm text-smoke">You are all caught up.</li> : null}
            {items.map((n) => {
              const body = (
                <>
                  <span className="flex items-start justify-between gap-2">
                    <span className={cn("text-sm", n.readAt ? "text-ink" : "font-semibold text-charcoal")}>{n.title}</span>
                    {!n.readAt ? <span className="mt-1.5 size-2 shrink-0 rounded-full bg-brass" /> : null}
                  </span>
                  <span className="mt-0.5 line-clamp-2 block text-xs text-smoke">{n.body}</span>
                  <span className="mt-1 block text-[0.68rem] text-mist">{formatRelative(n.createdAt)}</span>
                </>
              );
              return (
                <li key={n.id}>
                  {n.link ? (
                    <Link href={n.link} onClick={() => setOpen(false)} className="block px-4 py-3 hover:bg-travertine/40">
                      {body}
                    </Link>
                  ) : (
                    <div className="px-4 py-3">{body}</div>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      ) : null}
    </div>
  );
}

export function UserMenu({ name, email, profileHref, tone = "light" }: { name: string; email: string; profileHref: string; tone?: "light" | "dark" }) {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const ref = useRef<HTMLDivElement>(null);
  useOutside(ref, () => setOpen(false));
  async function logout() {
    await api("/api/auth/logout", { method: "POST" }).catch(() => {});
    router.push("/");
    router.refresh();
  }
  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} className={cn("flex items-center gap-2 rounded-full py-1 pl-1 pr-2 transition-colors", tone === "dark" ? "hover:bg-white/10" : "hover:bg-travertine/60")}>
        <span className="flex size-8 items-center justify-center rounded-full bg-brass text-xs font-semibold text-white">{initials(name)}</span>
        <span className={cn("hidden max-w-[10rem] truncate text-sm md:inline", tone === "dark" ? "text-paper" : "text-charcoal")}>{name}</span>
      </button>
      {open ? (
        <div className="absolute right-0 z-50 mt-2 w-60 overflow-hidden rounded-[var(--radius-md)] border border-line bg-paper text-ink shadow-xl">
          <div className="border-b border-line-soft px-4 py-3">
            <p className="truncate text-sm font-semibold text-charcoal">{name}</p>
            <p className="truncate text-xs text-smoke">{email}</p>
          </div>
          <Link href={profileHref} onClick={() => setOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-travertine/40">
            <User className="size-4 text-smoke" /> Profile & password
          </Link>
          <button type="button" onClick={logout} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm hover:bg-travertine/40">
            <LogOut className="size-4 text-smoke" /> Log out
          </button>
        </div>
      ) : null}
    </div>
  );
}
