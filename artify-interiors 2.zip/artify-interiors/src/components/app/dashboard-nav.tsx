"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/format";

const LINKS = [
  { href: "/dashboard", label: "Overview", exact: true },
  { href: "/dashboard/projects", label: "My projects" },
  { href: "/dashboard/designs", label: "Saved designs" },
  { href: "/dashboard/quotations", label: "Quotations" },
  { href: "/ai-designer", label: "New design" },
  { href: "/visualizer", label: "3D visualizer" },
];

export function DashboardNav() {
  const pathname = usePathname();
  return (
    <nav className="container-page -mb-px flex gap-1 overflow-x-auto" aria-label="Dashboard">
      {LINKS.map((l) => {
        const active = l.exact ? pathname === l.href : pathname.startsWith(l.href);
        return (
          <Link key={l.href} href={l.href} aria-current={active ? "page" : undefined} className={cn("shrink-0 border-b-2 px-3 py-2.5 text-sm transition-colors", active ? "border-charcoal font-semibold text-charcoal" : "border-transparent text-smoke hover:text-charcoal")}>
            {l.label}
          </Link>
        );
      })}
    </nav>
  );
}
