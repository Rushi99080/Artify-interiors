"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Panel, PanelHeader } from "@/components/ui/panel";
import { useToast } from "@/components/ui/toast";

export function ProfileForms({ name, phone, email }: { name: string; phone: string | null; email: string }) {
  const router = useRouter();
  const { toast } = useToast();
  const [p, setP] = useState({ name, phone: phone ?? "" });
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    setBusy("p");
    setErrors({});
    try {
      await api("/api/users/me", { method: "PATCH", body: p });
      toast("Profile updated");
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }
  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    if (pw.newPassword !== pw.confirm) return setErrors({ confirm: "Passwords do not match" });
    setBusy("pw");
    setErrors({});
    try {
      await api("/api/users/me", { method: "PATCH", body: { currentPassword: pw.currentPassword, newPassword: pw.newPassword } });
      toast("Password changed");
      setPw({ currentPassword: "", newPassword: "", confirm: "" });
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Panel>
        <PanelHeader title="Profile" description={email} />
        <form onSubmit={saveProfile} className="grid gap-4">
          <Field label="Full name" error={errors.name} htmlFor="pf-n">
            <Input id="pf-n" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} />
          </Field>
          <Field label="Mobile number" error={errors.phone} htmlFor="pf-p">
            <Input id="pf-p" type="tel" value={p.phone} onChange={(e) => setP({ ...p, phone: e.target.value })} />
          </Field>
          <div>
            <Button type="submit" loading={busy === "p"}>
              Save profile
            </Button>
          </div>
        </form>
      </Panel>
      <Panel>
        <PanelHeader title="Change password" />
        <form onSubmit={savePassword} className="grid gap-4">
          <Field label="Current password" error={errors.currentPassword} htmlFor="pw-c">
            <Input id="pw-c" type="password" autoComplete="current-password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />
          </Field>
          <Field label="New password" error={errors.newPassword} hint="At least 8 characters with letters and numbers" htmlFor="pw-n">
            <Input id="pw-n" type="password" autoComplete="new-password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
          </Field>
          <Field label="Confirm new password" error={errors.confirm} htmlFor="pw-cf">
            <Input id="pw-cf" type="password" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
          </Field>
          <div>
            <Button type="submit" loading={busy === "pw"} disabled={!pw.currentPassword || !pw.newPassword}>
              Change password
            </Button>
          </div>
        </form>
      </Panel>
    </div>
  );
}
