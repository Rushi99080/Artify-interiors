"use client";

import { useMemo, useState } from "react";
import { estimateRooms } from "@/lib/boq/engine";
import { LAYOUT_PRESETS } from "@/lib/boq/presets";
import { PRICE_TIERS, TIER_LABELS, TIER_DESCRIPTIONS, type PriceTierKey } from "@/lib/constants";
import { formatINRCompact, cn } from "@/lib/format";
import type { EstimatorData } from "@/lib/services/estimator";
import { ButtonLink } from "@/components/ui/button";

export function EstimatePreview({ data }: { data: EstimatorData }) {
  const [preset, setPreset] = useState("2BHK");
  const [tier, setTier] = useState<PriceTierKey>("STANDARD");
  const p = LAYOUT_PRESETS.find((x) => x.key === preset)!;
  const est = useMemo(() => estimateRooms(p.rooms, tier, { rateCard: data.rateCard, ctx: { byTier: data.byTier }, charges: data.charges }), [p, tier, data]);
  const total = est.totals.grandTotal;

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-center">
      <div>
        <h2 className="text-4xl md:text-5xl">What would your home cost?</h2>
        <p className="prose-body mt-4 text-smoke">
          Pick a layout and a finish level. The estimate uses the same rate card and BOQ formulas our designers use, including materials, labour, wastage and GST.
        </p>
        <div className="mt-8 flex flex-wrap gap-2" role="radiogroup" aria-label="Layout">
          {LAYOUT_PRESETS.slice(0, 4).map((x) => (
            <button
              key={x.key}
              type="button"
              role="radio"
              aria-checked={preset === x.key}
              onClick={() => setPreset(x.key)}
              className={cn("rounded-full border px-4 py-2 text-sm transition-colors", preset === x.key ? "border-charcoal bg-charcoal text-paper" : "border-line bg-paper text-ink hover:border-sand")}
            >
              {x.label}
            </button>
          ))}
        </div>
        <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4" role="radiogroup" aria-label="Finish level">
          {PRICE_TIERS.map((t) => (
            <button
              key={t}
              type="button"
              role="radio"
              aria-checked={tier === t}
              onClick={() => setTier(t)}
              className={cn("rounded-[var(--radius-sm)] border px-3 py-2.5 text-left transition-colors", tier === t ? "border-brass bg-brass-soft" : "border-line bg-paper hover:border-sand")}
            >
              <span className="block text-sm font-semibold text-charcoal">{TIER_LABELS[t]}</span>
            </button>
          ))}
        </div>
        <p className="mt-3 text-xs text-smoke">{TIER_DESCRIPTIONS[tier]}</p>
      </div>

      <div className="rounded-[var(--radius-md)] bg-charcoal p-7 text-paper md:p-9">
        <p className="text-sm text-sand">
          Estimated project cost · {p.label}, {p.carpetArea} sqft
        </p>
        <p className="mt-2 font-display text-6xl leading-none md:text-7xl">{formatINRCompact(total)}</p>
        <p className="mt-2 text-sm text-sand/80">
          Likely range {formatINRCompact(total * 0.9)} – {formatINRCompact(total * 1.15)}, incl. GST
        </p>
        <div className="mt-7 space-y-2.5">
          {est.totals.sections.slice(0, 6).map((s) => (
            <div key={s.section} className="flex items-center gap-3 text-sm">
              <span className="w-28 shrink-0 text-sand/90">{s.section}</span>
              <span className="h-px flex-1 bg-white/15">
                <span className="block h-px bg-brass" style={{ width: `${Math.min(100, (s.amount / est.totals.subtotal) * 100 * 2.2)}%` }} />
              </span>
              <span className="w-16 shrink-0 text-right tabular-nums">{formatINRCompact(s.amount)}</span>
            </div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap gap-2">
          <ButtonLink href="/cost-calculator" variant="light">
            Customise rooms & sizes
          </ButtonLink>
          <ButtonLink href="/ai-designer" variant="brass">
            Start your design
          </ButtonLink>
        </div>
      </div>
    </div>
  );
}
