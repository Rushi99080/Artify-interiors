"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { Check, Plus, Trash2 } from "lucide-react";
import { BUDGET_RANGES, DESIGN_STYLES, PROPERTY_TYPES, PROPERTY_TYPE_LABELS, ROOM_LABELS, ROOM_MODULES, ROOM_MODULE_BY_TYPE, STYLE_INFO, TIMELINE_OPTIONS, type DesignStyleKey, type PropertyTypeKey, type RoomTypeKey } from "@/lib/constants";
import type { AIStatusView } from "@/lib/views";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { cn } from "@/lib/format";
import { Button, ButtonLink } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/notice";
import { FileUploader, type UploadedFileView } from "@/components/projects/file-uploader";
import { GeneratePanel, type PhotoView } from "@/components/designs/generate-panel";

type RoomRow = { key: number; name: string; type: RoomTypeKey; lengthFt: string; widthFt: string; heightFt: string; preferences: string };
export type WizardPrefill = { rooms?: { name?: string; type: RoomTypeKey; lengthFt?: number; widthFt?: number; heightFt?: number }[]; style?: DesignStyleKey };

const blankRoom = (key: number, type: RoomTypeKey = "LIVING_ROOM", dims?: { lengthFt?: number; widthFt?: number; heightFt?: number }, name?: string): RoomRow => {
  const d = ROOM_MODULE_BY_TYPE[type]?.defaults;
  return { key, name: name ?? "", type, lengthFt: String(dims?.lengthFt ?? d?.lengthFt ?? ""), widthFt: String(dims?.widthFt ?? d?.widthFt ?? ""), heightFt: String(dims?.heightFt ?? d?.heightFt ?? 10), preferences: "" };
};

const STEPS = ["Project details", "Photos & plans", "Design concepts"];
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

export function ProjectWizard({ user, aiStatus, prefill }: { user: { name: string; email: string; phone: string | null }; aiStatus: AIStatusView; prefill?: WizardPrefill }) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [project, setProject] = useState<{ id: string; code: string; rooms: { id: string; name: string; type: string }[] } | null>(null);
  const [files, setFiles] = useState<UploadedFileView[]>([]);
  // deterministic keys (they end up in element ids, which must match between server and client render)
  const [rooms, setRooms] = useState<RoomRow[]>(() => (prefill?.rooms?.length ? prefill.rooms.map((r, i) => blankRoom(i + 1, r.type, r, r.name)) : [blankRoom(1, "LIVING_ROOM")]));
  const nextKey = () => Math.max(0, ...rooms.map((r) => r.key)) + 1;
  const [style, setStyle] = useState<DesignStyleKey>(prefill?.style ?? "MODERN");
  const [budget, setBudget] = useState(2);
  const [propertyType, setPropertyType] = useState<PropertyTypeKey>(prefill?.rooms?.some((r) => r.type === "OFFICE") ? "OFFICE" : "APARTMENT");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const totalArea = useMemo(() => Math.round(rooms.reduce((s, r) => s + (Number(r.lengthFt) || 0) * (Number(r.widthFt) || 0), 0)), [rooms]);

  async function submitDetails(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const b = BUDGET_RANGES[budget]!;
    setSaving(true);
    setErrors({});
    setFormError(null);
    try {
      const res = await api<{ project: { id: string; code: string; rooms: { id: string; name: string; type: string }[] } }>("/api/projects", {
        body: {
          name: fd.get("name"),
          fullName: fd.get("fullName"),
          phone: fd.get("phone"),
          email: fd.get("email"),
          location: fd.get("location"),
          address: fd.get("address"),
          propertyType,
          carpetAreaSqft: fd.get("carpetArea") || (totalArea || null),
          numberOfRooms: rooms.length,
          designStyle: style,
          budgetMin: b.min,
          budgetMax: b.max,
          colorPalette: fd.get("colorPalette"),
          materialPreferences: fd.get("materialPreferences"),
          timeline: fd.get("timeline"),
          rooms: rooms.map((r) => ({ name: r.name || null, type: r.type, lengthFt: r.lengthFt || null, widthFt: r.widthFt || null, heightFt: r.heightFt || null, preferences: r.preferences || null })),
        },
      });
      setProject(res.project);
      setStep(1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      setFormError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  const photos: PhotoView[] = files.filter((f) => f.url).map((f) => ({ id: f.id, url: f.url!, roomId: f.roomId ?? null, category: f.category, originalName: f.originalName, mimeType: f.mimeType }));

  return (
    <div>
      <ol className="mb-10 grid grid-cols-3 gap-2" aria-label="Progress">
        {STEPS.map((s, i) => (
          <li key={s} className="flex flex-col gap-2">
            <span className={cn("h-0.5 w-full", i <= step ? "bg-charcoal" : "bg-line")} />
            <span className={cn("flex items-center gap-1.5 text-sm", i === step ? "font-semibold text-charcoal" : i < step ? "text-ink" : "text-mist")}>
              {i < step ? <Check className="size-3.5 text-moss" /> : <span className="tabular-nums">{i + 1}.</span>}
              {s}
            </span>
          </li>
        ))}
      </ol>

      {step === 0 ? (
        <form onSubmit={submitDetails} className="space-y-10" noValidate>
          {formError ? <Notice kind="error">{formError}</Notice> : null}
          <Section title="About you and the property">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Project name" error={errors.name} required htmlFor="name">
                <Input id="name" name="name" placeholder="e.g. Our new home in Baner" required invalid={!!errors.name} />
              </Field>
              <Field label="Full name" error={errors.fullName} required htmlFor="fullName">
                <Input id="fullName" name="fullName" defaultValue={user.name} autoComplete="name" required />
              </Field>
              <Field label="Mobile number" error={errors.phone} required htmlFor="phone">
                <Input id="phone" name="phone" type="tel" defaultValue={user.phone ?? ""} autoComplete="tel" required invalid={!!errors.phone} />
              </Field>
              <Field label="Email" error={errors.email} required htmlFor="email">
                <Input id="email" name="email" type="email" defaultValue={user.email} autoComplete="email" required invalid={!!errors.email} />
              </Field>
              <Field label="Project location" error={errors.location} required htmlFor="location">
                <Input id="location" name="location" placeholder="Area, city" required invalid={!!errors.location} />
              </Field>
              <Field label="Address (optional)" htmlFor="address">
                <Input id="address" name="address" placeholder="Building, flat number" />
              </Field>
            </div>
            <div className="mt-5">
              <p className="text-[0.8rem] font-medium text-ink">Property type</p>
              <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {PROPERTY_TYPES.map((p) => (
                  <ChoiceButton key={p} active={propertyType === p} onClick={() => setPropertyType(p)}>
                    {PROPERTY_TYPE_LABELS[p]}
                  </ChoiceButton>
                ))}
              </div>
            </div>
            <div className="mt-5 grid gap-4 md:grid-cols-3">
              <Field label="Carpet area (sqft)" hint={totalArea ? `Rooms below add up to ≈${totalArea} sqft` : undefined} error={errors.carpetAreaSqft} htmlFor="carpetArea">
                <Input id="carpetArea" name="carpetArea" type="number" min={50} inputMode="numeric" />
              </Field>
              <Field label="Budget range" htmlFor="budget">
                <Select id="budget" value={budget} onChange={(e) => setBudget(Number(e.target.value))}>
                  {BUDGET_RANGES.map((b, i) => (
                    <option key={b.label} value={i}>
                      {b.label}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Timeline" htmlFor="timeline">
                <Select id="timeline" name="timeline" defaultValue={TIMELINE_OPTIONS[1]}>
                  {TIMELINE_OPTIONS.map((t) => (
                    <option key={t}>{t}</option>
                  ))}
                </Select>
              </Field>
            </div>
          </Section>

          <Section title="Rooms" description="Add each room you want designed. Dimensions in feet — approximate is fine; we measure on site later.">
            {errors.rooms ? <p className="mb-2 text-sm text-brick">{errors.rooms}</p> : null}
            <div className="space-y-3">
              {rooms.map((r, i) => {
                const mod = ROOM_MODULE_BY_TYPE[r.type];
                const set = (patch: Partial<RoomRow>) => setRooms((rs) => rs.map((x) => (x.key === r.key ? { ...x, ...patch } : x)));
                return (
                  <div key={r.key} className="grid gap-3 rounded-[var(--radius-md)] border border-line bg-white/70 p-4 md:grid-cols-[1.2fr_1fr_repeat(3,0.6fr)_auto] md:items-end">
                    <Field label="Room type" htmlFor={`rt-${r.key}`}>
                      <Select
                        id={`rt-${r.key}`}
                        value={r.type}
                        onChange={(e) => {
                          const t = e.target.value as RoomTypeKey;
                          const d = ROOM_MODULE_BY_TYPE[t].defaults;
                          set({ type: t, lengthFt: String(d.lengthFt), widthFt: String(d.widthFt), heightFt: String(d.heightFt) });
                        }}
                      >
                        {ROOM_MODULES.map((m) => (
                          <option key={m.type} value={m.type}>
                            {m.label}
                          </option>
                        ))}
                      </Select>
                    </Field>
                    <Field label="Name (optional)" htmlFor={`rn-${r.key}`}>
                      <Input id={`rn-${r.key}`} value={r.name} placeholder={ROOM_LABELS[r.type]} onChange={(e) => set({ name: e.target.value })} />
                    </Field>
                    <Field label={`${cap(mod.dimensionLabels.length.split(" ").pop()!)} (ft)`} error={errors[`rooms.${i}.lengthFt`]} htmlFor={`rl-${r.key}`}>
                      <Input id={`rl-${r.key}`} type="number" min={1} step={0.5} value={r.lengthFt} onChange={(e) => set({ lengthFt: e.target.value })} />
                    </Field>
                    <Field label={`${cap(mod.dimensionLabels.width.split(" ").pop()!)} (ft)`} error={errors[`rooms.${i}.widthFt`]} htmlFor={`rw-${r.key}`}>
                      <Input id={`rw-${r.key}`} type="number" min={1} step={0.5} value={r.widthFt} onChange={(e) => set({ widthFt: e.target.value })} />
                    </Field>
                    <Field label="Height (ft)" error={errors[`rooms.${i}.heightFt`]} htmlFor={`rh-${r.key}`}>
                      <Input id={`rh-${r.key}`} type="number" min={6} step={0.5} value={r.heightFt} onChange={(e) => set({ heightFt: e.target.value })} />
                    </Field>
                    <button type="button" onClick={() => setRooms((rs) => rs.filter((x) => x.key !== r.key))} disabled={rooms.length <= 1} className="mb-1 self-end rounded p-2 text-smoke hover:bg-brick-soft hover:text-brick disabled:opacity-30" aria-label="Remove room">
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                );
              })}
            </div>
            <Button type="button" variant="secondary" size="sm" className="mt-3" onClick={() => setRooms((rs) => [...rs, blankRoom(nextKey(), "MASTER_BEDROOM")])}>
              <Plus className="size-4" /> Add room
            </Button>
          </Section>

          <Section title="Preferred design style">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
              {DESIGN_STYLES.map((s) => (
                <button key={s} type="button" onClick={() => setStyle(s)} aria-pressed={style === s} className={cn("rounded-[var(--radius-md)] border p-3 text-left transition-colors", style === s ? "border-brass bg-brass-soft/70" : "border-line bg-white/70 hover:border-sand")}>
                  <span className="flex h-6 overflow-hidden rounded-[2px]">
                    {STYLE_INFO[s].palette.map((c) => (
                      <span key={c} className="flex-1" style={{ background: c }} />
                    ))}
                  </span>
                  <span className="mt-2 block font-display text-xl text-charcoal">{STYLE_INFO[s].label}</span>
                  <span className="mt-0.5 line-clamp-2 block text-xs text-smoke">{STYLE_INFO[s].description}</span>
                </button>
              ))}
            </div>
          </Section>

          <Section title="Colours and materials">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Preferred colour palette" hint="e.g. warm neutrals with sage green, or monochrome with brass" htmlFor="colorPalette">
                <Input id="colorPalette" name="colorPalette" />
              </Field>
              <Field label="Material preferences" hint="e.g. matte finishes, walnut wood, quartz counters, no glossy surfaces" htmlFor="materialPreferences">
                <Textarea id="materialPreferences" name="materialPreferences" rows={2} />
              </Field>
            </div>
          </Section>

          <div className="flex justify-end">
            <Button type="submit" size="lg" loading={saving}>
              Save and continue
            </Button>
          </div>
        </form>
      ) : null}

      {step === 1 && project ? (
        <div className="space-y-6">
          <Notice kind="success" title={`Project ${project.code} created`}>
            Now add photos of your rooms. Clear daylight photos taken from a corner work best. Floor plans, drawings, CAD files and reference images help too.
          </Notice>
          <FileUploader
            projectId={project.id}
            rooms={project.rooms}
            defaultRoomId={project.rooms[0]?.id}
            categories={["ROOM_PHOTO", "FLOOR_PLAN", "REFERENCE", "DRAWING_PDF", "CAD", "MEASUREMENT"]}
            onUploaded={(u) => setFiles((f) => [...u, ...f])}
          />
          <div className="flex flex-wrap justify-between gap-3">
            <ButtonLink href={`/dashboard/projects/${project.id}`} variant="ghost">
              Finish later
            </ButtonLink>
            <Button size="lg" onClick={() => setStep(2)}>
              {files.length ? "Continue to design concepts" : "Skip — design from dimensions"}
            </Button>
          </div>
        </div>
      ) : null}

      {step === 2 && project ? (
        <div className="space-y-6">
          <GeneratePanel projectId={project.id} rooms={project.rooms} photos={photos} aiStatus={aiStatus} defaultRoomId={project.rooms[0]?.id} />
          <div className="flex flex-wrap justify-between gap-3 border-t border-line pt-6">
            <Button variant="ghost" onClick={() => setStep(1)}>
              Back to uploads
            </Button>
            <div className="flex flex-wrap gap-2">
              <ButtonLink href={`/dashboard/projects/${project.id}/designs`} variant="secondary">
                Compare & save designs
              </ButtonLink>
              <Button onClick={() => router.push(`/dashboard/projects/${project.id}`)}>Go to my project</Button>
            </div>
          </div>
          <p className="text-xs text-smoke">
            You can generate concepts for your other rooms any time from{" "}
            <Link href={`/dashboard/projects/${project.id}/designs`} className="underline">
              your project
            </Link>
            .
          </p>
        </div>
      ) : null}
    </div>
  );
}

function Section({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="text-3xl">{title}</h2>
      {description ? <p className="mt-1 text-sm text-smoke">{description}</p> : null}
      <div className="mt-5">{children}</div>
    </section>
  );
}

function ChoiceButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} aria-pressed={active} className={cn("rounded-[var(--radius-sm)] border px-3 py-2.5 text-sm transition-colors", active ? "border-charcoal bg-charcoal text-paper" : "border-line bg-white/70 text-ink hover:border-sand")}>
      {children}
    </button>
  );
}
