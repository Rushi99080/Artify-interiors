"use client";

import { useEffect, useRef, useState } from "react";
import { Bookmark, Check, Heart, ImageOff, MessageSquare, RefreshCw, Sparkles } from "lucide-react";
import type { DesignView } from "@/lib/views";
import { DESIGN_STATUS_LABELS, MATERIAL_CATEGORY_LABELS, STYLE_INFO, TIER_LABELS, type DesignStyleKey, type MaterialCategoryKey, type PriceTierKey } from "@/lib/constants";
import { cn, formatINR, formatINRCompact } from "@/lib/format";
import { api, errorMessage } from "@/lib/client/api";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button, Spinner } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Field, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/notice";
import { useToast } from "@/components/ui/toast";

type Props = {
  design: DesignView;
  mode: "customer" | "team";
  onChange?: (d: DesignView) => void;
  compareSelected?: boolean;
  onCompareToggle?: (id: string) => void;
  autoRender?: boolean;
};

const renderStarted = new Set<string>();

export function DesignCard({ design, mode, onChange, compareSelected, onCompareToggle, autoRender = true }: Props) {
  const { toast } = useToast();
  const [d, setD] = useState(design);
  const [busy, setBusy] = useState<string | null>(null);
  const [regenOpen, setRegenOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState<null | "approve" | "request_changes">(null);
  const [detail, setDetail] = useState(false);
  const mounted = useRef(true);

  useEffect(() => setD(design), [design]);
  useEffect(
    () => () => {
      mounted.current = false;
    },
    [],
  );

  const update = (next: DesignView) => {
    setD(next);
    onChange?.(next);
  };

  async function render() {
    renderStarted.add(d.id);
    setD((x) => ({ ...x, imageStatus: "PROCESSING", imageError: null }));
    try {
      const res = await api<{ design: Parameters<typeof normalise>[0] }>(`/api/designs/${d.id}/render`, { method: "POST" });
      if (mounted.current) update(normalise(res.design, d));
    } catch (err) {
      if (mounted.current) setD((x) => ({ ...x, imageStatus: (err as { code?: string }).code === "NOT_CONFIGURED" ? "NOT_CONFIGURED" : "FAILED", imageError: errorMessage(err) }));
    }
  }

  useEffect(() => {
    if (autoRender && d.imageStatus === "PENDING" && !renderStarted.has(d.id)) void render();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [d.id, d.imageStatus, autoRender]);

  async function act(action: string, extra: Record<string, unknown> = {}) {
    setBusy(action);
    try {
      const res = await api<{ design: Parameters<typeof normalise>[0] }>(`/api/designs/${d.id}`, { method: "PATCH", body: { action, ...extra } });
      update(normalise(res.design, d));
      const msg: Record<string, string> = { save: "Design saved", unsave: "Removed from saved designs", favorite: "Added to favourites", unfavorite: "Removed from favourites", approve: "Design approved", request_changes: "Change request sent to the design team", reject: "Design rejected", reset: "Status reset" };
      toast(msg[action] ?? "Updated");
      return true;
    } catch (err) {
      toast(errorMessage(err), "error");
      return false;
    } finally {
      setBusy(null);
    }
  }

  async function regenerate(changeRequest: string) {
    setBusy("regenerate");
    try {
      const res = await api<{ design: Parameters<typeof normalise>[0] }>(`/api/designs/${d.id}/regenerate`, { body: { changeRequest } });
      const next = normalise(res.design, d);
      renderStarted.delete(d.id);
      update(next);
      setRegenOpen(false);
      toast("New version generated");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  const style = STYLE_INFO[d.style as DesignStyleKey]?.label ?? d.style;
  return (
    <article className={cn("flex flex-col overflow-hidden rounded-[var(--radius-md)] border bg-paper", compareSelected ? "border-brass ring-2 ring-brass/30" : "border-line")}>
      <DesignImage d={d} onRetry={render} canRetry={true} />
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="text-2xl leading-tight">{d.name}</h3>
            <p className="mt-1 text-xs text-smoke">
              {[d.roomName, style, TIER_LABELS[d.tier as PriceTierKey]].filter(Boolean).join(" · ")}
              {d.revisionNo > 1 ? ` · Version ${d.revisionNo}` : ""}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <IconToggle label={d.isFavorite ? "Remove favourite" : "Favourite"} active={d.isFavorite} onClick={() => act(d.isFavorite ? "unfavorite" : "favorite")} busy={busy === "favorite" || busy === "unfavorite"}>
              <Heart className={cn("size-4", d.isFavorite && "fill-brick text-brick")} />
            </IconToggle>
            <IconToggle label={d.isSaved ? "Unsave" : "Save design"} active={d.isSaved} onClick={() => act(d.isSaved ? "unsave" : "save")} busy={busy === "save" || busy === "unsave"}>
              <Bookmark className={cn("size-4", d.isSaved && "fill-charcoal")} />
            </IconToggle>
          </div>
        </div>

        {d.status !== "GENERATED" && d.status !== "SAVED" ? (
          <div className="mt-2">
            <StatusBadge status={d.status} label={DESIGN_STATUS_LABELS[d.status as keyof typeof DESIGN_STATUS_LABELS]} />
          </div>
        ) : null}

        {d.summary ? <p className="mt-3 text-sm leading-relaxed text-ink">{d.summary}</p> : null}

        {d.colorPalette.length ? (
          <div className="mt-4 flex h-8 overflow-hidden rounded-[3px] border border-line-soft" aria-label="Colour palette">
            {d.colorPalette.map((c, i) => (
              <span key={i} className="flex-1" style={{ background: c.hex }} title={`${c.name} ${c.hex}`} />
            ))}
          </div>
        ) : null}

        <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <div>
            <dt className="text-xs text-smoke">Estimated budget</dt>
            <dd className="tabular-nums text-charcoal">{d.estimatedBudgetMin ? `${formatINRCompact(d.estimatedBudgetMin)} – ${formatINRCompact(d.estimatedBudgetMax)}` : "—"}</dd>
          </div>
          <div>
            <dt className="text-xs text-smoke">Flooring</dt>
            <dd className="line-clamp-2 text-charcoal">{d.flooring || "—"}</dd>
          </div>
        </dl>

        <button type="button" onClick={() => setDetail((v) => !v)} className="mt-4 self-start text-sm text-charcoal underline decoration-sand underline-offset-4 hover:decoration-charcoal" aria-expanded={detail}>
          {detail ? "Hide details" : "Materials, furniture & layout"}
        </button>
        {detail ? <DesignDetails d={d} /> : null}

        {d.customerComment ? (
          <p className="mt-4 rounded-[var(--radius-sm)] bg-plaster px-3 py-2 text-xs text-ink">
            <MessageSquare className="mr-1 inline size-3.5 text-smoke" /> {d.customerComment}
          </p>
        ) : null}
        {mode === "team" && d.adminNotes ? <p className="mt-2 rounded-[var(--radius-sm)] bg-brass-soft px-3 py-2 text-xs text-ink">Team note: {d.adminNotes}</p> : null}

        <div className="mt-auto flex flex-wrap items-center gap-2 pt-5">
          {onCompareToggle ? (
            <label className="mr-auto inline-flex cursor-pointer items-center gap-2 text-sm text-ink">
              <input type="checkbox" checked={!!compareSelected} onChange={() => onCompareToggle(d.id)} className="size-4 accent-[var(--color-brass)]" />
              Compare
            </label>
          ) : null}
          <Button variant="secondary" size="sm" onClick={() => setRegenOpen(true)} loading={busy === "regenerate"}>
            <RefreshCw className="size-3.5" /> Regenerate
          </Button>
          {d.status !== "APPROVED" ? (
            <>
              {mode === "customer" ? (
                <Button variant="ghost" size="sm" onClick={() => setFeedbackOpen("request_changes")}>
                  Request changes
                </Button>
              ) : (
                <Button variant="ghost" size="sm" onClick={() => act("reject")} loading={busy === "reject"}>
                  Reject
                </Button>
              )}
              <Button size="sm" onClick={() => (mode === "customer" ? setFeedbackOpen("approve") : act("approve"))} loading={busy === "approve"}>
                <Check className="size-3.5" /> Approve
              </Button>
            </>
          ) : mode === "team" ? (
            <Button variant="ghost" size="sm" onClick={() => act("reset")} loading={busy === "reset"}>
              Undo approval
            </Button>
          ) : null}
        </div>
      </div>

      <RegenerateModal open={regenOpen} onClose={() => setRegenOpen(false)} onSubmit={regenerate} busy={busy === "regenerate"} name={d.name} />
      <FeedbackModal
        mode={feedbackOpen}
        onClose={() => setFeedbackOpen(null)}
        onSubmit={async (comment) => {
          const ok = await act(feedbackOpen!, { comment });
          if (ok) setFeedbackOpen(null);
        }}
        busy={!!busy}
      />
    </article>
  );
}

function normalise(raw: Record<string, unknown> & { id: string }, prev: DesignView): DesignView {
  const r = raw as Record<string, unknown>;
  const arr = <T,>(v: unknown, fb: T[]): T[] => (Array.isArray(v) ? (v as T[]) : fb);
  return {
    ...prev,
    name: (r.name as string) ?? prev.name,
    style: (r.style as string) ?? prev.style,
    tier: (r.tier as string) ?? prev.tier,
    summary: (r.summary as string | null) ?? null,
    colorPalette: arr(r.colorPalette, prev.colorPalette),
    materials: arr(r.materialSuggestions, prev.materials),
    furniture: arr(r.furnitureSuggestions, prev.furniture),
    furnitureLayout: (r.furnitureLayout as string | null) ?? null,
    wallFinish: (r.wallFinish as string | null) ?? null,
    ceilingDesign: (r.ceilingDesign as string | null) ?? null,
    lighting: (r.lighting as string | null) ?? null,
    flooring: (r.flooring as string | null) ?? null,
    decor: arr<string>(r.decor, prev.decor),
    estimatedBudgetMin: (r.estimatedBudgetMin as number | null) ?? null,
    estimatedBudgetMax: (r.estimatedBudgetMax as number | null) ?? null,
    imageStatus: (r.imageStatus as string) ?? prev.imageStatus,
    imageUrl: (r.imageUrl as string | null) ?? null,
    imageError: (r.imageError as string | null) ?? null,
    imageProvider: (r.imageProvider as string | null) ?? null,
    isSaved: Boolean(r.isSaved),
    isFavorite: Boolean(r.isFavorite),
    status: (r.status as string) ?? prev.status,
    customerComment: (r.customerComment as string | null) ?? null,
    adminNotes: (r.adminNotes as string | null) ?? prev.adminNotes,
    revisionNo: (r.revisionNo as number) ?? prev.revisionNo,
  };
}

function DesignImage({ d, onRetry, canRetry }: { d: DesignView; onRetry: () => void; canRetry: boolean }) {
  if (d.imageUrl && d.imageStatus === "COMPLETED") {
    return (
      <a href={d.imageUrl} target="_blank" rel="noopener noreferrer" className="block aspect-[3/2] overflow-hidden bg-travertine">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={d.imageUrl} alt={`AI visualization: ${d.name}`} className="h-full w-full object-cover" loading="lazy" />
      </a>
    );
  }
  if (d.imageStatus === "PENDING" || d.imageStatus === "PROCESSING") {
    return (
      <div className="skeleton relative flex aspect-[3/2] flex-col items-center justify-center gap-2 text-sm text-smoke">
        <Spinner className="size-5 text-brass" />
        Rendering visualization…
        <span className="text-xs text-mist">This usually takes 20–60 seconds</span>
      </div>
    );
  }
  return (
    <div className="flex aspect-[3/2] flex-col items-center justify-center gap-2 bg-[linear-gradient(135deg,var(--color-travertine),var(--color-plaster))] px-6 text-center">
      {d.imageStatus === "NOT_CONFIGURED" ? <Sparkles className="size-6 text-brass" /> : <ImageOff className="size-6 text-smoke" />}
      <p className="text-sm text-ink">{d.imageStatus === "NOT_CONFIGURED" ? "Visualization not configured" : d.imageStatus === "FAILED" ? "Visualization failed" : "No visualization yet"}</p>
      {d.imageError ? <p className="line-clamp-3 max-w-xs text-xs text-smoke">{d.imageError}</p> : null}
      {canRetry && d.imageStatus !== "NOT_CONFIGURED" ? (
        <Button variant="secondary" size="sm" onClick={onRetry}>
          {d.imageStatus === "FAILED" ? "Try again" : "Render visualization"}
        </Button>
      ) : null}
    </div>
  );
}

function DesignDetails({ d }: { d: DesignView }) {
  return (
    <div className="mt-4 space-y-5 border-t border-line-soft pt-4 text-sm">
      {d.materials.length ? (
        <section>
          <h4 className="font-sans text-xs font-semibold text-smoke">Materials</h4>
          <ul className="mt-2 space-y-1.5">
            {d.materials.map((m, i) => (
              <li key={i} className="flex justify-between gap-3">
                <span>
                  <span className="text-charcoal">{[m.brand, m.name].filter(Boolean).join(" ")}</span>
                  {m.application ? <span className="text-smoke"> — {m.application}</span> : null}
                  {m.materialId ? <Badge tone="moss" className="ml-1.5">In library</Badge> : null}
                </span>
                <span className="shrink-0 text-xs text-smoke">{m.rate ? `${formatINR(m.rate)}/${m.unit}` : MATERIAL_CATEGORY_LABELS[m.category as MaterialCategoryKey] ?? ""}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      {d.furniture.length ? (
        <section>
          <h4 className="font-sans text-xs font-semibold text-smoke">Furniture</h4>
          <ul className="mt-2 space-y-1.5">
            {d.furniture.map((f, i) => (
              <li key={i}>
                <span className="text-charcoal">{f.item}</span>
                {f.description ? <span className="text-ink"> — {f.description}</span> : null}
                {f.placement ? <span className="block text-xs text-smoke">{f.placement}</span> : null}
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      <dl className="grid gap-3">
        {(
          [
            ["Layout", d.furnitureLayout],
            ["Walls", d.wallFinish],
            ["Ceiling", d.ceilingDesign],
            ["Lighting", d.lighting],
            ["Flooring", d.flooring],
          ] as const
        )
          .filter(([, v]) => v)
          .map(([k, v]) => (
            <div key={k}>
              <dt className="text-xs font-semibold text-smoke">{k}</dt>
              <dd className="mt-0.5 leading-relaxed text-ink">{v}</dd>
            </div>
          ))}
      </dl>
      {d.decor.length ? (
        <section>
          <h4 className="font-sans text-xs font-semibold text-smoke">Decor</h4>
          <p className="mt-1 text-ink">{d.decor.join(", ")}</p>
        </section>
      ) : null}
      {d.imageProvider ? <p className="text-xs text-mist">Visualization: {d.imageProvider}. AI visuals are concept impressions, not construction drawings.</p> : null}
    </div>
  );
}

function IconToggle({ label, active, onClick, busy, children }: { label: string; active: boolean; onClick: () => void; busy?: boolean; children: React.ReactNode }) {
  return (
    <button type="button" aria-label={label} aria-pressed={active} title={label} onClick={onClick} disabled={busy} className="rounded-full p-2 text-smoke transition-colors hover:bg-travertine/60 hover:text-charcoal disabled:opacity-50">
      {busy ? <Spinner className="size-4" /> : children}
    </button>
  );
}

function RegenerateModal({ open, onClose, onSubmit, busy, name }: { open: boolean; onClose: () => void; onSubmit: (s: string) => void; busy: boolean; name: string }) {
  const [text, setText] = useState("");
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Regenerate design"
      description={`A new version of “${name}” will be created. The current version is kept in its history.`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={() => onSubmit(text)} loading={busy}>
            <RefreshCw className="size-4" /> Regenerate
          </Button>
        </>
      }
    >
      <Field label="What should change?" hint="Optional — leave empty for a fresh variation." htmlFor="regen">
        <Textarea id="regen" value={text} onChange={(e) => setText(e.target.value)} rows={4} placeholder="e.g. warmer wood tones, more storage near the window, replace the marble with quartz" />
      </Field>
      {busy ? (
        <Notice kind="info" className="mt-4">
          Writing the new concept… this can take up to a minute.
        </Notice>
      ) : null}
    </Modal>
  );
}

function FeedbackModal({ mode, onClose, onSubmit, busy }: { mode: null | "approve" | "request_changes"; onClose: () => void; onSubmit: (c: string) => void; busy: boolean }) {
  const [text, setText] = useState("");
  const approving = mode === "approve";
  return (
    <Modal
      open={!!mode}
      onClose={onClose}
      title={approving ? "Approve this design" : "Request changes"}
      description={approving ? "Our designer will use this concept for detailed drawings and your final BOQ." : "Tell the design team what you would like to change."}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={() => onSubmit(text)} loading={busy} disabled={!approving && text.trim().length < 3}>
            {approving ? "Approve design" : "Send request"}
          </Button>
        </>
      }
    >
      <Field label={approving ? "Comment (optional)" : "Your changes"} htmlFor="fb">
        <Textarea id="fb" value={text} onChange={(e) => setText(e.target.value)} rows={4} />
      </Field>
    </Modal>
  );
}
