"use client";

import { useMemo, useState } from "react";
import { ChevronDown, Columns3, Sparkles } from "lucide-react";
import type { AIStatusView, DesignView } from "@/lib/views";
import { STYLE_INFO, TIER_LABELS, type DesignStyleKey, type PriceTierKey } from "@/lib/constants";
import { cn, formatINRCompact } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { EmptyState } from "@/components/ui/panel";
import { DesignCard } from "@/components/designs/design-card";
import { GeneratePanel, type PhotoView } from "@/components/designs/generate-panel";

const FILTERS = [
  { key: "all", label: "All" },
  { key: "saved", label: "Saved" },
  { key: "favorite", label: "Favourites" },
  { key: "approved", label: "Approved" },
] as const;

export function DesignsBoard({
  projectId,
  designs: initial,
  rooms,
  photos,
  aiStatus,
  mode,
  allowGenerate = true,
}: {
  projectId: string;
  designs: DesignView[];
  rooms: { id: string; name: string }[];
  photos: PhotoView[];
  aiStatus: AIStatusView;
  mode: "customer" | "team";
  allowGenerate?: boolean;
}) {
  const [designs, setDesigns] = useState(initial);
  const [room, setRoom] = useState<string>("all");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["key"]>("all");
  const [compare, setCompare] = useState<string[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);
  const [genOpen, setGenOpen] = useState(initial.length === 0);

  const shown = useMemo(
    () =>
      designs.filter(
        (d) =>
          (room === "all" || d.roomId === room) &&
          (filter === "all" || (filter === "saved" && d.isSaved) || (filter === "favorite" && d.isFavorite) || (filter === "approved" && d.status === "APPROVED")),
      ),
    [designs, room, filter],
  );
  const toggleCompare = (id: string) => setCompare((c) => (c.includes(id) ? c.filter((x) => x !== id) : c.length >= 3 ? [...c.slice(1), id] : [...c, id]));
  const replace = (d: DesignView) => setDesigns((list) => list.map((x) => (x.id === d.id ? d : x)));

  return (
    <div>
      {allowGenerate ? (
        <section className="mb-8 rounded-[var(--radius-md)] border border-line bg-paper">
          <button type="button" onClick={() => setGenOpen((o) => !o)} className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left" aria-expanded={genOpen}>
            <span className="flex items-center gap-2">
              <Sparkles className="size-5 text-brass" />
              <span className="font-semibold text-charcoal">Generate new design concepts</span>
            </span>
            <ChevronDown className={cn("size-5 text-smoke transition-transform", genOpen && "rotate-180")} />
          </button>
          {genOpen ? (
            <div className="border-t border-line-soft px-5 py-5">
              <GeneratePanel projectId={projectId} rooms={rooms} photos={photos} aiStatus={aiStatus} mode={mode} onGenerated={(n) => setDesigns((d) => [...n, ...d])} />
            </div>
          ) : null}
        </section>
      ) : null}

      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button key={f.key} type="button" onClick={() => setFilter(f.key)} aria-pressed={filter === f.key} className={cn("rounded-full border px-3 py-1.5 text-sm", filter === f.key ? "border-charcoal bg-charcoal text-paper" : "border-line bg-paper text-ink hover:border-sand")}>
              {f.label}
            </button>
          ))}
          {rooms.length > 1 ? (
            <select value={room} onChange={(e) => setRoom(e.target.value)} className="field-input w-auto py-1.5 text-sm" aria-label="Filter by room">
              <option value="all">All rooms</option>
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
          ) : null}
        </div>
        <Button variant="secondary" size="sm" disabled={compare.length < 2} onClick={() => setCompareOpen(true)}>
          <Columns3 className="size-4" /> Compare {compare.length ? `(${compare.length})` : ""}
        </Button>
      </div>

      {shown.length ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {shown.map((d) => (
            <DesignCard key={d.id} design={d} mode={mode} onChange={replace} compareSelected={compare.includes(d.id)} onCompareToggle={toggleCompare} />
          ))}
        </div>
      ) : (
        <EmptyState title={designs.length ? "No designs match this filter" : "No design concepts yet"} description={designs.length ? "Try another filter." : "Generate concepts for a room to see them here."} />
      )}

      <Modal open={compareOpen} onClose={() => setCompareOpen(false)} title="Compare designs" size="xl">
        <CompareTable designs={designs.filter((d) => compare.includes(d.id))} />
      </Modal>
    </div>
  );
}

function CompareTable({ designs }: { designs: DesignView[] }) {
  const rows: [string, (d: DesignView) => React.ReactNode][] = [
    ["Visualization", (d) => (d.imageUrl ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={d.imageUrl} alt={d.name} className="aspect-[3/2] w-full rounded-[3px] object-cover" /> : <span className="text-smoke">—</span>)],
    ["Style", (d) => STYLE_INFO[d.style as DesignStyleKey]?.label ?? d.style],
    ["Finish level", (d) => TIER_LABELS[d.tier as PriceTierKey] ?? d.tier],
    ["Estimated budget", (d) => (d.estimatedBudgetMin ? `${formatINRCompact(d.estimatedBudgetMin)} – ${formatINRCompact(d.estimatedBudgetMax)}` : "—")],
    [
      "Palette",
      (d) => (
        <span className="flex h-6 overflow-hidden rounded-[2px]">
          {d.colorPalette.map((c, i) => (
            <span key={i} className="flex-1" style={{ background: c.hex }} title={c.name} />
          ))}
        </span>
      ),
    ],
    ["Walls", (d) => d.wallFinish ?? "—"],
    ["Ceiling", (d) => d.ceilingDesign ?? "—"],
    ["Flooring", (d) => d.flooring ?? "—"],
    ["Lighting", (d) => d.lighting ?? "—"],
    ["Key materials", (d) => d.materials.slice(0, 5).map((m) => m.name).join(", ") || "—"],
    ["Furniture", (d) => d.furniture.slice(0, 6).map((f) => f.item).join(", ") || "—"],
    ["Layout", (d) => d.furnitureLayout ?? "—"],
  ];
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] border-separate border-spacing-0 text-sm">
        <thead>
          <tr>
            <th className="w-36" />
            {designs.map((d) => (
              <th key={d.id} className="px-3 pb-3 text-left align-bottom">
                <span className="font-display text-xl font-medium text-charcoal">{d.name}</span>
                <span className="block text-xs font-normal text-smoke">{d.roomName}</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map(([label, fn]) => (
            <tr key={label}>
              <th className="border-t border-line-soft py-3 pr-3 text-left align-top text-xs font-semibold text-smoke">{label}</th>
              {designs.map((d) => (
                <td key={d.id} className="border-t border-line-soft px-3 py-3 align-top text-ink">
                  {fn(d)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
