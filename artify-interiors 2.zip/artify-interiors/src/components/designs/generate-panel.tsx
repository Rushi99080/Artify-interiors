"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, Sparkles } from "lucide-react";
import type { AIStatusView, DesignView } from "@/lib/views";
import { toDesignView } from "@/lib/views";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { cn } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Field, Select, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/notice";
import { DesignCard } from "@/components/designs/design-card";

export type PhotoView = { id: string; url: string; roomId: string | null; category: string; originalName: string; mimeType: string };

type Analysis = { detectedRoomType?: string; observations?: string; existingFeatures?: string[]; lightingConditions?: string; constraints?: string[] } | null;

const STEPS = ["Studying your photos and room", "Matching materials from our library", "Writing design concepts", "Estimating budgets"];

export function GeneratePanel({
  projectId,
  rooms,
  photos,
  aiStatus,
  defaultRoomId,
  mode = "customer",
  onGenerated,
}: {
  projectId: string;
  rooms: { id: string; name: string }[];
  photos: PhotoView[];
  aiStatus: AIStatusView;
  defaultRoomId?: string | null;
  mode?: "customer" | "team";
  onGenerated?: (designs: DesignView[]) => void;
}) {
  const [roomId, setRoomId] = useState(defaultRoomId ?? rooms[0]?.id ?? "");
  const roomPhotos = useMemo(() => photos.filter((p) => p.mimeType.startsWith("image/") && (p.roomId === roomId || !p.roomId)), [photos, roomId]);
  const [selected, setSelected] = useState<string[]>([]);
  const [instructions, setInstructions] = useState("");
  const [variations, setVariations] = useState(aiStatus.variations);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(0);
  const [error, setError] = useState<{ message: string; config?: boolean } | null>(null);
  const [designs, setDesigns] = useState<DesignView[]>([]);
  const [analysis, setAnalysis] = useState<Analysis>(null);

  useEffect(() => {
    setSelected(roomPhotos.filter((p) => p.category === "ROOM_PHOTO").slice(0, 2).map((p) => p.id));
  }, [roomPhotos]);

  useEffect(() => {
    if (!loading) return;
    setStep(0);
    const t = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 9000);
    return () => clearInterval(t);
  }, [loading]);

  async function generate() {
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ designs: Parameters<typeof toDesignView>[0][]; analysis: Analysis }>("/api/ai/generate", {
        body: { projectId, roomId: roomId || null, fileIds: selected, instructions: instructions || null, variations },
      });
      const roomName = rooms.find((r) => r.id === roomId)?.name ?? null;
      const views = res.designs.map((d) => ({ ...toDesignView({ ...d, room: roomName ? { name: roomName } : null }) }));
      setDesigns(views);
      setAnalysis(res.analysis);
      onGenerated?.(views);
    } catch (err) {
      setError({ message: errorMessage(err), config: err instanceof ApiClientError && err.code === "NOT_CONFIGURED" });
    } finally {
      setLoading(false);
    }
  }

  const toggle = (id: string) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : s.length >= 3 ? s : [...s, id]));

  return (
    <div>
      {!aiStatus.text.configured ? (
        <Notice kind="config" title="AI design generation is not configured yet" className="mb-6">
          {aiStatus.text.detail}. Add an AI provider key in your environment variables (README → “AI providers”). Everything else — uploads, estimates, quotations — keeps working.
        </Notice>
      ) : !aiStatus.image.configured ? (
        <Notice kind="config" title="Visualizations are not configured" className="mb-6">
          Concepts will be generated without images. {aiStatus.image.detail}.
        </Notice>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[1fr_1.3fr]">
        <div className="grid content-start gap-4">
          <Field label="Room" htmlFor="gen-room">
            <Select id="gen-room" value={roomId} onChange={(e) => setRoomId(e.target.value)}>
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Concept variations" htmlFor="gen-var">
            <Select id="gen-var" value={variations} onChange={(e) => setVariations(Number(e.target.value))}>
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={n}>
                  {n} {n === 1 ? "concept" : "concepts"}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Anything specific?" hint="Optional — e.g. a pooja unit, a study corner, keep the existing flooring" htmlFor="gen-ins">
            <Textarea id="gen-ins" value={instructions} onChange={(e) => setInstructions(e.target.value)} rows={3} maxLength={1000} />
          </Field>
        </div>
        <div>
          <p className="text-[0.8rem] font-medium text-ink">Photos to use (up to 3)</p>
          {roomPhotos.length ? (
            <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-4">
              {roomPhotos.map((p) => {
                const on = selected.includes(p.id);
                return (
                  <button key={p.id} type="button" onClick={() => toggle(p.id)} aria-pressed={on} className={cn("relative aspect-square overflow-hidden rounded-[var(--radius-sm)] border-2 transition-colors", on ? "border-brass" : "border-transparent opacity-80 hover:opacity-100")}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={p.url} alt={p.originalName} className="h-full w-full object-cover" />
                    {on ? (
                      <span className="absolute right-1 top-1 rounded-full bg-brass p-0.5 text-white">
                        <Check className="size-3" />
                      </span>
                    ) : null}
                    <span className="absolute inset-x-0 bottom-0 truncate bg-charcoal/60 px-1.5 py-0.5 text-[0.65rem] text-paper">{p.category === "ROOM_PHOTO" ? "Room" : p.category === "FLOOR_PLAN" ? "Plan" : "Reference"}</span>
                  </button>
                );
              })}
            </div>
          ) : (
            <p className="mt-2 rounded-[var(--radius-sm)] border border-dashed border-line px-4 py-6 text-center text-sm text-smoke">No photos for this room yet. Concepts will be designed from your dimensions and preferences — upload a photo for results that match your actual space.</p>
          )}
        </div>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-4">
        <Button size="lg" onClick={generate} loading={loading} disabled={!aiStatus.text.configured || !roomId}>
          <Sparkles className="size-4" /> {designs.length ? "Generate more concepts" : "Generate design concepts"}
        </Button>
        {loading ? (
          <p className="text-sm text-smoke" aria-live="polite">
            {STEPS[step]}… this usually takes under a minute.
          </p>
        ) : null}
      </div>
      {error ? (
        <Notice kind={error.config ? "config" : "error"} className="mt-4" title={error.config ? "AI is not configured" : "Generation failed"}>
          {error.message}
        </Notice>
      ) : null}

      {analysis?.observations ? (
        <div className="mt-8 rounded-[var(--radius-md)] border border-line bg-white/60 p-5">
          <p className="text-sm font-semibold text-charcoal">What the AI noticed</p>
          <p className="mt-1 text-sm leading-relaxed text-ink">{analysis.observations}</p>
          {analysis.constraints?.length ? <p className="mt-2 text-xs text-smoke">Constraints: {analysis.constraints.join("; ")}</p> : null}
        </div>
      ) : null}

      {designs.length ? (
        <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {designs.map((d) => (
            <DesignCard key={d.id} design={d} mode={mode} />
          ))}
        </div>
      ) : null}
    </div>
  );
}
