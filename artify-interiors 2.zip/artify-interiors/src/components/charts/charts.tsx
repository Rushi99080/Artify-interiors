"use client";

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { formatINR, formatINRCompact } from "@/lib/format";

// Chart palette — validated (light surface #fbfaf7): ochre then blue, fixed order.
export const CHART = { series1: "#b8862e", series2: "#2b77a8", grid: "#ebe5dc", axis: "#9b938a" };

type Props = {
  data: Record<string, string | number>[];
  xKey: string;
  series: { key: string; label: string; color?: string }[];
  money?: boolean;
  height?: number;
};

function TooltipBox({ active, payload, label, money }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string; money?: boolean }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-[var(--radius-sm)] border border-line bg-paper px-3 py-2 text-xs shadow-lg">
      <p className="mb-1 font-semibold text-charcoal">{label}</p>
      {payload.map((p) => (
        <p key={p.name} className="flex items-center gap-2 text-ink">
          <span className="size-2 rounded-full" style={{ background: p.color }} />
          {p.name}: <span className="tabular-nums text-charcoal">{money ? formatINR(p.value) : p.value}</span>
        </p>
      ))}
    </div>
  );
}

/** Vertical bar chart (1–2 series, one y-axis, recessive grid, hover tooltip). */
export function BarsChart({ data, xKey, series, money, height = 260, emptyText = "Nothing recorded in this period yet." }: Props & { emptyText?: string }) {
  const hasData = data.some((d) => series.some((s) => Number(d[s.key]) > 0));
  if (!hasData)
    return (
      <div style={{ height }} className="grid w-full place-items-center rounded-[var(--radius-sm)] border border-dashed border-line text-sm text-smoke">
        {emptyText}
      </div>
    );
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 4, left: 0, bottom: 0 }} barGap={2} barCategoryGap="24%">
          <CartesianGrid vertical={false} stroke={CHART.grid} />
          <XAxis dataKey={xKey} tickLine={false} axisLine={{ stroke: CHART.grid }} tick={{ fill: CHART.axis, fontSize: 11 }} interval="preserveStartEnd" />
          <YAxis tickLine={false} axisLine={false} tick={{ fill: CHART.axis, fontSize: 11 }} width={56} tickFormatter={(v: number) => (money ? formatINRCompact(v) : String(v))} allowDecimals={false} />
          <Tooltip cursor={{ fill: "rgba(167,137,79,0.08)" }} content={<TooltipBox money={money} />} />
          {series.length > 1 ? <Legend verticalAlign="top" align="right" height={28} itemSorter={null} iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, color: "#2f2c28" }} /> : null}
          {series.map((s, i) => (
            <Bar key={s.key} dataKey={s.key} name={s.label} fill={s.color ?? (i === 0 ? CHART.series1 : CHART.series2)} radius={[4, 4, 0, 0]} maxBarSize={28} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/** Horizontal magnitude bars in plain HTML (single series, labels in text ink). */
export function HBars({ rows, money }: { rows: { label: string; value: number }[]; money?: boolean }) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  const format = money ? formatINRCompact : undefined;
  if (!rows.length) return <p className="text-sm text-smoke">No data yet.</p>;
  return (
    <ul className="space-y-2.5">
      {rows.map((r) => (
        <li key={r.label} className="grid grid-cols-[7.5rem_1fr_auto] items-center gap-3 text-sm" title={`${r.label}: ${format ? format(r.value) : r.value}`}>
          <span className="truncate text-ink">{r.label}</span>
          <span className="h-2 overflow-hidden rounded-full bg-line-soft">
            <span className="block h-full rounded-full" style={{ width: `${(r.value / max) * 100}%`, background: CHART.series1 }} />
          </span>
          <span className="tabular-nums text-charcoal">{format ? format(r.value) : r.value}</span>
        </li>
      ))}
    </ul>
  );
}
