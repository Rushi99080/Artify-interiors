"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { BellRing, CreditCard, FileDown, Pencil, Plus, Trash2 } from "lucide-react";
import { PAYMENT_METHOD_LABELS } from "@/lib/constants";
import { formatDate, formatINR } from "@/lib/format";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, Panel, PanelHeader, StatCard } from "@/components/ui/panel";
import { Notice } from "@/components/ui/notice";
import { useToast } from "@/components/ui/toast";

export type PaymentsData = {
  summary: { contract: number; received: number; pending: number; percent: number; status: string };
  milestones: { id: string; name: string; percent: number; amount: number; received: number; balance: number; status: string; overdue: boolean; dueDate: string | null }[];
  payments: { id: string; receiptNo: string | null; amount: number; method: string; reference: string | null; status: string; paidAt: string; notes: string | null }[];
};

declare global {
  interface Window {
    Razorpay?: new (opts: Record<string, unknown>) => { open: () => void; on: (e: string, cb: (r: unknown) => void) => void };
  }
}

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export function PaymentsPanel({ projectId, data, mode, onlinePayments, canDelete }: { projectId: string; data: PaymentsData; mode: "customer" | "team"; onlinePayments: boolean; canDelete?: boolean }) {
  const router = useRouter();
  const { toast } = useToast();
  const [recordOpen, setRecordOpen] = useState(false);
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const s = data.summary;

  async function payOnline(milestoneId: string) {
    setBusy(milestoneId);
    try {
      const ok = await loadRazorpay();
      if (!ok || !window.Razorpay) throw new Error("Could not load the payment window. Check your connection and try again.");
      const order = await api<{ orderId: string; amount: number; currency: string; keyId: string; description: string; projectName: string; prefill: Record<string, string> }>("/api/payments/razorpay/order", { body: { projectId, milestoneId } });
      const rzp = new window.Razorpay({
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        order_id: order.orderId,
        name: "Artify Interiors",
        description: `${order.projectName} — ${order.description}`,
        prefill: order.prefill,
        theme: { color: "#22201d" },
        handler: async (resp: Record<string, string>) => {
          try {
            const r = await api<{ receiptNo: string }>("/api/payments/razorpay/verify", { body: resp });
            toast(`Payment received. Receipt ${r.receiptNo}`);
            router.refresh();
          } catch (err) {
            toast(errorMessage(err), "error");
          }
        },
      });
      rzp.on("payment.failed", () => toast("Payment failed or was cancelled.", "error"));
      rzp.open();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  async function reminder() {
    setBusy("reminder");
    try {
      const r = await api<{ milestone: string; amount: number }>(`/api/projects/${projectId}/payment-reminder`, { method: "POST" });
      toast(`Reminder sent for ${r.milestone} (${formatINR(r.amount)})`);
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  async function removePayment(id: string) {
    if (!confirm("Delete this payment record? Its receipt number will not be reused.")) return;
    try {
      await api(`/api/payments/${id}`, { method: "DELETE" });
      toast("Payment deleted");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }

  if (!s.contract && data.payments.length === 0) {
    return <EmptyState title="Payments start after quotation approval" description="Once a final quotation is approved, your payment schedule appears here with receipts for every payment." />;
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-4">
        <StatCard label="Contract value" value={formatINR(s.contract)} />
        <StatCard label="Received" value={formatINR(s.received)} tone="moss" hint={`${s.percent}% of contract`} />
        <StatCard label="Pending" value={formatINR(s.pending)} tone="amber" />
        <div className="flex flex-col justify-center rounded-[var(--radius-md)] border border-line bg-paper px-4 py-4">
          <p className="text-[0.78rem] text-smoke">Payment status</p>
          <div className="mt-2">
            <StatusBadge status={s.status === "NO_CONTRACT" ? "PENDING" : s.status} />
          </div>
        </div>
      </div>

      <Panel>
        <PanelHeader
          title="Payment schedule"
          actions={
            mode === "team" ? (
              <>
                <Button size="sm" variant="secondary" onClick={() => setScheduleOpen(true)}>
                  <Pencil className="size-3.5" /> Edit schedule
                </Button>
                <Button size="sm" variant="secondary" onClick={reminder} loading={busy === "reminder"} disabled={s.pending <= 0}>
                  <BellRing className="size-3.5" /> Send reminder
                </Button>
                <Button size="sm" onClick={() => setRecordOpen(true)}>
                  <Plus className="size-3.5" /> Record payment
                </Button>
              </>
            ) : null
          }
        />
        {mode === "customer" && !onlinePayments && s.pending > 0 ? <Notice kind="info" className="mb-4">Pay by bank transfer, UPI or cheque as per your quotation. Receipts appear here once the team records your payment.</Notice> : null}
        <div className="overflow-x-auto">
          <table className="data-table min-w-[720px]">
            <thead>
              <tr>
                <th>Milestone</th>
                <th className="num">Share</th>
                <th className="num">Amount</th>
                <th className="num">Received</th>
                <th className="num">Balance</th>
                <th>Due</th>
                <th>Status</th>
                {mode === "customer" && onlinePayments ? <th /> : null}
              </tr>
            </thead>
            <tbody>
              {data.milestones.map((m) => (
                <tr key={m.id} id={`pm-${m.id}`}>
                  <td className="text-charcoal">{m.name}</td>
                  <td className="num">{m.percent}%</td>
                  <td className="num">{formatINR(m.amount)}</td>
                  <td className="num">{formatINR(m.received)}</td>
                  <td className="num">{formatINR(m.balance)}</td>
                  <td className={m.overdue ? "text-brick" : "text-smoke"}>{m.dueDate ? formatDate(m.dueDate) : "—"}</td>
                  <td>
                    <StatusBadge status={m.overdue ? "BLOCKED" : m.status} label={m.overdue ? "Overdue" : undefined} />
                  </td>
                  {mode === "customer" && onlinePayments ? (
                    <td>
                      {m.balance > 0 ? (
                        <Button size="sm" onClick={() => payOnline(m.id)} loading={busy === m.id}>
                          <CreditCard className="size-3.5" /> Pay {formatINR(m.balance)}
                        </Button>
                      ) : null}
                    </td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Payment history" />
        {data.payments.length ? (
          <div className="overflow-x-auto">
            <table className="data-table min-w-[640px]">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Receipt</th>
                  <th>Method</th>
                  <th>Reference</th>
                  <th>Status</th>
                  <th className="num">Amount</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {data.payments.map((p) => (
                  <tr key={p.id}>
                    <td>{formatDate(p.paidAt)}</td>
                    <td className="text-charcoal">{p.receiptNo ?? "—"}</td>
                    <td>{PAYMENT_METHOD_LABELS[p.method as keyof typeof PAYMENT_METHOD_LABELS] ?? p.method}</td>
                    <td className="text-smoke">{p.reference ?? "—"}</td>
                    <td>
                      <StatusBadge status={p.status} />
                    </td>
                    <td className="num text-charcoal">{formatINR(p.amount, { decimals: true })}</td>
                    <td className="whitespace-nowrap text-right">
                      {p.status === "SUCCESS" && p.receiptNo ? (
                        <a href={`/api/payments/${p.id}/receipt`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm text-charcoal underline decoration-sand underline-offset-4">
                          <FileDown className="size-3.5" /> Receipt
                        </a>
                      ) : null}
                      {mode === "team" && canDelete ? (
                        <button type="button" onClick={() => removePayment(p.id)} className="ml-2 rounded p-1 text-smoke hover:text-brick" aria-label="Delete payment">
                          <Trash2 className="size-3.5" />
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-smoke">No payments recorded yet.</p>
        )}
      </Panel>

      {mode === "team" ? <RecordPaymentModal open={recordOpen} onClose={() => setRecordOpen(false)} projectId={projectId} milestones={data.milestones} /> : null}
      {mode === "team" ? <ScheduleModal open={scheduleOpen} onClose={() => setScheduleOpen(false)} projectId={projectId} milestones={data.milestones} contract={s.contract} /> : null}
    </div>
  );
}

function RecordPaymentModal({ open, onClose, projectId, milestones }: { open: boolean; onClose: () => void; projectId: string; milestones: PaymentsData["milestones"] }) {
  const router = useRouter();
  const { toast } = useToast();
  const next = milestones.find((m) => m.balance > 0);
  const [form, setForm] = useState({ amount: next ? String(next.balance) : "", method: "BANK_TRANSFER", reference: "", paidAt: new Date().toISOString().slice(0, 10), notes: "", paymentMilestoneId: next?.id ?? "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));
  async function submit() {
    setBusy(true);
    setErrors({});
    try {
      await api(`/api/projects/${projectId}/payments`, { body: { ...form, amount: Number(form.amount), paymentMilestoneId: form.paymentMilestoneId || null } });
      toast("Payment recorded and receipt issued");
      onClose();
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Record payment"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit} loading={busy}>
            Record payment
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Amount (₹)" error={errors.amount} htmlFor="rp-a">
          <Input id="rp-a" type="number" min={1} step="0.01" value={form.amount} onChange={set("amount")} />
        </Field>
        <Field label="Date received" htmlFor="rp-d">
          <Input id="rp-d" type="date" value={form.paidAt} onChange={set("paidAt")} />
        </Field>
        <Field label="Method" htmlFor="rp-m">
          <Select id="rp-m" value={form.method} onChange={set("method")}>
            {(["BANK_TRANSFER", "UPI", "CHEQUE", "CASH", "CARD"] as const).map((m) => (
              <option key={m} value={m}>
                {PAYMENT_METHOD_LABELS[m]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Reference (UTR / cheque no.)" htmlFor="rp-r">
          <Input id="rp-r" value={form.reference} onChange={set("reference")} />
        </Field>
        <Field label="Towards milestone" htmlFor="rp-ms" className="sm:col-span-2">
          <Select id="rp-ms" value={form.paymentMilestoneId} onChange={set("paymentMilestoneId")}>
            <option value="">General project payment</option>
            {milestones.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name} — balance {formatINR(m.balance)}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Notes" htmlFor="rp-n" className="sm:col-span-2">
          <Textarea id="rp-n" value={form.notes} onChange={set("notes")} rows={2} />
        </Field>
      </div>
    </Modal>
  );
}

function ScheduleModal({ open, onClose, projectId, milestones, contract }: { open: boolean; onClose: () => void; projectId: string; milestones: PaymentsData["milestones"]; contract: number }) {
  const router = useRouter();
  const { toast } = useToast();
  const [rows, setRows] = useState(() => milestones.map((m) => ({ name: m.name, percent: String(m.percent), dueDate: m.dueDate?.slice(0, 10) ?? "" })));
  const [busy, setBusy] = useState(false);
  const total = rows.reduce((s, r) => s + (Number(r.percent) || 0), 0);
  async function save() {
    setBusy(true);
    try {
      await api(`/api/projects/${projectId}/payment-schedule`, { method: "PUT", body: { milestones: rows.map((r) => ({ name: r.name, percent: Number(r.percent), dueDate: r.dueDate || null })) } });
      toast("Payment schedule updated");
      onClose();
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Payment schedule"
      description={`Contract value ${formatINR(contract)}. Percentages must total 100%.`}
      size="lg"
      footer={
        <>
          <span className={`mr-auto self-center text-sm ${Math.abs(total - 100) < 0.01 ? "text-moss" : "text-brick"}`}>Total {total}%</span>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={busy} disabled={Math.abs(total - 100) > 0.01}>
            Save schedule
          </Button>
        </>
      }
    >
      <div className="space-y-2">
        {rows.map((r, i) => (
          <div key={i} className="grid grid-cols-[1fr_90px_150px_auto] items-center gap-2">
            <Input aria-label="Milestone name" value={r.name} onChange={(e) => setRows((rs) => rs.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
            <Input aria-label="Percent" type="number" min={0.5} max={100} step={0.5} value={r.percent} onChange={(e) => setRows((rs) => rs.map((x, j) => (j === i ? { ...x, percent: e.target.value } : x)))} />
            <Input aria-label="Due date" type="date" value={r.dueDate} onChange={(e) => setRows((rs) => rs.map((x, j) => (j === i ? { ...x, dueDate: e.target.value } : x)))} />
            <button type="button" onClick={() => setRows((rs) => rs.filter((_, j) => j !== i))} disabled={rows.length <= 1} className="rounded p-1.5 text-smoke hover:text-brick disabled:opacity-30" aria-label="Remove milestone">
              <Trash2 className="size-4" />
            </button>
          </div>
        ))}
        <Button size="sm" variant="secondary" onClick={() => setRows((rs) => [...rs, { name: "New milestone", percent: "0", dueDate: "" }])}>
          <Plus className="size-3.5" /> Add milestone
        </Button>
      </div>
    </Modal>
  );
}
