import type { BOQTotals } from "@/lib/calc/boq";
import { formatINR, formatNumber } from "@/lib/format";
import { BOQ_SECTIONS } from "@/lib/boq/engine";

export type BOQItemView = {
  id: string;
  section: string;
  item: string;
  dimensions: string | null;
  primaryMaterial: string | null;
  finishBrand: string | null;
  hardware: string | null;
  accessories: string | null;
  quantity: number;
  unit: string;
  rate: number;
  amount: number;
  itemType: string;
  isEstimated: boolean;
};

export function groupBySection<T extends { section: string }>(items: T[]) {
  const order = (s: string) => {
    const i = (BOQ_SECTIONS as readonly string[]).indexOf(s);
    return i === -1 ? 999 : i;
  };
  const map = new Map<string, T[]>();
  for (const it of items) map.set(it.section, [...(map.get(it.section) ?? []), it]);
  return [...map.entries()].sort((a, b) => order(a[0]) - order(b[0]));
}

/** Read-only BOQ table with all spec columns. */
export function BOQTable({ items, totals, showInternal, marginLabel }: { items: BOQItemView[]; totals: BOQTotals; showInternal?: boolean; marginLabel: string }) {
  let sr = 0;
  const groups = groupBySection(items);
  return (
    <div>
      <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
        <table className="data-table min-w-[1100px] text-[0.82rem]">
          <thead>
            <tr>
              <th>Sr.</th>
              <th>Item</th>
              <th>Dimensions</th>
              <th>Primary material</th>
              <th>Finish / brand</th>
              <th>Hardware</th>
              <th>Accessories</th>
              <th className="num">Qty</th>
              <th>Unit</th>
              <th className="num">Rate</th>
              <th className="num">Amount</th>
            </tr>
          </thead>
          <tbody>
            {groups.map(([section, list]) => (
              <SectionBlock key={section} section={section} total={totals.sections.find((s) => s.section === section)?.amount ?? 0}>
                {list.map((it) => {
                  sr += 1;
                  return (
                    <tr key={it.id}>
                      <td className="text-smoke">{sr}</td>
                      <td className="min-w-[200px] text-charcoal">
                        {it.item}
                        {it.isEstimated ? <span className="ml-1.5 rounded bg-amber-soft px-1.5 py-px text-[0.65rem] font-semibold text-amber">estimate</span> : null}
                      </td>
                      <td className="text-smoke">{it.dimensions ?? "—"}</td>
                      <td>{it.primaryMaterial ?? "—"}</td>
                      <td className="text-smoke">{it.finishBrand ?? "—"}</td>
                      <td className="text-smoke">{it.hardware ?? "—"}</td>
                      <td className="text-smoke">{it.accessories ?? "—"}</td>
                      <td className="num">{formatNumber(it.quantity)}</td>
                      <td>{it.unit}</td>
                      <td className="num">{formatINR(it.rate)}</td>
                      <td className="num text-charcoal">{formatINR(it.amount, { decimals: true })}</td>
                    </tr>
                  );
                })}
              </SectionBlock>
            ))}
          </tbody>
        </table>
      </div>
      <TotalsBox totals={totals} showInternal={showInternal} marginLabel={marginLabel} />
    </div>
  );
}

function SectionBlock({ section, total, children }: { section: string; total: number; children: React.ReactNode }) {
  return (
    <>
      <tr>
        <td colSpan={10} className="bg-travertine/60 font-semibold text-charcoal">
          {section}
        </td>
        <td className="num bg-travertine/60 font-semibold text-charcoal">{formatINR(total, { decimals: true })}</td>
      </tr>
      {children}
    </>
  );
}

export function TotalsBox({ totals: t, showInternal, marginLabel }: { totals: BOQTotals; showInternal?: boolean; marginLabel: string }) {
  const rows: [string, number, string?][] = [
    ["Subtotal", t.subtotal, "strong"],
    ...(showInternal
      ? ([
          ["  Material cost", t.materialCost, "muted"],
          ["  Labour cost", t.labourCost, "muted"],
          ["  Services", t.serviceCost, "muted"],
        ] as [string, number, string][])
      : []),
    ["Material wastage allowance", t.wastageAmount],
    ["Transportation", t.transportCharges],
    ["Installation charges", t.installationCharges],
    [showInternal ? "Profit margin" : marginLabel, t.profitAmount],
    ["Discount", -t.discountAmount],
    ["Taxable value", t.taxableAmount, "strong"],
    [`GST @ ${t.gstRate}%`, t.gstAmount],
  ];
  return (
    <div className="ml-auto mt-5 w-full max-w-md rounded-[var(--radius-md)] border border-line bg-paper p-5 text-sm">
      {rows
        .filter(([, v, k]) => v !== 0 || k === "strong")
        .map(([label, v, kind]) => (
          <div key={label} className={`flex justify-between py-1 ${kind === "strong" ? "font-semibold text-charcoal" : kind === "muted" ? "pl-3 text-xs text-smoke" : "text-ink"}`}>
            <span>{label.trim()}</span>
            <span className="tabular-nums">{v < 0 ? `− ${formatINR(-v, { decimals: true })}` : formatINR(v, { decimals: true })}</span>
          </div>
        ))}
      <div className="mt-2 flex items-baseline justify-between border-t border-line pt-3">
        <span className="font-semibold text-charcoal">Grand total</span>
        <span className="font-display text-3xl text-charcoal tabular-nums">{formatINR(t.grandTotal, { decimals: true })}</span>
      </div>
    </div>
  );
}
