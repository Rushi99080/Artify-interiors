"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { FileSpreadsheet } from "lucide-react";
import { PRICE_TIERS, TIER_LABELS, type PriceTierKey } from "@/lib/constants";
import { api, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/field";
import { useToast } from "@/components/ui/toast";

/** Customer action: generate (or refresh) a preliminary BOQ and — if enabled — an instant preliminary quotation. */
export function PreliminaryQuoteButton({ projectId, defaultTier, hasBoq, label }: { projectId: string; defaultTier?: string | null; hasBoq: boolean; label?: string }) {
  const router = useRouter();
  const { toast } = useToast();
  const [tier, setTier] = useState<PriceTierKey>((defaultTier as PriceTierKey) ?? "STANDARD");
  const [busy, setBusy] = useState(false);
  async function run() {
    setBusy(true);
    try {
      const res = await api<{ mode: "quotation" | "requested" }>(`/api/projects/${projectId}/quotations/preliminary`, { body: { tier } });
      toast(res.mode === "quotation" ? "Your preliminary quotation is ready" : "Estimate generated — our team will send your quotation shortly");
      router.push(res.mode === "quotation" ? `/dashboard/projects/${projectId}/quotations` : `/dashboard/projects/${projectId}/boq`);
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select aria-label="Finish level" value={tier} onChange={(e) => setTier(e.target.value as PriceTierKey)} className="w-auto">
        {PRICE_TIERS.map((t) => (
          <option key={t} value={t}>
            {TIER_LABELS[t]} finish
          </option>
        ))}
      </Select>
      <Button onClick={run} loading={busy}>
        <FileSpreadsheet className="size-4" /> {label ?? (hasBoq ? "Refresh my estimate" : "Get my preliminary estimate")}
      </Button>
    </div>
  );
}
