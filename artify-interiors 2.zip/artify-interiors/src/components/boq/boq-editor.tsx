"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { BadgeCheck, Check, Download, Pencil, Plus, Trash2, X } from "lucide-react";
import { BOQ_SECTIONS } from "@/lib/boq/engine";
import { computeBOQTotals, lineAmount } from "@/lib/calc/boq";
import { MATERIAL_CATEGORY_LABELS, type MaterialCategoryKey } from "@/lib/constants";
import { api, errorMessage } from "@/lib/client/api";
import { cn, formatINR, formatNumber } from "@/lib/format";
import { Button, buttonClass } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/notice";
import { Panel, PanelHeader } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";
import { TotalsBox, groupBySection, type BOQItemView } from "@/components/boq/boq-table";
import { CreateQuotationButton } from "@/components/boq/boq-actions";

type BOQ = {
  id: string;
  title: string;
  version: number;
  status: string;
  tier: string;
  gstRate: number;
  wastagePercent: number;
  profitMarginPercent: number;
  transportCharges: number;
  installationCharges: number;
  discountAmount: number;
  notes: string | null;
  verifiedAt: string | null;
  verifiedByName: string | null;
  project: { id: string; name: string; code: string };
  items: BOQItemView[];
};
type LibMaterial = { id: string; name: string; brand: string | null; category: string; rate: number; unit: string; finish: string | null };

const blank = { section: "Living Room", item: "", dimensions: "", primaryMaterial: "", finishBrand: "", hardware: "", accessories: "", quantity: "1", unit: "nos", rate: "0", itemType: "MATERIAL", materialId: "" };

export function BOQEditor({ boq: initial, materials, marginLabel }: { boq: BOQ; materials: LibMaterial[]; marginLabel: string }) {
  const router = useRouter();
  const { toast } = useToast();
  const [boq, setBoq] = useState(initial);
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [charges, setCharges] = useState({
    gstRate: String(initial.gstRate),
    wastagePercent: String(initial.wastagePercent),
    profitMarginPercent: String(initial.profitMarginPercent),
    transportCharges: String(initial.transportCharges),
    installationCharges: String(initial.installationCharges),
    discountAmount: String(initial.discountAmount),
    notes: initial.notes ?? "",
    title: initial.title,
  });
  const [addOpen, setAddOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const locked = boq.status === "FINAL";

  const totals = useMemo(
    () =>
      computeBOQTotals(
        boq.items.map((i) => ({ section: i.section, quantity: i.quantity, rate: i.rate, itemType: i.itemType as "MATERIAL" })),
        { gstRate: Number(charges.gstRate) || 0, wastagePercent: Number(charges.wastagePercent) || 0, profitMarginPercent: Number(charges.profitMarginPercent) || 0, transportCharges: Number(charges.transportCharges) || 0, installationCharges: Number(charges.installationCharges) || 0, discountAmount: Number(charges.discountAmount) || 0 },
        [...BOQ_SECTIONS],
      ),
    [boq.items, charges],
  );
  const estimates = boq.items.filter((i) => i.isEstimated).length;
  const sections = Array.from(new Set([...BOQ_SECTIONS, ...boq.items.map((i) => i.section)]));

  async function saveCharges(extra: Record<string, unknown> = {}) {
    setBusy("charges");
    try {
      await api(`/api/boq/${boq.id}`, {
        method: "PATCH",
        body: { title: charges.title, notes: charges.notes || null, gstRate: Number(charges.gstRate), wastagePercent: Number(charges.wastagePercent), profitMarginPercent: Number(charges.profitMarginPercent), transportCharges: Number(charges.transportCharges), installationCharges: Number(charges.installationCharges), discountAmount: Number(charges.discountAmount), ...extra },
      });
      toast(extra.status === "VERIFIED" ? "BOQ marked as verified against site measurements" : "BOQ saved");
      if (extra.status) setBoq((b) => ({ ...b, status: String(extra.status), items: b.items.map((i) => ({ ...i, isEstimated: false })) }));
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  async function saveItem(id: string, patch: Record<string, unknown>) {
    setBusy(id);
    try {
      const r = await api<{ item: BOQItemView }>(`/api/boq/items/${id}`, { method: "PATCH", body: patch });
      setBoq((b) => ({ ...b, items: b.items.map((i) => (i.id === id ? { ...i, ...r.item } : i)) }));
      setEditing(null);
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  async function removeItem(id: string) {
    if (!confirm("Remove this line?")) return;
    setBusy(id);
    try {
      await api(`/api/boq/items/${id}`, { method: "DELETE" });
      setBoq((b) => ({ ...b, items: b.items.filter((i) => i.id !== id) }));
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  function startEdit(i: BOQItemView) {
    setEditing(i.id);
    setDraft({ item: i.item, dimensions: i.dimensions ?? "", primaryMaterial: i.primaryMaterial ?? "", finishBrand: i.finishBrand ?? "", hardware: i.hardware ?? "", accessories: i.accessories ?? "", quantity: String(i.quantity), unit: i.unit, rate: String(i.rate), section: i.section, itemType: i.itemType });
  }

  let sr = 0;
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <Link href={`/admin/projects/${boq.project.id}/boq`} className="link-underline text-sm text-smoke">
            {boq.project.name} ({boq.project.code})
          </Link>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <h1 className="text-3xl md:text-[2.2rem]">BOQ v{boq.version}</h1>
            <StatusBadge status={boq.status} />
          </div>
          {boq.verifiedAt ? (
            <p className="mt-1 text-xs text-smoke">
              Verified by {boq.verifiedByName} on {new Date(boq.verifiedAt).toLocaleDateString("en-IN")}
            </p>
          ) : null}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <a href={`/api/boq/${boq.id}/export`} className={buttonClass("secondary")}>
            <Download className="size-4" /> Excel
          </a>
          {boq.status === "PRELIMINARY" ? (
            <Button variant="secondary" onClick={() => saveCharges({ status: "VERIFIED" })} loading={busy === "charges"}>
              <BadgeCheck className="size-4" /> Mark verified on site
            </Button>
          ) : null}
          {!locked ? <CreateQuotationButton boqId={boq.id} preliminary={boq.status === "PRELIMINARY"} /> : null}
        </div>
      </div>

      {locked ? <Notice kind="info">This BOQ is final — its quotation was approved. Generate a new version from the project to make changes.</Notice> : null}
      {boq.status === "PRELIMINARY" && estimates ? (
        <Notice kind="warning" title={`${estimates} line${estimates === 1 ? "" : "s"} are preliminary estimates`}>
          Quantities were derived from room dimensions. Edit quantities after site measurement (edited lines are marked verified), then mark the BOQ as verified to issue a final quotation.
        </Notice>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
        <div className="min-w-0">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-sm text-smoke">{boq.items.length} lines · click a quantity or rate to change it</p>
            {!locked ? (
              <Button size="sm" onClick={() => setAddOpen(true)}>
                <Plus className="size-3.5" /> Add item
              </Button>
            ) : null}
          </div>
          <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
            <table className="data-table min-w-[1180px] text-[0.8rem]">
              <thead>
                <tr>
                  <th>Sr.</th>
                  <th>Item</th>
                  <th>Dimensions</th>
                  <th>Primary material</th>
                  <th>Finish / brand</th>
                  <th>Hardware</th>
                  <th>Accessories</th>
                  <th className="num">Qty</th>
                  <th>Unit</th>
                  <th className="num">Rate</th>
                  <th className="num">Amount</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {groupBySection(boq.items).map(([section, list]) => (
                  <SectionRows key={section} section={section} total={totals.sections.find((s) => s.section === section)?.amount ?? 0}>
                    {list.map((it) => {
                      sr += 1;
                      if (editing === it.id) {
                        return (
                          <tr key={it.id} className="bg-brass-soft/30">
                            <td className="text-smoke">{sr}</td>
                            <td>
                              <Input value={draft.item} onChange={(e) => setDraft({ ...draft, item: e.target.value })} className="min-w-[180px] py-1 text-xs" aria-label="Item" />
                              <Select value={draft.section} onChange={(e) => setDraft({ ...draft, section: e.target.value })} className="mt-1 py-1 text-xs" aria-label="Section">
                                {sections.map((s) => (
                                  <option key={s}>{s}</option>
                                ))}
                              </Select>
                            </td>
                            {(["dimensions", "primaryMaterial", "finishBrand", "hardware", "accessories"] as const).map((k) => (
                              <td key={k}>
                                <Input value={draft[k]} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} className="min-w-[110px] py-1 text-xs" aria-label={k} />
                              </td>
                            ))}
                            <td>
                              <Input type="number" step="0.01" value={draft.quantity} onChange={(e) => setDraft({ ...draft, quantity: e.target.value })} className="w-20 py-1 text-right text-xs" aria-label="Quantity" />
                            </td>
                            <td>
                              <Input value={draft.unit} onChange={(e) => setDraft({ ...draft, unit: e.target.value })} className="w-16 py-1 text-xs" aria-label="Unit" />
                            </td>
                            <td>
                              <Input type="number" step="0.01" value={draft.rate} onChange={(e) => setDraft({ ...draft, rate: e.target.value })} className="w-24 py-1 text-right text-xs" aria-label="Rate" />
                            </td>
                            <td className="num">{formatINR(lineAmount(Number(draft.quantity), Number(draft.rate)), { decimals: true })}</td>
                            <td className="whitespace-nowrap">
                              <button type="button" onClick={() => saveItem(it.id, { ...draft, quantity: Number(draft.quantity), rate: Number(draft.rate) })} className="rounded p-1 text-moss hover:bg-moss-soft" aria-label="Save line">
                                <Check className="size-4" />
                              </button>
                              <button type="button" onClick={() => setEditing(null)} className="rounded p-1 text-smoke hover:bg-travertine" aria-label="Cancel">
                                <X className="size-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      }
                      return (
                        <tr key={it.id} className={cn(busy === it.id && "opacity-50")}>
                          <td className="text-smoke">{sr}</td>
                          <td className="min-w-[180px] text-charcoal">
                            {it.item}
                            {it.isEstimated ? <span className="ml-1.5 rounded bg-amber-soft px-1.5 py-px text-[0.62rem] font-semibold text-amber">estimate</span> : null}
                            <span className="block text-[0.68rem] text-mist">{it.itemType.toLowerCase()}</span>
                          </td>
                          <td className="text-smoke">{it.dimensions ?? "—"}</td>
                          <td>{it.primaryMaterial ?? "—"}</td>
                          <td className="text-smoke">{it.finishBrand ?? "—"}</td>
                          <td className="text-smoke">{it.hardware ?? "—"}</td>
                          <td className="text-smoke">{it.accessories ?? "—"}</td>
                          <td className="num">
                            <InlineNumber value={it.quantity} disabled={locked} onSave={(v) => saveItem(it.id, { quantity: v })} label="Quantity" display={formatNumber(it.quantity)} />
                          </td>
                          <td>{it.unit}</td>
                          <td className="num">
                            <InlineNumber value={it.rate} disabled={locked} onSave={(v) => saveItem(it.id, { rate: v })} label="Rate" display={formatINR(it.rate)} />
                          </td>
                          <td className="num text-charcoal">{formatINR(it.amount, { decimals: true })}</td>
                          <td className="whitespace-nowrap">
                            {!locked ? (
                              <>
                                <button type="button" onClick={() => startEdit(it)} className="rounded p-1 text-smoke hover:text-charcoal" aria-label={`Edit ${it.item}`}>
                                  <Pencil className="size-3.5" />
                                </button>
                                <button type="button" onClick={() => removeItem(it.id)} className="rounded p-1 text-smoke hover:text-brick" aria-label={`Remove ${it.item}`}>
                                  <Trash2 className="size-3.5" />
                                </button>
                              </>
                            ) : null}
                          </td>
                        </tr>
                      );
                    })}
                  </SectionRows>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-5 xl:sticky xl:top-20 xl:self-start">
          <Panel>
            <PanelHeader title="Charges & tax" />
            <fieldset disabled={locked} className="grid grid-cols-2 gap-3">
              <Field label="GST %" htmlFor="c-gst">
                <Input id="c-gst" type="number" step="0.5" min={0} max={28} value={charges.gstRate} onChange={(e) => setCharges({ ...charges, gstRate: e.target.value })} />
              </Field>
              <Field label="Wastage %" htmlFor="c-w">
                <Input id="c-w" type="number" step="0.5" min={0} value={charges.wastagePercent} onChange={(e) => setCharges({ ...charges, wastagePercent: e.target.value })} />
              </Field>
              <Field label="Profit margin %" htmlFor="c-m">
                <Input id="c-m" type="number" step="0.5" min={0} value={charges.profitMarginPercent} onChange={(e) => setCharges({ ...charges, profitMarginPercent: e.target.value })} />
              </Field>
              <Field label="Discount (₹)" htmlFor="c-d">
                <Input id="c-d" type="number" min={0} value={charges.discountAmount} onChange={(e) => setCharges({ ...charges, discountAmount: e.target.value })} />
              </Field>
              <Field label="Transportation (₹)" htmlFor="c-t">
                <Input id="c-t" type="number" min={0} value={charges.transportCharges} onChange={(e) => setCharges({ ...charges, transportCharges: e.target.value })} />
              </Field>
              <Field label="Installation (₹)" htmlFor="c-i">
                <Input id="c-i" type="number" min={0} value={charges.installationCharges} onChange={(e) => setCharges({ ...charges, installationCharges: e.target.value })} />
              </Field>
              <Field label="Notes" htmlFor="c-n" className="col-span-2">
                <Textarea id="c-n" rows={2} value={charges.notes} onChange={(e) => setCharges({ ...charges, notes: e.target.value })} />
              </Field>
            </fieldset>
            {!locked ? (
              <Button className="mt-3 w-full" onClick={() => saveCharges()} loading={busy === "charges"}>
                Save charges
              </Button>
            ) : null}
            <p className="mt-3 text-xs text-smoke">Margin appears on client documents as “{marginLabel}”. Wastage applies to material lines only.</p>
          </Panel>
          <TotalsBox totals={totals} showInternal marginLabel={marginLabel} />
        </div>
      </div>

      <AddItemModal open={addOpen} onClose={() => setAddOpen(false)} boqId={boq.id} sections={sections} materials={materials} onAdded={(item) => setBoq((b) => ({ ...b, items: [...b.items, item] }))} />
    </div>
  );
}

function SectionRows({ section, total, children }: { section: string; total: number; children: React.ReactNode }) {
  return (
    <>
      <tr>
        <td colSpan={10} className="bg-travertine/60 font-semibold text-charcoal">
          {section}
        </td>
        <td className="num bg-travertine/60 font-semibold text-charcoal">{formatINR(total, { decimals: true })}</td>
        <td className="bg-travertine/60" />
      </tr>
      {children}
    </>
  );
}

function InlineNumber({ value, display, onSave, disabled, label }: { value: number; display: string; onSave: (v: number) => void; disabled?: boolean; label: string }) {
  const [edit, setEdit] = useState(false);
  const [v, setV] = useState(String(value));
  if (disabled) return <span>{display}</span>;
  if (!edit)
    return (
      <button type="button" onClick={() => (setV(String(value)), setEdit(true))} className="rounded px-1 py-0.5 hover:bg-brass-soft" aria-label={`Edit ${label.toLowerCase()}`}>
        {display}
      </button>
    );
  const commit = () => {
    setEdit(false);
    const n = Number(v);
    if (Number.isFinite(n) && n >= 0 && n !== value) onSave(n);
  };
  return (
    <input
      autoFocus
      aria-label={label}
      type="number"
      step="0.01"
      min={0}
      value={v}
      onChange={(e) => setV(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") commit();
        if (e.key === "Escape") setEdit(false);
      }}
      className="field-input w-24 py-1 text-right text-xs"
    />
  );
}

function AddItemModal({ open, onClose, boqId, sections, materials, onAdded }: { open: boolean; onClose: () => void; boqId: string; sections: string[]; materials: LibMaterial[]; onAdded: (i: BOQItemView) => void }) {
  const { toast } = useToast();
  const [f, setF] = useState<Record<string, string>>(blank);
  const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF((x) => ({ ...x, [k]: e.target.value }));
  async function submit() {
    setBusy(true);
    try {
      const r = await api<{ item: BOQItemView }>(`/api/boq/${boqId}/items`, {
        body: { ...f, quantity: Number(f.quantity), rate: Number(f.rate), materialId: f.materialId || null, dimensions: f.dimensions || null, primaryMaterial: f.primaryMaterial || null, finishBrand: f.finishBrand || null, hardware: f.hardware || null, accessories: f.accessories || null },
      });
      onAdded(r.item);
      toast("Line added");
      setF(blank);
      onClose();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add BOQ item"
      size="lg"
      footer={
        <>
          <span className="mr-auto self-center text-sm text-smoke">Amount {formatINR(lineAmount(Number(f.quantity), Number(f.rate)), { decimals: true })}</span>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit} loading={busy} disabled={!f.item.trim()}>
            Add item
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="From material library (optional)" htmlFor="ai-m" className="sm:col-span-2">
          <Select
            id="ai-m"
            value={f.materialId}
            onChange={(e) => {
              const m = materials.find((x) => x.id === e.target.value);
              setF((x) => ({ ...x, materialId: e.target.value, ...(m ? { item: x.item || m.name, primaryMaterial: [m.brand, m.name].filter(Boolean).join(" "), finishBrand: m.finish ?? "", unit: m.unit, rate: String(m.rate), itemType: "MATERIAL" } : {}) }));
            }}
          >
            <option value="">— Custom item —</option>
            {materials.map((m) => (
              <option key={m.id} value={m.id}>
                {MATERIAL_CATEGORY_LABELS[m.category as MaterialCategoryKey]}: {[m.brand, m.name].filter(Boolean).join(" ")} — {formatINR(m.rate)}/{m.unit}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Section" htmlFor="ai-s">
          <Select id="ai-s" value={f.section} onChange={set("section")}>
            {sections.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </Select>
        </Field>
        <Field label="Type" htmlFor="ai-t">
          <Select id="ai-t" value={f.itemType} onChange={set("itemType")}>
            <option value="MATERIAL">Material (supply & install)</option>
            <option value="LABOUR">Labour</option>
            <option value="SERVICE">Service</option>
          </Select>
        </Field>
        <Field label="Item" htmlFor="ai-i" className="sm:col-span-2">
          <Input id="ai-i" value={f.item} onChange={set("item")} placeholder="e.g. Pooja unit — Living Room" />
        </Field>
        <Field label="Dimensions" htmlFor="ai-d">
          <Input id="ai-d" value={f.dimensions} onChange={set("dimensions")} placeholder="e.g. 4' W × 6' H" />
        </Field>
        <Field label="Primary material" htmlFor="ai-p">
          <Input id="ai-p" value={f.primaryMaterial} onChange={set("primaryMaterial")} />
        </Field>
        <Field label="Finish / brand" htmlFor="ai-f">
          <Input id="ai-f" value={f.finishBrand} onChange={set("finishBrand")} />
        </Field>
        <Field label="Hardware" htmlFor="ai-h">
          <Input id="ai-h" value={f.hardware} onChange={set("hardware")} />
        </Field>
        <Field label="Accessories" htmlFor="ai-a" className="sm:col-span-2">
          <Input id="ai-a" value={f.accessories} onChange={set("accessories")} />
        </Field>
        <div className="grid grid-cols-3 gap-3 sm:col-span-2">
          <Field label="Quantity" htmlFor="ai-q">
            <Input id="ai-q" type="number" step="0.01" min={0} value={f.quantity} onChange={set("quantity")} />
          </Field>
          <Field label="Unit" htmlFor="ai-u">
            <Input id="ai-u" value={f.unit} onChange={set("unit")} />
          </Field>
          <Field label="Rate (₹)" htmlFor="ai-r">
            <Input id="ai-r" type="number" step="0.01" min={0} value={f.rate} onChange={set("rate")} />
          </Field>
        </div>
      </div>
    </Modal>
  );
}
