"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { FilePlus2, Sparkles } from "lucide-react";
import { PRICE_TIERS, TIER_LABELS, type PriceTierKey } from "@/lib/constants";
import { api, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Select, Checkbox } from "@/components/ui/field";
import { useToast } from "@/components/ui/toast";

export function GenerateBOQButton({ projectId, defaultTier = "STANDARD" }: { projectId: string; defaultTier?: string }) {
  const router = useRouter();
  const { toast } = useToast();
  const [tier, setTier] = useState<PriceTierKey>(defaultTier as PriceTierKey);
  const [busy, setBusy] = useState(false);
  async function run() {
    setBusy(true);
    try {
      const r = await api<{ boq: { id: string; version: number } }>(`/api/projects/${projectId}/boq`, { body: { tier } });
      toast(`BOQ v${r.boq.version} generated`);
      router.push(`/admin/boq/${r.boq.id}`);
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select aria-label="Finish level" value={tier} onChange={(e) => setTier(e.target.value as PriceTierKey)} className="w-auto">
        {PRICE_TIERS.map((t) => (
          <option key={t} value={t}>
            {TIER_LABELS[t]}
          </option>
        ))}
      </Select>
      <Button onClick={run} loading={busy}>
        <Sparkles className="size-4" /> Generate new BOQ version
      </Button>
    </div>
  );
}

export function CreateQuotationButton({ boqId, preliminary }: { boqId: string; preliminary: boolean }) {
  const router = useRouter();
  const { toast } = useToast();
  const [send, setSend] = useState(true);
  const [busy, setBusy] = useState(false);
  async function run() {
    if (preliminary && !confirm("This BOQ is still preliminary (not verified on site). Create a preliminary quotation?")) return;
    setBusy(true);
    try {
      const r = await api<{ quotation: { id: string; number: string } }>(`/api/boq/${boqId}/quotation`, { body: { send } });
      toast(`Quotation ${r.quotation.number} ${send ? "created and sent" : "created as draft"}`);
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="flex flex-wrap items-center gap-3">
      <Checkbox label="Send to client now" checked={send} onChange={(e) => setSend(e.target.checked)} />
      <Button size="sm" onClick={run} loading={busy}>
        <FilePlus2 className="size-3.5" /> Create quotation
      </Button>
    </div>
  );
}
