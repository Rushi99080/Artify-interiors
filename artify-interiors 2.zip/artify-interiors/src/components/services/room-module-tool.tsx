"use client";

import { useMemo, useState } from "react";
import { estimateRooms, type MaterialPick } from "@/lib/boq/engine";
import { DESIGN_STYLES, MATERIAL_CATEGORY_LABELS, PRICE_TIERS, STYLE_INFO, TIER_DESCRIPTIONS, TIER_LABELS, type DesignStyleKey, type MaterialCategoryKey, type PriceTierKey, type RoomModule } from "@/lib/constants";
import { formatINR, formatINRCompact, cn } from "@/lib/format";
import type { EstimatorData } from "@/lib/services/estimator";
import { Field, Input, Select, Checkbox } from "@/components/ui/field";
import { ButtonLink } from "@/components/ui/button";
import { EstimateBreakdown } from "@/components/estimate/estimate-breakdown";
import { LeadForm } from "@/components/site/lead-form";

type Mat = { id: string; name: string; brand: string | null; category: string; rate: number; unit: string; finish: string | null; tier: string };

const FLOORING_ROOMS = ["LIVING_ROOM", "MASTER_BEDROOM", "KIDS_BEDROOM", "GUEST_BEDROOM", "DINING_ROOM", "KITCHEN"];

export function RoomModuleTool({ module, data, materials }: { module: RoomModule; data: EstimatorData; materials: Mat[] }) {
  const [dims, setDims] = useState({ lengthFt: module.defaults.lengthFt, widthFt: module.defaults.widthFt, heightFt: module.defaults.heightFt });
  const [style, setStyle] = useState<DesignStyleKey>("MODERN");
  const [tier, setTier] = useState<PriceTierKey>("STANDARD");
  const [selected, setSelected] = useState<Record<string, string>>({});
  const [flooring, setFlooring] = useState(false);
  const [showQuote, setShowQuote] = useState(false);

  const byCategory = useMemo(() => {
    const m = new Map<string, Mat[]>();
    for (const x of materials) m.set(x.category, [...(m.get(x.category) ?? []), x]);
    return m;
  }, [materials]);

  const estimate = useMemo(() => {
    const sel: Partial<Record<MaterialCategoryKey, MaterialPick>> = {};
    for (const [cat, id] of Object.entries(selected)) {
      const m = materials.find((x) => x.id === id);
      if (m) sel[cat as MaterialCategoryKey] = { id: m.id, name: m.name, brand: m.brand, finish: m.finish, rate: m.rate, unit: m.unit };
    }
    return estimateRooms([{ name: module.label, type: module.type, ...dims, includeFlooring: flooring }], tier, { rateCard: data.rateCard, ctx: { selected: sel, byTier: data.byTier }, charges: data.charges, includeExtras: false });
  }, [dims, tier, selected, flooring, materials, module, data]);

  const setDim = (k: keyof typeof dims) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = Number(e.target.value);
    setDims((d) => ({ ...d, [k]: Number.isFinite(v) && v > 0 ? Math.min(v, 200) : d[k] }));
  };

  const aiHref = `/ai-designer?room=${module.type}&l=${dims.lengthFt}&w=${dims.widthFt}&h=${dims.heightFt}&style=${style}`;
  const total = estimate.totals.grandTotal;

  return (
    <div className="grid gap-8 lg:grid-cols-[1.25fr_1fr]">
      <div className="rounded-[var(--radius-md)] border border-line bg-paper p-6 md:p-8">
        <h2 className="text-3xl">Plan your {module.label.toLowerCase()}</h2>
        <p className="mt-1 text-sm text-smoke">Adjust the size, style, finish level and materials. The estimate updates as you go.</p>

        <div className="mt-6 grid grid-cols-3 gap-3">
          <Field label={`${module.dimensionLabels.length} (ft)`} htmlFor="dim-l">
            <Input id="dim-l" type="number" min={1} step={0.5} inputMode="decimal" defaultValue={dims.lengthFt} onChange={setDim("lengthFt")} />
          </Field>
          <Field label={`${module.dimensionLabels.width} (ft)`} htmlFor="dim-w">
            <Input id="dim-w" type="number" min={1} step={0.5} inputMode="decimal" defaultValue={dims.widthFt} onChange={setDim("widthFt")} />
          </Field>
          <Field label={`${module.dimensionLabels.height} (ft)`} htmlFor="dim-h">
            <Input id="dim-h" type="number" min={1} step={0.5} inputMode="decimal" defaultValue={dims.heightFt} onChange={setDim("heightFt")} />
          </Field>
        </div>
        <div className="mt-2 text-xs tabular-nums text-smoke">
          {module.type === "WARDROBE" || module.type === "TV_UNIT" ? `Front area ${Math.round(dims.lengthFt * dims.heightFt)} sqft` : `Floor area ${Math.round(dims.lengthFt * dims.widthFt)} sqft`}
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <Field label="Design style" htmlFor="style">
            <Select id="style" value={style} onChange={(e) => setStyle(e.target.value as DesignStyleKey)}>
              {DESIGN_STYLES.map((s) => (
                <option key={s} value={s}>
                  {STYLE_INFO[s].label}
                </option>
              ))}
            </Select>
          </Field>
          {FLOORING_ROOMS.includes(module.type) ? (
            <div className="flex items-end pb-2">
              <Checkbox label="Include new flooring" checked={flooring} onChange={(e) => setFlooring(e.target.checked)} />
            </div>
          ) : null}
        </div>

        <fieldset className="mt-6">
          <legend className="text-[0.8rem] font-medium text-ink">Finish level</legend>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {PRICE_TIERS.map((t) => (
              <button
                key={t}
                type="button"
                aria-pressed={tier === t}
                onClick={() => setTier(t)}
                className={cn("rounded-[var(--radius-sm)] border px-3 py-2.5 text-left text-sm transition-colors", tier === t ? "border-brass bg-brass-soft font-semibold text-charcoal" : "border-line bg-white text-ink hover:border-sand")}
              >
                {TIER_LABELS[t]}
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-smoke">{TIER_DESCRIPTIONS[tier]}</p>
        </fieldset>

        {byCategory.size ? (
          <div className="mt-6">
            <p className="text-[0.8rem] font-medium text-ink">Materials</p>
            <p className="text-xs text-smoke">Leave on “Recommended” to use the typical material for your finish level.</p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {[...byCategory.entries()].map(([cat, list]) => (
                <Field key={cat} label={MATERIAL_CATEGORY_LABELS[cat as MaterialCategoryKey]} htmlFor={`mat-${cat}`}>
                  <Select id={`mat-${cat}`} value={selected[cat] ?? ""} onChange={(e) => setSelected((s) => ({ ...s, [cat]: e.target.value }))}>
                    <option value="">Recommended for {TIER_LABELS[tier]}</option>
                    {list.map((m) => (
                      <option key={m.id} value={m.id}>
                        {[m.brand, m.name].filter(Boolean).join(" ")} — {formatINR(m.rate)}/{m.unit}
                      </option>
                    ))}
                  </Select>
                </Field>
              ))}
            </div>
          </div>
        ) : null}
      </div>

      <div className="flex flex-col gap-5 lg:sticky lg:top-24 lg:self-start">
        <div className="rounded-[var(--radius-md)] bg-charcoal p-7 text-paper">
          <p className="text-sm text-sand">Estimated cost, including GST</p>
          <p className="mt-1 font-display text-6xl leading-none">{formatINRCompact(total)}</p>
          <p className="mt-2 text-sm text-sand/80">
            Likely range {formatINRCompact(total * 0.9)} – {formatINRCompact(total * 1.15)}
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            <ButtonLink href={aiHref} variant="brass">
              Generate AI concepts
            </ButtonLink>
            <button type="button" onClick={() => setShowQuote((v) => !v)} className="inline-flex h-10 items-center rounded-[var(--radius-sm)] border border-white/25 px-4 text-sm text-paper hover:bg-white/10">
              Get an exact quote
            </button>
          </div>
        </div>
        {showQuote ? (
          <div className="rounded-[var(--radius-md)] border border-line bg-paper p-6">
            <LeadForm compact source="COST_CALCULATOR" submitLabel="Request my quote" meta={{ module: module.type, dims, tier, style, estimate: Math.round(total) }} defaultMessage={`${module.label}, ${dims.lengthFt}′ × ${dims.widthFt}′, ${TIER_LABELS[tier]} finish, ${STYLE_INFO[style].label} style. Online estimate ${formatINRCompact(total)}.`} />
          </div>
        ) : null}
        <div className="rounded-[var(--radius-md)] border border-line bg-paper p-6">
          <EstimateBreakdown estimate={estimate} />
        </div>
      </div>
    </div>
  );
}
