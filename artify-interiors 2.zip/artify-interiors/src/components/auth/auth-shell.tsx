import type { ReactNode } from "react";
import { getSettings } from "@/lib/settings";
import { SmartImage } from "@/components/ui/smart-image";

export async function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: ReactNode }) {
  const { about } = await getSettings();
  return (
    <div className="container-page grid min-h-[calc(100svh-72px)] items-center gap-12 py-12 lg:grid-cols-2">
      <div className="mx-auto w-full max-w-md">
        <h1 className="text-4xl md:text-5xl">{title}</h1>
        <p className="mt-3 text-smoke">{subtitle}</p>
        <div className="mt-8">{children}</div>
      </div>
      <SmartImage src={about.imageUrl} alt="Interior by Artify" className="hidden aspect-[4/5] max-h-[78svh] w-full lg:block" fallbackLabel="Artify Interiors" />
    </div>
  );
}
