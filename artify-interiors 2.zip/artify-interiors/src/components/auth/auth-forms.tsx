"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState, type FormEvent } from "react";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Notice } from "@/components/ui/notice";

function safeNext(next: string | null) {
  return next && next.startsWith("/") && !next.startsWith("//") ? next : null;
}

export function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setLoading(true);
    setError(null);
    setFields({});
    try {
      const res = await api<{ redirect: string }>("/api/auth/login", { body: { email: fd.get("email"), password: fd.get("password") } });
      router.push(safeNext(params.get("next")) ?? res.redirect);
      router.refresh();
    } catch (err) {
      setLoading(false);
      if (err instanceof ApiClientError && err.fields) setFields(err.fields);
      setError(errorMessage(err));
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4" noValidate>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <Field label="Email" error={fields.email} htmlFor="email">
        <Input id="email" name="email" type="email" autoComplete="email" required autoFocus invalid={!!fields.email} />
      </Field>
      <Field label="Password" error={fields.password} htmlFor="password">
        <Input id="password" name="password" type="password" autoComplete="current-password" required invalid={!!fields.password} />
      </Field>
      <Button type="submit" size="lg" loading={loading}>
        Log in
      </Button>
      <p className="text-center text-sm text-smoke">
        New to Artify?{" "}
        <Link href={`/register${params.get("next") ? `?next=${encodeURIComponent(params.get("next")!)}` : ""}`} className="link-underline text-charcoal">
          Create an account
        </Link>
      </p>
    </form>
  );
}

export function RegisterForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (fd.get("password") !== fd.get("confirm")) {
      setFields({ confirm: "Passwords do not match" });
      return;
    }
    setLoading(true);
    setError(null);
    setFields({});
    try {
      const res = await api<{ redirect: string }>("/api/auth/register", { body: { name: fd.get("name"), email: fd.get("email"), phone: fd.get("phone"), password: fd.get("password") } });
      router.push(safeNext(params.get("next")) ?? res.redirect);
      router.refresh();
    } catch (err) {
      setLoading(false);
      if (err instanceof ApiClientError && err.fields) setFields(err.fields);
      setError(errorMessage(err));
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4" noValidate>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <Field label="Full name" error={fields.name} htmlFor="name" required>
        <Input id="name" name="name" autoComplete="name" required autoFocus invalid={!!fields.name} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Email" error={fields.email} htmlFor="email" required>
          <Input id="email" name="email" type="email" autoComplete="email" required invalid={!!fields.email} />
        </Field>
        <Field label="Mobile number" error={fields.phone} htmlFor="phone" required>
          <Input id="phone" name="phone" type="tel" autoComplete="tel" inputMode="tel" required invalid={!!fields.phone} />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Password" error={fields.password} hint="At least 8 characters with letters and numbers" htmlFor="password" required>
          <Input id="password" name="password" type="password" autoComplete="new-password" required invalid={!!fields.password} />
        </Field>
        <Field label="Confirm password" error={fields.confirm} htmlFor="confirm" required>
          <Input id="confirm" name="confirm" type="password" autoComplete="new-password" required invalid={!!fields.confirm} />
        </Field>
      </div>
      <Button type="submit" size="lg" loading={loading}>
        Create account
      </Button>
      <p className="text-center text-sm text-smoke">
        Already have an account?{" "}
        <Link href="/login" className="link-underline text-charcoal">
          Log in
        </Link>
      </p>
    </form>
  );
}
