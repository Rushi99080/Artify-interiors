import type { ComponentProps, ReactNode } from "react";
import { cn } from "@/lib/format";

export function Field({ label, hint, error, children, className, htmlFor, required }: { label?: ReactNode; hint?: ReactNode; error?: string | null; children: ReactNode; className?: string; htmlFor?: string; required?: boolean }) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label ? (
        <label htmlFor={htmlFor} className="text-[0.8rem] font-medium text-ink">
          {label}
          {required ? <span className="text-brass"> *</span> : null}
        </label>
      ) : null}
      {children}
      {error ? (
        <p className="text-xs text-brick" role="alert">
          {error}
        </p>
      ) : hint ? (
        <p className="text-xs text-smoke">{hint}</p>
      ) : null}
    </div>
  );
}

export function Input({ className, invalid, ...props }: ComponentProps<"input"> & { invalid?: boolean }) {
  return <input {...props} aria-invalid={invalid || undefined} className={cn("field-input", className)} />;
}

export function Textarea({ className, invalid, ...props }: ComponentProps<"textarea"> & { invalid?: boolean }) {
  return <textarea rows={3} {...props} aria-invalid={invalid || undefined} className={cn("field-input min-h-[5rem] resize-y leading-relaxed", className)} />;
}

export function Select({ className, invalid, children, ...props }: ComponentProps<"select"> & { invalid?: boolean }) {
  return (
    <select {...props} aria-invalid={invalid || undefined} className={cn("field-input", className)}>
      {children}
    </select>
  );
}

export function Checkbox({ label, className, ...props }: ComponentProps<"input"> & { label: ReactNode }) {
  return (
    <label className={cn("inline-flex cursor-pointer items-center gap-2 text-sm text-ink", className)}>
      <input type="checkbox" {...props} className="size-4 rounded-[3px] border-line accent-[var(--color-charcoal)]" />
      {label}
    </label>
  );
}
