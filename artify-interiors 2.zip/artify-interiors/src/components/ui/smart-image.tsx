"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/format";

/**
 * <img> with a graceful fallback: if the image fails (missing file, offline CDN) a quiet
 * travertine panel with a hairline frame is shown instead of a broken icon.
 */
export function SmartImage({ src, alt, className, imgClassName, eager, fallbackLabel }: { src?: string | null; alt: string; className?: string; imgClassName?: string; eager?: boolean; fallbackLabel?: string }) {
  const [failed, setFailed] = useState(!src);
  const ref = useRef<HTMLImageElement>(null);

  useEffect(() => {
    setFailed(!src);
  }, [src]);

  // The error event can fire before hydration attaches onError — check the element once mounted.
  useEffect(() => {
    const img = ref.current;
    if (img && img.complete && img.naturalWidth === 0) setFailed(true);
  }, [src]);

  const positioned = /\b(absolute|fixed)\b/.test(className ?? "");
  return (
    <div className={cn("overflow-hidden bg-travertine", !positioned && "relative", className)}>
      {!failed && src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img ref={ref} src={src} alt={alt} loading={eager ? "eager" : "lazy"} decoding="async" onError={() => setFailed(true)} className={cn("h-full w-full object-cover", imgClassName)} />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center bg-[linear-gradient(135deg,var(--color-travertine),var(--color-plaster))]">
          <div className="absolute inset-3 border border-sand/70" />
          <span className="relative px-4 text-center font-display text-lg text-smoke">{fallbackLabel ?? alt}</span>
        </div>
      )}
    </div>
  );
}
