import type { ReactNode } from "react";
import { cn } from "@/lib/format";

export function Panel({ children, className, padded = true }: { children: ReactNode; className?: string; padded?: boolean }) {
  return <section className={cn("rounded-[var(--radius-md)] border border-line bg-paper", padded && "p-5 md:p-6", className)}>{children}</section>;
}

export function PanelHeader({ title, description, actions, className }: { title: ReactNode; description?: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <div className={cn("mb-4 flex flex-wrap items-start justify-between gap-3", className)}>
      <div className="min-w-0">
        <h2 className="font-sans text-[0.95rem] font-semibold tracking-normal text-charcoal">{title}</h2>
        {description ? <p className="mt-0.5 text-sm text-smoke">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function PageHeader({ title, description, actions, back }: { title: ReactNode; description?: ReactNode; actions?: ReactNode; back?: ReactNode }) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-4 md:mb-8">
      <div className="min-w-0">
        {back ? <div className="mb-2 text-sm">{back}</div> : null}
        <h1 className="text-3xl md:text-[2.4rem]">{title}</h1>
        {description ? <p className="mt-1.5 max-w-2xl text-sm text-smoke md:text-[0.95rem]">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </header>
  );
}

export function StatCard({ label, value, hint, tone = "default" }: { label: string; value: ReactNode; hint?: ReactNode; tone?: "default" | "brass" | "moss" | "amber" }) {
  const accent = { default: "bg-sand", brass: "bg-brass", moss: "bg-moss", amber: "bg-amber" }[tone];
  return (
    <div className="relative overflow-hidden rounded-[var(--radius-md)] border border-line bg-paper px-4 py-4">
      <span className={cn("absolute inset-y-0 left-0 w-[3px]", accent)} aria-hidden />
      <p className="text-[0.78rem] text-smoke">{label}</p>
      <p className="mt-1 font-display text-[1.9rem] leading-none text-charcoal tabular-nums">{value}</p>
      {hint ? <p className="mt-1.5 text-xs text-smoke">{hint}</p> : null}
    </div>
  );
}

export function EmptyState({ title, description, action, icon }: { title: string; description?: ReactNode; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-[var(--radius-md)] border border-dashed border-line bg-paper/60 px-6 py-12 text-center">
      {icon ? <div className="mb-3 text-brass">{icon}</div> : null}
      <p className="font-display text-2xl text-charcoal">{title}</p>
      {description ? <p className="mt-1.5 max-w-md text-sm text-smoke">{description}</p> : null}
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  );
}
