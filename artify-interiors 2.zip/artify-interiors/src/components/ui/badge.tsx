import type { ReactNode } from "react";
import { cn } from "@/lib/format";

export type Tone = "neutral" | "brass" | "moss" | "amber" | "brick" | "slate" | "dark";

const tones: Record<Tone, string> = {
  neutral: "bg-travertine/70 text-ink",
  brass: "bg-brass-soft text-brass-deep",
  moss: "bg-moss-soft text-moss",
  amber: "bg-amber-soft text-amber",
  brick: "bg-brick-soft text-brick",
  slate: "bg-slate-soft text-slate",
  dark: "bg-charcoal text-paper",
};

export function Badge({ children, tone = "neutral", className }: { children: ReactNode; tone?: Tone; className?: string }) {
  return <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[0.72rem] font-semibold whitespace-nowrap", tones[tone], className)}>{children}</span>;
}

const STATUS_TONES: Record<string, Tone> = {
  // projects
  DRAFT: "neutral",
  DESIGN: "slate",
  QUOTATION: "brass",
  ACTIVE: "moss",
  ON_HOLD: "amber",
  COMPLETED: "dark",
  CANCELLED: "brick",
  // quotations
  SENT: "slate",
  CHANGES_REQUESTED: "amber",
  APPROVED: "moss",
  REJECTED: "brick",
  SUPERSEDED: "neutral",
  // leads
  NEW: "brass",
  CONTACTED: "slate",
  CONSULTATION: "slate",
  QUOTATION_SENT: "brass",
  CONVERTED: "moss",
  LOST: "brick",
  // milestones / generic
  PENDING: "neutral",
  IN_PROGRESS: "slate",
  SKIPPED: "neutral",
  BLOCKED: "brick",
  PARTIAL: "amber",
  PAID: "moss",
  SUCCESS: "moss",
  FAILED: "brick",
  PROCESSING: "slate",
  NOT_CONFIGURED: "amber",
  GENERATED: "neutral",
  SAVED: "brass",
  PRELIMINARY: "amber",
  VERIFIED: "moss",
  FINAL: "dark",
  IN_STOCK: "moss",
  LIMITED: "amber",
  ON_ORDER: "slate",
  DISCONTINUED: "brick",
  SKIPPED_NOT_CONFIGURED: "amber",
};

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  const text = label ?? status.replace(/_/g, " ").toLowerCase().replace(/^\w/, (c) => c.toUpperCase());
  return <Badge tone={STATUS_TONES[status] ?? "neutral"}>{text}</Badge>;
}
