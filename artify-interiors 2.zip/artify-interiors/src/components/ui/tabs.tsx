"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/format";

/** Route-based tabs (each tab is its own URL; pass `active` when tabs differ only by query string). */
export function TabNav({ tabs }: { tabs: { href: string; label: string; count?: number; exact?: boolean; active?: boolean }[] }) {
  const pathname = usePathname();
  return (
    <nav className="-mx-1 mb-6 flex gap-1 overflow-x-auto border-b border-line px-1" aria-label="Sections">
      {tabs.map((t) => {
        const active = t.active !== undefined ? t.active : t.exact ? pathname === t.href : pathname === t.href || pathname.startsWith(`${t.href}/`);
        return (
          <Link
            key={t.href}
            href={t.href}
            aria-current={active ? "page" : undefined}
            className={cn(
              "relative -mb-px flex shrink-0 items-center gap-1.5 border-b-2 px-3 py-2.5 text-sm transition-colors",
              active ? "border-charcoal font-semibold text-charcoal" : "border-transparent text-smoke hover:text-charcoal",
            )}
          >
            {t.label}
            {typeof t.count === "number" ? <span className="rounded-full bg-travertine px-1.5 text-[0.7rem] font-semibold text-ink">{t.count}</span> : null}
          </Link>
        );
      })}
    </nav>
  );
}
