import type { ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Info, PlugZap, XCircle } from "lucide-react";
import { cn } from "@/lib/format";

type Kind = "info" | "warning" | "error" | "success" | "config";

const styles: Record<Kind, { box: string; Icon: typeof Info }> = {
  info: { box: "border-slate/25 bg-slate-soft/70 text-slate", Icon: Info },
  warning: { box: "border-amber/30 bg-amber-soft text-amber", Icon: AlertTriangle },
  error: { box: "border-brick/30 bg-brick-soft text-brick", Icon: XCircle },
  success: { box: "border-moss/30 bg-moss-soft text-moss", Icon: CheckCircle2 },
  config: { box: "border-brass/35 bg-brass-soft text-brass-deep", Icon: PlugZap },
};

export function Notice({ kind = "info", title, children, className, action }: { kind?: Kind; title?: ReactNode; children?: ReactNode; className?: string; action?: ReactNode }) {
  const { box, Icon } = styles[kind];
  return (
    <div role={kind === "error" ? "alert" : "status"} className={cn("flex gap-3 rounded-[var(--radius-md)] border px-4 py-3 text-sm", box, className)}>
      <Icon className="mt-0.5 size-4 shrink-0" aria-hidden />
      <div className="min-w-0 flex-1 text-ink">
        {title ? <p className="font-semibold text-charcoal">{title}</p> : null}
        {children ? <div className={cn("text-[0.85rem] leading-relaxed", title ? "mt-0.5" : null)}>{children}</div> : null}
      </div>
      {action ? <div className="shrink-0 self-center">{action}</div> : null}
    </div>
  );
}
