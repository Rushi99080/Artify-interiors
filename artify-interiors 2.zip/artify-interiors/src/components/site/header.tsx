import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { Logo } from "@/components/brand/logo";
import { ButtonLink } from "@/components/ui/button";
import { MobileMenu } from "@/components/site/mobile-menu";
import { NavLinks } from "@/components/site/nav-links";

export const NAV_LINKS = [
  { href: "/designs", label: "Explore Designs" },
  { href: "/ai-designer", label: "AI Interior Designer" },
  { href: "/services", label: "Our Services" },
  { href: "/materials", label: "Materials Library" },
  { href: "/cost-calculator", label: "Cost Calculator" },
  { href: "/about", label: "About Us" },
  { href: "/contact", label: "Contact" },
];

export async function SiteHeader({ overlay = false }: { overlay?: boolean }) {
  const user = await getCurrentUser().catch(() => null);
  const dashHref = user && (user.role === "ADMIN" || user.role === "STAFF") ? "/admin" : "/dashboard";
  return (
    <header className={overlay ? "absolute inset-x-0 top-0 z-40" : "sticky top-0 z-40 border-b border-line/70 bg-plaster/90 backdrop-blur-md"}>
      <div className="container-page flex h-[72px] items-center justify-between gap-6">
        <Link href="/" aria-label="Artify Interiors — home" className="shrink-0">
          <Logo />
        </Link>
        <NavLinks links={NAV_LINKS} />
        <div className="hidden items-center gap-2 xl:flex">
          {user ? (
            <ButtonLink href={dashHref} variant="primary" size="sm">
              {user.role === "CUSTOMER" ? "My Projects" : "Admin"}
            </ButtonLink>
          ) : (
            <>
              <Link href="/login" className="px-3 py-2 text-sm text-ink hover:text-charcoal">
                Login
              </Link>
              <ButtonLink href="/register" variant="primary" size="sm">
                Register
              </ButtonLink>
            </>
          )}
        </div>
        <MobileMenu links={[{ href: "/", label: "Home" }, ...NAV_LINKS]} user={user ? { name: user.name, dashHref, isCustomer: user.role === "CUSTOMER" } : null} />
      </div>
    </header>
  );
}
