import Link from "next/link";
import { Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { getSettings } from "@/lib/settings";
import { ROOM_MODULES } from "@/lib/constants";

export async function SiteFooter() {
  const { company } = await getSettings();
  const year = new Date().getFullYear();
  return (
    <footer className="mt-24 bg-charcoal text-sand">
      <div className="container-page grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo tone="light" />
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-sand/80">{company.tagline}. Homes, offices and commercial spaces — designed, estimated and delivered by one team.</p>
          <div className="mt-6 space-y-2 text-sm">
            <p className="flex items-start gap-2">
              <MapPin className="mt-0.5 size-4 shrink-0 text-brass" /> {company.address}
            </p>
            {company.phone ? (
              <a href={`tel:${company.phone.replace(/\s/g, "")}`} className="flex items-center gap-2 hover:text-paper">
                <Phone className="size-4 text-brass" /> {company.phone}
              </a>
            ) : null}
            {company.email ? (
              <a href={`mailto:${company.email}`} className="flex items-center gap-2 hover:text-paper">
                <Mail className="size-4 text-brass" /> {company.email}
              </a>
            ) : null}
          </div>
        </div>
        <FooterCol
          title="Studio"
          links={[
            { href: "/", label: "Home" },
            { href: "/designs", label: "Explore Designs" },
            { href: "/about", label: "About Us" },
            { href: "/contact", label: "Contact" },
          ]}
        />
        <FooterCol
          title="Plan your space"
          links={[
            { href: "/ai-designer", label: "AI Interior Designer" },
            { href: "/visualizer", label: "3D Room Visualizer" },
            { href: "/cost-calculator", label: "Cost Calculator" },
            { href: "/materials", label: "Materials Library" },
          ]}
        />
        <FooterCol title="Services" links={ROOM_MODULES.filter((m) => m.showInServices).slice(0, 6).map((m) => ({ href: `/services/${m.slug}`, label: m.label }))} />
      </div>
      <div className="border-t border-white/10">
        <div className="container-page flex flex-col gap-2 py-5 text-xs text-sand/60 md:flex-row md:items-center md:justify-between">
          <p>
            © {year} {company.legalName}. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/login" className="hover:text-paper">
              Client login
            </Link>
            <Link href="/register" className="hover:text-paper">
              Create account
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <p className="font-display text-xl text-paper">{title}</p>
      <ul className="mt-4 space-y-2.5 text-sm">
        {links.map((l) => (
          <li key={l.href}>
            <Link href={l.href} className="link-underline text-sand/85 hover:text-paper">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
