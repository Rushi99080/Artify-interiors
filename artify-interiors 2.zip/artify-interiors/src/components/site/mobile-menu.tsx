"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { cn } from "@/lib/format";

export function MobileMenu({ links, user }: { links: { href: string; label: string }[]; user: { name: string; dashHref: string; isCustomer: boolean } | null }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="xl:hidden">
      <button type="button" onClick={() => setOpen(true)} className="rounded p-2 text-charcoal hover:bg-travertine/60" aria-label="Open menu" aria-expanded={open}>
        <Menu className="size-6" />
      </button>
      {open ? (
        <div className="fixed inset-0 z-50 flex flex-col bg-plaster fade-in" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="container-page flex h-[72px] items-center justify-between">
            <Logo />
            <button type="button" onClick={() => setOpen(false)} className="rounded p-2 text-charcoal hover:bg-travertine/60" aria-label="Close menu">
              <X className="size-6" />
            </button>
          </div>
          <nav className="container-page flex flex-1 flex-col overflow-y-auto pb-8 pt-4">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className={cn("border-b border-line-soft py-3.5 font-display text-[1.7rem] leading-tight", pathname === l.href ? "text-brass-deep" : "text-charcoal")}>
                {l.label}
              </Link>
            ))}
            <div className="mt-8 flex flex-col gap-3">
              {user ? (
                <Link href={user.dashHref} className="rounded-[var(--radius-sm)] bg-charcoal px-4 py-3 text-center text-paper">
                  {user.isCustomer ? "My Projects" : "Admin dashboard"}
                </Link>
              ) : (
                <>
                  <Link href="/register" className="rounded-[var(--radius-sm)] bg-charcoal px-4 py-3 text-center text-paper">
                    Create an account
                  </Link>
                  <Link href="/login" className="rounded-[var(--radius-sm)] border border-line px-4 py-3 text-center text-charcoal">
                    Login
                  </Link>
                </>
              )}
            </div>
          </nav>
        </div>
      ) : null}
    </div>
  );
}
