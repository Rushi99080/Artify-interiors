"use client";

import { useState, type FormEvent } from "react";
import { CheckCircle2 } from "lucide-react";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { BUDGET_RANGES, PROPERTY_TYPES, PROPERTY_TYPE_LABELS } from "@/lib/constants";
import { cn } from "@/lib/format";

type Props = { source?: "WEBSITE" | "COST_CALCULATOR" | "AI_DESIGNER"; compact?: boolean; meta?: Record<string, unknown>; defaultMessage?: string; submitLabel?: string; className?: string };

export function LeadForm({ source = "WEBSITE", compact, meta, defaultMessage, submitLabel = "Request a consultation", className }: Props) {
  const [state, setState] = useState<"idle" | "sending" | "done">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [leadCode, setLeadCode] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setState("sending");
    setErrors({});
    setFormError(null);
    try {
      const res = await api<{ leadCode: string }>("/api/leads", {
        body: {
          name: fd.get("name"),
          phone: fd.get("phone"),
          email: fd.get("email"),
          city: fd.get("city"),
          projectType: fd.get("projectType") || null,
          budget: fd.get("budget") || null,
          message: fd.get("message"),
          website: fd.get("website"),
          source,
          meta,
        },
      });
      setLeadCode(res.leadCode);
      setState("done");
    } catch (err) {
      setState("idle");
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      setFormError(errorMessage(err));
    }
  }

  if (state === "done") {
    return (
      <div className={cn("rounded-[var(--radius-md)] border border-moss/30 bg-moss-soft/60 p-6", className)}>
        <CheckCircle2 className="size-6 text-moss" />
        <p className="mt-3 font-display text-2xl text-charcoal">Thank you — we have your enquiry.</p>
        <p className="mt-1 text-sm text-ink">Reference {leadCode}. A designer will call you within one working day to schedule a consultation.</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className={cn("grid gap-4", !compact && "sm:grid-cols-2", className)} noValidate>
      <Field label="Full name" error={errors.name} required htmlFor="lf-name">
        <Input id="lf-name" name="name" autoComplete="name" required invalid={!!errors.name} />
      </Field>
      <Field label="Mobile number" error={errors.phone} required htmlFor="lf-phone">
        <Input id="lf-phone" name="phone" type="tel" autoComplete="tel" inputMode="tel" placeholder="+91 98xxx xxxxx" required invalid={!!errors.phone} />
      </Field>
      <Field label="Email" error={errors.email} htmlFor="lf-email">
        <Input id="lf-email" name="email" type="email" autoComplete="email" invalid={!!errors.email} />
      </Field>
      <Field label="City / area" error={errors.city} htmlFor="lf-city">
        <Input id="lf-city" name="city" autoComplete="address-level2" placeholder="Baner, Pune" />
      </Field>
      {!compact ? (
        <>
          <Field label="Property type" htmlFor="lf-type">
            <Select id="lf-type" name="projectType" defaultValue="">
              <option value="">Select</option>
              {PROPERTY_TYPES.map((p) => (
                <option key={p} value={p}>
                  {PROPERTY_TYPE_LABELS[p]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Budget" htmlFor="lf-budget">
            <Select id="lf-budget" name="budget" defaultValue="">
              <option value="">Not sure yet</option>
              {BUDGET_RANGES.map((b) => (
                <option key={b.label} value={b.label}>
                  {b.label}
                </option>
              ))}
            </Select>
          </Field>
        </>
      ) : null}
      <Field label="Tell us about your space" error={errors.message} className={compact ? "" : "sm:col-span-2"} htmlFor="lf-msg">
        <Textarea id="lf-msg" name="message" defaultValue={defaultMessage} placeholder="Rooms you want to do, possession date, styles you like…" />
      </Field>
      {/* honeypot */}
      <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      {formError ? <p className="text-sm text-brick sm:col-span-2">{formError}</p> : null}
      <div className={compact ? "" : "sm:col-span-2"}>
        <Button type="submit" size="lg" loading={state === "sending"} className="w-full sm:w-auto">
          {submitLabel}
        </Button>
      </div>
    </form>
  );
}
