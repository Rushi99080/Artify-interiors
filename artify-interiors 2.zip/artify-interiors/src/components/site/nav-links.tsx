"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/format";

export function NavLinks({ links }: { links: { href: string; label: string }[] }) {
  const pathname = usePathname();
  return (
    <nav className="hidden items-center gap-0.5 xl:flex" aria-label="Main">
      {links.map((l) => {
        const active = pathname === l.href || pathname.startsWith(`${l.href}/`);
        return (
          <Link
            key={l.href}
            href={l.href}
            aria-current={active ? "page" : undefined}
            className={cn("relative px-2.5 py-2 text-[0.84rem] transition-colors", active ? "text-charcoal" : "text-smoke hover:text-charcoal")}
          >
            {l.label}
            {active ? <span className="absolute inset-x-2.5 -bottom-0.5 h-px bg-brass" aria-hidden /> : null}
          </Link>
        );
      })}
    </nav>
  );
}
