"use client";

import { Canvas } from "@react-three/fiber";
import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Camera, Copy, FolderOpen, RotateCw, Save, Trash2 } from "lucide-react";
import { VisualizerScene } from "@/components/visualizer/scene";
import { CAMERAS, FABRIC_SWATCHES, FLOORS, FURNITURE, LIGHTING, WALL_SWATCHES, defaultConfig, defaultLayout, newId, type CameraKind, type FloorKind, type FurnitureType, type LightingKind, type VizConfig } from "@/components/visualizer/model";
import { ROOM_MODULES } from "@/lib/constants";
import { api, errorMessage } from "@/lib/client/api";
import { cn, formatRelative } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";

export type VizProject = { id: string; name: string; rooms: { id: string; name: string; type: string; lengthFt: number | null; widthFt: number | null; heightFt: number | null }[] };
type Saved = { id: string; name: string; projectId: string | null; config: VizConfig; updatedAt: string };

export default function Visualizer({ signedIn, projects, initialProjectId, initialRoomType, initialDims }: { signedIn: boolean; projects: VizProject[]; initialProjectId?: string | null; initialRoomType?: string; initialDims?: { lengthFt: number; widthFt: number; heightFt: number } }) {
  const { toast } = useToast();
  const [roomType, setRoomType] = useState<string>(initialRoomType ?? "LIVING_ROOM");
  const [config, setConfig] = useState<VizConfig>(() => defaultConfig(initialRoomType ?? "LIVING_ROOM", initialDims));
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [projectId, setProjectId] = useState<string>(initialProjectId ?? "");
  const [saveOpen, setSaveOpen] = useState(false);
  const [loadOpen, setLoadOpen] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const patch = useCallback((p: Partial<VizConfig>) => setConfig((c) => ({ ...c, ...p })), []);
  const selected = config.items.find((i) => i.id === selectedId) ?? null;
  const updateItem = (id: string, p: Partial<VizConfig["items"][number]>) => setConfig((c) => ({ ...c, items: c.items.map((i) => (i.id === id ? { ...i, ...p } : i)) }));

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!selectedId || (e.target as HTMLElement)?.closest("input,select,textarea")) return;
      const step = e.shiftKey ? 1 : 0.25;
      const it = config.items.find((i) => i.id === selectedId);
      if (!it) return;
      if (e.key === "ArrowLeft") updateItem(it.id, { x: it.x - step });
      else if (e.key === "ArrowRight") updateItem(it.id, { x: it.x + step });
      else if (e.key === "ArrowUp") updateItem(it.id, { z: it.z - step });
      else if (e.key === "ArrowDown") updateItem(it.id, { z: it.z + step });
      else if (e.key.toLowerCase() === "r") updateItem(it.id, { rot: it.rot + Math.PI / 2 });
      else if (e.key === "Delete" || e.key === "Backspace") {
        setConfig((c) => ({ ...c, items: c.items.filter((i) => i.id !== it.id) }));
        setSelectedId(null);
      } else return;
      e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function applyRoom(type: string, dims: { lengthFt: number; widthFt: number; heightFt: number }) {
    setRoomType(type);
    setConfig((c) => ({ ...c, room: dims, items: defaultLayout(type, dims.lengthFt, dims.widthFt) }));
    setSelectedId(null);
  }

  function screenshot() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const a = document.createElement("a");
    a.href = canvas.toDataURL("image/png");
    a.download = `artify-room-${Date.now()}.png`;
    a.click();
    toast("Screenshot downloaded");
  }

  const project = projects.find((p) => p.id === projectId);

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_330px]">
      <div className="relative">
        <div className="relative h-[58vh] min-h-[380px] overflow-hidden rounded-[var(--radius-md)] border border-line bg-[#efebe4] lg:h-[calc(100svh-210px)]">
          <Canvas
            shadows
            dpr={[1, 2]}
            gl={{ preserveDrawingBuffer: true, antialias: true }}
            camera={{ position: [10, 12, 18], fov: 45, near: 0.1, far: 500 }}
            onCreated={({ gl }) => {
              canvasRef.current = gl.domElement;
            }}
          >
            <VisualizerScene config={config} selectedId={selectedId} onSelect={setSelectedId} onMove={(id, x, z) => updateItem(id, { x, z })} />
          </Canvas>
          <div className="pointer-events-none absolute left-3 top-3 max-w-[calc(100%-1.5rem)] rounded-[var(--radius-sm)] bg-paper/90 px-3 py-1.5 text-[0.72rem] text-smoke backdrop-blur">
            Approximate visualization for planning — not a construction drawing. Drag furniture to move it; R rotates, Delete removes.
          </div>
          <div className="absolute bottom-3 left-3 flex flex-wrap gap-1.5">
            {(Object.keys(CAMERAS) as CameraKind[]).map((k) => (
              <button key={k} type="button" onClick={() => patch({ camera: k })} className={cn("rounded-full px-3 py-1.5 text-xs backdrop-blur transition-colors", config.camera === k ? "bg-charcoal text-paper" : "bg-paper/85 text-ink hover:bg-paper")}>
                {CAMERAS[k]}
              </button>
            ))}
          </div>
          <div className="absolute bottom-3 right-3 flex gap-1.5">
            <Button size="sm" variant="light" onClick={screenshot}>
              <Camera className="size-4" /> Screenshot
            </Button>
          </div>
        </div>
      </div>

      <aside className="space-y-5 text-sm lg:max-h-[calc(100svh-210px)] lg:overflow-y-auto lg:pr-1">
        <Panel title="Room">
          {signedIn && projects.length ? (
            <Field label="Load dimensions from a project room" htmlFor="viz-proj">
              <Select
                id="viz-proj"
                value={projectId}
                onChange={(e) => {
                  setProjectId(e.target.value);
                }}
              >
                <option value="">No project</option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
          {project ? (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {project.rooms.map((r) => (
                <button key={r.id} type="button" onClick={() => applyRoom(r.type, { lengthFt: r.lengthFt ?? 14, widthFt: r.widthFt ?? 12, heightFt: r.heightFt ?? 10 })} className="rounded-full border border-line bg-white px-2.5 py-1 text-xs text-ink hover:border-brass">
                  {r.name}
                </button>
              ))}
            </div>
          ) : null}
          <Field label="Room type" htmlFor="viz-type" className="mt-3">
            <Select id="viz-type" value={roomType} onChange={(e) => applyRoom(e.target.value, config.room)}>
              {ROOM_MODULES.map((m) => (
                <option key={m.type} value={m.type}>
                  {m.label}
                </option>
              ))}
            </Select>
          </Field>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {(["lengthFt", "widthFt", "heightFt"] as const).map((k) => (
              <Field key={k} label={k === "lengthFt" ? "Length" : k === "widthFt" ? "Width" : "Height"} htmlFor={`viz-${k}`}>
                <Input
                  id={`viz-${k}`}
                  type="number"
                  min={k === "heightFt" ? 7 : 4}
                  max={60}
                  step={0.5}
                  value={config.room[k]}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    if (Number.isFinite(v) && v >= (k === "heightFt" ? 7 : 4) && v <= 60) patch({ room: { ...config.room, [k]: v } });
                  }}
                />
              </Field>
            ))}
          </div>
        </Panel>

        <Panel title="Walls & floor">
          <p className="text-xs text-smoke">Wall colour</p>
          <Swatches value={config.wallColor} options={WALL_SWATCHES} onChange={(c) => patch({ wallColor: c })} />
          <div className="mt-3 flex items-center justify-between gap-3">
            <Checkbox label="Accent wall" checked={config.accentWall.enabled} onChange={(e) => patch({ accentWall: { ...config.accentWall, enabled: e.target.checked } })} />
            <Select aria-label="Accent wall position" value={config.accentWall.wall} onChange={(e) => patch({ accentWall: { ...config.accentWall, wall: e.target.value as "back" | "left" | "right" } })} className="w-auto py-1.5 text-xs" disabled={!config.accentWall.enabled}>
              <option value="back">Back wall</option>
              <option value="left">Left wall</option>
              <option value="right">Right wall</option>
            </Select>
          </div>
          {config.accentWall.enabled ? <Swatches value={config.accentWall.color} options={WALL_SWATCHES} onChange={(c) => patch({ accentWall: { ...config.accentWall, color: c } })} /> : null}
          <Field label="Flooring" htmlFor="viz-floor" className="mt-3">
            <Select id="viz-floor" value={config.floor} onChange={(e) => patch({ floor: e.target.value as FloorKind })}>
              {(Object.keys(FLOORS) as FloorKind[]).map((f) => (
                <option key={f} value={f}>
                  {FLOORS[f]}
                </option>
              ))}
            </Select>
          </Field>
        </Panel>

        <Panel title="Lighting">
          <div className="grid grid-cols-2 gap-1.5">
            {(Object.keys(LIGHTING) as LightingKind[]).map((l) => (
              <button key={l} type="button" onClick={() => patch({ lighting: l })} aria-pressed={config.lighting === l} className={cn("rounded-[var(--radius-sm)] border px-2.5 py-2 text-left text-xs", config.lighting === l ? "border-brass bg-brass-soft text-charcoal" : "border-line bg-white text-ink hover:border-sand")}>
                {LIGHTING[l]}
              </button>
            ))}
          </div>
          <div className="mt-3">
            <Checkbox label="Cove lighting" checked={config.cove} onChange={(e) => patch({ cove: e.target.checked })} />
          </div>
        </Panel>

        <Panel title="Furniture">
          <Select
            aria-label="Add furniture"
            value=""
            onChange={(e) => {
              const type = e.target.value as FurnitureType;
              if (!type) return;
              const it = { id: newId(), type, x: 0, z: 0, rot: 0, color: FURNITURE[type].defaultColor };
              setConfig((c) => ({ ...c, items: [...c.items, it] }));
              setSelectedId(it.id);
            }}
          >
            <option value="">Add an item…</option>
            {(Object.keys(FURNITURE) as FurnitureType[]).map((f) => (
              <option key={f} value={f}>
                {FURNITURE[f].label}
              </option>
            ))}
          </Select>
          <ul className="mt-2 max-h-40 space-y-1 overflow-y-auto">
            {config.items.map((i) => (
              <li key={i.id}>
                <button type="button" onClick={() => setSelectedId(i.id)} className={cn("flex w-full items-center gap-2 rounded px-2 py-1 text-left text-xs", i.id === selectedId ? "bg-brass-soft text-charcoal" : "text-ink hover:bg-travertine/50")}>
                  <span className="size-3 rounded-full border border-line" style={{ background: i.color }} />
                  {FURNITURE[i.type].label}
                </button>
              </li>
            ))}
          </ul>
          {selected ? (
            <div className="mt-3 rounded-[var(--radius-sm)] border border-line bg-white p-3">
              <p className="text-xs font-semibold text-charcoal">{FURNITURE[selected.type].label}</p>
              <p className="mt-2 text-xs text-smoke">{FURNITURE[selected.type].colorLabel}</p>
              <Swatches value={selected.color} options={FABRIC_SWATCHES} onChange={(c) => updateItem(selected.id, { color: c })} />
              <div className="mt-3 flex flex-wrap gap-1.5">
                <IconBtn label="Move left" onClick={() => updateItem(selected.id, { x: selected.x - 0.5 })}>
                  <ArrowLeft className="size-3.5" />
                </IconBtn>
                <IconBtn label="Move right" onClick={() => updateItem(selected.id, { x: selected.x + 0.5 })}>
                  <ArrowRight className="size-3.5" />
                </IconBtn>
                <IconBtn label="Move back" onClick={() => updateItem(selected.id, { z: selected.z - 0.5 })}>
                  <ArrowUp className="size-3.5" />
                </IconBtn>
                <IconBtn label="Move forward" onClick={() => updateItem(selected.id, { z: selected.z + 0.5 })}>
                  <ArrowDown className="size-3.5" />
                </IconBtn>
                <IconBtn label="Rotate 90°" onClick={() => updateItem(selected.id, { rot: selected.rot + Math.PI / 2 })}>
                  <RotateCw className="size-3.5" />
                </IconBtn>
                <IconBtn
                  label="Duplicate"
                  onClick={() => {
                    const copy = { ...selected, id: newId(), x: selected.x + 1, z: selected.z + 1 };
                    setConfig((c) => ({ ...c, items: [...c.items, copy] }));
                    setSelectedId(copy.id);
                  }}
                >
                  <Copy className="size-3.5" />
                </IconBtn>
                <IconBtn
                  label="Remove"
                  onClick={() => {
                    setConfig((c) => ({ ...c, items: c.items.filter((i) => i.id !== selected.id) }));
                    setSelectedId(null);
                  }}
                >
                  <Trash2 className="size-3.5" />
                </IconBtn>
              </div>
            </div>
          ) : null}
          <Button variant="ghost" size="sm" className="mt-2" onClick={() => applyRoom(roomType, config.room)}>
            Reset layout
          </Button>
        </Panel>

        <div className="flex gap-2">
          <Button className="flex-1" onClick={() => (signedIn ? setSaveOpen(true) : (window.location.href = `/login?next=${encodeURIComponent("/visualizer")}`))}>
            <Save className="size-4" /> Save
          </Button>
          <Button variant="secondary" className="flex-1" disabled={!signedIn} onClick={() => setLoadOpen(true)}>
            <FolderOpen className="size-4" /> Open saved
          </Button>
        </div>
        {!signedIn ? <p className="text-xs text-smoke">Log in to save configurations to your project.</p> : null}
      </aside>

      <SaveModal open={saveOpen} onClose={() => setSaveOpen(false)} projects={projects} defaultProjectId={projectId} config={config} />
      <LoadModal
        open={loadOpen}
        onClose={() => setLoadOpen(false)}
        projectId={projectId || null}
        onLoad={(c) => {
          setConfig(c);
          setSelectedId(null);
          setLoadOpen(false);
          toast("Configuration loaded");
        }}
      />
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-[var(--radius-md)] border border-line bg-paper p-4">
      <h2 className="mb-3 font-sans text-[0.8rem] font-semibold text-charcoal">{title}</h2>
      {children}
    </section>
  );
}

function Swatches({ value, options, onChange }: { value: string; options: string[]; onChange: (c: string) => void }) {
  return (
    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
      {options.map((c) => (
        <button key={c} type="button" onClick={() => onChange(c)} aria-label={`Colour ${c}`} aria-pressed={value === c} className={cn("size-6 rounded-full border transition-transform hover:scale-110", value === c ? "border-charcoal ring-2 ring-brass/50" : "border-line")} style={{ background: c }} />
      ))}
      <label className="relative size-6 cursor-pointer overflow-hidden rounded-full border border-dashed border-sand" title="Custom colour">
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="absolute inset-0 size-full cursor-pointer opacity-0" aria-label="Custom colour" />
        <span className="flex size-full items-center justify-center text-[0.6rem] text-smoke">+</span>
      </label>
    </div>
  );
}

function IconBtn({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} aria-label={label} title={label} className="rounded border border-line bg-paper p-1.5 text-ink hover:border-sand hover:text-charcoal">
      {children}
    </button>
  );
}

function SaveModal({ open, onClose, projects, defaultProjectId, config }: { open: boolean; onClose: () => void; projects: VizProject[]; defaultProjectId: string; config: VizConfig }) {
  const { toast } = useToast();
  const [name, setName] = useState("My room layout");
  const [projectId, setProjectId] = useState(defaultProjectId);
  const [busy, setBusy] = useState(false);
  useEffect(() => setProjectId(defaultProjectId), [defaultProjectId]);
  async function save() {
    setBusy(true);
    try {
      await api("/api/visualizer", { body: { name, projectId: projectId || null, config } });
      toast("Configuration saved");
      onClose();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Save configuration"
      size="sm"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={busy} disabled={!name.trim()}>
            <Save className="size-4" /> Save
          </Button>
        </>
      }
    >
      <div className="grid gap-4">
        <Field label="Name" htmlFor="save-name">
          <Input id="save-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
        </Field>
        {projects.length ? (
          <Field label="Attach to project" htmlFor="save-proj">
            <Select id="save-proj" value={projectId} onChange={(e) => setProjectId(e.target.value)}>
              <option value="">Not attached</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
        ) : null}
      </div>
    </Modal>
  );
}

function LoadModal({ open, onClose, onLoad, projectId }: { open: boolean; onClose: () => void; onLoad: (c: VizConfig) => void; projectId: string | null }) {
  const { toast } = useToast();
  const [items, setItems] = useState<Saved[] | null>(null);
  useEffect(() => {
    if (!open) return;
    setItems(null);
    api<{ configs: Saved[] }>(`/api/visualizer${projectId ? `?projectId=${projectId}` : ""}`)
      .then((r) => setItems(r.configs))
      .catch((err) => {
        toast(errorMessage(err), "error");
        setItems([]);
      });
  }, [open, projectId, toast]);
  async function remove(id: string) {
    try {
      await api(`/api/visualizer/${id}`, { method: "DELETE" });
      setItems((l) => l?.filter((x) => x.id !== id) ?? null);
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }
  return (
    <Modal open={open} onClose={onClose} title="Saved configurations" size="md">
      {items === null ? (
        <p className="text-sm text-smoke">Loading…</p>
      ) : items.length === 0 ? (
        <p className="text-sm text-smoke">No saved configurations yet.</p>
      ) : (
        <ul className="divide-y divide-line-soft">
          {items.map((s) => (
            <li key={s.id} className="flex items-center justify-between gap-3 py-2.5">
              <div>
                <p className="text-sm text-charcoal">{s.name}</p>
                <p className="text-xs text-smoke">
                  {s.config.room.lengthFt}′ × {s.config.room.widthFt}′ · {s.config.items.length} items · {formatRelative(s.updatedAt)}
                </p>
              </div>
              <div className="flex gap-1.5">
                <Button size="sm" onClick={() => onLoad(s.config)}>
                  Open
                </Button>
                <Button size="sm" variant="ghost" onClick={() => remove(s.id)} aria-label={`Delete ${s.name}`}>
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Modal>
  );
}

