"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import { ContactShadows, Html, OrbitControls, useCursor } from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { FURNITURE, ftIn, type CameraKind, type FloorKind, type LightingKind, type VizConfig, type VizItem } from "@/components/visualizer/model";

// ── Procedural floor textures (no external assets needed) ─────────────────

function makeFloorTexture(kind: FloorKind) {
  const size = 512;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d")!;
  const rand = (a: number, b: number) => a + Math.random() * (b - a);
  const plank = (base: [number, number, number], vertical = true) => {
    const rows = 8;
    const h = size / rows;
    for (let r = 0; r < rows; r++) {
      let x = -rand(0, size / 2);
      while (x < size) {
        const len = rand(size * 0.35, size * 0.8);
        const v = rand(-14, 14);
        g.fillStyle = `rgb(${base[0] + v},${base[1] + v},${base[2] + v})`;
        if (vertical) g.fillRect(r * h, x, h - 2, len - 2);
        else g.fillRect(x, r * h, len - 2, h - 2);
        for (let i = 0; i < 6; i++) {
          g.strokeStyle = `rgba(0,0,0,${rand(0.03, 0.07)})`;
          g.beginPath();
          const off = rand(4, h - 4);
          if (vertical) {
            g.moveTo(r * h + off, x);
            g.lineTo(r * h + off + rand(-3, 3), x + len);
          } else {
            g.moveTo(x, r * h + off);
            g.lineTo(x + len, r * h + off + rand(-3, 3));
          }
          g.stroke();
        }
        x += len;
      }
    }
  };
  switch (kind) {
    case "oak":
      g.fillStyle = "#6e5236";
      g.fillRect(0, 0, size, size);
      plank([186, 150, 108]);
      break;
    case "walnut":
      g.fillStyle = "#2e2016";
      g.fillRect(0, 0, size, size);
      plank([104, 74, 52]);
      break;
    case "herringbone": {
      g.fillStyle = "#5f4630";
      g.fillRect(0, 0, size, size);
      const w = 32;
      const l = 128;
      for (let y = -l; y < size + l; y += w * 2) {
        for (let x = -l; x < size + l; x += l) {
          for (const dir of [1, -1]) {
            g.save();
            g.translate(x + (dir === 1 ? 0 : w * 2), y);
            g.rotate((dir * Math.PI) / 4);
            const v = rand(-14, 14);
            g.fillStyle = `rgb(${178 + v},${140 + v},${98 + v})`;
            g.fillRect(0, 0, l - 2, w - 2);
            g.restore();
          }
        }
      }
      break;
    }
    case "marble": {
      g.fillStyle = "#efece7";
      g.fillRect(0, 0, size, size);
      for (let i = 0; i < 14; i++) {
        g.strokeStyle = `rgba(120,110,100,${rand(0.08, 0.25)})`;
        g.lineWidth = rand(0.6, 2.2);
        g.beginPath();
        let x = rand(0, size);
        let y = 0;
        g.moveTo(x, y);
        while (y < size) {
          x += rand(-28, 28);
          y += rand(18, 40);
          g.lineTo(x, y);
        }
        g.stroke();
      }
      g.strokeStyle = "rgba(0,0,0,0.06)";
      g.strokeRect(0, 0, size, size);
      break;
    }
    case "tiles": {
      g.fillStyle = "#cfc8bd";
      g.fillRect(0, 0, size, size);
      const t = size / 2;
      for (let y = 0; y < 2; y++)
        for (let x = 0; x < 2; x++) {
          const v = rand(-6, 6);
          g.fillStyle = `rgb(${226 + v},${221 + v},${212 + v})`;
          g.fillRect(x * t + 2, y * t + 2, t - 4, t - 4);
        }
      break;
    }
    case "concrete": {
      const img = g.createImageData(size, size);
      for (let i = 0; i < img.data.length; i += 4) {
        const v = 168 + rand(-14, 14);
        img.data[i] = v;
        img.data[i + 1] = v - 2;
        img.data[i + 2] = v - 6;
        img.data[i + 3] = 255;
      }
      g.putImageData(img, 0, 0);
      break;
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

const FLOOR_TILE_FT: Record<FloorKind, number> = { oak: 6, walnut: 6, herringbone: 5, marble: 4, tiles: 4, concrete: 8 };

// ── Room shell ───────────────────────────────────────────────────────────

function Room({ config }: { config: VizConfig }) {
  const { lengthFt: L, widthFt: W, heightFt: H } = config.room;
  const floorTex = useMemo(() => makeFloorTexture(config.floor), [config.floor]);
  useEffect(() => {
    const t = FLOOR_TILE_FT[config.floor];
    floorTex.repeat.set(L / t, W / t);
    floorTex.needsUpdate = true;
  }, [floorTex, L, W, config.floor]);
  useEffect(() => () => floorTex.dispose(), [floorTex]);

  const wallColor = (w: "back" | "left" | "right") => (config.accentWall.enabled && config.accentWall.wall === w ? config.accentWall.color : config.wallColor);
  const t = 0.4; // wall thickness
  const floorRough = config.floor === "marble" || config.floor === "tiles" ? 0.25 : config.floor === "concrete" ? 0.6 : 0.7;

  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[L, W]} />
        <meshStandardMaterial map={floorTex} roughness={floorRough} metalness={0} />
      </mesh>
      {/* skirting + walls */}
      <mesh position={[0, H / 2, -W / 2 - t / 2]} receiveShadow castShadow>
        <boxGeometry args={[L + t * 2, H, t]} />
        <meshStandardMaterial color={wallColor("back")} roughness={0.95} />
      </mesh>
      <mesh position={[-L / 2 - t / 2, H / 2, 0]} receiveShadow castShadow>
        <boxGeometry args={[t, H, W]} />
        <meshStandardMaterial color={wallColor("left")} roughness={0.95} />
      </mesh>
      <mesh position={[L / 2 + t / 2, H / 2, 0]} receiveShadow castShadow>
        <boxGeometry args={[t, H, W]} />
        <meshStandardMaterial color={wallColor("right")} roughness={0.95} />
      </mesh>
      {/* window on the left wall */}
      <mesh position={[-L / 2 + 0.01, H * 0.52, -W * 0.05]} rotation-y={Math.PI / 2}>
        <planeGeometry args={[Math.min(W * 0.45, 7), H * 0.5]} />
        <meshStandardMaterial color="#dfe9ee" emissive="#cfe3ee" emissiveIntensity={config.lighting === "evening" ? 0.05 : 0.6} />
      </mesh>
      {/* skirting */}
      {[
        [0, 0.15, -W / 2 + 0.02, L, 0.04],
        [-L / 2 + 0.02, 0.15, 0, 0.04, W],
        [L / 2 - 0.02, 0.15, 0, 0.04, W],
      ].map(([x, y, z, sx, sz], i) => (
        <mesh key={i} position={[x!, y!, z!]}>
          <boxGeometry args={[sx!, 0.3, sz!]} />
          <meshStandardMaterial color="#f4f1ea" roughness={0.6} />
        </mesh>
      ))}
      {/* cove light strips */}
      {config.cove
        ? [
            [0, H - 0.6, -W / 2 + 0.25, L - 0.6, 0.08],
            [-L / 2 + 0.25, H - 0.6, 0, 0.08, W - 0.6],
            [L / 2 - 0.25, H - 0.6, 0, 0.08, W - 0.6],
          ].map(([x, y, z, sx, sz], i) => (
            <mesh key={`cove-${i}`} position={[x!, y!, z!]}>
              <boxGeometry args={[sx!, 0.06, sz!]} />
              <meshStandardMaterial color="#fff2d6" emissive="#ffd9a0" emissiveIntensity={config.lighting === "evening" ? 3 : 1.2} toneMapped={false} />
            </mesh>
          ))
        : null}
      <DimensionLabels L={L} W={W} H={H} />
    </group>
  );
}

function DimensionLabels({ L, W, H }: { L: number; W: number; H: number }) {
  const style: React.CSSProperties = {
    background: "rgba(34,32,29,.82)",
    color: "#f4f2ee",
    fontSize: 11,
    padding: "2px 6px",
    borderRadius: 3,
    whiteSpace: "nowrap",
    fontFamily: "var(--font-sans)",
    pointerEvents: "none",
  };
  return (
    <>
      <Html position={[0, 0.05, W / 2 + 0.6]} center style={style}>
        L {ftIn(L)}
      </Html>
      <Html position={[L / 2 + 0.6, 0.05, 0]} center style={style}>
        W {ftIn(W)}
      </Html>
      <Html position={[L / 2 + 0.3, H / 2, -W / 2]} center style={style}>
        H {ftIn(H)}
      </Html>
    </>
  );
}

// ── Furniture (built from primitives) ────────────────────────────────────

function M({ color, rough = 0.8, metal = 0 }: { color: string; rough?: number; metal?: number }) {
  return <meshStandardMaterial color={color} roughness={rough} metalness={metal} />;
}

function shade(hex: string, amt: number) {
  const c = new THREE.Color(hex);
  c.offsetHSL(0, 0, amt);
  return `#${c.getHexString()}`;
}

function FurnitureMesh({ item }: { item: VizItem }) {
  const f = FURNITURE[item.type];
  const c = item.color;
  const wood = "#6f5641";
  switch (item.type) {
    case "sofa":
      return (
        <group>
          <mesh position={[0, 0.75, 0.15]} castShadow>
            <boxGeometry args={[f.w - 0.8, 0.7, f.d - 0.6]} />
            <M color={c} />
          </mesh>
          <mesh position={[0, 1.5, -f.d / 2 + 0.35]} castShadow>
            <boxGeometry args={[f.w, 1.9, 0.7]} />
            <M color={shade(c, -0.04)} />
          </mesh>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[(s * (f.w - 0.4)) / 2, 1.05, 0]} castShadow>
              <boxGeometry args={[0.4, 1.3, f.d]} />
              <M color={shade(c, -0.03)} />
            </mesh>
          ))}
          {[-1.6, 0, 1.6].map((x) => (
            <mesh key={x} position={[x, 1.2, 0.15]} castShadow>
              <boxGeometry args={[1.5, 0.25, f.d - 0.8]} />
              <M color={shade(c, 0.03)} />
            </mesh>
          ))}
          <mesh position={[0, 0.2, 0]}>
            <boxGeometry args={[f.w - 0.2, 0.4, f.d - 0.2]} />
            <M color="#2b2926" />
          </mesh>
        </group>
      );
    case "armchair":
      return (
        <group>
          <mesh position={[0, 0.7, 0.1]} castShadow>
            <boxGeometry args={[f.w - 0.6, 0.6, f.d - 0.5]} />
            <M color={c} />
          </mesh>
          <mesh position={[0, 1.5, -f.d / 2 + 0.3]} castShadow>
            <boxGeometry args={[f.w, 1.6, 0.6]} />
            <M color={shade(c, -0.04)} />
          </mesh>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[(s * (f.w - 0.3)) / 2, 1, 0]} castShadow>
              <boxGeometry args={[0.3, 1.2, f.d]} />
              <M color={shade(c, -0.03)} />
            </mesh>
          ))}
        </group>
      );
    case "coffee_table":
    case "side_table":
    case "desk": {
      const top = item.type === "desk" ? 2.5 : f.h;
      return (
        <group>
          <mesh position={[0, top - 0.08, 0]} castShadow>
            <boxGeometry args={[f.w, 0.16, f.d]} />
            <M color={c} rough={0.5} />
          </mesh>
          {[
            [-1, -1],
            [1, -1],
            [-1, 1],
            [1, 1],
          ].map(([sx, sz], i) => (
            <mesh key={i} position={[(sx! * (f.w - 0.3)) / 2, (top - 0.16) / 2, (sz! * (f.d - 0.3)) / 2]} castShadow>
              <boxGeometry args={[0.12, top - 0.16, 0.12]} />
              <M color="#2b2926" rough={0.4} metal={0.5} />
            </mesh>
          ))}
          {item.type === "desk" ? (
            <group position={[0, 0, f.d / 2 + 0.9]}>
              <mesh position={[0, 1.5, 0]} castShadow>
                <boxGeometry args={[1.6, 0.25, 1.6]} />
                <M color="#2b2926" />
              </mesh>
              <mesh position={[0, 2.3, 0.7]} castShadow>
                <boxGeometry args={[1.6, 1.6, 0.2]} />
                <M color="#2b2926" />
              </mesh>
              <mesh position={[0, 0.75, 0]}>
                <cylinderGeometry args={[0.08, 0.08, 1.5]} />
                <M color="#555" metal={0.6} rough={0.3} />
              </mesh>
            </group>
          ) : null}
        </group>
      );
    }
    case "tv_unit":
      return (
        <group>
          <mesh position={[0, 0.8 + 0.5, 0]} castShadow>
            <boxGeometry args={[f.w, 1.0, f.d]} />
            <M color={c} rough={0.55} />
          </mesh>
          {[-1, 0, 1].map((x) => (
            <mesh key={x} position={[x * (f.w / 3), 1.3, f.d / 2 + 0.01]}>
              <boxGeometry args={[f.w / 3 - 0.06, 0.94, 0.01]} />
              <M color={shade(c, 0.04)} rough={0.5} />
            </mesh>
          ))}
          <mesh position={[0, 4.3, -f.d / 2 + 0.1]} castShadow>
            <boxGeometry args={[4.8, 2.8, 0.12]} />
            <M color="#111" rough={0.2} metal={0.3} />
          </mesh>
        </group>
      );
    case "bed":
      return (
        <group>
          <mesh position={[0, 0.6, 0.2]} castShadow>
            <boxGeometry args={[f.w, 1.2, f.d - 0.4]} />
            <M color={wood} rough={0.6} />
          </mesh>
          <mesh position={[0, 1.45, 0.25]} castShadow>
            <boxGeometry args={[f.w - 0.2, 0.55, f.d - 0.6]} />
            <M color="#f3efe8" rough={0.95} />
          </mesh>
          <mesh position={[0, 1.78, 1.5]} castShadow>
            <boxGeometry args={[f.w - 0.1, 0.15, f.d / 2]} />
            <M color={shade(c, -0.1)} rough={0.95} />
          </mesh>
          <mesh position={[0, 2.1, -f.d / 2 + 0.2]} castShadow>
            <boxGeometry args={[f.w + 0.6, f.h, 0.4]} />
            <M color={c} />
          </mesh>
          {[-1.2, 1.2].map((x) => (
            <mesh key={x} position={[x, 1.95, -f.d / 2 + 1]} castShadow>
              <boxGeometry args={[2, 0.45, 1.1]} />
              <M color="#fbf9f5" rough={1} />
            </mesh>
          ))}
        </group>
      );
    case "wardrobe":
      return (
        <group>
          <mesh position={[0, f.h / 2, 0]} castShadow>
            <boxGeometry args={[f.w, f.h, f.d]} />
            <M color={c} rough={0.5} />
          </mesh>
          {Array.from({ length: Math.round(f.w / 1.5) - 1 }).map((_, i) => (
            <mesh key={i} position={[-f.w / 2 + (i + 1) * (f.w / Math.round(f.w / 1.5)), f.h / 2, f.d / 2 + 0.005]}>
              <boxGeometry args={[0.02, f.h - 0.2, 0.01]} />
              <M color={shade(c, -0.2)} />
            </mesh>
          ))}
          {Array.from({ length: Math.round(f.w / 1.5) }).map((_, i) => (
            <mesh key={`h${i}`} position={[-f.w / 2 + (i + 0.5) * (f.w / Math.round(f.w / 1.5)) + 0.5, f.h / 2, f.d / 2 + 0.05]}>
              <boxGeometry args={[0.05, 1.4, 0.05]} />
              <M color="#a7894f" rough={0.3} metal={0.8} />
            </mesh>
          ))}
        </group>
      );
    case "dining_set":
      return (
        <group>
          <mesh position={[0, 2.42, 0]} castShadow>
            <boxGeometry args={[f.w, 0.16, f.d]} />
            <M color={c} rough={0.45} />
          </mesh>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[(s * (f.w - 1)) / 2, 1.2, 0]} castShadow>
              <boxGeometry args={[0.3, 2.4, f.d - 0.8]} />
              <M color={shade(c, -0.05)} />
            </mesh>
          ))}
          {[-1.8, 0, 1.8].flatMap((x) =>
            [-1, 1].map((s) => (
              <group key={`${x}${s}`} position={[x, 0, s * (f.d / 2 + 0.8)]} rotation-y={s === 1 ? Math.PI : 0}>
                <mesh position={[0, 1.5, 0]} castShadow>
                  <boxGeometry args={[1.4, 0.18, 1.4]} />
                  <M color="#c9bba6" />
                </mesh>
                <mesh position={[0, 2.4, -0.65]} castShadow>
                  <boxGeometry args={[1.4, 1.6, 0.14]} />
                  <M color="#c9bba6" />
                </mesh>
                {[
                  [-0.6, -0.6],
                  [0.6, -0.6],
                  [-0.6, 0.6],
                  [0.6, 0.6],
                ].map(([lx, lz], li) => (
                  <mesh key={li} position={[lx!, 0.7, lz!]}>
                    <boxGeometry args={[0.1, 1.4, 0.1]} />
                    <M color={shade(c, -0.1)} />
                  </mesh>
                ))}
              </group>
            )),
          )}
        </group>
      );
    case "rug":
      return (
        <mesh position={[0, 0.03, 0]} receiveShadow>
          <boxGeometry args={[f.w, 0.05, f.d]} />
          <M color={c} rough={1} />
        </mesh>
      );
    case "plant":
      return (
        <group>
          <mesh position={[0, 0.8, 0]} castShadow>
            <cylinderGeometry args={[0.55, 0.45, 1.6, 24]} />
            <M color={c} rough={0.7} />
          </mesh>
          {[
            [0, 2.6, 0, 1.0],
            [0.4, 3.3, 0.2, 0.75],
            [-0.35, 3.1, -0.25, 0.7],
            [0.1, 3.9, -0.1, 0.55],
          ].map(([x, y, z, r], i) => (
            <mesh key={i} position={[x!, y!, z!]} castShadow>
              <icosahedronGeometry args={[r!, 1]} />
              <M color={["#4f6b45", "#5d7a50", "#46613d", "#6a8a5a"][i]!} rough={0.9} />
            </mesh>
          ))}
        </group>
      );
    case "floor_lamp":
      return (
        <group>
          <mesh position={[0, 0.05, 0]}>
            <cylinderGeometry args={[0.55, 0.55, 0.1, 24]} />
            <M color={c} metal={0.6} rough={0.3} />
          </mesh>
          <mesh position={[0, 2.5, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 5]} />
            <M color={c} metal={0.6} rough={0.3} />
          </mesh>
          <mesh position={[0, 5.1, 0]}>
            <cylinderGeometry args={[0.45, 0.65, 0.9, 24, 1, true]} />
            <meshStandardMaterial color="#f5ecd9" emissive="#ffd9a0" emissiveIntensity={0.8} side={THREE.DoubleSide} />
          </mesh>
          <pointLight position={[0, 4.9, 0]} intensity={4} distance={10} color="#ffd9a0" />
        </group>
      );
    case "kitchen_run":
      return (
        <group>
          <mesh position={[0, 1.45, 0]} castShadow>
            <boxGeometry args={[f.w, 2.9, f.d]} />
            <M color={c} rough={0.5} />
          </mesh>
          <mesh position={[0, 2.95, 0.05]} castShadow>
            <boxGeometry args={[f.w + 0.05, 0.12, f.d + 0.1]} />
            <M color="#f1eee8" rough={0.2} />
          </mesh>
          <mesh position={[0, 6.0, -f.d / 2 + 0.6]} castShadow>
            <boxGeometry args={[f.w, 2.2, 1.2]} />
            <M color={shade(c, 0.05)} rough={0.5} />
          </mesh>
          {Array.from({ length: Math.round(f.w / 2) }).map((_, i) => (
            <mesh key={i} position={[-f.w / 2 + 1 + i * 2, 2.4, f.d / 2 + 0.03]}>
              <boxGeometry args={[1.2, 0.05, 0.05]} />
              <M color="#a7894f" metal={0.8} rough={0.3} />
            </mesh>
          ))}
        </group>
      );
    case "bookshelf":
      return (
        <group>
          {[0, 1.5, 3, 4.5, 5.9].map((y) => (
            <mesh key={y} position={[0, y + 0.05, 0]} castShadow>
              <boxGeometry args={[f.w, 0.1, f.d]} />
              <M color={c} />
            </mesh>
          ))}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[(s * f.w) / 2, f.h / 2, 0]} castShadow>
              <boxGeometry args={[0.1, f.h, f.d]} />
              <M color={c} />
            </mesh>
          ))}
          {[0.75, 2.25, 3.75].map((y, i) => (
            <mesh key={i} position={[-0.4 + i * 0.3, y, 0]} castShadow>
              <boxGeometry args={[1.4, 1, 0.7]} />
              <M color={["#8f7a63", "#5f7a5b", "#b56f4f"][i]!} />
            </mesh>
          ))}
        </group>
      );
  }
}

function Furniture({ item, selected, onSelect, onDragStart }: { item: VizItem; selected: boolean; onSelect: (id: string) => void; onDragStart: (id: string, e: ThreeEvent<PointerEvent>) => void }) {
  const [hover, setHover] = useState(false);
  useCursor(hover, "grab");
  const f = FURNITURE[item.type];
  return (
    <group
      position={[item.x, 0, item.z]}
      rotation-y={item.rot}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHover(true);
      }}
      onPointerOut={() => setHover(false)}
      onPointerDown={(e) => {
        e.stopPropagation();
        onSelect(item.id);
        onDragStart(item.id, e);
      }}
    >
      <FurnitureMesh item={item} />
      {selected ? (
        <mesh position={[0, 0.02, 0]} rotation-x={-Math.PI / 2}>
          <planeGeometry args={[f.w + 0.5, f.d + 0.5]} />
          <meshBasicMaterial color="#a7894f" transparent opacity={0.28} />
        </mesh>
      ) : null}
    </group>
  );
}

// ── Lighting & camera ───────────────────────────────────────────────────

function Lights({ kind, room }: { kind: LightingKind; room: VizConfig["room"] }) {
  const { lengthFt: L, widthFt: W, heightFt: H } = room;
  const presets = {
    daylight: { ambient: 0.55, ambientColor: "#ffffff", sun: 2.2, sunColor: "#fff4e5", points: 0, pointColor: "#ffe2b8", hemi: 0.5 },
    warm: { ambient: 0.35, ambientColor: "#ffe9cf", sun: 0.9, sunColor: "#ffe2c0", points: 10, pointColor: "#ffcf91", hemi: 0.3 },
    evening: { ambient: 0.12, ambientColor: "#ffd9a8", sun: 0, sunColor: "#ffffff", points: 14, pointColor: "#ffbe73", hemi: 0.08 },
    cool: { ambient: 0.5, ambientColor: "#eef3ff", sun: 1.8, sunColor: "#f0f5ff", points: 6, pointColor: "#f4f7ff", hemi: 0.45 },
  }[kind];
  return (
    <>
      <ambientLight intensity={presets.ambient} color={presets.ambientColor} />
      <hemisphereLight args={["#fdfbf7", "#b9a68d", presets.hemi]} />
      {presets.sun > 0 ? (
        <directionalLight position={[-L, H * 1.6, W * 0.4]} intensity={presets.sun} color={presets.sunColor} castShadow shadow-mapSize-width={2048} shadow-mapSize-height={2048} shadow-camera-left={-L} shadow-camera-right={L} shadow-camera-top={W} shadow-camera-bottom={-W} shadow-bias={-0.0004} />
      ) : null}
      {presets.points > 0
        ? [
            [-L / 4, H - 0.5, -W / 4],
            [L / 4, H - 0.5, -W / 4],
            [-L / 4, H - 0.5, W / 4],
            [L / 4, H - 0.5, W / 4],
          ].map((p, i) => <pointLight key={i} position={p as [number, number, number]} intensity={presets.points} distance={Math.max(L, W) * 1.2} decay={1.6} color={presets.pointColor} />)
        : null}
    </>
  );
}

function CameraRig({ kind, room, controls }: { kind: CameraKind; room: VizConfig["room"]; controls: React.RefObject<OrbitControlsImpl | null> }) {
  const { camera } = useThree();
  const target = useRef<THREE.Vector3 | null>(null);
  useEffect(() => {
    const { lengthFt: L, widthFt: W, heightFt: H } = room;
    const m = Math.max(L, W);
    const pos = {
      perspective: new THREE.Vector3(L * 0.7, H * 1.45 + m * 0.2, W * 1.25 + m * 0.55),
      top: new THREE.Vector3(0.001, m * 1.65, 0.01),
      front: new THREE.Vector3(0, H * 0.55, W * 1.6),
      side: new THREE.Vector3(L * 1.6, H * 0.55, 0),
    }[kind];
    target.current = pos;
  }, [kind, room]);
  useFrame(() => {
    if (!target.current) return;
    camera.position.lerp(target.current, 0.12);
    controls.current?.target.lerp(new THREE.Vector3(0, room.heightFt * 0.3, 0), 0.12);
    controls.current?.update();
    if (camera.position.distanceTo(target.current) < 0.05) target.current = null;
  });
  return null;
}

// ── Scene ───────────────────────────────────────────────────────────────

export function VisualizerScene({ config, selectedId, onSelect, onMove }: { config: VizConfig; selectedId: string | null; onSelect: (id: string | null) => void; onMove: (id: string, x: number, z: number) => void }) {
  const controls = useRef<OrbitControlsImpl | null>(null);
  const dragging = useRef<{ id: string; offsetX: number; offsetZ: number } | null>(null);
  const { lengthFt: L, widthFt: W, heightFt: H } = config.room;

  const onDragStart = (id: string, e: ThreeEvent<PointerEvent>) => {
    const it = config.items.find((i) => i.id === id);
    if (!it) return;
    dragging.current = { id, offsetX: e.point.x - it.x, offsetZ: e.point.z - it.z };
    if (controls.current) controls.current.enabled = false;
    (e.target as Element | null)?.setPointerCapture?.(e.pointerId);
  };
  const endDrag = () => {
    dragging.current = null;
    if (controls.current) controls.current.enabled = true;
  };

  return (
    <>
      <color attach="background" args={["#efebe4"]} />
      <Lights kind={config.lighting} room={config.room} />
      <Room config={config} />
      {config.items.map((it) => (
        <Furniture key={it.id} item={it} selected={it.id === selectedId} onSelect={onSelect} onDragStart={onDragStart} />
      ))}
      {/* invisible drag plane */}
      <mesh
        rotation-x={-Math.PI / 2}
        position={[0, 0.01, 0]}
        onPointerMove={(e) => {
          if (!dragging.current) return;
          e.stopPropagation();
          const it = config.items.find((i) => i.id === dragging.current!.id);
          if (!it) return;
          const f = FURNITURE[it.type];
          const halfW = (Math.abs(Math.cos(it.rot)) * f.w + Math.abs(Math.sin(it.rot)) * f.d) / 2;
          const halfD = (Math.abs(Math.sin(it.rot)) * f.w + Math.abs(Math.cos(it.rot)) * f.d) / 2;
          const x = THREE.MathUtils.clamp(e.point.x - dragging.current.offsetX, -L / 2 + halfW, L / 2 - halfW);
          const z = THREE.MathUtils.clamp(e.point.z - dragging.current.offsetZ, -W / 2 + halfD, W / 2 - halfD);
          onMove(it.id, Math.round(x * 4) / 4, Math.round(z * 4) / 4);
        }}
        onPointerUp={endDrag}
        onPointerLeave={endDrag}
        onPointerDown={(e) => {
          if (e.object === e.eventObject && !dragging.current) onSelect(null);
        }}
      >
        <planeGeometry args={[L * 3, W * 3]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
      <ContactShadows position={[0, 0.02, 0]} scale={Math.max(L, W) * 1.4} opacity={0.35} blur={2.4} far={6} />
      <OrbitControls ref={controls} makeDefault enableDamping dampingFactor={0.08} minDistance={4} maxDistance={Math.max(L, W) * 3} maxPolarAngle={Math.PI / 2.05} target={[0, H * 0.3, 0]} />
      <CameraRig kind={config.camera} room={config.room} controls={controls} />
    </>
  );
}
