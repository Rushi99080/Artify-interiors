"use client";

import dynamic from "next/dynamic";
import { Spinner } from "@/components/ui/button";
import type { VizProject } from "@/components/visualizer/visualizer";

// three.js needs the browser — load the visualizer client-side only.
const Visualizer = dynamic(() => import("@/components/visualizer/visualizer"), {
  ssr: false,
  loading: () => (
    <div className="flex h-[60vh] items-center justify-center gap-2 rounded-[var(--radius-md)] border border-line bg-paper text-sm text-smoke">
      <Spinner className="size-5 text-brass" /> Loading 3D visualizer…
    </div>
  ),
});

export function VisualizerLoader(props: { signedIn: boolean; projects: VizProject[]; initialProjectId?: string | null; initialRoomType?: string; initialDims?: { lengthFt: number; widthFt: number; heightFt: number } }) {
  return <Visualizer {...props} />;
}
