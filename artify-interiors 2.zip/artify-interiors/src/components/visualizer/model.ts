// 3D visualizer model: furniture catalogue, finishes, presets. Units are feet (1 scene unit = 1 ft).
import type { RoomTypeKey } from "@/lib/constants";

export type FurnitureType =
  | "sofa"
  | "armchair"
  | "coffee_table"
  | "tv_unit"
  | "bed"
  | "wardrobe"
  | "side_table"
  | "dining_set"
  | "rug"
  | "plant"
  | "floor_lamp"
  | "desk"
  | "kitchen_run"
  | "bookshelf";

export const FURNITURE: Record<FurnitureType, { label: string; w: number; d: number; h: number; defaultColor: string; colorLabel: string }> = {
  sofa: { label: "Sofa", w: 7, d: 3, h: 2.8, defaultColor: "#c9bba6", colorLabel: "Upholstery" },
  armchair: { label: "Armchair", w: 2.8, d: 2.8, h: 2.7, defaultColor: "#8f7a63", colorLabel: "Upholstery" },
  coffee_table: { label: "Coffee table", w: 4, d: 2, h: 1.4, defaultColor: "#6f5641", colorLabel: "Wood" },
  tv_unit: { label: "TV unit", w: 7, d: 1.5, h: 1.6, defaultColor: "#4a3c31", colorLabel: "Finish" },
  bed: { label: "Queen bed", w: 5.5, d: 7, h: 3.6, defaultColor: "#d8cfc2", colorLabel: "Headboard" },
  wardrobe: { label: "Wardrobe", w: 6, d: 2, h: 7.5, defaultColor: "#e7e0d4", colorLabel: "Shutters" },
  side_table: { label: "Side table", w: 1.6, d: 1.6, h: 1.8, defaultColor: "#6f5641", colorLabel: "Wood" },
  dining_set: { label: "Dining set (6)", w: 6, d: 3, h: 2.5, defaultColor: "#7a5f46", colorLabel: "Wood" },
  rug: { label: "Rug", w: 8, d: 5, h: 0.05, defaultColor: "#b9ab97", colorLabel: "Rug" },
  plant: { label: "Plant", w: 1.5, d: 1.5, h: 4.5, defaultColor: "#c8bba8", colorLabel: "Pot" },
  floor_lamp: { label: "Floor lamp", w: 1.3, d: 1.3, h: 5.5, defaultColor: "#2e2b28", colorLabel: "Metal" },
  desk: { label: "Desk & chair", w: 4, d: 2, h: 2.5, defaultColor: "#8a6c4f", colorLabel: "Wood" },
  kitchen_run: { label: "Kitchen run", w: 8, d: 2, h: 7, defaultColor: "#9aa58f", colorLabel: "Shutters" },
  bookshelf: { label: "Bookshelf", w: 3, d: 1, h: 6, defaultColor: "#6f5641", colorLabel: "Wood" },
};

export type FloorKind = "oak" | "walnut" | "herringbone" | "marble" | "tiles" | "concrete";
export const FLOORS: Record<FloorKind, string> = {
  oak: "Light oak planks",
  walnut: "Walnut planks",
  herringbone: "Herringbone oak",
  marble: "White marble",
  tiles: "Large-format tiles",
  concrete: "Polished concrete",
};

export type LightingKind = "daylight" | "warm" | "evening" | "cool";
export const LIGHTING: Record<LightingKind, string> = { daylight: "Daylight", warm: "Warm white", evening: "Evening ambience", cool: "Cool white" };

export type CameraKind = "perspective" | "top" | "front" | "side";
export const CAMERAS: Record<CameraKind, string> = { perspective: "3/4 view", top: "Top (plan)", front: "Front", side: "Side" };

export type VizItem = { id: string; type: FurnitureType; x: number; z: number; rot: number; color: string };

export type VizConfig = {
  version: 1;
  room: { lengthFt: number; widthFt: number; heightFt: number };
  wallColor: string;
  accentWall: { enabled: boolean; color: string; wall: "back" | "left" | "right" };
  floor: FloorKind;
  cove: boolean;
  lighting: LightingKind;
  camera: CameraKind;
  items: VizItem[];
};

export const WALL_SWATCHES = ["#efe9df", "#e8e1d6", "#d9cfc1", "#c9c4b8", "#b9b5a9", "#a9b4a2", "#8f9c94", "#7d8a99", "#d8c3b0", "#b88f75", "#4b4743", "#2f3a37"];
export const FABRIC_SWATCHES = ["#e9e2d6", "#c9bba6", "#a8987f", "#8f7a63", "#6f5641", "#4a3c31", "#9aa58f", "#5f7a5b", "#7d8a99", "#2f3a4f", "#b56f4f", "#2b2926"];

let n = 0;
export const newId = () => `i${Date.now().toString(36)}${(n++).toString(36)}`;

function item(type: FurnitureType, x: number, z: number, rot = 0): VizItem {
  return { id: newId(), type, x, z, rot, color: FURNITURE[type].defaultColor };
}

/** Sensible starting layout per room type (positions relative to room centre). */
export function defaultLayout(type: RoomTypeKey | string, L: number, W: number): VizItem[] {
  const hx = L / 2;
  const hz = W / 2;
  switch (type) {
    case "LIVING_ROOM":
      return [item("rug", 0, 0.5), item("sofa", 0, hz - 2), item("coffee_table", 0, 0.5), item("tv_unit", 0, -hz + 1), item("armchair", -hx + 2.2, 0.5, Math.PI / 2), item("plant", hx - 1.2, -hz + 1.2), item("floor_lamp", hx - 1.2, hz - 1.2)];
    case "MASTER_BEDROOM":
    case "GUEST_BEDROOM":
    case "KIDS_BEDROOM":
      return [item("rug", 0, 0.5), item("bed", 0, -hz + 3.6), item("side_table", -3.8, -hz + 1.2), item("side_table", 3.8, -hz + 1.2), item("wardrobe", hx - 1.1, hz - 3.5, -Math.PI / 2), item("plant", -hx + 1, hz - 1)];
    case "DINING_ROOM":
      return [item("rug", 0, 0), item("dining_set", 0, 0), item("plant", hx - 1, -hz + 1)];
    case "KITCHEN":
      return [item("kitchen_run", 0, -hz + 1), item("kitchen_run", -hx + 1, 0, Math.PI / 2)];
    case "OFFICE":
    case "COMMERCIAL":
      return [item("desk", -hx / 2, -hz / 2), item("desk", hx / 2, -hz / 2), item("desk", -hx / 2, hz / 2), item("desk", hx / 2, hz / 2), item("bookshelf", 0, -hz + 0.6), item("plant", hx - 1, hz - 1)];
    case "WARDROBE":
      return [item("wardrobe", 0, -hz + 1)];
    case "TV_UNIT":
      return [item("tv_unit", 0, -hz + 1), item("sofa", 0, hz - 2)];
    default:
      return [item("rug", 0, 0), item("armchair", 0, 0), item("plant", hx - 1, -hz + 1)];
  }
}

export function defaultConfig(type: RoomTypeKey | string = "LIVING_ROOM", dims = { lengthFt: 16, widthFt: 12, heightFt: 10 }): VizConfig {
  return {
    version: 1,
    room: dims,
    wallColor: "#e8e1d6",
    accentWall: { enabled: true, color: "#8f9c94", wall: "back" },
    floor: "oak",
    cove: true,
    lighting: "daylight",
    camera: "perspective",
    items: defaultLayout(type, dims.lengthFt, dims.widthFt),
  };
}

export function ftIn(v: number) {
  const ft = Math.floor(v);
  const inch = Math.round((v - ft) * 12);
  return inch === 12 ? `${ft + 1}′-0″` : `${ft}′-${inch}″`;
}
