"use client";

import { useMemo, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { estimateRooms, floorAreaOf, type RoomInput } from "@/lib/boq/engine";
import { LAYOUT_PRESETS } from "@/lib/boq/presets";
import { PRICE_TIERS, ROOM_LABELS, ROOM_MODULES, TIER_DESCRIPTIONS, TIER_LABELS, type PriceTierKey, type RoomTypeKey } from "@/lib/constants";
import { cn, formatINRCompact } from "@/lib/format";
import type { EstimatorData } from "@/lib/services/estimator";
import { Input, Select, Checkbox } from "@/components/ui/field";
import { Button, ButtonLink } from "@/components/ui/button";
import { EstimateBreakdown } from "@/components/estimate/estimate-breakdown";
import { LeadForm } from "@/components/site/lead-form";

type Row = { id: number; name: string; type: RoomTypeKey; lengthFt: number; widthFt: number; heightFt: number };
let nextId = 1;
const fromPreset = (key: string): Row[] => (LAYOUT_PRESETS.find((p) => p.key === key)?.rooms ?? []).map((r) => ({ ...r, id: nextId++ }));

export function CostCalculator({ data }: { data: EstimatorData }) {
  const [preset, setPreset] = useState("2BHK");
  const [rows, setRows] = useState<Row[]>(() => fromPreset("2BHK"));
  const [tier, setTier] = useState<PriceTierKey>("STANDARD");
  const [flooring, setFlooring] = useState(false);
  const [showLead, setShowLead] = useState(false);

  const rooms: RoomInput[] = rows.map((r) => ({ name: r.name, type: r.type, lengthFt: r.lengthFt, widthFt: r.widthFt, heightFt: r.heightFt, includeFlooring: flooring }));
  const estimate = useMemo(() => estimateRooms(rooms, tier, { rateCard: data.rateCard, ctx: { byTier: data.byTier }, charges: data.charges }), [JSON.stringify(rooms), tier, data]); // eslint-disable-line react-hooks/exhaustive-deps
  const perRoom = useMemo(
    () => rooms.map((r) => estimateRooms([r], tier, { rateCard: data.rateCard, ctx: { byTier: data.byTier }, charges: data.charges, includeExtras: false }).totals.grandTotal),
    [JSON.stringify(rooms), tier, data], // eslint-disable-line react-hooks/exhaustive-deps
  );
  const area = Math.round(rooms.reduce((s, r) => s + floorAreaOf(r), 0));
  const total = estimate.totals.grandTotal;

  const update = (id: number, patch: Partial<Row>) => setRows((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  const num = (v: string, fallback: number) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? Math.min(n, 300) : fallback;
  };

  const startHref = `/ai-designer?preset=${encodeURIComponent(JSON.stringify(rows.map(({ name, type, lengthFt, widthFt, heightFt }) => ({ name, type, lengthFt, widthFt, heightFt }))))}`;

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,1.65fr)_minmax(0,1fr)]">
      <div>
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Layout">
          {LAYOUT_PRESETS.map((p) => (
            <button
              key={p.key}
              type="button"
              role="radio"
              aria-checked={preset === p.key}
              onClick={() => {
                setPreset(p.key);
                setRows(fromPreset(p.key));
              }}
              className={cn("rounded-full border px-4 py-2 text-sm transition-colors", preset === p.key ? "border-charcoal bg-charcoal text-paper" : "border-line bg-paper text-ink hover:border-sand")}
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className="mt-6 overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[700px]">
            <thead>
              <tr>
                <th>Room</th>
                <th>Type</th>
                <th className="num">L (ft)</th>
                <th className="num">W (ft)</th>
                <th className="num">H (ft)</th>
                <th className="num">Estimate</th>
                <th aria-label="Remove" />
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.id}>
                  <td>
                    <Input aria-label="Room name" value={r.name} onChange={(e) => update(r.id, { name: e.target.value })} className="min-w-[6.5rem] py-1.5" />
                  </td>
                  <td>
                    <Select aria-label="Room type" value={r.type} onChange={(e) => update(r.id, { type: e.target.value as RoomTypeKey })} className="min-w-[9rem] py-1.5">
                      {ROOM_MODULES.map((m) => (
                        <option key={m.type} value={m.type}>
                          {m.label}
                        </option>
                      ))}
                    </Select>
                  </td>
                  {(["lengthFt", "widthFt", "heightFt"] as const).map((k) => (
                    <td key={k} className="num">
                      <Input aria-label={`${r.name} ${{ lengthFt: "length", widthFt: "width", heightFt: "height" }[k]} in feet`} type="number" min={1} step={0.5} defaultValue={r[k]} onChange={(e) => update(r.id, { [k]: num(e.target.value, r[k]) })} className="w-16 px-2 py-1.5 text-right [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none" />
                    </td>
                  ))}
                  <td className="num align-middle text-charcoal">{formatINRCompact(perRoom[i] ?? 0)}</td>
                  <td className="align-middle">
                    <button type="button" onClick={() => setRows((rs) => rs.filter((x) => x.id !== r.id))} disabled={rows.length <= 1} className="rounded p-1.5 text-smoke hover:bg-brick-soft hover:text-brick disabled:opacity-30" aria-label={`Remove ${r.name}`}>
                      <Trash2 className="size-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <Button type="button" variant="secondary" size="sm" onClick={() => setRows((rs) => [...rs, { id: nextId++, name: `Room ${rs.length + 1}`, type: "GUEST_BEDROOM", lengthFt: 12, widthFt: 10, heightFt: 10 }])}>
            <Plus className="size-4" /> Add room
          </Button>
          <span className="text-sm tabular-nums text-smoke">Total floor area ≈ {area} sqft</span>
        </div>

        <fieldset className="mt-8">
          <legend className="text-sm font-medium text-ink">Finish level</legend>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {PRICE_TIERS.map((t) => (
              <button key={t} type="button" aria-pressed={tier === t} onClick={() => setTier(t)} className={cn("rounded-[var(--radius-sm)] border px-3 py-3 text-left transition-colors", tier === t ? "border-brass bg-brass-soft" : "border-line bg-paper hover:border-sand")}>
                <span className="block text-sm font-semibold text-charcoal">{TIER_LABELS[t]}</span>
                <span className="mt-0.5 block text-xs text-smoke">{TIER_DESCRIPTIONS[t]}</span>
              </button>
            ))}
          </div>
        </fieldset>
        <div className="mt-4">
          <Checkbox label="Include new flooring in living areas and bedrooms" checked={flooring} onChange={(e) => setFlooring(e.target.checked)} />
        </div>
      </div>

      <div className="flex flex-col gap-5 lg:sticky lg:top-24 lg:self-start">
        <div className="rounded-[var(--radius-md)] bg-charcoal p-7 text-paper">
          <p className="text-sm text-sand">
            {rows.length} rooms · {TIER_LABELS[tier]} finish
          </p>
          <p className="mt-1 font-display text-6xl leading-none md:text-7xl">{formatINRCompact(total)}</p>
          <p className="mt-2 text-sm text-sand/80">
            Likely range {formatINRCompact(total * 0.9)} – {formatINRCompact(total * 1.15)}, incl. GST
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            <ButtonLink href={startHref} variant="brass">
              Start a project with these rooms
            </ButtonLink>
            <button type="button" onClick={() => setShowLead((v) => !v)} className="inline-flex h-10 items-center rounded-[var(--radius-sm)] border border-white/25 px-4 text-sm text-paper hover:bg-white/10">
              Request a callback
            </button>
          </div>
        </div>
        {showLead ? (
          <div className="rounded-[var(--radius-md)] border border-line bg-paper p-6">
            <LeadForm
              compact
              source="COST_CALCULATOR"
              submitLabel="Request a callback"
              meta={{ tier, rooms: rows.map(({ name, type, lengthFt, widthFt }) => ({ name, type, lengthFt, widthFt })), estimate: Math.round(total) }}
              defaultMessage={`Online estimate: ${rows.length} rooms (${rows.map((r) => ROOM_LABELS[r.type]).join(", ")}), ${TIER_LABELS[tier]} finish — ${formatINRCompact(total)}.`}
            />
          </div>
        ) : null}
        <div className="rounded-[var(--radius-md)] border border-line bg-paper p-6">
          <EstimateBreakdown estimate={estimate} />
        </div>
      </div>
    </div>
  );
}
