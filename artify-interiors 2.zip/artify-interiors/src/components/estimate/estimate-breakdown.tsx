"use client";

import { useState } from "react";
import type { Estimate } from "@/lib/boq/engine";
import { formatINR } from "@/lib/format";
import { cn } from "@/lib/format";

/** Line-by-line breakdown of an estimate, grouped by BOQ section. */
export function EstimateBreakdown({ estimate, initiallyOpen = false }: { estimate: Estimate; initiallyOpen?: boolean }) {
  const [open, setOpen] = useState(initiallyOpen);
  const t = estimate.totals;
  return (
    <div>
      <div className="space-y-1.5 text-sm">
        <Row label="Items subtotal" value={t.subtotal} />
        <Row label="Wastage, overheads & supervision" value={t.additionalCharges - t.discountAmount} muted />
        <Row label={`GST (${t.gstRate}%)`} value={t.gstAmount} muted />
        <div className="border-t border-line pt-2">
          <Row label="Estimated total" value={t.grandTotal} strong />
        </div>
      </div>
      <button type="button" onClick={() => setOpen((o) => !o)} className="mt-4 text-sm text-charcoal underline decoration-sand underline-offset-4 hover:decoration-charcoal" aria-expanded={open}>
        {open ? "Hide" : "Show"} itemised estimate ({estimate.lines.length} items)
      </button>
      {open ? (
        <div className="mt-4 max-h-[420px] overflow-auto rounded-[var(--radius-sm)] border border-line">
          <table className="data-table text-[0.8rem]">
            <thead>
              <tr>
                <th>Item</th>
                <th className="num">Qty</th>
                <th className="num">Rate</th>
                <th className="num">Amount</th>
              </tr>
            </thead>
            <tbody>
              {t.sections.map((s) => (
                <SectionRows key={s.section} section={s.section} amount={s.amount} lines={estimate.lines.filter((l) => l.section === s.section)} />
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      <p className="mt-3 text-xs text-smoke">Preliminary estimate from standard formulas. Final quantities are confirmed after site measurement.</p>
    </div>
  );
}

function SectionRows({ section, amount, lines }: { section: string; amount: number; lines: Estimate["lines"] }) {
  return (
    <>
      <tr>
        <td colSpan={3} className="bg-travertine/50 font-semibold text-charcoal">
          {section}
        </td>
        <td className="num bg-travertine/50 font-semibold text-charcoal">{formatINR(amount)}</td>
      </tr>
      {lines.map((l, i) => (
        <tr key={`${l.key}-${i}`}>
          <td>
            <span className="text-charcoal">{l.item.replace(/ — .*$/, "")}</span>
            {l.primaryMaterial ? <span className="block text-[0.72rem] text-smoke">{l.primaryMaterial}</span> : null}
          </td>
          <td className="num">
            {l.quantity} {l.unit}
          </td>
          <td className="num">{formatINR(l.rate)}</td>
          <td className="num">{formatINR(l.amount)}</td>
        </tr>
      ))}
    </>
  );
}

function Row({ label, value, strong, muted }: { label: string; value: number; strong?: boolean; muted?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <span className={cn(muted ? "text-smoke" : "text-ink", strong && "font-semibold text-charcoal")}>{label}</span>
      <span className={cn("tabular-nums", strong ? "font-display text-2xl text-charcoal" : "text-ink")}>{formatINR(value)}</span>
    </div>
  );
}
