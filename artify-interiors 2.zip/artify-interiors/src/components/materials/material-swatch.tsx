// Visual swatch for a material without a photo — a pattern derived from its category and colour.
import { cn } from "@/lib/format";

const COLOR_WORDS: Record<string, string> = {
  white: "#f4f1ec",
  ivory: "#efe8da",
  beige: "#ddd0bb",
  grey: "#a9a59e",
  gray: "#a9a59e",
  charcoal: "#3b3835",
  black: "#262422",
  walnut: "#5d4330",
  oak: "#b08a5e",
  teak: "#8d5f37",
  sage: "#9aa58f",
  green: "#5f7a5b",
  emerald: "#2e5e4e",
  navy: "#2a3550",
  tan: "#b38458",
  gold: "#b39256",
  linen: "#ddd3c2",
  oatmeal: "#d8cdb9",
  calacatta: "#f1ede6",
  statuario: "#f3f1ee",
};

function baseColor(color: string | null, fallback: string) {
  const c = (color ?? "").toLowerCase();
  for (const [w, hex] of Object.entries(COLOR_WORDS)) if (c.includes(w)) return hex;
  return fallback;
}

export function MaterialSwatch({ category, color, name, imageUrl, className }: { category: string; color: string | null; name: string; imageUrl?: string | null; className?: string }) {
  if (imageUrl) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={imageUrl} alt={name} loading="lazy" className={cn("aspect-[4/3] w-full rounded-[2px] border border-line object-cover", className)} />;
  }
  const lower = `${name} ${color ?? ""}`.toLowerCase();
  let background: string;
  switch (category) {
    case "VENEER":
    case "FLOORING": {
      const b = baseColor(color ?? (lower.includes("walnut") ? "walnut" : lower.includes("teak") ? "teak" : "oak"), "#a17a52");
      background = `repeating-linear-gradient(90deg, ${b} 0 38px, color-mix(in srgb, ${b} 85%, black) 38px 40px), linear-gradient(180deg, transparent, rgba(0,0,0,.05))`;
      break;
    }
    case "MARBLE":
    case "QUARTZ": {
      const b = baseColor(color, "#f1eee8");
      background = `linear-gradient(125deg, ${b} 0%, ${b} 38%, #cfc6ba 39%, ${b} 41%, ${b} 70%, #d9d1c5 71%, ${b} 72%)`;
      break;
    }
    case "TILES": {
      const b = baseColor(color, "#e7e2da");
      background = `linear-gradient(${b},${b}) padding-box, repeating-linear-gradient(0deg, transparent 0 46px, #cdc6bb 46px 48px), repeating-linear-gradient(90deg, ${b} 0 46px, #cdc6bb 46px 48px)`;
      break;
    }
    case "LAMINATE":
    case "ACRYLIC":
    case "MDF":
    case "HDHMR":
    case "PLYWOOD": {
      const b = baseColor(color, category === "PLYWOOD" ? "#d2b48c" : "#d9d1c4");
      background = category === "ACRYLIC" ? `linear-gradient(160deg, color-mix(in srgb, ${b} 70%, white), ${b} 55%, color-mix(in srgb, ${b} 85%, white))` : category === "PLYWOOD" ? `repeating-linear-gradient(0deg, ${b} 0 6px, #c39f73 6px 7px)` : b;
      break;
    }
    case "GLASS":
      background = lower.includes("flute") ? "repeating-linear-gradient(90deg,#dfe7e6 0 8px,#c9d4d3 8px 10px)" : "linear-gradient(135deg,#e6eeee,#cfdcdc)";
      break;
    case "UPHOLSTERY":
      background = `radial-gradient(circle at 2px 2px, rgba(0,0,0,.08) 1px, transparent 1.5px) 0 0/6px 6px, ${baseColor(color, "#cfc3b0")}`;
      break;
    case "PAINT":
    case "WALLPAPER":
      background = baseColor(color, "#e8e0d2");
      break;
    default:
      background = "linear-gradient(135deg, var(--color-travertine), var(--color-plaster))";
  }
  return <div className={cn("aspect-[4/3] w-full rounded-[2px] border border-line", className)} style={{ background }} role="img" aria-label={name} />;
}
