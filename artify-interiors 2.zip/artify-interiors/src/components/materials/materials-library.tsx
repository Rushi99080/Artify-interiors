"use client";

import { useMemo, useState } from "react";
import { Search, Sparkles } from "lucide-react";
import { AVAILABILITY_LABELS, DESIGN_STYLES, MATERIAL_CATEGORIES, MATERIAL_CATEGORY_LABELS, PRICE_TIERS, STYLE_INFO, TIER_LABELS, type DesignStyleKey, type MaterialCategoryKey, type PriceTierKey } from "@/lib/constants";
import { cn, formatDate, formatINR } from "@/lib/format";
import { api, errorMessage } from "@/lib/client/api";
import { Input, Select, Field, Textarea } from "@/components/ui/field";
import { Button } from "@/components/ui/button";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { Notice } from "@/components/ui/notice";
import { MaterialSwatch } from "@/components/materials/material-swatch";

export type LibraryMaterial = {
  id: string;
  name: string;
  category: string;
  brand: string | null;
  productCode: string | null;
  finish: string | null;
  color: string | null;
  unit: string;
  rate: number;
  imageUrl: string | null;
  specifications: string | null;
  availability: string;
  tier: string;
  durability: number;
  maintenance: number;
  styles: string[];
  updatedAt: string;
  supplierName: string | null;
};

type Rec = { material: LibraryMaterial; score: number; reasons: string[] };

export function MaterialsLibrary({ materials, initialCategory }: { materials: LibraryMaterial[]; initialCategory?: string }) {
  const [category, setCategory] = useState<string>(initialCategory && (MATERIAL_CATEGORIES as readonly string[]).includes(initialCategory) ? initialCategory : "ALL");
  const [q, setQ] = useState("");
  const [tier, setTier] = useState("");
  const [open, setOpen] = useState<LibraryMaterial | null>(null);
  const [recOpen, setRecOpen] = useState(false);

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const m of materials) c[m.category] = (c[m.category] ?? 0) + 1;
    return c;
  }, [materials]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return materials.filter(
      (m) =>
        (category === "ALL" || m.category === category) &&
        (!tier || m.tier === tier) &&
        (!s || `${m.name} ${m.brand ?? ""} ${m.finish ?? ""} ${m.color ?? ""} ${m.productCode ?? ""}`.toLowerCase().includes(s)),
    );
  }, [materials, category, q, tier]);

  return (
    <div>
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="relative w-full md:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-mist" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, brand, colour or code" className="pl-9" aria-label="Search materials" />
        </div>
        <div className="flex gap-2">
          <Select value={tier} onChange={(e) => setTier(e.target.value)} aria-label="Finish level" className="w-auto">
            <option value="">All finish levels</option>
            {PRICE_TIERS.map((t) => (
              <option key={t} value={t}>
                {TIER_LABELS[t]}
              </option>
            ))}
          </Select>
          <Button variant="brass" onClick={() => setRecOpen(true)}>
            <Sparkles className="size-4" /> Recommend for me
          </Button>
        </div>
      </div>

      <div className="-mx-1 mt-5 flex gap-1.5 overflow-x-auto px-1 pb-2">
        <CatChip active={category === "ALL"} onClick={() => setCategory("ALL")}>
          All <span className="text-mist">{materials.length}</span>
        </CatChip>
        {MATERIAL_CATEGORIES.filter((c) => counts[c]).map((c) => (
          <CatChip key={c} active={category === c} onClick={() => setCategory(c)}>
            {MATERIAL_CATEGORY_LABELS[c]} <span className={category === c ? "text-sand" : "text-mist"}>{counts[c]}</span>
          </CatChip>
        ))}
      </div>

      {filtered.length ? (
        <div className="mt-6 grid grid-cols-2 gap-x-5 gap-y-8 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((m) => (
            <button key={m.id} type="button" onClick={() => setOpen(m)} className="group text-left">
              <MaterialSwatch category={m.category} color={m.color} name={m.name} imageUrl={m.imageUrl} className="transition-transform duration-300 group-hover:-translate-y-0.5" />
              <div className="mt-3 flex items-center justify-between gap-2 text-[0.75rem] text-smoke">
                <span>{MATERIAL_CATEGORY_LABELS[m.category as MaterialCategoryKey]}</span>
                <span>{TIER_LABELS[m.tier as PriceTierKey]}</span>
              </div>
              <p className="mt-0.5 text-sm font-medium leading-snug text-charcoal">{m.name}</p>
              <p className="text-xs text-smoke">{[m.brand, m.finish].filter(Boolean).join(", ")}</p>
              <p className="mt-1.5 text-sm tabular-nums text-ink">
                {formatINR(m.rate)} <span className="text-smoke">/ {m.unit}</span>
              </p>
            </button>
          ))}
        </div>
      ) : (
        <p className="mt-10 text-center text-smoke">No materials match your search.</p>
      )}

      <Modal open={!!open} onClose={() => setOpen(null)} title={open?.name ?? ""} description={open ? [open.brand, MATERIAL_CATEGORY_LABELS[open.category as MaterialCategoryKey]].filter(Boolean).join(" · ") : ""} size="lg">
        {open ? <MaterialDetail m={open} /> : null}
      </Modal>
      <RecommendModal open={recOpen} onClose={() => setRecOpen(false)} onPick={(m) => setOpen(m)} materials={materials} />
    </div>
  );
}

function MaterialDetail({ m }: { m: LibraryMaterial }) {
  return (
    <div className="grid gap-6 md:grid-cols-[1fr_1.2fr]">
      <MaterialSwatch category={m.category} color={m.color} name={m.name} imageUrl={m.imageUrl} />
      <div>
        <p className="font-display text-3xl text-charcoal">
          {formatINR(m.rate)} <span className="text-lg text-smoke">/ {m.unit}</span>
        </p>
        <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
          <Item k="Finish" v={m.finish} />
          <Item k="Colour" v={m.color} />
          <Item k="Product code" v={m.productCode} />
          <Item k="Finish level" v={TIER_LABELS[m.tier as PriceTierKey]} />
          <div>
            <dt className="text-smoke">Durability</dt>
            <dd>
              <Dots n={m.durability} />
            </dd>
          </div>
          <div>
            <dt className="text-smoke">Ease of maintenance</dt>
            <dd>
              <Dots n={m.maintenance} />
            </dd>
          </div>
          <div>
            <dt className="text-smoke">Availability</dt>
            <dd>
              <StatusBadge status={m.availability} label={AVAILABILITY_LABELS[m.availability as keyof typeof AVAILABILITY_LABELS]} />
            </dd>
          </div>
          <Item k="Supplier" v={m.supplierName} />
          <Item k="Last updated" v={formatDate(m.updatedAt)} />
        </dl>
        {m.styles.length ? (
          <div className="mt-4 flex flex-wrap gap-1.5">
            {m.styles.map((s) => (
              <Badge key={s} tone="brass">
                {STYLE_INFO[s as DesignStyleKey]?.label ?? s}
              </Badge>
            ))}
          </div>
        ) : null}
        {m.specifications ? <p className="mt-4 text-sm leading-relaxed text-ink">{m.specifications}</p> : null}
      </div>
    </div>
  );
}

function RecommendModal({ open, onClose, onPick, materials }: { open: boolean; onClose: () => void; onPick: (m: LibraryMaterial) => void; materials: LibraryMaterial[] }) {
  const [style, setStyle] = useState<DesignStyleKey>("MODERN");
  const [tier, setTier] = useState<PriceTierKey>("STANDARD");
  const [durability, setDurability] = useState(0.6);
  const [maintenance, setMaintenance] = useState(0.6);
  const [prefs, setPrefs] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Record<string, Rec[]> | null>(null);

  async function run() {
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ recommendations: Record<string, { material: { id: string }; score: number; reasons: string[] }[]> }>("/api/materials/recommend", {
        body: { style, tier, durabilityWeight: durability, maintenanceWeight: maintenance, preferences: prefs, perCategory: 2 },
      });
      const byId = new Map(materials.map((m) => [m.id, m]));
      const out: Record<string, Rec[]> = {};
      for (const [cat, list] of Object.entries(res.recommendations)) out[cat] = list.map((r) => ({ ...r, material: byId.get(r.material.id)! })).filter((r) => r.material);
      setResult(out);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Material recommendations" description="Ranked by your style, budget level, durability and maintenance priorities." size="xl">
      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <div className="grid content-start gap-4">
          <Field label="Design style" htmlFor="rec-style">
            <Select id="rec-style" value={style} onChange={(e) => setStyle(e.target.value as DesignStyleKey)}>
              {DESIGN_STYLES.map((s) => (
                <option key={s} value={s}>
                  {STYLE_INFO[s].label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Budget level" htmlFor="rec-tier">
            <Select id="rec-tier" value={tier} onChange={(e) => setTier(e.target.value as PriceTierKey)}>
              {PRICE_TIERS.map((t) => (
                <option key={t} value={t}>
                  {TIER_LABELS[t]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={`Durability priority: ${Math.round(durability * 100)}%`} htmlFor="rec-d">
            <input id="rec-d" type="range" min={0} max={1} step={0.1} value={durability} onChange={(e) => setDurability(Number(e.target.value))} className="accent-[var(--color-brass)]" />
          </Field>
          <Field label={`Low-maintenance priority: ${Math.round(maintenance * 100)}%`} htmlFor="rec-m">
            <input id="rec-m" type="range" min={0} max={1} step={0.1} value={maintenance} onChange={(e) => setMaintenance(Number(e.target.value))} className="accent-[var(--color-brass)]" />
          </Field>
          <Field label="Your preferences" hint="e.g. matte, walnut, no high gloss" htmlFor="rec-p">
            <Textarea id="rec-p" value={prefs} onChange={(e) => setPrefs(e.target.value)} rows={2} />
          </Field>
          <Button onClick={run} loading={loading}>
            Show recommendations
          </Button>
        </div>
        <div className="min-h-[300px]">
          {error ? <Notice kind="error">{error}</Notice> : null}
          {!result && !error ? <p className="text-sm text-smoke">Set your priorities and press “Show recommendations”.</p> : null}
          {result ? (
            <div className="grid gap-5 sm:grid-cols-2">
              {Object.entries(result).map(([cat, recs]) => (
                <div key={cat}>
                  <p className="text-sm font-semibold text-charcoal">{MATERIAL_CATEGORY_LABELS[cat as MaterialCategoryKey]}</p>
                  <ul className="mt-2 space-y-2">
                    {recs.map((r, i) => (
                      <li key={r.material.id}>
                        <button type="button" onClick={() => onPick(r.material)} className="flex w-full gap-3 rounded-[var(--radius-sm)] border border-line bg-white p-2.5 text-left hover:border-sand">
                          <MaterialSwatch category={r.material.category} color={r.material.color} name={r.material.name} imageUrl={r.material.imageUrl} className="w-16 shrink-0" />
                          <span className="min-w-0">
                            <span className="block text-sm text-charcoal">
                              {i === 0 ? <Badge tone="brass" className="mr-1.5">Best match</Badge> : null}
                              {r.material.name}
                            </span>
                            <span className="block text-xs text-smoke">
                              {r.material.brand} · {formatINR(r.material.rate)}/{r.material.unit}
                            </span>
                            {r.reasons.length ? <span className="mt-1 block text-xs text-moss">{r.reasons.slice(0, 3).join(" · ")}</span> : null}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    </Modal>
  );
}

function CatChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} aria-pressed={active} className={cn("flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm transition-colors", active ? "border-charcoal bg-charcoal text-paper" : "border-line bg-paper text-ink hover:border-sand")}>
      {children}
    </button>
  );
}

function Item({ k, v }: { k: string; v: string | null | undefined }) {
  return (
    <div>
      <dt className="text-smoke">{k}</dt>
      <dd className="text-charcoal">{v || "—"}</dd>
    </div>
  );
}

function Dots({ n }: { n: number }) {
  return (
    <span className="mt-1 inline-flex gap-1" aria-label={`${n} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className={cn("size-2 rounded-full", i < n ? "bg-brass" : "bg-line")} />
      ))}
    </span>
  );
}
