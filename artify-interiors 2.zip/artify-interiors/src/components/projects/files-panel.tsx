"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Download, FileText, Trash2 } from "lucide-react";
import { FILE_CATEGORY_LABELS } from "@/lib/constants";
import { formatBytes, formatDate } from "@/lib/format";
import { api, errorMessage } from "@/lib/client/api";
import type { UploadCategory } from "@/lib/storage/rules";
import { FileUploader } from "@/components/projects/file-uploader";
import { Panel, PanelHeader, EmptyState } from "@/components/ui/panel";
import { useToast } from "@/components/ui/toast";

export type FileRow = { id: string; originalName: string; category: string; mimeType: string; sizeBytes: number; createdAt: string; roomName: string | null; canDelete: boolean };

export function FilesPanel({ projectId, files, rooms, categories }: { projectId: string; files: FileRow[]; rooms: { id: string; name: string }[]; categories: UploadCategory[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const groups = new Map<string, FileRow[]>();
  for (const f of files) groups.set(f.category, [...(groups.get(f.category) ?? []), f]);

  async function remove(f: FileRow) {
    if (!confirm(`Delete ${f.originalName}?`)) return;
    setBusy(f.id);
    try {
      await api(`/api/files/${f.id}`, { method: "DELETE" });
      toast("File deleted");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
      <Panel className="self-start">
        <PanelHeader title="Upload files" description="Room photos, floor plans, drawings, CAD files and measurements." />
        <FileUploader projectId={projectId} rooms={rooms} categories={categories} onUploaded={() => router.refresh()} compact />
      </Panel>
      <div className="space-y-6">
        {files.length === 0 ? <EmptyState title="No files yet" description="Upload photos of each room — they help the AI and our designers understand your space." /> : null}
        {[...groups.entries()].map(([cat, list]) => (
          <Panel key={cat}>
            <PanelHeader title={FILE_CATEGORY_LABELS[cat as keyof typeof FILE_CATEGORY_LABELS] ?? cat} description={`${list.length} file${list.length === 1 ? "" : "s"}`} />
            <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
              {list.map((f) => (
                <li key={f.id} className="group">
                  <a href={`/api/files/${f.id}`} target="_blank" rel="noopener noreferrer" className="block aspect-[4/3] overflow-hidden rounded-[var(--radius-sm)] border border-line bg-travertine">
                    {f.mimeType.startsWith("image/") ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={`/api/files/${f.id}`} alt={f.originalName} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]" />
                    ) : (
                      <span className="flex h-full flex-col items-center justify-center gap-1 text-smoke">
                        <FileText className="size-7" />
                        <span className="text-xs uppercase">{f.originalName.split(".").pop()}</span>
                      </span>
                    )}
                  </a>
                  <div className="mt-2 flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm text-charcoal" title={f.originalName}>
                        {f.originalName}
                      </p>
                      <p className="text-xs text-smoke">
                        {[f.roomName, formatBytes(f.sizeBytes), formatDate(f.createdAt)].filter(Boolean).join(" · ")}
                      </p>
                    </div>
                    <div className="flex shrink-0">
                      <a href={`/api/files/${f.id}?download=1`} className="rounded p-1 text-smoke hover:text-charcoal" aria-label={`Download ${f.originalName}`}>
                        <Download className="size-4" />
                      </a>
                      {f.canDelete ? (
                        <button type="button" onClick={() => remove(f)} disabled={busy === f.id} className="rounded p-1 text-smoke hover:text-brick disabled:opacity-40" aria-label={`Delete ${f.originalName}`}>
                          <Trash2 className="size-4" />
                        </button>
                      ) : null}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Panel>
        ))}
      </div>
    </div>
  );
}
