"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { Box, Layers, Plus, Trash2 } from "lucide-react";
import { DESIGN_STYLES, MATERIAL_CATEGORY_LABELS, PRICE_TIERS, ROOM_LABELS, ROOM_MODULES, ROOM_MODULE_BY_TYPE, STYLE_INFO, TIER_LABELS, type MaterialCategoryKey, type RoomTypeKey } from "@/lib/constants";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { formatINR } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/toast";
import { MaterialSwatch } from "@/components/materials/material-swatch";

export type RoomView = {
  id: string;
  name: string;
  type: string;
  lengthFt: number | null;
  widthFt: number | null;
  heightFt: number | null;
  style: string | null;
  tier: string | null;
  preferences: string | null;
  selections: { materialId: string; application: string | null }[];
};
export type PickerMaterial = { id: string; name: string; brand: string | null; category: string; rate: number; unit: string; finish: string | null; color: string | null; tier: string; imageUrl: string | null };

export function RoomsPanel({ projectId, rooms, materials, editable, projectStyle }: { projectId: string; rooms: RoomView[]; materials: PickerMaterial[]; editable: boolean; projectStyle: string | null }) {
  const router = useRouter();
  const { toast } = useToast();
  const [adding, setAdding] = useState(false);
  const [newType, setNewType] = useState<RoomTypeKey>("MASTER_BEDROOM");

  async function addRoom() {
    setAdding(true);
    try {
      const d = ROOM_MODULE_BY_TYPE[newType].defaults;
      await api(`/api/projects/${projectId}/rooms`, { body: { type: newType, ...d } });
      toast("Room added");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setAdding(false);
    }
  }

  return (
    <div className="space-y-5">
      {rooms.map((r) => (
        <RoomEditor key={r.id} room={r} materials={materials} editable={editable} projectId={projectId} canDelete={rooms.length > 1} projectStyle={projectStyle} />
      ))}
      {editable ? (
        <div className="flex flex-wrap items-end gap-2 rounded-[var(--radius-md)] border border-dashed border-line p-4">
          <Field label="Add a room" htmlFor="new-room" className="min-w-[14rem]">
            <Select id="new-room" value={newType} onChange={(e) => setNewType(e.target.value as RoomTypeKey)}>
              {ROOM_MODULES.map((m) => (
                <option key={m.type} value={m.type}>
                  {m.label}
                </option>
              ))}
            </Select>
          </Field>
          <Button variant="secondary" onClick={addRoom} loading={adding}>
            <Plus className="size-4" /> Add room
          </Button>
        </div>
      ) : null}
    </div>
  );
}

function RoomEditor({ room, materials, editable, projectId, canDelete, projectStyle }: { room: RoomView; materials: PickerMaterial[]; editable: boolean; projectId: string; canDelete: boolean; projectStyle: string | null }) {
  const router = useRouter();
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: room.name,
    type: room.type,
    lengthFt: room.lengthFt?.toString() ?? "",
    widthFt: room.widthFt?.toString() ?? "",
    heightFt: room.heightFt?.toString() ?? "10",
    style: room.style ?? "",
    tier: room.tier ?? "",
    preferences: room.preferences ?? "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const dirty = JSON.stringify(form) !== JSON.stringify({ name: room.name, type: room.type, lengthFt: room.lengthFt?.toString() ?? "", widthFt: room.widthFt?.toString() ?? "", heightFt: room.heightFt?.toString() ?? "10", style: room.style ?? "", tier: room.tier ?? "", preferences: room.preferences ?? "" });
  const mod = ROOM_MODULE_BY_TYPE[form.type as RoomTypeKey];
  const selected = room.selections.map((s) => ({ ...s, material: materials.find((m) => m.id === s.materialId) })).filter((s) => s.material);

  async function save() {
    setSaving(true);
    setErrors({});
    try {
      await api(`/api/rooms/${room.id}`, { method: "PATCH", body: { ...form, style: form.style || null, tier: form.tier || null, lengthFt: form.lengthFt || null, widthFt: form.widthFt || null, heightFt: form.heightFt || null } });
      toast("Room saved");
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  }
  async function remove() {
    if (!confirm(`Remove ${room.name}? Designs for this room are kept.`)) return;
    try {
      await api(`/api/rooms/${room.id}`, { method: "DELETE" });
      toast("Room removed");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <section className="rounded-[var(--radius-md)] border border-line bg-paper p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-2xl">{room.name}</h2>
          <p className="text-xs text-smoke">
            {ROOM_LABELS[room.type as RoomTypeKey]}
            {room.lengthFt && room.widthFt ? ` · ${room.lengthFt}′ × ${room.widthFt}′ × ${room.heightFt ?? 10}′` : " · dimensions not set"}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href={`/visualizer?project=${projectId}&room=${room.id}`} className="inline-flex h-8 items-center gap-1.5 rounded-[var(--radius-sm)] border border-line px-3 text-[0.8rem] text-charcoal hover:border-sand">
            <Box className="size-3.5" /> 3D
          </Link>
          {editable && canDelete ? (
            <Button variant="ghost" size="sm" onClick={remove} aria-label={`Remove ${room.name}`}>
              <Trash2 className="size-3.5" />
            </Button>
          ) : null}
        </div>
      </div>

      <fieldset disabled={!editable} className="mt-4 grid gap-3 md:grid-cols-6">
        <Field label="Name" htmlFor={`n-${room.id}`} className="md:col-span-2">
          <Input id={`n-${room.id}`} value={form.name} onChange={set("name")} />
        </Field>
        <Field label="Type" htmlFor={`t-${room.id}`} className="md:col-span-1">
          <Select id={`t-${room.id}`} value={form.type} onChange={set("type")}>
            {ROOM_MODULES.map((m) => (
              <option key={m.type} value={m.type}>
                {m.label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={`${mod?.dimensionLabels.length ?? "Length"} (ft)`} error={errors.lengthFt} htmlFor={`l-${room.id}`}>
          <Input id={`l-${room.id}`} type="number" step={0.5} min={1} value={form.lengthFt} onChange={set("lengthFt")} />
        </Field>
        <Field label={`${mod?.dimensionLabels.width ?? "Width"} (ft)`} error={errors.widthFt} htmlFor={`w-${room.id}`}>
          <Input id={`w-${room.id}`} type="number" step={0.5} min={1} value={form.widthFt} onChange={set("widthFt")} />
        </Field>
        <Field label="Height (ft)" error={errors.heightFt} htmlFor={`h-${room.id}`}>
          <Input id={`h-${room.id}`} type="number" step={0.5} min={6} value={form.heightFt} onChange={set("heightFt")} />
        </Field>
        <Field label="Style for this room" htmlFor={`s-${room.id}`} className="md:col-span-2">
          <Select id={`s-${room.id}`} value={form.style} onChange={set("style")}>
            <option value="">Same as project{projectStyle ? ` (${STYLE_INFO[projectStyle as keyof typeof STYLE_INFO]?.label})` : ""}</option>
            {DESIGN_STYLES.map((s) => (
              <option key={s} value={s}>
                {STYLE_INFO[s].label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Finish level" htmlFor={`f-${room.id}`} className="md:col-span-2">
          <Select id={`f-${room.id}`} value={form.tier} onChange={set("tier")}>
            <option value="">Based on budget</option>
            {PRICE_TIERS.map((t) => (
              <option key={t} value={t}>
                {TIER_LABELS[t]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Notes for the designer" htmlFor={`p-${room.id}`} className="md:col-span-2">
          <Textarea id={`p-${room.id}`} rows={1} value={form.preferences} onChange={set("preferences")} placeholder="e.g. need a study corner" />
        </Field>
      </fieldset>
      {editable && dirty ? (
        <div className="mt-3 flex justify-end">
          <Button size="sm" onClick={save} loading={saving}>
            Save room
          </Button>
        </div>
      ) : null}

      <div className="mt-5 border-t border-line-soft pt-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-semibold text-charcoal">Selected materials</p>
          {editable ? (
            <Button size="sm" variant="secondary" onClick={() => setPickerOpen(true)}>
              <Layers className="size-3.5" /> {selected.length ? "Change materials" : "Select materials"}
            </Button>
          ) : null}
        </div>
        {selected.length ? (
          <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {selected.map((s) => (
              <li key={s.materialId} className="flex items-center gap-3 rounded-[var(--radius-sm)] border border-line-soft bg-white p-2">
                <MaterialSwatch category={s.material!.category} color={s.material!.color} name={s.material!.name} imageUrl={s.material!.imageUrl} className="w-14 shrink-0" />
                <div className="min-w-0 text-xs">
                  <p className="text-smoke">{MATERIAL_CATEGORY_LABELS[s.material!.category as MaterialCategoryKey]}</p>
                  <p className="truncate text-sm text-charcoal">{s.material!.name}</p>
                  <p className="text-smoke">
                    {s.material!.brand} · {formatINR(s.material!.rate)}/{s.material!.unit}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-2 text-sm text-smoke">No materials selected — estimates use typical materials for the finish level.</p>
        )}
      </div>

      {pickerOpen ? <MaterialPicker room={room} materials={materials} onClose={() => setPickerOpen(false)} categories={(mod?.materialCategories ?? []) as MaterialCategoryKey[]} /> : null}
    </section>
  );
}

function MaterialPicker({ room, materials, categories, onClose }: { room: RoomView; materials: PickerMaterial[]; categories: MaterialCategoryKey[]; onClose: () => void }) {
  const router = useRouter();
  const { toast } = useToast();
  const initial = useMemo(() => {
    const m: Record<string, string> = {};
    for (const s of room.selections) {
      const mat = materials.find((x) => x.id === s.materialId);
      if (mat) m[mat.category] = mat.id;
    }
    return m;
  }, [room.selections, materials]);
  const [choice, setChoice] = useState<Record<string, string>>(initial);
  const [saving, setSaving] = useState(false);
  const tier = room.tier ?? "STANDARD";

  async function save() {
    setSaving(true);
    try {
      await api(`/api/rooms/${room.id}/materials`, { method: "PUT", body: { selections: Object.entries(choice).filter(([, v]) => v).map(([cat, materialId]) => ({ materialId, application: MATERIAL_CATEGORY_LABELS[cat as MaterialCategoryKey] })) } });
      toast("Materials saved");
      onClose();
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={`Materials for ${room.name}`}
      description="Pick one option per category, or leave a category on “No preference”."
      size="xl"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={saving}>
            Save selection
          </Button>
        </>
      }
    >
      <div className="space-y-6">
        {categories.map((cat) => {
          const list = materials.filter((m) => m.category === cat);
          if (!list.length) return null;
          return (
            <section key={cat}>
              <div className="flex items-center justify-between">
                <h3 className="font-sans text-sm font-semibold text-charcoal">{MATERIAL_CATEGORY_LABELS[cat]}</h3>
                <button type="button" onClick={() => setChoice((c) => ({ ...c, [cat]: "" }))} className="text-xs text-smoke hover:text-charcoal">
                  No preference
                </button>
              </div>
              <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {list.map((m) => {
                  const on = choice[cat] === m.id;
                  return (
                    <button key={m.id} type="button" onClick={() => setChoice((c) => ({ ...c, [cat]: m.id }))} aria-pressed={on} className={`flex items-center gap-3 rounded-[var(--radius-sm)] border p-2 text-left transition-colors ${on ? "border-brass bg-brass-soft/60" : "border-line bg-white hover:border-sand"}`}>
                      <MaterialSwatch category={m.category} color={m.color} name={m.name} imageUrl={m.imageUrl} className="w-14 shrink-0" />
                      <span className="min-w-0 text-xs">
                        <span className="block truncate text-sm text-charcoal">{m.name}</span>
                        <span className="block text-smoke">
                          {m.brand} · {formatINR(m.rate)}/{m.unit}
                        </span>
                        {m.tier === tier ? <Badge tone="brass" className="mt-1">Fits your finish level</Badge> : <span className="mt-1 block text-mist">{TIER_LABELS[m.tier as keyof typeof TIER_LABELS]}</span>}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
    </Modal>
  );
}
