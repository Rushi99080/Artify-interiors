"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { FileText, ImageIcon, UploadCloud, X } from "lucide-react";
import { UPLOAD_RULES, checkUploadMeta, type UploadCategory } from "@/lib/storage/rules";
import { FILE_CATEGORY_LABELS } from "@/lib/constants";
import { cn, formatBytes } from "@/lib/format";
import { api, errorMessage } from "@/lib/client/api";
import { Select } from "@/components/ui/field";

export type UploadedFileView = { id: string; roomId?: string | null; originalName: string; category: string; mimeType: string; sizeBytes: number; url: string | null };

type Item = { key: string; file: File; progress: number; status: "queued" | "uploading" | "done" | "error"; error?: string };

function xhrUpload(url: string, form: FormData, onProgress: (p: number) => void): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => {
      let data: unknown = null;
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        data = null;
      }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data);
      else reject(new Error((data as { error?: string; error_message?: string })?.error ?? (data as { error?: { message?: string } })?.error?.toString() ?? `Upload failed (${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error("Network error during upload."));
    xhr.send(form);
  });
}

/**
 * Drag-and-drop uploader with validation and progress. Uses the API route for local storage and a signed
 * direct upload for Cloudinary (so large files never pass through the serverless function).
 */
export function FileUploader({
  projectId,
  categories,
  defaultCategory,
  rooms,
  defaultRoomId,
  onUploaded,
  compact,
}: {
  projectId: string;
  categories: UploadCategory[];
  defaultCategory?: UploadCategory;
  rooms?: { id: string; name: string }[];
  defaultRoomId?: string | null;
  onUploaded?: (files: UploadedFileView[]) => void;
  compact?: boolean;
}) {
  const [category, setCategory] = useState<UploadCategory>(defaultCategory ?? categories[0]!);
  const [roomId, setRoomId] = useState<string>(defaultRoomId ?? "");
  const [items, setItems] = useState<Item[]>([]);
  const [drag, setDrag] = useState(false);
  const [provider, setProvider] = useState<"local" | "cloudinary" | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    api<{ provider: "local" | "cloudinary" }>("/api/uploads/config")
      .then((r) => setProvider(r.provider))
      .catch(() => setProvider("local"));
  }, []);
  useEffect(() => setRoomId(defaultRoomId ?? ""), [defaultRoomId]);

  const rule = UPLOAD_RULES[category];

  const uploadOne = useCallback(
    async (item: Item): Promise<UploadedFileView | null> => {
      const set = (patch: Partial<Item>) => setItems((list) => list.map((i) => (i.key === item.key ? { ...i, ...patch } : i)));
      set({ status: "uploading", progress: 0 });
      try {
        if (provider === "cloudinary") {
          const sign = await api<{ uploadUrl: string; fields: Record<string, string | number>; publicId: string; resourceType: "image" | "raw" }>(`/api/projects/${projectId}/files/sign`, {
            body: { filename: item.file.name, size: item.file.size, category },
          });
          const form = new FormData();
          for (const [k, v] of Object.entries(sign.fields)) form.append(k, String(v));
          form.append("file", item.file);
          const res = (await xhrUpload(sign.uploadUrl, form, (p) => set({ progress: p }))) as { public_id: string; version: number; signature: string; bytes: number };
          const reg = await api<{ file: UploadedFileView }>(`/api/projects/${projectId}/files/register`, {
            body: { publicId: res.public_id, version: res.version, signature: res.signature, resourceType: sign.resourceType, bytes: res.bytes, originalName: item.file.name, category, roomId: roomId || null },
          });
          set({ status: "done", progress: 100 });
          return reg.file;
        }
        const form = new FormData();
        form.append("category", category);
        if (roomId) form.append("roomId", roomId);
        form.append("file", item.file);
        const res = (await xhrUpload(`/api/projects/${projectId}/files`, form, (p) => set({ progress: p }))) as { files: UploadedFileView[] };
        set({ status: "done", progress: 100 });
        return res.files[0] ?? null;
      } catch (err) {
        set({ status: "error", error: errorMessage(err) });
        return null;
      }
    },
    [provider, projectId, category, roomId],
  );

  async function addFiles(list: FileList | File[]) {
    const files = Array.from(list).slice(0, 10);
    const newItems: Item[] = files.map((f) => {
      const problem = checkUploadMeta(category, f.name, f.size);
      return { key: `${f.name}-${f.size}-${Math.random()}`, file: f, progress: 0, status: problem ? "error" : "queued", error: problem ?? undefined };
    });
    setItems((prev) => [...newItems, ...prev].slice(0, 30));
    const uploaded: UploadedFileView[] = [];
    for (const it of newItems.filter((i) => i.status === "queued")) {
      const res = await uploadOne(it);
      if (res) uploaded.push(res);
    }
    if (uploaded.length) onUploaded?.(uploaded);
  }

  return (
    <div>
      {categories.length > 1 || (rooms && rooms.length > 0) ? (
        <div className={cn("mb-3 grid gap-3", rooms?.length && categories.length > 1 ? "sm:grid-cols-2" : "")}>
          {categories.length > 1 ? (
            <Select aria-label="What are you uploading?" value={category} onChange={(e) => setCategory(e.target.value as UploadCategory)}>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {FILE_CATEGORY_LABELS[c as keyof typeof FILE_CATEGORY_LABELS] ?? c}
                </option>
              ))}
            </Select>
          ) : null}
          {rooms && rooms.length ? (
            <Select aria-label="Room" value={roomId} onChange={(e) => setRoomId(e.target.value)}>
              <option value="">Whole project (not room-specific)</option>
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </Select>
          ) : null}
        </div>
      ) : null}

      <div
        role="button"
        tabIndex={0}
        onClick={() => inputRef.current?.click()}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          if (e.dataTransfer.files.length) void addFiles(e.dataTransfer.files);
        }}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center rounded-[var(--radius-md)] border border-dashed px-6 text-center transition-colors",
          compact ? "py-6" : "py-10",
          drag ? "border-brass bg-brass-soft/60" : "border-sand bg-white/60 hover:border-brass hover:bg-paper",
        )}
      >
        <UploadCloud className="size-7 text-brass" />
        <p className="mt-2 text-sm font-medium text-charcoal">Drop files here or click to browse</p>
        <p className="mt-1 text-xs text-smoke">
          {rule.label} · up to {rule.maxMB} MB each{provider === "cloudinary" ? " · secure cloud storage" : ""}
        </p>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={rule.exts.map((e) => `.${e}`).join(",")}
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.length) void addFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </div>

      {items.length ? (
        <ul className="mt-3 space-y-2">
          {items.map((i) => (
            <li key={i.key} className="flex items-center gap-3 rounded-[var(--radius-sm)] border border-line bg-white px-3 py-2 text-sm">
              {i.file.type.startsWith("image/") ? <ImageIcon className="size-4 shrink-0 text-smoke" /> : <FileText className="size-4 shrink-0 text-smoke" />}
              <div className="min-w-0 flex-1">
                <p className="truncate text-charcoal">{i.file.name}</p>
                {i.status === "error" ? (
                  <p className="text-xs text-brick">{i.error}</p>
                ) : (
                  <div className="mt-1 h-1 overflow-hidden rounded bg-line-soft">
                    <div className={cn("h-full transition-all", i.status === "done" ? "bg-moss" : "bg-brass")} style={{ width: `${i.progress}%` }} />
                  </div>
                )}
              </div>
              <span className="shrink-0 text-xs text-smoke">{i.status === "done" ? "Uploaded" : i.status === "uploading" ? `${i.progress}%` : i.status === "error" ? "" : formatBytes(i.file.size)}</span>
              {i.status !== "uploading" ? (
                <button type="button" onClick={() => setItems((l) => l.filter((x) => x.key !== i.key))} className="text-mist hover:text-charcoal" aria-label="Dismiss">
                  <X className="size-4" />
                </button>
              ) : null}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
