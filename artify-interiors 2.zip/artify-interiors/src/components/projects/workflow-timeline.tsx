import { CheckCircle2, Circle, CircleDot, MinusCircle, OctagonAlert } from "lucide-react";
import { formatDate } from "@/lib/format";
import { cn } from "@/lib/format";
import { computeProgress } from "@/lib/workflow/stages";

export type MilestoneView = { id: string; stageKey: string; name: string; sortOrder: number; status: "PENDING" | "IN_PROGRESS" | "COMPLETED" | "SKIPPED" | "BLOCKED"; dueDate: Date | string | null; completedAt: Date | string | null; notes: string | null; assigneeName?: string | null; customerVisible?: boolean };

const ICON = { COMPLETED: CheckCircle2, IN_PROGRESS: CircleDot, PENDING: Circle, SKIPPED: MinusCircle, BLOCKED: OctagonAlert };

/** Vertical project timeline (read-only). */
export function WorkflowTimeline({ milestones, compact }: { milestones: MilestoneView[]; compact?: boolean }) {
  const sorted = [...milestones].sort((a, b) => a.sortOrder - b.sortOrder);
  const progress = computeProgress(sorted);
  return (
    <div>
      <div className="mb-5">
        <div className="flex justify-between text-sm">
          <span className="text-ink">
            {progress.done} of {progress.total} stages complete
          </span>
          <span className="tabular-nums text-charcoal">{progress.percent}%</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-line-soft">
          <div className="h-full bg-brass transition-all" style={{ width: `${progress.percent}%` }} />
        </div>
      </div>
      <ol className="relative">
        {sorted.map((m, i) => {
          const Icon = ICON[m.status];
          const last = i === sorted.length - 1;
          return (
            <li key={m.id} className="relative flex gap-3 pb-4">
              {!last ? <span className={cn("absolute left-[9px] top-6 h-[calc(100%-1.25rem)] w-px", m.status === "COMPLETED" ? "bg-brass" : "bg-line")} aria-hidden /> : null}
              <Icon className={cn("relative mt-0.5 size-[19px] shrink-0 bg-paper", m.status === "COMPLETED" ? "text-brass" : m.status === "IN_PROGRESS" ? "text-slate" : m.status === "BLOCKED" ? "text-brick" : "text-mist")} />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                  <p className={cn("text-sm", m.status === "IN_PROGRESS" ? "font-semibold text-charcoal" : m.status === "COMPLETED" ? "text-ink" : "text-smoke")}>{m.name}</p>
                  <p className="text-xs text-mist">{m.completedAt ? `Done ${formatDate(m.completedAt)}` : m.dueDate ? `Target ${formatDate(m.dueDate)}` : ""}</p>
                </div>
                {!compact && (m.notes || m.assigneeName) ? <p className="mt-0.5 text-xs text-smoke">{[m.assigneeName ? `Owner: ${m.assigneeName}` : null, m.notes].filter(Boolean).join(" — ")}</p> : null}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
