"use client";

import { useEffect, useRef, useState } from "react";
import { Send } from "lucide-react";
import { api, errorMessage } from "@/lib/client/api";
import { cn, formatDate, initials } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/field";
import { useToast } from "@/components/ui/toast";

export type MessageView = { id: string; body: string; kind: string; fromTeam: boolean; createdAt: string; senderName: string | null };

export function MessagesThread({ projectId, initial, viewer }: { projectId: string; initial: MessageView[]; viewer: "customer" | "team" }) {
  const { toast } = useToast();
  const [messages, setMessages] = useState(initial);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  useEffect(() => {
    end.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  useEffect(() => {
    const t = setInterval(async () => {
      try {
        const r = await api<{ messages: { id: string; body: string; kind: string; fromTeam: boolean; createdAt: string; sender: { name: string } | null }[] }>(`/api/projects/${projectId}/messages`);
        setMessages(r.messages.map((m) => ({ id: m.id, body: m.body, kind: m.kind, fromTeam: m.fromTeam, createdAt: m.createdAt, senderName: m.sender?.name ?? null })));
      } catch {
        /* ignore polling errors */
      }
    }, 20_000);
    return () => clearInterval(t);
  }, [projectId]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    try {
      const r = await api<{ message: { id: string; body: string; kind: string; fromTeam: boolean; createdAt: string; sender: { name: string } | null } }>(`/api/projects/${projectId}/messages`, { body: { body: text } });
      setMessages((m) => [...m, { id: r.message.id, body: r.message.body, kind: r.message.kind, fromTeam: r.message.fromTeam, createdAt: r.message.createdAt, senderName: r.message.sender?.name ?? null }]);
      setText("");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-[calc(100svh-320px)] min-h-[420px] flex-col overflow-hidden rounded-[var(--radius-md)] border border-line bg-paper">
      <div className="flex-1 space-y-4 overflow-y-auto p-5">
        {messages.length === 0 ? <p className="py-10 text-center text-sm text-smoke">No messages yet. Ask a question or share an idea with the {viewer === "customer" ? "design team" : "client"}.</p> : null}
        {messages.map((m) => {
          if (m.kind !== "MESSAGE") {
            return (
              <p key={m.id} className="mx-auto max-w-md text-center text-xs text-smoke">
                <span className="rounded-full bg-travertine/70 px-3 py-1">{m.body}</span>
                <span className="mt-1 block text-[0.65rem] text-mist">{formatDate(m.createdAt, true)}</span>
              </p>
            );
          }
          const mine = viewer === "team" ? m.fromTeam : !m.fromTeam;
          return (
            <div key={m.id} className={cn("flex items-end gap-2", mine ? "flex-row-reverse" : "")}>
              <span className={cn("flex size-7 shrink-0 items-center justify-center rounded-full text-[0.65rem] font-semibold", m.fromTeam ? "bg-charcoal text-paper" : "bg-brass text-white")}>{initials(m.senderName ?? (m.fromTeam ? "Artify" : "Client"))}</span>
              <div className={cn("max-w-[75%] rounded-[var(--radius-md)] px-3.5 py-2.5 text-sm", mine ? "bg-charcoal text-paper" : "border border-line bg-white text-ink")}>
                <p className="whitespace-pre-line">{m.body}</p>
                <p className={cn("mt-1 text-[0.65rem]", mine ? "text-sand" : "text-mist")}>
                  {m.senderName ?? (m.fromTeam ? "Artify team" : "Client")} · {formatDate(m.createdAt, true)}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={end} />
      </div>
      <form onSubmit={send} className="flex items-end gap-2 border-t border-line-soft bg-plaster/60 p-3">
        <Textarea
          aria-label="Message"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) void send(e);
          }}
          rows={2}
          placeholder="Write a message…"
          className="min-h-0 flex-1 resize-none"
          maxLength={4000}
        />
        <Button type="submit" loading={busy} disabled={!text.trim()}>
          <Send className="size-4" /> Send
        </Button>
      </form>
    </div>
  );
}
