import { BUDGET_RANGES, PROPERTY_TYPE_LABELS, STYLE_INFO, type DesignStyleKey } from "@/lib/constants";
import { formatDate, formatINR } from "@/lib/format";

type P = {
  propertyType: string;
  carpetAreaSqft: number | null;
  designStyle: string | null;
  budgetMin: number | null;
  budgetMax: number | null;
  colorPalette: string | null;
  materialPreferences: string | null;
  timeline: string | null;
  address: string | null;
  location: string;
  createdAt: Date;
  startDate: Date | null;
  targetDate: Date | null;
  notes?: string | null;
};

export function ProjectBrief({ p, showNotes }: { p: P; showNotes?: boolean }) {
  const budget = BUDGET_RANGES.find((b) => b.min === p.budgetMin && b.max === p.budgetMax)?.label ?? (p.budgetMax ? `${formatINR(p.budgetMin ?? 0)} – ${formatINR(p.budgetMax)}` : "—");
  const rows: [string, string | null][] = [
    ["Property", PROPERTY_TYPE_LABELS[p.propertyType as keyof typeof PROPERTY_TYPE_LABELS] ?? p.propertyType],
    ["Carpet area", p.carpetAreaSqft ? `${p.carpetAreaSqft} sqft` : null],
    ["Style", p.designStyle ? STYLE_INFO[p.designStyle as DesignStyleKey].label : null],
    ["Budget", budget],
    ["Timeline", p.timeline],
    ["Address", p.address ?? p.location],
    ["Colour palette", p.colorPalette],
    ["Material preferences", p.materialPreferences],
    ["Created", formatDate(p.createdAt)],
    ["Target completion", p.targetDate ? formatDate(p.targetDate) : null],
  ];
  if (showNotes) rows.push(["Notes", p.notes ?? null]);
  return (
    <dl className="grid gap-x-6 gap-y-4 text-sm sm:grid-cols-2">
      {rows.map(([k, v]) => (
        <div key={k}>
          <dt className="text-xs text-smoke">{k}</dt>
          <dd className="mt-0.5 whitespace-pre-line text-charcoal">{v || "—"}</dd>
        </div>
      ))}
    </dl>
  );
}
