"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { MILESTONE_STATUS_LABELS } from "@/lib/constants";
import { api, errorMessage } from "@/lib/client/api";
import { cn, formatDate } from "@/lib/format";
import { computeProgress } from "@/lib/workflow/stages";
import { Button } from "@/components/ui/button";
import { Input, Select, Checkbox } from "@/components/ui/field";
import { useToast } from "@/components/ui/toast";

export type EditableMilestone = { id: string; stageKey: string; name: string; sortOrder: number; status: "PENDING" | "IN_PROGRESS" | "COMPLETED" | "SKIPPED" | "BLOCKED"; assigneeId: string | null; dueDate: string | null; completedAt: string | null; notes: string | null; customerVisible: boolean };

/** Team: manage each workflow stage — status, owner, due date, notes. Changes notify the client. */
export function WorkflowEditor({ projectId, milestones, team }: { projectId: string; milestones: EditableMilestone[]; team: { id: string; name: string }[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [notify, setNotify] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const progress = computeProgress(milestones);

  async function update(id: string, body: Record<string, unknown>) {
    setBusy(id);
    try {
      await api(`/api/milestones/${id}`, { method: "PATCH", body: { ...body, notifyCustomer: notify } });
      toast("Stage updated");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }
  async function sync() {
    setBusy("sync");
    try {
      await api(`/api/projects/${projectId}/workflow`, { method: "POST" });
      toast("Workflow synced with stage settings");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-[220px] flex-1">
          <div className="flex justify-between text-sm">
            <span>
              {progress.done} of {progress.total} stages complete
            </span>
            <span className="tabular-nums">{progress.percent}%</span>
          </div>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-line-soft">
            <div className="h-full bg-brass" style={{ width: `${progress.percent}%` }} />
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Checkbox label="Notify client of changes" checked={notify} onChange={(e) => setNotify(e.target.checked)} />
          <Button size="sm" variant="secondary" onClick={sync} loading={busy === "sync"}>
            Sync stages
          </Button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="data-table min-w-[900px]">
          <thead>
            <tr>
              <th>#</th>
              <th>Stage</th>
              <th>Status</th>
              <th>Owner</th>
              <th>Due</th>
              <th>Notes</th>
              <th>Client sees</th>
            </tr>
          </thead>
          <tbody>
            {[...milestones]
              .sort((a, b) => a.sortOrder - b.sortOrder)
              .map((m, i) => (
                <MilestoneRow key={m.id} m={m} index={i + 1} team={team} busy={busy === m.id} onUpdate={(b) => update(m.id, b)} />
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MilestoneRow({ m, index, team, busy, onUpdate }: { m: EditableMilestone; index: number; team: { id: string; name: string }[]; busy: boolean; onUpdate: (b: Record<string, unknown>) => void }) {
  const [notes, setNotes] = useState(m.notes ?? "");
  return (
    <tr className={cn(busy && "opacity-60")}>
      <td className="text-smoke">{index}</td>
      <td className={cn(m.status === "IN_PROGRESS" ? "font-semibold text-charcoal" : "text-ink")}>
        {m.name}
        {m.completedAt ? <span className="block text-xs font-normal text-smoke">Done {formatDate(m.completedAt)}</span> : null}
      </td>
      <td>
        <Select aria-label={`Status of ${m.name}`} value={m.status} onChange={(e) => onUpdate({ status: e.target.value })} className="py-1.5 text-sm">
          {Object.entries(MILESTONE_STATUS_LABELS).map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </Select>
      </td>
      <td>
        <Select aria-label={`Owner of ${m.name}`} value={m.assigneeId ?? ""} onChange={(e) => onUpdate({ assigneeId: e.target.value || null })} className="py-1.5 text-sm">
          <option value="">Unassigned</option>
          {team.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </Select>
      </td>
      <td>
        <Input aria-label={`Due date of ${m.name}`} type="date" defaultValue={m.dueDate?.slice(0, 10) ?? ""} onBlur={(e) => e.target.value !== (m.dueDate?.slice(0, 10) ?? "") && onUpdate({ dueDate: e.target.value || null })} className="py-1.5 text-sm" />
      </td>
      <td>
        <Input aria-label={`Notes for ${m.name}`} value={notes} onChange={(e) => setNotes(e.target.value)} onBlur={() => notes !== (m.notes ?? "") && onUpdate({ notes: notes || null })} placeholder="Add a note" className="min-w-[12rem] py-1.5 text-sm" />
      </td>
      <td>
        <input type="checkbox" aria-label={`Visible to client: ${m.name}`} checked={m.customerVisible} onChange={(e) => onUpdate({ customerVisible: e.target.checked })} className="size-4 accent-[var(--color-brass)]" />
      </td>
    </tr>
  );
}
