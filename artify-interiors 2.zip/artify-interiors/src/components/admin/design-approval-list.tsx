"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Check, NotebookPen, RotateCcw, X } from "lucide-react";
import { DESIGN_STATUS_LABELS, STYLE_INFO, TIER_LABELS, type DesignStyleKey, type PriceTierKey } from "@/lib/constants";
import { formatINRCompact, formatRelative } from "@/lib/format";
import { api, errorMessage } from "@/lib/client/api";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Field, Textarea } from "@/components/ui/field";
import { SmartImage } from "@/components/ui/smart-image";
import { useToast } from "@/components/ui/toast";

export type ApprovalRow = {
  id: string;
  name: string;
  style: string;
  tier: string;
  status: string;
  imageUrl: string | null;
  palette: string[];
  budgetMin: number | null;
  budgetMax: number | null;
  customerComment: string | null;
  adminNotes: string | null;
  updatedAt: string;
  project: { id: string; name: string; code: string; customer: string };
  roomName: string | null;
};

export function DesignApprovalList({ rows: initial }: { rows: ApprovalRow[] }) {
  const { toast } = useToast();
  const router = useRouter();
  const [rows, setRows] = useState(initial);
  useEffect(() => setRows(initial), [initial]);
  const [busy, setBusy] = useState<string | null>(null);
  const [notesFor, setNotesFor] = useState<ApprovalRow | null>(null);
  const [notes, setNotes] = useState("");

  async function patch(row: ApprovalRow, body: Record<string, unknown>, done: string) {
    setBusy(`${row.id}:${String(body.action ?? "notes")}`);
    try {
      const r = await api<{ design: { status: string; adminNotes: string | null; updatedAt: string } }>(`/api/designs/${row.id}`, { method: "PATCH", body });
      setRows((list) => list.map((x) => (x.id === row.id ? { ...x, status: r.design.status, adminNotes: r.design.adminNotes, updatedAt: r.design.updatedAt } : x)));
      toast(done);
      // decisions move the concept between tabs — refresh counts and lists
      if (body.action) setTimeout(() => router.refresh(), 1200);
      return true;
    } catch (err) {
      toast(errorMessage(err), "error");
      return false;
    } finally {
      setBusy(null);
    }
  }

  return (
    <>
      <ul className="grid gap-3">
        {rows.map((d) => {
          const style = STYLE_INFO[d.style as DesignStyleKey]?.label ?? d.style;
          const decided = d.status === "APPROVED" || d.status === "REJECTED";
          return (
            <li key={d.id} className="grid gap-4 rounded-[var(--radius-md)] border border-line bg-paper p-3 sm:grid-cols-[160px_1fr] md:p-4 lg:grid-cols-[180px_1fr_auto]">
              <SmartImage src={d.imageUrl} alt={`${d.name} concept render`} className="aspect-[4/3] rounded-[var(--radius-sm)]" fallbackLabel="No render" />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-sans text-[0.95rem] font-semibold text-charcoal">{d.name}</h3>
                  <StatusBadge status={d.status} label={DESIGN_STATUS_LABELS[d.status as keyof typeof DESIGN_STATUS_LABELS]} />
                </div>
                <p className="mt-0.5 text-sm text-smoke">
                  {style} · {TIER_LABELS[d.tier as PriceTierKey] ?? d.tier}
                  {d.budgetMin && d.budgetMax ? ` · ${formatINRCompact(d.budgetMin)}–${formatINRCompact(d.budgetMax)}` : ""}
                </p>
                <p className="mt-1 text-sm">
                  <Link href={`/admin/projects/${d.project.id}/designs`} className="text-ink underline decoration-sand underline-offset-4">
                    {d.project.name}
                  </Link>
                  <span className="text-smoke">
                    {" "}
                    · {d.roomName ?? "Whole home"} · {d.project.customer}
                  </span>
                </p>
                {d.palette.length ? (
                  <div className="mt-2 flex gap-1" aria-label="Colour palette">
                    {d.palette.slice(0, 6).map((hex, i) => (
                      <span key={`${hex}-${i}`} title={hex} className="size-4 rounded-full border border-black/10" style={{ background: hex }} />
                    ))}
                  </div>
                ) : null}
                {d.customerComment ? <p className="mt-2 rounded-[var(--radius-sm)] bg-amber-soft px-3 py-2 text-sm text-ink">Client: “{d.customerComment}”</p> : null}
                {d.adminNotes ? <p className="mt-2 rounded-[var(--radius-sm)] bg-brass-soft px-3 py-2 text-sm text-ink">Team note: {d.adminNotes}</p> : null}
                <p className="mt-2 text-xs text-smoke">Updated {formatRelative(d.updatedAt)}</p>
              </div>
              <div className="flex flex-wrap items-start gap-2 sm:col-span-2 lg:col-span-1 lg:flex-col lg:items-stretch">
                {!decided ? (
                  <>
                    <Button size="sm" onClick={() => patch(d, { action: "approve" }, "Design approved — client notified")} loading={busy === `${d.id}:approve`}>
                      <Check className="size-3.5" /> Approve
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => patch(d, { action: "reject" }, "Design rejected")} loading={busy === `${d.id}:reject`}>
                      <X className="size-3.5" /> Reject
                    </Button>
                  </>
                ) : (
                  <Button size="sm" variant="secondary" onClick={() => patch(d, { action: "reset" }, "Decision reset")} loading={busy === `${d.id}:reset`}>
                    <RotateCcw className="size-3.5" /> Reset decision
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setNotes(d.adminNotes ?? "");
                    setNotesFor(d);
                  }}
                >
                  <NotebookPen className="size-3.5" /> {d.adminNotes ? "Edit team note" : "Add team note"}
                </Button>
              </div>
            </li>
          );
        })}
      </ul>

      <Modal open={!!notesFor} onClose={() => setNotesFor(null)} title="Team note" description="Visible to the studio team only — clients never see it.">
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (notesFor && (await patch(notesFor, { adminNotes: notes }, "Team note saved"))) setNotesFor(null);
          }}
          className="space-y-4"
        >
          <Field label="Note" htmlFor="design-note">
            <Textarea id="design-note" rows={5} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={2000} placeholder="e.g. Swap the fluted panel for a plain laminate to keep within budget." />
          </Field>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={() => setNotesFor(null)}>
              Cancel
            </Button>
            <Button type="submit" loading={!!busy && busy.endsWith(":notes")}>
              Save note
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}
