"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { FolderPlus, Plus } from "lucide-react";
import { DESIGN_STYLES, LEAD_SOURCE_LABELS, LEAD_STATUS_LABELS, PROPERTY_TYPES, PROPERTY_TYPE_LABELS, STYLE_INFO } from "@/lib/constants";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";

export function NewLeadButton({ team }: { team: { id: string; name: string }[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  void team;
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    setErrors({});
    try {
      await api("/api/leads", { body: Object.fromEntries([...fd.entries()].map(([k, v]) => [k, v === "" ? null : v])) });
      toast("Lead created");
      setOpen(false);
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Button onClick={() => setOpen(true)}>
        <Plus className="size-4" /> New lead
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title="New lead" description="Walk-ins, referrals and phone enquiries.">
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Name" error={errors.name} htmlFor="nl-n">
            <Input id="nl-n" name="name" required />
          </Field>
          <Field label="Phone" error={errors.phone} htmlFor="nl-p">
            <Input id="nl-p" name="phone" type="tel" required />
          </Field>
          <Field label="Email" error={errors.email} htmlFor="nl-e">
            <Input id="nl-e" name="email" type="email" />
          </Field>
          <Field label="City / area" htmlFor="nl-c">
            <Input id="nl-c" name="city" />
          </Field>
          <Field label="Property type" htmlFor="nl-t">
            <Select id="nl-t" name="projectType" defaultValue="">
              <option value="">—</option>
              {PROPERTY_TYPES.map((p) => (
                <option key={p} value={p}>
                  {PROPERTY_TYPE_LABELS[p]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Source" htmlFor="nl-s">
            <Select id="nl-s" name="source" defaultValue="WALK_IN">
              {Object.entries(LEAD_SOURCE_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Budget" htmlFor="nl-b">
            <Input id="nl-b" name="budget" placeholder="e.g. ₹10 – 20 Lakh" />
          </Field>
          <Field label="Notes" htmlFor="nl-m" className="sm:col-span-2">
            <Textarea id="nl-m" name="message" rows={3} />
          </Field>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={busy}>
              Create lead
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}

export function LeadEditor({ lead, team }: { lead: { id: string; status: string; followUpDate: string | null; assignedToId: string | null; lostReason: string | null }; team: { id: string; name: string }[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [form, setForm] = useState({ status: lead.status, followUpDate: lead.followUpDate?.slice(0, 10) ?? "", assignedToId: lead.assignedToId ?? "", lostReason: lead.lostReason ?? "", note: "" });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      await api(`/api/leads/${lead.id}`, { method: "PATCH", body: { status: form.status, followUpDate: form.followUpDate || null, assignedToId: form.assignedToId || null, lostReason: form.lostReason, note: form.note } });
      toast("Lead updated");
      setForm((f) => ({ ...f, note: "" }));
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));
  return (
    <div className="grid gap-4">
      <Field label="Status" htmlFor="le-s">
        <Select id="le-s" value={form.status} onChange={set("status")}>
          {Object.entries(LEAD_STATUS_LABELS).map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Next follow-up" htmlFor="le-f">
          <Input id="le-f" type="date" value={form.followUpDate} onChange={set("followUpDate")} />
        </Field>
        <Field label="Assigned to" htmlFor="le-a">
          <Select id="le-a" value={form.assignedToId} onChange={set("assignedToId")}>
            <option value="">Unassigned</option>
            {team.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      {form.status === "LOST" ? (
        <Field label="Reason lost" htmlFor="le-l">
          <Input id="le-l" value={form.lostReason} onChange={set("lostReason")} placeholder="Budget, timing, chose another firm…" />
        </Field>
      ) : null}
      <Field label="Add an internal note" htmlFor="le-n">
        <Textarea id="le-n" value={form.note} onChange={set("note")} rows={3} placeholder="Call summary, next steps…" />
      </Field>
      <div>
        <Button onClick={save} loading={busy}>
          Save changes
        </Button>
      </div>
    </div>
  );
}

export function ConvertLeadButton({ leadId, defaultName, defaultLocation, defaultType }: { leadId: string; defaultName: string; defaultLocation: string; defaultType: string | null }) {
  const router = useRouter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const r = await api<{ projectId: string }>(`/api/leads/${leadId}/convert`, { body: { projectName: fd.get("projectName"), location: fd.get("location"), propertyType: fd.get("propertyType"), designStyle: fd.get("designStyle") || undefined } });
      toast("Project created");
      router.push(`/admin/projects/${r.projectId}`);
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Button onClick={() => setOpen(true)}>
        <FolderPlus className="size-4" /> Create project
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Create project from lead" description="Creates the customer record and a draft project with workflow. Add rooms and dimensions next.">
        <form onSubmit={submit} className="grid gap-4">
          <Field label="Project name" htmlFor="cv-n">
            <Input id="cv-n" name="projectName" defaultValue={defaultName} required />
          </Field>
          <Field label="Location" htmlFor="cv-l">
            <Input id="cv-l" name="location" defaultValue={defaultLocation} required />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Property type" htmlFor="cv-t">
              <Select id="cv-t" name="propertyType" defaultValue={defaultType ?? "APARTMENT"}>
                {PROPERTY_TYPES.map((p) => (
                  <option key={p} value={p}>
                    {PROPERTY_TYPE_LABELS[p]}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Design style" htmlFor="cv-s">
              <Select id="cv-s" name="designStyle" defaultValue="">
                <option value="">Not decided</option>
                {DESIGN_STYLES.map((s) => (
                  <option key={s} value={s}>
                    {STYLE_INFO[s].label}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={busy}>
              Create project
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}
