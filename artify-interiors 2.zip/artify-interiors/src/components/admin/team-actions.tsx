"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Checkbox } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { Notice } from "@/components/ui/notice";
import { useToast } from "@/components/ui/toast";

export type TeamMemberView = { id: string; name: string; designation: string; department: string | null; phone: string | null; email: string | null; isActive: boolean; login: { role: "STAFF" | "ADMIN" | "CUSTOMER"; email: string; isActive: boolean } | null; isSelf: boolean };

export function TeamMemberFormButton({ member }: { member?: TeamMemberView }) {
  const router = useRouter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [createLogin, setCreateLogin] = useState(false);
  const hasLogin = !!member?.login;

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const s = (k: string) => {
      const v = String(fd.get(k) ?? "").trim();
      return v === "" ? null : v;
    };
    const password = s("password");
    const body: Record<string, unknown> = {
      name: s("name") ?? "",
      designation: s("designation") ?? "",
      department: s("department"),
      phone: s("phone"),
      email: s("email"),
      // disabled inputs are not submitted — your own account always stays active
      isActive: member?.isSelf ? true : fd.get("isActive") === "on",
    };
    if (hasLogin) {
      body.loginRole = s("loginRole") ?? undefined;
      if (password) body.password = password;
    } else if (createLogin) {
      body.createLogin = true;
      body.loginRole = s("loginRole") ?? "STAFF";
      body.password = password ?? "";
    }
    setBusy(true);
    setErrors({});
    try {
      if (member) await api(`/api/team/${member.id}`, { method: "PATCH", body });
      else await api("/api/team", { body });
      toast(member ? "Team member updated" : "Team member added");
      setOpen(false);
      setCreateLogin(false);
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {member ? (
        <button type="button" onClick={() => setOpen(true)} className="rounded p-1.5 text-smoke hover:bg-travertine/60 hover:text-charcoal" aria-label={`Edit ${member.name}`}>
          <Pencil className="size-4" />
        </button>
      ) : (
        <Button onClick={() => setOpen(true)}>
          <Plus className="size-4" /> Add team member
        </Button>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title={member ? `Edit ${member.name}` : "Add team member"} description="Team members can be assigned to workflow stages and leads. Give them a login to use the admin panel." size="lg">
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Full name" htmlFor="t-name" required error={errors.name}>
            <Input id="t-name" name="name" defaultValue={member?.name} required maxLength={100} />
          </Field>
          <Field label="Designation" htmlFor="t-designation" required error={errors.designation}>
            <Input id="t-designation" name="designation" defaultValue={member?.designation} required maxLength={80} placeholder="e.g. Senior Designer, Site Supervisor" />
          </Field>
          <Field label="Department" htmlFor="t-department" error={errors.department}>
            <Input id="t-department" name="department" defaultValue={member?.department ?? ""} maxLength={80} placeholder="Design, Execution, Sales" />
          </Field>
          <Field label="Phone" htmlFor="t-phone" error={errors.phone}>
            <Input id="t-phone" name="phone" type="tel" defaultValue={member?.phone ?? ""} maxLength={30} />
          </Field>
          <Field label="Email" htmlFor="t-email" error={errors.email} hint={hasLogin ? `Login email: ${member!.login!.email}` : undefined} className="sm:col-span-2">
            <Input id="t-email" name="email" type="email" defaultValue={member?.email ?? ""} maxLength={160} />
          </Field>

          <div className="rounded-[var(--radius-md)] border border-line-soft bg-plaster/50 p-4 sm:col-span-2">
            {hasLogin ? (
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Access level" htmlFor="t-role" hint="Admins also manage settings, team, website content, expenses and reports.">
                  <Select id="t-role" name="loginRole" defaultValue={member!.login!.role === "ADMIN" ? "ADMIN" : "STAFF"} disabled={member!.isSelf}>
                    <option value="STAFF">Staff</option>
                    <option value="ADMIN">Admin</option>
                  </Select>
                </Field>
                <Field label="Reset password" htmlFor="t-password" error={errors.password} hint="Leave blank to keep the current password.">
                  <Input id="t-password" name="password" type="password" autoComplete="new-password" minLength={8} maxLength={128} />
                </Field>
              </div>
            ) : (
              <>
                <Checkbox label="Create a login for the admin panel" checked={createLogin} onChange={(e) => setCreateLogin(e.target.checked)} />
                {createLogin ? (
                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    <Field label="Access level" htmlFor="t-role-new">
                      <Select id="t-role-new" name="loginRole" defaultValue="STAFF">
                        <option value="STAFF">Staff</option>
                        <option value="ADMIN">Admin</option>
                      </Select>
                    </Field>
                    <Field label="Temporary password" htmlFor="t-password-new" required error={errors.password} hint="At least 8 characters with letters and numbers. Share it privately.">
                      <Input id="t-password-new" name="password" type="password" autoComplete="new-password" required minLength={8} maxLength={128} />
                    </Field>
                    <Notice kind="info" className="sm:col-span-2">
                      The login uses the email above. Ask them to change the password from their profile after signing in.
                    </Notice>
                  </div>
                ) : null}
              </>
            )}
          </div>

          <Checkbox name="isActive" label={hasLogin ? "Active (unticking also blocks their login)" : "Active"} defaultChecked={member?.isActive ?? true} disabled={member?.isSelf} className="sm:col-span-2" />
          <div className="flex justify-end gap-2 border-t border-line-soft pt-4 sm:col-span-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={busy}>
              {member ? "Save changes" : "Add team member"}
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}

export function RemoveTeamMemberButton({ id, name }: { id: string; name: string }) {
  const router = useRouter();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  async function run() {
    if (!confirm(`Remove ${name} from the team? Their login (if any) is disabled and their stage assignments are cleared.`)) return;
    setBusy(true);
    try {
      await api(`/api/team/${id}`, { method: "DELETE" });
      toast(`${name} removed`);
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <button type="button" onClick={run} disabled={busy} className="rounded p-1.5 text-smoke hover:bg-brick-soft hover:text-brick disabled:opacity-50" aria-label={`Remove ${name}`}>
      <Trash2 className="size-4" />
    </button>
  );
}
