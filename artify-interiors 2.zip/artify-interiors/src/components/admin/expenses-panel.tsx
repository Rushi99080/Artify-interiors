"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { EXPENSE_CATEGORY_LABELS } from "@/lib/constants";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { formatDate, formatINR } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Panel, PanelHeader } from "@/components/ui/panel";
import { useToast } from "@/components/ui/toast";

type Expense = { id: string; category: string; description: string; amount: number; paidTo: string | null; spentAt: string; supplierName: string | null };

export function ExpensesPanel({ projectId, expenses, suppliers, canManage }: { projectId: string; expenses: Expense[]; suppliers: { id: string; name: string }[]; canManage: boolean }) {
  const router = useRouter();
  const { toast } = useToast();
  const [form, setForm] = useState({ category: "MATERIAL", description: "", amount: "", paidTo: "", supplierId: "", spentAt: new Date().toISOString().slice(0, 10) });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const total = expenses.reduce((s, e) => s + e.amount, 0);
  const byCat = Object.entries(expenses.reduce<Record<string, number>>((acc, e) => ((acc[e.category] = (acc[e.category] ?? 0) + e.amount), acc), {}));

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    try {
      await api(`/api/projects/${projectId}/expenses`, { body: { ...form, amount: Number(form.amount), supplierId: form.supplierId || null } });
      toast("Expense recorded");
      setForm((f) => ({ ...f, description: "", amount: "", paidTo: "" }));
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  async function remove(id: string) {
    if (!confirm("Delete this expense?")) return;
    try {
      await api(`/api/expenses/${id}`, { method: "DELETE" });
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }

  return (
    <Panel>
      <PanelHeader title="Project expenses" description={`Actual spend — ${formatINR(total)} recorded. Used for project-wise profit and material cost reports.`} />
      {byCat.length ? (
        <div className="mb-4 flex flex-wrap gap-2 text-xs">
          {byCat.map(([c, v]) => (
            <span key={c} className="rounded-full bg-travertine/70 px-3 py-1 text-ink">
              {EXPENSE_CATEGORY_LABELS[c as keyof typeof EXPENSE_CATEGORY_LABELS]}: <span className="tabular-nums">{formatINR(v)}</span>
            </span>
          ))}
        </div>
      ) : null}
      {canManage ? (
        <form onSubmit={add} className="mb-5 grid gap-3 rounded-[var(--radius-sm)] border border-line-soft bg-white p-3 md:grid-cols-[130px_1fr_120px_1fr_140px_auto] md:items-end">
          <Field label="Category" htmlFor="ex-c">
            <Select id="ex-c" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {Object.entries(EXPENSE_CATEGORY_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Description" error={errors.description} htmlFor="ex-d">
            <Input id="ex-d" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="e.g. 20 sheets BWP ply" />
          </Field>
          <Field label="Amount (₹)" error={errors.amount} htmlFor="ex-a">
            <Input id="ex-a" type="number" min={1} step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          </Field>
          <Field label="Paid to" htmlFor="ex-p">
            {suppliers.length ? (
              <Select id="ex-p" value={form.supplierId} onChange={(e) => setForm({ ...form, supplierId: e.target.value, paidTo: e.target.selectedOptions[0]?.text ?? "" })}>
                <option value="">Other / not a supplier</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            ) : (
              <Input id="ex-p" value={form.paidTo} onChange={(e) => setForm({ ...form, paidTo: e.target.value })} />
            )}
          </Field>
          <Field label="Date" htmlFor="ex-dt">
            <Input id="ex-dt" type="date" value={form.spentAt} onChange={(e) => setForm({ ...form, spentAt: e.target.value })} />
          </Field>
          <Button type="submit" loading={busy}>
            <Plus className="size-4" /> Add
          </Button>
        </form>
      ) : null}
      {expenses.length ? (
        <div className="overflow-x-auto">
          <table className="data-table min-w-[640px]">
            <thead>
              <tr>
                <th>Date</th>
                <th>Category</th>
                <th>Description</th>
                <th>Paid to</th>
                <th className="num">Amount</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {expenses.map((e) => (
                <tr key={e.id}>
                  <td>{formatDate(e.spentAt)}</td>
                  <td>{EXPENSE_CATEGORY_LABELS[e.category as keyof typeof EXPENSE_CATEGORY_LABELS]}</td>
                  <td className="text-charcoal">{e.description}</td>
                  <td className="text-smoke">{e.supplierName ?? e.paidTo ?? "—"}</td>
                  <td className="num">{formatINR(e.amount, { decimals: true })}</td>
                  <td className="text-right">
                    {canManage ? (
                      <button type="button" onClick={() => remove(e.id)} className="rounded p-1 text-smoke hover:text-brick" aria-label="Delete expense">
                        <Trash2 className="size-3.5" />
                      </button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-sm text-smoke">No expenses recorded.</p>
      )}
    </Panel>
  );
}
