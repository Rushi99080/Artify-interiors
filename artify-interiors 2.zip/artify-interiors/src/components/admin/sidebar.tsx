"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import {
  BarChart3,
  Bell,
  Box,
  CalendarRange,
  ClipboardList,
  FileText,
  FolderKanban,
  Globe,
  LayoutDashboard,
  Layers,
  Menu,
  Settings,
  Sparkles,
  CheckSquare,
  Truck,
  UserCog,
  Users,
  Wallet,
  X,
  Contact,
} from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { cn } from "@/lib/format";

type NavItem = { href: string; label: string; icon: typeof LayoutDashboard; perm?: string; exact?: boolean };

const GROUPS: { title: string; items: NavItem[] }[] = [
  { title: "", items: [{ href: "/admin", label: "Overview", icon: LayoutDashboard, exact: true }] },
  {
    title: "Clients",
    items: [
      { href: "/admin/leads", label: "Leads & CRM", icon: Contact },
      { href: "/admin/customers", label: "Customers", icon: Users },
    ],
  },
  {
    title: "Projects",
    items: [
      { href: "/admin/projects", label: "Projects", icon: FolderKanban },
      { href: "/admin/timeline", label: "Project timeline", icon: CalendarRange },
      { href: "/admin/ai-requests", label: "AI design requests", icon: Sparkles },
      { href: "/admin/designs", label: "Design approval", icon: CheckSquare },
    ],
  },
  {
    title: "Commercial",
    items: [
      { href: "/admin/boq", label: "BOQ management", icon: ClipboardList },
      { href: "/admin/quotations", label: "Quotations", icon: FileText },
      { href: "/admin/payments", label: "Payments", icon: Wallet },
    ],
  },
  {
    title: "Catalogue",
    items: [
      { href: "/admin/materials", label: "Material library", icon: Layers },
      { href: "/admin/suppliers", label: "Suppliers", icon: Truck },
    ],
  },
  {
    title: "Studio",
    items: [
      { href: "/admin/team", label: "Team", icon: UserCog, perm: "team.manage" },
      { href: "/admin/content", label: "Website content", icon: Globe, perm: "content.manage" },
      { href: "/admin/reports", label: "Reports", icon: BarChart3, perm: "reports.view" },
      { href: "/admin/notifications", label: "Notification log", icon: Bell, perm: "settings.manage" },
      { href: "/admin/settings", label: "Settings", icon: Settings, perm: "settings.manage" },
    ],
  },
];

export function AdminSidebar({ permissions }: { permissions: string[] }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [pathname]);

  const nav = (
    <nav className="flex flex-col gap-5 py-4" aria-label="Admin">
      {GROUPS.map((g) => {
        const items = g.items.filter((i) => !i.perm || permissions.includes(i.perm));
        if (!items.length) return null;
        return (
          <div key={g.title || "root"}>
            {g.title ? <p className="px-4 pb-1.5 text-[0.7rem] font-semibold text-sand/60">{g.title}</p> : null}
            <ul>
              {items.map((i) => {
                const active = i.exact ? pathname === i.href : pathname === i.href || pathname.startsWith(`${i.href}/`);
                return (
                  <li key={i.href}>
                    <Link href={i.href} aria-current={active ? "page" : undefined} className={cn("mx-2 flex items-center gap-2.5 rounded-[var(--radius-sm)] px-3 py-2 text-sm transition-colors", active ? "bg-white/10 text-paper" : "text-sand/85 hover:bg-white/5 hover:text-paper")}>
                      <i.icon className={cn("size-4", active ? "text-brass" : "text-sand/60")} />
                      {i.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}
      <div className="mx-4 mt-2 border-t border-white/10 pt-4">
        <Link href="/" className="flex items-center gap-2 text-xs text-sand/70 hover:text-paper">
          <Box className="size-3.5" /> View website
        </Link>
      </div>
    </nav>
  );

  return (
    <>
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col overflow-y-auto bg-charcoal lg:flex">
        <Link href="/admin" className="flex h-16 shrink-0 items-center px-4">
          <Logo tone="light" />
        </Link>
        {nav}
      </aside>
      <button type="button" onClick={() => setOpen(true)} className="fixed left-3 top-3 z-40 rounded p-2 text-charcoal hover:bg-travertine/60 lg:hidden" aria-label="Open admin menu">
        <Menu className="size-5" />
      </button>
      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-charcoal/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 overflow-y-auto bg-charcoal">
            <div className="flex h-16 items-center justify-between px-4">
              <Logo tone="light" />
              <button type="button" onClick={() => setOpen(false)} className="rounded p-1 text-sand hover:text-paper" aria-label="Close menu">
                <X className="size-5" />
              </button>
            </div>
            {nav}
          </aside>
        </div>
      ) : null}
    </>
  );
}
