"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { DESIGN_STYLES, PROJECT_STATUS_LABELS, STYLE_INFO } from "@/lib/constants";
import { api, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { useToast } from "@/components/ui/toast";

type P = { id: string; name: string; status: string; location: string; address: string | null; designStyle: string | null; carpetAreaSqft: number | null; notes: string | null; contractValue: number | null; timeline: string | null };

export function ProjectAdminForm({ p, canDelete }: { p: P; canDelete: boolean }) {
  const router = useRouter();
  const { toast } = useToast();
  const [f, setF] = useState({ name: p.name, status: p.status, location: p.location, address: p.address ?? "", designStyle: p.designStyle ?? "", carpetAreaSqft: p.carpetAreaSqft?.toString() ?? "", notes: p.notes ?? "", contractValue: p.contractValue?.toString() ?? "", timeline: p.timeline ?? "" });
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF((x) => ({ ...x, [k]: e.target.value }));
  async function save() {
    setBusy(true);
    try {
      await api(`/api/projects/${p.id}`, {
        method: "PATCH",
        body: { name: f.name, status: f.status, location: f.location, address: f.address || null, designStyle: f.designStyle || undefined, carpetAreaSqft: f.carpetAreaSqft || null, notes: f.notes || null, timeline: f.timeline || null, ...(f.contractValue && Number(f.contractValue) !== p.contractValue ? { contractValue: Number(f.contractValue) } : {}) },
      });
      toast("Project updated");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    if (!confirm("Delete this project and all its rooms, designs, BOQs, quotations and payments? This cannot be undone.")) return;
    try {
      await api(`/api/projects/${p.id}`, { method: "DELETE" });
      toast("Project deleted");
      router.push("/admin/projects");
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }
  return (
    <div className="grid gap-4">
      <Field label="Project name" htmlFor="pa-n">
        <Input id="pa-n" value={f.name} onChange={set("name")} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Status" htmlFor="pa-s">
          <Select id="pa-s" value={f.status} onChange={set("status")}>
            {Object.entries(PROJECT_STATUS_LABELS).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Design style" htmlFor="pa-st">
          <Select id="pa-st" value={f.designStyle} onChange={set("designStyle")}>
            <option value="">—</option>
            {DESIGN_STYLES.map((s) => (
              <option key={s} value={s}>
                {STYLE_INFO[s].label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Location" htmlFor="pa-l">
          <Input id="pa-l" value={f.location} onChange={set("location")} />
        </Field>
        <Field label="Carpet area (sqft)" htmlFor="pa-a">
          <Input id="pa-a" type="number" value={f.carpetAreaSqft} onChange={set("carpetAreaSqft")} />
        </Field>
        <Field label="Contract value (₹)" hint="Set automatically on quotation approval. Changing it rescales the payment schedule." htmlFor="pa-c">
          <Input id="pa-c" type="number" value={f.contractValue} onChange={set("contractValue")} />
        </Field>
        <Field label="Timeline" htmlFor="pa-t">
          <Input id="pa-t" value={f.timeline} onChange={set("timeline")} />
        </Field>
      </div>
      <Field label="Site address" htmlFor="pa-ad">
        <Input id="pa-ad" value={f.address} onChange={set("address")} />
      </Field>
      <Field label="Internal notes" htmlFor="pa-no">
        <Textarea id="pa-no" value={f.notes} onChange={set("notes")} rows={3} />
      </Field>
      <div className="flex flex-wrap justify-between gap-2">
        <Button onClick={save} loading={busy}>
          Save project
        </Button>
        {canDelete ? (
          <Button variant="ghost" onClick={remove} className="text-brick">
            Delete project
          </Button>
        ) : null}
      </div>
    </div>
  );
}
