"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { MATERIAL_CATEGORIES, MATERIAL_CATEGORY_LABELS } from "@/lib/constants";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea, Checkbox } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";

export type SupplierView = { id: string; name: string; contactPerson: string | null; phone: string | null; email: string | null; address: string | null; gstin: string | null; categories: string[]; notes: string | null; isActive: boolean };

export function SupplierFormButton({ supplier }: { supplier?: SupplierView }) {
  const router = useRouter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [cats, setCats] = useState<string[]>(supplier?.categories ?? []);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const s = (k: string) => {
      const v = String(fd.get(k) ?? "").trim();
      return v === "" ? null : v;
    };
    const body = { name: s("name") ?? "", contactPerson: s("contactPerson"), phone: s("phone"), email: s("email"), address: s("address"), gstin: s("gstin"), notes: s("notes"), categories: cats, isActive: fd.get("isActive") === "on" };
    setBusy(true);
    setErrors({});
    try {
      if (supplier) await api(`/api/suppliers/${supplier.id}`, { method: "PATCH", body });
      else await api("/api/suppliers", { body });
      toast(supplier ? "Supplier updated" : "Supplier added");
      setOpen(false);
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {supplier ? (
        <button type="button" onClick={() => setOpen(true)} className="rounded p-1.5 text-smoke hover:bg-travertine/60 hover:text-charcoal" aria-label={`Edit ${supplier.name}`}>
          <Pencil className="size-4" />
        </button>
      ) : (
        <Button onClick={() => setOpen(true)}>
          <Plus className="size-4" /> Add supplier
        </Button>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title={supplier ? "Edit supplier" : "Add supplier"} size="lg">
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Supplier name" htmlFor="s-name" required error={errors.name} className="sm:col-span-2">
            <Input id="s-name" name="name" defaultValue={supplier?.name} required maxLength={140} />
          </Field>
          <Field label="Contact person" htmlFor="s-contact" error={errors.contactPerson}>
            <Input id="s-contact" name="contactPerson" defaultValue={supplier?.contactPerson ?? ""} maxLength={100} />
          </Field>
          <Field label="Phone" htmlFor="s-phone" error={errors.phone}>
            <Input id="s-phone" name="phone" type="tel" defaultValue={supplier?.phone ?? ""} maxLength={30} />
          </Field>
          <Field label="Email" htmlFor="s-email" error={errors.email}>
            <Input id="s-email" name="email" type="email" defaultValue={supplier?.email ?? ""} maxLength={160} />
          </Field>
          <Field label="GSTIN" htmlFor="s-gstin" error={errors.gstin}>
            <Input id="s-gstin" name="gstin" defaultValue={supplier?.gstin ?? ""} maxLength={20} className="uppercase" />
          </Field>
          <Field label="Address" htmlFor="s-address" error={errors.address} className="sm:col-span-2">
            <Textarea id="s-address" name="address" rows={2} defaultValue={supplier?.address ?? ""} maxLength={300} />
          </Field>
          <fieldset className="sm:col-span-2">
            <legend className="mb-2 text-[0.8rem] font-medium text-ink">Supplies</legend>
            <div className="grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-4">
              {MATERIAL_CATEGORIES.map((c) => (
                <Checkbox key={c} label={MATERIAL_CATEGORY_LABELS[c]} checked={cats.includes(c)} onChange={(e) => setCats((cur) => (e.target.checked ? [...cur, c] : cur.filter((x) => x !== c)))} />
              ))}
            </div>
          </fieldset>
          <Field label="Notes" htmlFor="s-notes" className="sm:col-span-2">
            <Textarea id="s-notes" name="notes" rows={2} defaultValue={supplier?.notes ?? ""} maxLength={1000} placeholder="Credit terms, lead times, delivery areas" />
          </Field>
          <Checkbox name="isActive" label="Active supplier" defaultChecked={supplier?.isActive ?? true} className="sm:col-span-2" />
          <div className="flex justify-end gap-2 border-t border-line-soft pt-4 sm:col-span-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={busy}>
              {supplier ? "Save changes" : "Add supplier"}
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}

export function DeleteSupplierButton({ id, name, materials }: { id: string; name: string; materials: number }) {
  const router = useRouter();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  async function run() {
    if (!confirm(`Delete supplier “${name}”?${materials ? ` ${materials} material${materials === 1 ? "" : "s"} will keep their rates but lose the supplier link.` : ""}`)) return;
    setBusy(true);
    try {
      await api(`/api/suppliers/${id}`, { method: "DELETE" });
      toast("Supplier deleted");
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <button type="button" onClick={run} disabled={busy} className="rounded p-1.5 text-smoke hover:bg-brick-soft hover:text-brick disabled:opacity-50" aria-label={`Delete ${name}`}>
      <Trash2 className="size-4" />
    </button>
  );
}
