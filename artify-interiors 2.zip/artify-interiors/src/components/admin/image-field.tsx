"use client";

import { useRef, useState } from "react";
import { ImagePlus } from "lucide-react";
import { api, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/field";
import { useToast } from "@/components/ui/toast";

/** Image picker for website content: upload to storage (returns a public URL) or paste a URL. */
export function ImageField({ value, onChange, label, id }: { value: string; onChange: (url: string) => void; label: string; id: string }) {
  const { toast } = useToast();
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function upload(file: File) {
    const fd = new FormData();
    fd.set("file", file);
    setBusy(true);
    try {
      const r = await api<{ url: string }>("/api/content/upload", { form: fd });
      onChange(r.url);
      toast("Image uploaded");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
      if (ref.current) ref.current.value = "";
    }
  }

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[0.8rem] font-medium text-ink">
        {label}
      </label>
      <div className="flex flex-wrap items-center gap-3">
        {value ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={value} alt="" className="h-16 w-24 rounded-[var(--radius-sm)] border border-line object-cover" />
        ) : (
          <span className="grid h-16 w-24 place-items-center rounded-[var(--radius-sm)] border border-dashed border-line text-xs text-mist">No image</span>
        )}
        <input ref={ref} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
        <Button type="button" variant="secondary" size="sm" onClick={() => ref.current?.click()} loading={busy}>
          <ImagePlus className="size-3.5" /> Upload
        </Button>
        <Input id={id} value={value} onChange={(e) => onChange(e.target.value)} placeholder="…or paste an image URL" className="min-w-0 flex-1 basis-56" />
      </div>
    </div>
  );
}
