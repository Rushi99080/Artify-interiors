"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { ArrowDown, ArrowUp, Plus, RotateCcw, Send, X } from "lucide-react";
import type { AutomationSettings, BoqDefaults, CompanySettings, PaymentScheduleItem, QuotationSettings } from "@/lib/settings-defaults";
import type { RateCard } from "@/lib/boq/engine";
import { PRICE_TIERS, TIER_LABELS } from "@/lib/constants";
import { formatINR } from "@/lib/format";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea, Checkbox } from "@/components/ui/field";
import { Panel, PanelHeader } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { Notice } from "@/components/ui/notice";
import { useToast } from "@/components/ui/toast";
import { ImageField } from "@/components/admin/image-field";

function useSaver() {
  const router = useRouter();
  const { toast } = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const save = async (path: string, body: unknown, message: string) => {
    setBusy(path);
    setErrors({});
    try {
      await api(path, { method: "PUT", body });
      toast(message);
      router.refresh();
      return true;
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
      return false;
    } finally {
      setBusy(null);
    }
  };
  return { save, busy, errors };
}

const num = (v: string) => (v === "" ? 0 : Number(v));

// ───────────────────────── company & tax ─────────────────────────

export function CompanyForm({ company: initial, gstRate: initialGst }: { company: CompanySettings; gstRate: number }) {
  const [c, setC] = useState(initial);
  const [gst, setGst] = useState(String(initialGst));
  const { save, busy, errors } = useSaver();
  const set = (k: keyof CompanySettings) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setC({ ...c, [k]: e.target.value });

  return (
    <Panel>
      <PanelHeader title="Company profile" description="Printed on quotations, receipts and emails, and shown in the website footer." />
      <form
        className="grid gap-4 sm:grid-cols-2"
        onSubmit={async (e) => {
          e.preventDefault();
          const ok = await save("/api/settings/company", c, "Company profile saved");
          if (ok && Number(gst) !== initialGst) await save("/api/settings/tax", { gstRate: Number(gst) }, "GST rate saved");
        }}
      >
        <Field label="Brand name" htmlFor="c-name" required error={errors.name}>
          <Input id="c-name" value={c.name} onChange={set("name")} required maxLength={80} />
        </Field>
        <Field label="Legal / registered name" htmlFor="c-legal" required error={errors.legalName}>
          <Input id="c-legal" value={c.legalName} onChange={set("legalName")} required maxLength={120} />
        </Field>
        <Field label="Tagline" htmlFor="c-tagline" className="sm:col-span-2">
          <Input id="c-tagline" value={c.tagline} onChange={set("tagline")} maxLength={120} />
        </Field>
        <Field label="Address" htmlFor="c-address" className="sm:col-span-2">
          <Textarea id="c-address" rows={2} value={c.address} onChange={set("address")} maxLength={400} />
        </Field>
        <Field label="Phone" htmlFor="c-phone">
          <Input id="c-phone" type="tel" value={c.phone} onChange={set("phone")} maxLength={40} />
        </Field>
        <Field label="Email" htmlFor="c-email" error={errors.email}>
          <Input id="c-email" type="email" value={c.email} onChange={set("email")} maxLength={160} />
        </Field>
        <Field label="Website" htmlFor="c-website">
          <Input id="c-website" value={c.website} onChange={set("website")} maxLength={200} placeholder="https://" />
        </Field>
        <Field label="WhatsApp number" htmlFor="c-whatsapp" hint="Used for the “Chat on WhatsApp” link on the website.">
          <Input id="c-whatsapp" type="tel" value={c.whatsappNumber} onChange={set("whatsappNumber")} maxLength={20} placeholder="+91 98xxxxxxx" />
        </Field>
        <Field label="Instagram URL" htmlFor="c-instagram">
          <Input id="c-instagram" value={c.instagramUrl} onChange={set("instagramUrl")} maxLength={200} />
        </Field>
        <Field label="GSTIN" htmlFor="c-gstin" error={errors.gstin}>
          <Input id="c-gstin" value={c.gstin} onChange={set("gstin")} maxLength={20} className="uppercase" />
        </Field>
        <Field label="GST rate on quotations (%)" htmlFor="c-gst" hint="Applied to new BOQs. Interior works are usually 18%.">
          <Input id="c-gst" type="number" min={0} max={28} step="0.01" value={gst} onChange={(e) => setGst(e.target.value)} />
        </Field>
        <Field label="Bank details for payments" htmlFor="c-bank" hint="Printed on quotations and receipts." className="sm:col-span-2">
          <Textarea id="c-bank" rows={3} value={c.bankDetails} onChange={set("bankDetails")} maxLength={1000} placeholder={"Account name\nBank & branch\nA/c no. · IFSC\nUPI ID"} />
        </Field>
        <div className="sm:col-span-2">
          <ImageField id="c-logo" label="Logo for documents (optional — PNG/JPG)" value={c.logoUrl} onChange={(logoUrl) => setC({ ...c, logoUrl })} />
        </div>
        <div className="flex justify-end sm:col-span-2">
          <Button type="submit" loading={!!busy}>
            Save company profile
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── quotation ─────────────────────────

export function QuotationForm({ initial }: { initial: QuotationSettings }) {
  const [q, setQ] = useState(initial);
  const { save, busy, errors } = useSaver();
  const set = (k: keyof QuotationSettings) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setQ({ ...q, [k]: e.target.value });
  return (
    <Panel>
      <PanelHeader title="Quotation defaults" description="Copied into each new quotation — you can still edit a quotation's text by revising it." />
      <form
        className="grid gap-4 sm:grid-cols-2"
        onSubmit={(e) => {
          e.preventDefault();
          save("/api/settings/quotation", { ...q, validityDays: Number(q.validityDays), prefix: q.prefix.toUpperCase() }, "Quotation defaults saved");
        }}
      >
        <Field label="Number prefix" htmlFor="q-prefix" hint={`Next numbers look like ${q.prefix.toUpperCase() || "AIQ"}/2026-27/0001`} error={errors.prefix}>
          <Input id="q-prefix" value={q.prefix} onChange={set("prefix")} maxLength={12} className="uppercase" />
        </Field>
        <Field label="Valid for (days)" htmlFor="q-valid" error={errors.validityDays}>
          <Input id="q-valid" type="number" min={1} max={180} value={q.validityDays} onChange={set("validityDays")} />
        </Field>
        <Field label="Scope of work" htmlFor="q-scope" className="sm:col-span-2">
          <Textarea id="q-scope" rows={4} value={q.scopeOfWork} onChange={set("scopeOfWork")} />
        </Field>
        <Field label="Payment terms" htmlFor="q-payment" className="sm:col-span-2" hint="One line per instalment reads best on the PDF.">
          <Textarea id="q-payment" rows={4} value={q.paymentTerms} onChange={set("paymentTerms")} />
        </Field>
        <Field label="Timeline" htmlFor="q-timeline" className="sm:col-span-2">
          <Textarea id="q-timeline" rows={4} value={q.timelineText} onChange={set("timelineText")} />
        </Field>
        <Field label="Terms & conditions" htmlFor="q-terms" className="sm:col-span-2">
          <Textarea id="q-terms" rows={10} value={q.terms} onChange={set("terms")} maxLength={10000} />
        </Field>
        <div className="flex justify-end sm:col-span-2">
          <Button type="submit" loading={!!busy}>
            Save quotation defaults
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── payment schedule ─────────────────────────

export function PaymentScheduleForm({ initial }: { initial: PaymentScheduleItem[] }) {
  const [rows, setRows] = useState(initial.map((r) => ({ name: r.name, percent: String(r.percent) })));
  const { save, busy } = useSaver();
  const total = rows.reduce((s, r) => s + num(r.percent), 0);
  const ok = Math.abs(total - 100) < 0.001;
  return (
    <Panel>
      <PanelHeader title="Payment schedule" description="Milestones created for every project when a quotation is approved. Existing projects keep their schedule." />
      <form
        className="grid gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          save("/api/settings/paymentSchedule", rows.map((r) => ({ name: r.name.trim(), percent: num(r.percent) })), "Payment schedule saved");
        }}
      >
        {rows.map((r, i) => (
          <div key={i} className="grid grid-cols-[1fr_90px_auto] gap-2">
            <Input aria-label={`Instalment ${i + 1} name`} value={r.name} onChange={(e) => setRows(rows.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} maxLength={120} required />
            <div className="relative">
              <Input aria-label={`Instalment ${i + 1} percent`} type="number" min={0.5} max={100} step="0.5" value={r.percent} onChange={(e) => setRows(rows.map((x, j) => (j === i ? { ...x, percent: e.target.value } : x)))} className="pr-7 text-right" required />
              <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sm text-smoke">%</span>
            </div>
            <Button type="button" variant="ghost" size="sm" disabled={rows.length === 1} onClick={() => setRows(rows.filter((_, j) => j !== i))} aria-label={`Remove instalment ${i + 1}`}>
              <X className="size-4" />
            </Button>
          </div>
        ))}
        <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            {rows.length < 12 ? (
              <Button type="button" variant="ghost" size="sm" onClick={() => setRows([...rows, { name: "", percent: "" }])}>
                <Plus className="size-3.5" /> Add instalment
              </Button>
            ) : null}
            <span className={`text-sm tabular-nums ${ok ? "text-moss" : "text-brick"}`}>Total {Math.round(total * 100) / 100}%</span>
          </div>
          <Button type="submit" loading={!!busy} disabled={!ok}>
            Save schedule
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── BOQ defaults & rate card ─────────────────────────

export function BoqDefaultsForm({ initial }: { initial: BoqDefaults }) {
  const [b, setB] = useState({ ...initial, wastagePercent: String(initial.wastagePercent), profitMarginPercent: String(initial.profitMarginPercent), transportCharges: String(initial.transportCharges), installationCharges: String(initial.installationCharges) });
  const { save, busy, errors } = useSaver();
  return (
    <Panel>
      <PanelHeader title="BOQ defaults" description="Applied to newly generated BOQs. Each BOQ can still be adjusted individually." />
      <form
        className="grid gap-4 sm:grid-cols-2"
        onSubmit={(e) => {
          e.preventDefault();
          save("/api/settings/boqDefaults", { wastagePercent: num(b.wastagePercent), profitMarginPercent: num(b.profitMarginPercent), transportCharges: num(b.transportCharges), installationCharges: num(b.installationCharges), marginLabel: b.marginLabel }, "BOQ defaults saved");
        }}
      >
        <Field label="Material wastage (%)" htmlFor="b-wastage" hint="Added on material lines only." error={errors.wastagePercent}>
          <Input id="b-wastage" type="number" min={0} max={50} step="0.5" value={b.wastagePercent} onChange={(e) => setB({ ...b, wastagePercent: e.target.value })} />
        </Field>
        <Field label="Studio margin (%)" htmlFor="b-margin" error={errors.profitMarginPercent}>
          <Input id="b-margin" type="number" min={0} max={200} step="0.5" value={b.profitMarginPercent} onChange={(e) => setB({ ...b, profitMarginPercent: e.target.value })} />
        </Field>
        <Field label="Transport (₹ per project)" htmlFor="b-transport">
          <Input id="b-transport" type="number" min={0} step="100" value={b.transportCharges} onChange={(e) => setB({ ...b, transportCharges: e.target.value })} />
        </Field>
        <Field label="Installation (₹ per project)" htmlFor="b-install">
          <Input id="b-install" type="number" min={0} step="100" value={b.installationCharges} onChange={(e) => setB({ ...b, installationCharges: e.target.value })} />
        </Field>
        <Field label="How the margin is labelled to clients" htmlFor="b-label" className="sm:col-span-2" hint="Shown on quotations instead of the word “profit”." error={errors.marginLabel}>
          <Input id="b-label" value={b.marginLabel} onChange={(e) => setB({ ...b, marginLabel: e.target.value })} maxLength={80} />
        </Field>
        <div className="flex justify-end sm:col-span-2">
          <Button type="submit" loading={!!busy}>
            Save BOQ defaults
          </Button>
        </div>
      </form>
    </Panel>
  );
}

export function RateCardEditor({ rateCard, defaults }: { rateCard: RateCard; defaults: RateCard }) {
  const [rows, setRows] = useState(() => Object.fromEntries(Object.entries(rateCard).map(([k, v]) => [k, Object.fromEntries(PRICE_TIERS.map((t) => [t, String(v.rates[t])]))])) as Record<string, Record<string, string>>);
  const [filter, setFilter] = useState("");
  const { save, busy } = useSaver();
  const keys = Object.keys(rateCard).filter((k) => !filter || rateCard[k]!.label.toLowerCase().includes(filter.toLowerCase()));
  const changed = (k: string) => PRICE_TIERS.some((t) => num(rows[k]![t]!) !== defaults[k]?.rates[t]);

  return (
    <Panel>
      <PanelHeader
        title="Rate card"
        description="Supply-and-install rates per finish level, used for fabricated items, ceilings, painting, electrical and services. Material-priced lines (flooring, countertops, hardware) use the material library instead."
        actions={<Input aria-label="Filter rate card" placeholder="Filter items" value={filter} onChange={(e) => setFilter(e.target.value)} className="w-48" />}
      />
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const payload = Object.fromEntries(Object.entries(rows).map(([k, r]) => [k, { rates: Object.fromEntries(PRICE_TIERS.map((t) => [t, num(r[t]!)])) }]));
          save("/api/settings/rateCard", payload, "Rate card saved — new BOQs and estimates use these rates");
        }}
      >
        <div className="max-h-[560px] overflow-auto rounded-[var(--radius-sm)] border border-line-soft">
          <table className="data-table min-w-[820px]">
            <thead className="sticky top-0 z-10">
              <tr>
                <th>Item</th>
                <th>Unit</th>
                {PRICE_TIERS.map((t) => (
                  <th key={t} className="num">
                    {TIER_LABELS[t]} (₹)
                  </th>
                ))}
                <th />
              </tr>
            </thead>
            <tbody>
              {keys.map((k) => (
                <tr key={k}>
                  <td>
                    {rateCard[k]!.label}
                    {rateCard[k]!.itemType !== "MATERIAL" ? <Badge className="ml-2">{rateCard[k]!.itemType === "LABOUR" ? "Labour" : "Service"}</Badge> : null}
                  </td>
                  <td className="text-smoke">{rateCard[k]!.unit}</td>
                  {PRICE_TIERS.map((t) => (
                    <td key={t} className="num">
                      <input
                        type="number"
                        min={0}
                        step="1"
                        aria-label={`${rateCard[k]!.label} — ${TIER_LABELS[t]}`}
                        value={rows[k]![t]}
                        onChange={(e) => setRows({ ...rows, [k]: { ...rows[k]!, [t]: e.target.value } })}
                        className="w-24 rounded-[var(--radius-sm)] border border-line bg-white px-2 py-1 text-right tabular-nums focus:border-brass focus:outline-none"
                      />
                    </td>
                  ))}
                  <td>
                    {changed(k) && defaults[k] ? (
                      <button type="button" onClick={() => setRows({ ...rows, [k]: Object.fromEntries(PRICE_TIERS.map((t) => [t, String(defaults[k]!.rates[t])])) })} className="rounded p-1 text-smoke hover:text-charcoal" title={`Reset to default (${PRICE_TIERS.map((t) => formatINR(defaults[k]!.rates[t])).join(" / ")})`} aria-label={`Reset ${rateCard[k]!.label} to default`}>
                        <RotateCcw className="size-3.5" />
                      </button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex justify-end">
          <Button type="submit" loading={!!busy}>
            Save rate card
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── automation ─────────────────────────

export function AutomationForm({ initial }: { initial: AutomationSettings }) {
  const [a, setA] = useState({ ...initial, paymentReminderDays: String(initial.paymentReminderDays) });
  const { save, busy } = useSaver();
  return (
    <Panel>
      <PanelHeader title="Automation" description="What the platform does on its own." />
      <form
        className="grid gap-5"
        onSubmit={(e) => {
          e.preventDefault();
          save("/api/settings/automation", { autoPreliminaryQuotation: a.autoPreliminaryQuotation, paymentReminderDays: num(a.paymentReminderDays) }, "Automation settings saved");
        }}
      >
        <div>
          <Checkbox label="Let clients create a preliminary quotation themselves" checked={a.autoPreliminaryQuotation} onChange={(e) => setA({ ...a, autoPreliminaryQuotation: e.target.checked })} />
          <p className="mt-1 pl-6 text-xs text-smoke">Clients get an instant, clearly-marked preliminary quotation from their rooms and finish level. Your team still verifies quantities on site before the final quotation.</p>
        </div>
        <Field label="Payment reminders — days before a due date" htmlFor="a-days" hint="A daily job emails (and WhatsApps, if configured) clients with an instalment due within this many days or overdue. Requires CRON_SECRET on Vercel.">
          <Input id="a-days" type="number" min={1} max={30} value={a.paymentReminderDays} onChange={(e) => setA({ ...a, paymentReminderDays: e.target.value })} className="w-32" />
        </Field>
        <div className="flex justify-end">
          <Button type="submit" loading={!!busy}>
            Save automation
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── workflow stages ─────────────────────────

type Stage = { id?: string; key?: string; name: string; defaultDurationDays: number; customerVisible: boolean; isActive: boolean };

export function WorkflowStagesEditor({ stages: initial }: { stages: Stage[] }) {
  const [stages, setStages] = useState(initial);
  const { save, busy } = useSaver();
  const move = (i: number, d: -1 | 1) => {
    const j = i + d;
    if (j < 0 || j >= stages.length) return;
    const next = [...stages];
    [next[i], next[j]] = [next[j]!, next[i]!];
    setStages(next);
  };
  const update = (i: number, patch: Partial<Stage>) => setStages(stages.map((s, j) => (j === i ? { ...s, ...patch } : s)));
  const totalDays = stages.filter((s) => s.isActive).reduce((sum, s) => sum + s.defaultDurationDays, 0);

  return (
    <Panel>
      <PanelHeader title="Project workflow stages" description={`New projects get these stages in this order. Planned duration of all active stages: ${totalDays} days. Renaming or reordering also updates running projects; removed stages stay on projects that already have them.`} />
      <form
        onSubmit={(e) => {
          e.preventDefault();
          save("/api/settings/workflow", { stages: stages.map((s) => ({ id: s.id, key: s.key, name: s.name.trim(), defaultDurationDays: s.defaultDurationDays, customerVisible: s.customerVisible, isActive: s.isActive })) }, "Workflow saved");
        }}
      >
        <ol className="grid gap-2">
          {stages.map((s, i) => (
            <li key={s.id ?? `new-${i}`} className={`grid items-center gap-2 rounded-[var(--radius-sm)] border border-line-soft bg-white/50 px-3 py-2 sm:grid-cols-[2rem_1fr_110px_auto_auto_auto] ${s.isActive ? "" : "opacity-60"}`}>
              <span className="text-sm tabular-nums text-smoke">{i + 1}.</span>
              <Input aria-label={`Stage ${i + 1} name`} value={s.name} onChange={(e) => update(i, { name: e.target.value })} maxLength={80} required />
              <div className="relative">
                <Input aria-label={`Stage ${i + 1} duration in days`} type="number" min={0} max={365} value={s.defaultDurationDays} onChange={(e) => update(i, { defaultDurationDays: num(e.target.value) })} className="pr-12 text-right" />
                <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-smoke">days</span>
              </div>
              <Checkbox label="Client sees" checked={s.customerVisible} onChange={(e) => update(i, { customerVisible: e.target.checked })} />
              <Checkbox label="Active" checked={s.isActive} onChange={(e) => update(i, { isActive: e.target.checked })} />
              <div className="flex items-center">
                <Button type="button" variant="ghost" size="sm" onClick={() => move(i, -1)} disabled={i === 0} aria-label={`Move ${s.name} up`}>
                  <ArrowUp className="size-3.5" />
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => move(i, 1)} disabled={i === stages.length - 1} aria-label={`Move ${s.name} down`}>
                  <ArrowDown className="size-3.5" />
                </Button>
                {!s.id ? (
                  <Button type="button" variant="ghost" size="sm" onClick={() => setStages(stages.filter((_, j) => j !== i))} aria-label="Remove new stage">
                    <X className="size-3.5" />
                  </Button>
                ) : null}
              </div>
            </li>
          ))}
        </ol>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
          <Button type="button" variant="ghost" size="sm" onClick={() => setStages([...stages, { name: "", defaultDurationDays: 3, customerVisible: true, isActive: true }])}>
            <Plus className="size-3.5" /> Add stage
          </Button>
          <Button type="submit" loading={!!busy}>
            Save workflow
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── integrations ─────────────────────────

export type IntegrationRow = { key: string; label: string; configured: boolean; detail: string; env: string; required?: boolean };

export function IntegrationsPanel({ rows }: { rows: IntegrationRow[] }) {
  return (
    <Panel>
      <PanelHeader title="Integrations" description="Keys live in environment variables on the server (never in the browser). After changing them, redeploy or restart the app." />
      <ul className="divide-y divide-line-soft">
        {rows.map((r) => (
          <li key={r.key} className="grid gap-1 py-3 sm:grid-cols-[200px_1fr_auto] sm:items-center sm:gap-4">
            <p className="font-medium text-charcoal">
              {r.label}
              {r.required ? <span className="ml-1 text-xs font-normal text-smoke">(core)</span> : null}
            </p>
            <div className="min-w-0">
              <p className="text-sm text-ink">{r.detail}</p>
              <p className="mt-0.5 truncate font-mono text-[0.7rem] text-smoke">{r.env}</p>
            </div>
            {r.configured ? <Badge tone="moss">Configured</Badge> : <Badge tone="amber">Not configured</Badge>}
          </li>
        ))}
      </ul>
    </Panel>
  );
}

export function TestMessageForm({ emailReady, whatsappReady, defaultEmail, defaultPhone }: { emailReady: boolean; whatsappReady: boolean; defaultEmail: string; defaultPhone: string }) {
  const { toast } = useToast();
  const [channel, setChannel] = useState<"email" | "whatsapp">(emailReady || !whatsappReady ? "email" : "whatsapp");
  const [to, setTo] = useState(channel === "email" ? defaultEmail : defaultPhone);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ status: string; providerMessageId: string | null; error: string | null } | null>(null);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setResult(null);
    try {
      const r = await api<{ status: string; providerMessageId: string | null; error: string | null }>("/api/notifications/test", { body: { channel, to } });
      setResult(r);
      toast(r.status === "SENT" ? "Provider accepted the test message" : `Not sent: ${r.error ?? r.status}`, r.status === "SENT" ? "success" : "error");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Panel>
      <PanelHeader title="Send a test message" description="Sends a real message through the configured provider and records the result in the notification log." />
      <form onSubmit={send} className="grid gap-3 sm:grid-cols-[140px_1fr]">
        <Field label="Channel" htmlFor="t-channel">
          <Select
            id="t-channel"
            value={channel}
            onChange={(e) => {
              const c = e.target.value as "email" | "whatsapp";
              setChannel(c);
              setTo(c === "email" ? defaultEmail : defaultPhone);
            }}
          >
            <option value="email">Email</option>
            <option value="whatsapp">WhatsApp</option>
          </Select>
        </Field>
        <Field label={channel === "email" ? "Send to email" : "Send to WhatsApp number"} htmlFor="t-to">
          <Input id="t-to" type={channel === "email" ? "email" : "tel"} value={to} onChange={(e) => setTo(e.target.value)} required placeholder={channel === "email" ? "you@studio.com" : "+91 98xxxxxxxx"} />
        </Field>
        <div className="flex justify-end sm:col-span-2">
          <Button type="submit" loading={busy}>
            <Send className="size-4" /> Send test
          </Button>
        </div>
      </form>
      {(channel === "email" && !emailReady) || (channel === "whatsapp" && !whatsappReady) ? (
        <p className="mt-3 text-sm text-amber">{channel === "email" ? "Email" : "WhatsApp"} is not configured, so the test will be logged as skipped.</p>
      ) : null}
      {channel === "whatsapp" ? <p className="mt-2 text-xs text-smoke">WhatsApp uses your template mapped to “TEST” in WHATSAPP_TEMPLATES, or Meta&apos;s default “hello_world” template.</p> : null}
      {result ? (
        <Notice kind={result.status === "SENT" ? "success" : result.status === "SKIPPED" ? "config" : "error"} className="mt-4" title={result.status === "SENT" ? "Accepted by the provider" : result.status === "SKIPPED" ? "Skipped" : "Failed"}>
          {result.status === "SENT" ? `Message ID: ${result.providerMessageId}` : result.error}
        </Notice>
      ) : null}
    </Panel>
  );
}
