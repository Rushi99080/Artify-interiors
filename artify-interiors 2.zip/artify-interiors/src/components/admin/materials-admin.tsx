"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { FileSpreadsheet, ImagePlus, Pencil, Plus, Trash2, Upload } from "lucide-react";
import { AVAILABILITY_LABELS, DESIGN_STYLES, MATERIAL_CATEGORIES, MATERIAL_CATEGORY_LABELS, MATERIAL_UNITS, PRICE_TIERS, STYLE_INFO, TIER_LABELS, type MaterialCategoryKey, type PriceTierKey } from "@/lib/constants";
import { formatINR } from "@/lib/format";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea, Checkbox } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { Notice } from "@/components/ui/notice";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { MaterialSwatch } from "@/components/materials/material-swatch";
import { useToast } from "@/components/ui/toast";

export type AdminMaterial = {
  id: string;
  name: string;
  category: string;
  brand: string | null;
  productCode: string | null;
  finish: string | null;
  color: string | null;
  unit: string;
  rate: number;
  imageUrl: string | null;
  specifications: string | null;
  availability: string;
  supplierId: string | null;
  supplierName: string | null;
  tier: string;
  durability: number;
  maintenance: number;
  styles: string[];
  isActive: boolean;
  usage: number;
};

type Supplier = { id: string; name: string };

// ───────────────────────── table ─────────────────────────

export function MaterialsTable({ materials, suppliers, canDelete }: { materials: AdminMaterial[]; suppliers: Supplier[]; canDelete: boolean }) {
  const router = useRouter();
  const { toast } = useToast();
  const [rows, setRows] = useState(materials);
  const [editing, setEditing] = useState<AdminMaterial | null>(null);
  useEffect(() => setRows(materials), [materials]);

  async function patch(m: AdminMaterial, body: Partial<AdminMaterial>, msg: string) {
    try {
      await api(`/api/materials/${m.id}`, { method: "PATCH", body });
      setRows((list) => list.map((x) => (x.id === m.id ? { ...x, ...body } : x)));
      toast(msg);
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }

  async function remove(m: AdminMaterial) {
    if (!confirm(`Delete “${m.name}”? Materials already used in a BOQ or room are deactivated instead.`)) return;
    try {
      const r = await api<{ deactivated: boolean; message?: string }>(`/api/materials/${m.id}`, { method: "DELETE" });
      if (r.deactivated) {
        setRows((list) => list.map((x) => (x.id === m.id ? { ...x, isActive: false } : x)));
        toast(r.message ?? "Material deactivated");
      } else {
        setRows((list) => list.filter((x) => x.id !== m.id));
        toast("Material deleted");
      }
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }

  return (
    <>
      <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
        <table className="data-table min-w-[1120px]">
          <thead>
            <tr>
              <th className="w-14" />
              <th>Material</th>
              <th>Category</th>
              <th>Finish / colour</th>
              <th>Finish level</th>
              <th className="num">Rate (₹)</th>
              <th>Unit</th>
              <th>Availability</th>
              <th>Supplier</th>
              <th>Active</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {rows.map((m) => (
              <tr key={m.id} className={m.isActive ? undefined : "opacity-60"}>
                <td>
                  <MaterialSwatch category={m.category} color={m.color} name={m.name} imageUrl={m.imageUrl} className="w-12" />
                </td>
                <td>
                  <span className="font-medium text-charcoal">{m.name}</span>
                  <span className="block text-xs text-smoke">
                    {[m.brand, m.productCode].filter(Boolean).join(" · ") || "—"}
                    {m.usage ? ` · used ${m.usage}×` : ""}
                  </span>
                </td>
                <td>{MATERIAL_CATEGORY_LABELS[m.category as MaterialCategoryKey] ?? m.category}</td>
                <td className="text-smoke">{[m.finish, m.color].filter(Boolean).join(" · ") || "—"}</td>
                <td>{TIER_LABELS[m.tier as PriceTierKey] ?? m.tier}</td>
                <td className="num">
                  <RateInput value={m.rate} label={`Rate for ${m.name}`} onSave={(rate) => patch(m, { rate }, `Rate updated to ${formatINR(rate)}/${m.unit}`)} />
                </td>
                <td className="text-smoke">{m.unit}</td>
                <td>
                  <StatusBadge status={m.availability} label={AVAILABILITY_LABELS[m.availability as keyof typeof AVAILABILITY_LABELS]} />
                </td>
                <td className="text-smoke">{m.supplierName ?? "—"}</td>
                <td>
                  <input type="checkbox" checked={m.isActive} onChange={(e) => patch(m, { isActive: e.target.checked }, e.target.checked ? "Material is visible in the library" : "Material hidden from the library")} aria-label={`${m.name} active`} className="size-4 accent-[var(--color-charcoal)]" />
                </td>
                <td className="whitespace-nowrap text-right">
                  <button type="button" onClick={() => setEditing(m)} className="rounded p-1.5 text-smoke hover:bg-travertine/60 hover:text-charcoal" aria-label={`Edit ${m.name}`}>
                    <Pencil className="size-4" />
                  </button>
                  {canDelete ? (
                    <button type="button" onClick={() => remove(m)} className="rounded p-1.5 text-smoke hover:bg-brick-soft hover:text-brick" aria-label={`Delete ${m.name}`}>
                      <Trash2 className="size-4" />
                    </button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {editing ? (
        <MaterialFormModal
          material={editing}
          suppliers={suppliers}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            router.refresh();
          }}
        />
      ) : null}
    </>
  );
}

function RateInput({ value, onSave, label }: { value: number; onSave: (v: number) => void; label: string }) {
  const [v, setV] = useState(String(value));
  const commit = () => {
    const n = Number(v);
    if (!Number.isFinite(n) || n < 0) return setV(String(value));
    if (Math.abs(n - value) > 0.001) onSave(Math.round(n * 100) / 100);
  };
  return (
    <input
      type="number"
      min={0}
      step="0.01"
      inputMode="decimal"
      value={v}
      aria-label={label}
      onChange={(e) => setV(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
        if (e.key === "Escape") setV(String(value));
      }}
      className="w-28 rounded-[var(--radius-sm)] border border-transparent bg-transparent px-2 py-1 text-right tabular-nums hover:border-line focus:border-brass focus:bg-white focus:outline-none"
    />
  );
}

// ───────────────────────── add / edit ─────────────────────────

export function NewMaterialButton({ suppliers }: { suppliers: Supplier[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)}>
        <Plus className="size-4" /> Add material
      </Button>
      {open ? (
        <MaterialFormModal
          suppliers={suppliers}
          onClose={() => setOpen(false)}
          onSaved={() => {
            setOpen(false);
            router.refresh();
          }}
        />
      ) : null}
    </>
  );
}

function MaterialFormModal({ material, suppliers, onClose, onSaved }: { material?: AdminMaterial; suppliers: Supplier[]; onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [imageUrl, setImageUrl] = useState(material?.imageUrl ?? "");
  const [styles, setStyles] = useState<string[]>(material?.styles ?? []);
  const fileRef = useRef<HTMLInputElement>(null);

  async function upload(file: File) {
    const fd = new FormData();
    fd.set("file", file);
    setUploading(true);
    try {
      const r = await api<{ url: string }>("/api/content/upload", { form: fd });
      setImageUrl(r.url);
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setUploading(false);
    }
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const s = (k: string) => {
      const v = String(fd.get(k) ?? "").trim();
      return v === "" ? null : v;
    };
    const body = {
      name: s("name") ?? "",
      category: s("category"),
      brand: s("brand"),
      productCode: s("productCode"),
      finish: s("finish"),
      color: s("color"),
      unit: s("unit") ?? "",
      rate: Number(fd.get("rate")),
      imageUrl: imageUrl || null,
      specifications: s("specifications"),
      availability: s("availability"),
      supplierId: s("supplierId"),
      tier: s("tier"),
      durability: Number(fd.get("durability")),
      maintenance: Number(fd.get("maintenance")),
      styles,
      isActive: fd.get("isActive") === "on",
    };
    setBusy(true);
    setErrors({});
    try {
      if (material) await api(`/api/materials/${material.id}`, { method: "PATCH", body });
      else await api("/api/materials", { body });
      toast(material ? "Material updated" : "Material added to the library");
      onSaved();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open onClose={onClose} title={material ? "Edit material" : "Add material"} description="Rates are used by the BOQ generator and the cost calculator." size="lg">
      <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
        <Field label="Material name" htmlFor="m-name" required error={errors.name} className="sm:col-span-2">
          <Input id="m-name" name="name" defaultValue={material?.name} required maxLength={140} />
        </Field>
        <Field label="Category" htmlFor="m-category" required error={errors.category}>
          <Select id="m-category" name="category" defaultValue={material?.category ?? "PLYWOOD"}>
            {MATERIAL_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {MATERIAL_CATEGORY_LABELS[c]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Brand" htmlFor="m-brand" error={errors.brand}>
          <Input id="m-brand" name="brand" defaultValue={material?.brand ?? ""} maxLength={80} />
        </Field>
        <Field label="Product code" htmlFor="m-code" hint="Unique. Imports with the same code update this material." error={errors.productCode}>
          <Input id="m-code" name="productCode" defaultValue={material?.productCode ?? ""} maxLength={60} />
        </Field>
        <Field label="Finish" htmlFor="m-finish" error={errors.finish}>
          <Input id="m-finish" name="finish" defaultValue={material?.finish ?? ""} maxLength={80} placeholder="e.g. Matte, High gloss" />
        </Field>
        <Field label="Colour" htmlFor="m-color" error={errors.color}>
          <Input id="m-color" name="color" defaultValue={material?.color ?? ""} maxLength={60} placeholder="e.g. Walnut, Ivory" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Rate (₹)" htmlFor="m-rate" required error={errors.rate}>
            <Input id="m-rate" name="rate" type="number" min={0} step="0.01" defaultValue={material?.rate ?? ""} required />
          </Field>
          <Field label="Unit" htmlFor="m-unit" required error={errors.unit}>
            <Input id="m-unit" name="unit" list="m-units" defaultValue={material?.unit ?? "sqft"} required maxLength={20} />
            <datalist id="m-units">
              {MATERIAL_UNITS.map((u) => (
                <option key={u} value={u} />
              ))}
            </datalist>
          </Field>
        </div>
        <Field label="Finish level" htmlFor="m-tier" hint="Used for AI recommendations and BOQ tier matching.">
          <Select id="m-tier" name="tier" defaultValue={material?.tier ?? "STANDARD"}>
            {PRICE_TIERS.map((t) => (
              <option key={t} value={t}>
                {TIER_LABELS[t]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Availability" htmlFor="m-availability">
          <Select id="m-availability" name="availability" defaultValue={material?.availability ?? "IN_STOCK"}>
            {Object.entries(AVAILABILITY_LABELS).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Supplier" htmlFor="m-supplier">
          <Select id="m-supplier" name="supplierId" defaultValue={material?.supplierId ?? ""}>
            <option value="">No supplier</option>
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Durability (1–5)" htmlFor="m-durability">
            <Select id="m-durability" name="durability" defaultValue={String(material?.durability ?? 3)}>
              {[1, 2, 3, 4, 5].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Maintenance ease (1–5)" htmlFor="m-maintenance">
            <Select id="m-maintenance" name="maintenance" defaultValue={String(material?.maintenance ?? 3)}>
              {[1, 2, 3, 4, 5].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="Specifications" htmlFor="m-specs" className="sm:col-span-2" error={errors.specifications}>
          <Textarea id="m-specs" name="specifications" rows={3} defaultValue={material?.specifications ?? ""} maxLength={2000} placeholder="Thickness, grade, warranty, installation notes" />
        </Field>
        <fieldset className="sm:col-span-2">
          <legend className="mb-2 text-[0.8rem] font-medium text-ink">Suits these styles</legend>
          <div className="flex flex-wrap gap-x-4 gap-y-2">
            {DESIGN_STYLES.map((st) => (
              <Checkbox key={st} label={STYLE_INFO[st].label} checked={styles.includes(st)} onChange={(e) => setStyles((cur) => (e.target.checked ? [...cur, st] : cur.filter((x) => x !== st)))} />
            ))}
          </div>
        </fieldset>
        <div className="sm:col-span-2">
          <p className="mb-2 text-[0.8rem] font-medium text-ink">Photo</p>
          <div className="flex flex-wrap items-center gap-3">
            {imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={imageUrl} alt="" className="size-16 rounded-[var(--radius-sm)] border border-line object-cover" />
            ) : (
              <span className="grid size-16 place-items-center rounded-[var(--radius-sm)] border border-dashed border-line text-xs text-mist">None</span>
            )}
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
            <Button type="button" variant="secondary" size="sm" onClick={() => fileRef.current?.click()} loading={uploading}>
              <ImagePlus className="size-3.5" /> Upload photo
            </Button>
            <Input aria-label="Or paste an image URL" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="…or paste an image URL" className="min-w-0 flex-1" />
          </div>
        </div>
        <Checkbox name="isActive" label="Show in the material library and BOQ picker" defaultChecked={material?.isActive ?? true} className="sm:col-span-2" />
        <div className="flex justify-end gap-2 border-t border-line-soft pt-4 sm:col-span-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={busy}>
            {material ? "Save changes" : "Add material"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}

// ───────────────────────── import ─────────────────────────

type Preview = { total: number; valid: number; errors: { row: number; message: string }[]; sample: { name: string; category: string; brand: string | null; productCode: string | null; unit: string; rate: number; tier: string }[] };

export function ImportMaterialsButton() {
  const router = useRouter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [busy, setBusy] = useState<null | "preview" | "import">(null);
  const [result, setResult] = useState<{ created: number; updated: number; skipped: number } | null>(null);

  const reset = () => {
    setFile(null);
    setPreview(null);
    setResult(null);
  };

  async function send(mode: "preview" | "import", f = file) {
    if (!f) return;
    const fd = new FormData();
    fd.set("file", f);
    fd.set("mode", mode);
    setBusy(mode);
    try {
      if (mode === "preview") setPreview(await api<Preview>("/api/materials/import", { form: fd }));
      else {
        const r = await api<{ created: number; updated: number; skipped: number }>("/api/materials/import", { form: fd });
        setResult(r);
        toast(`Imported: ${r.created} added, ${r.updated} updated`);
        router.refresh();
      }
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(null);
    }
  }

  return (
    <>
      <Button variant="secondary" onClick={() => setOpen(true)}>
        <Upload className="size-4" /> Import CSV / Excel
      </Button>
      <Modal
        open={open}
        onClose={() => {
          setOpen(false);
          reset();
        }}
        title="Import materials"
        description="Use the template's columns. Rows with an existing product code update that material; the rest are added."
        size="lg"
      >
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <a href="/api/materials/template" className="inline-flex items-center gap-1.5 text-sm text-ink underline decoration-sand underline-offset-4">
              <FileSpreadsheet className="size-4" /> Download template (.xlsx)
            </a>
          </div>
          <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-[var(--radius-md)] border border-dashed border-sand bg-plaster/50 px-4 py-8 text-center hover:border-brass">
            <Upload className="size-5 text-brass" />
            <span className="text-sm text-ink">{file ? file.name : "Choose a .csv or .xlsx file (max 5 MB)"}</span>
            <input
              type="file"
              accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              className="sr-only"
              onChange={(e) => {
                const f = e.target.files?.[0] ?? null;
                setFile(f);
                setPreview(null);
                setResult(null);
                if (f) send("preview", f);
              }}
            />
          </label>

          {busy === "preview" ? <p className="text-sm text-smoke">Reading file…</p> : null}

          {preview && !result ? (
            <>
              <p className="text-sm text-ink">
                {preview.total} row{preview.total === 1 ? "" : "s"} found · <strong>{preview.valid} ready to import</strong>
                {preview.errors.length ? ` · ${preview.errors.length} with problems (will be skipped)` : ""}
              </p>
              {preview.sample.length ? (
                <div className="overflow-x-auto rounded-[var(--radius-sm)] border border-line">
                  <table className="data-table min-w-[620px] text-sm">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Brand / code</th>
                        <th>Level</th>
                        <th className="num">Rate</th>
                      </tr>
                    </thead>
                    <tbody>
                      {preview.sample.map((m, i) => (
                        <tr key={i}>
                          <td>{m.name}</td>
                          <td>{MATERIAL_CATEGORY_LABELS[m.category as MaterialCategoryKey] ?? m.category}</td>
                          <td className="text-smoke">{[m.brand, m.productCode].filter(Boolean).join(" · ") || "—"}</td>
                          <td>{TIER_LABELS[m.tier as PriceTierKey] ?? m.tier}</td>
                          <td className="num">
                            {formatINR(m.rate)}/{m.unit}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {preview.valid > preview.sample.length ? <p className="px-3 py-2 text-xs text-smoke">…and {preview.valid - preview.sample.length} more</p> : null}
                </div>
              ) : null}
              {preview.errors.length ? (
                <Notice kind="warning" title="Rows that will be skipped">
                  <ul className="max-h-40 list-disc overflow-y-auto pl-4">
                    {preview.errors.slice(0, 50).map((e, i) => (
                      <li key={i}>
                        Row {e.row}: {e.message}
                      </li>
                    ))}
                  </ul>
                </Notice>
              ) : null}
              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={reset}>
                  Choose another file
                </Button>
                <Button onClick={() => send("import")} loading={busy === "import"} disabled={!preview.valid}>
                  Import {preview.valid} material{preview.valid === 1 ? "" : "s"}
                </Button>
              </div>
            </>
          ) : null}

          {result ? (
            <Notice kind="success" title="Import complete">
              {result.created} added · {result.updated} updated · {result.skipped} skipped.
            </Notice>
          ) : null}
        </div>
      </Modal>
    </>
  );
}

export function MaterialsSummary({ total, active, categories }: { total: number; active: number; categories: number }) {
  return (
    <p className="mb-4 flex flex-wrap gap-2 text-sm text-smoke">
      <Badge>{total} materials</Badge>
      <Badge tone="moss">{active} active</Badge>
      <Badge tone="brass">{categories} categories in use</Badge>
    </p>
  );
}
