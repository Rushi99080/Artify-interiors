"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { FolderPlus, Plus, Pencil } from "lucide-react";
import { BUDGET_RANGES, DESIGN_STYLES, PROPERTY_TYPES, PROPERTY_TYPE_LABELS, ROOM_MODULES, ROOM_MODULE_BY_TYPE, STYLE_INFO, type RoomTypeKey } from "@/lib/constants";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";

type Customer = { id: string; fullName: string; phone: string; email: string | null; address: string | null; city: string | null; notes: string | null };

export function CustomerFormButton({ customer }: { customer?: Customer }) {
  const router = useRouter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const body = Object.fromEntries([...fd.entries()].map(([k, v]) => [k, v === "" ? null : v]));
    setBusy(true);
    setErrors({});
    try {
      if (customer) await api(`/api/customers/${customer.id}`, { method: "PATCH", body });
      else {
        const r = await api<{ customer: { id: string } }>("/api/customers", { body });
        router.push(`/admin/customers/${r.customer.id}`);
      }
      toast(customer ? "Customer updated" : "Customer created");
      setOpen(false);
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Button variant={customer ? "secondary" : "primary"} onClick={() => setOpen(true)}>
        {customer ? <Pencil className="size-4" /> : <Plus className="size-4" />} {customer ? "Edit" : "New customer"}
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title={customer ? "Edit customer" : "New customer"}>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Full name" error={errors.fullName} htmlFor="cu-n">
            <Input id="cu-n" name="fullName" defaultValue={customer?.fullName} required />
          </Field>
          <Field label="Phone" error={errors.phone} htmlFor="cu-p">
            <Input id="cu-p" name="phone" defaultValue={customer?.phone} required />
          </Field>
          <Field label="Email" error={errors.email} htmlFor="cu-e">
            <Input id="cu-e" name="email" type="email" defaultValue={customer?.email ?? ""} />
          </Field>
          <Field label="City" htmlFor="cu-c">
            <Input id="cu-c" name="city" defaultValue={customer?.city ?? ""} />
          </Field>
          <Field label="Address" htmlFor="cu-a" className="sm:col-span-2">
            <Input id="cu-a" name="address" defaultValue={customer?.address ?? ""} />
          </Field>
          <Field label="Internal notes" htmlFor="cu-no" className="sm:col-span-2">
            <Textarea id="cu-no" name="notes" defaultValue={customer?.notes ?? ""} rows={3} />
          </Field>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={busy}>
              Save
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}

/** Team: create a project for an existing customer. */
export function TeamNewProjectButton({ customer }: { customer: Customer }) {
  const router = useRouter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const b = BUDGET_RANGES[Number(fd.get("budget"))]!;
    const roomType = fd.get("room") as RoomTypeKey;
    setBusy(true);
    setErrors({});
    try {
      const r = await api<{ project: { id: string } }>("/api/projects", {
        body: {
          customerId: customer.id,
          fullName: customer.fullName,
          phone: customer.phone,
          email: customer.email ?? "",
          name: fd.get("name"),
          location: fd.get("location"),
          propertyType: fd.get("propertyType"),
          designStyle: fd.get("designStyle"),
          carpetAreaSqft: fd.get("carpetArea") || null,
          budgetMin: b.min,
          budgetMax: b.max,
          rooms: [{ type: roomType, ...ROOM_MODULE_BY_TYPE[roomType].defaults }],
        },
      });
      toast("Project created");
      router.push(`/admin/projects/${r.project.id}/rooms`);
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Button onClick={() => setOpen(true)}>
        <FolderPlus className="size-4" /> New project
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title={`New project for ${customer.fullName}`} description="You can add more rooms and dimensions after creating it.">
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="Project name" error={errors.name} htmlFor="tp-n" className="sm:col-span-2">
            <Input id="tp-n" name="name" required />
          </Field>
          <Field label="Location" error={errors.location} htmlFor="tp-l">
            <Input id="tp-l" name="location" defaultValue={customer.city ?? ""} required />
          </Field>
          <Field label="Carpet area (sqft)" htmlFor="tp-a">
            <Input id="tp-a" name="carpetArea" type="number" min={50} />
          </Field>
          <Field label="Property type" htmlFor="tp-t">
            <Select id="tp-t" name="propertyType" defaultValue="APARTMENT">
              {PROPERTY_TYPES.map((p) => (
                <option key={p} value={p}>
                  {PROPERTY_TYPE_LABELS[p]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Design style" htmlFor="tp-s">
            <Select id="tp-s" name="designStyle" defaultValue="MODERN">
              {DESIGN_STYLES.map((s) => (
                <option key={s} value={s}>
                  {STYLE_INFO[s].label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Budget" htmlFor="tp-b">
            <Select id="tp-b" name="budget" defaultValue="2">
              {BUDGET_RANGES.map((b, i) => (
                <option key={b.label} value={i}>
                  {b.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="First room" htmlFor="tp-r">
            <Select id="tp-r" name="room" defaultValue="LIVING_ROOM">
              {ROOM_MODULES.map((m) => (
                <option key={m.type} value={m.type}>
                  {m.label}
                </option>
              ))}
            </Select>
          </Field>
          <div className="flex justify-end gap-2 sm:col-span-2">
            <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={busy}>
              Create project
            </Button>
          </div>
        </form>
      </Modal>
    </>
  );
}
