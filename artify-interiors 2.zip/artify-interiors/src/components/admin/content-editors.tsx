"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Eye, EyeOff, Pencil, Plus, Star, Trash2, X } from "lucide-react";
import type { AboutContent, HeroContent, StatItem } from "@/lib/settings-defaults";
import { DESIGN_STYLES, ROOM_MODULES, STYLE_INFO, ROOM_LABELS, type RoomTypeKey, type DesignStyleKey } from "@/lib/constants";
import { api, ApiClientError, errorMessage } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea, Checkbox } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { Panel, PanelHeader } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { SmartImage } from "@/components/ui/smart-image";
import { useToast } from "@/components/ui/toast";
import { ImageField } from "@/components/admin/image-field";

function useSave(key: string, label: string) {
  const router = useRouter();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const save = async (value: unknown) => {
    setBusy(true);
    try {
      await api(`/api/settings/${key}`, { method: "PUT", body: value });
      toast(`${label} saved — live on the website`);
      router.refresh();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  };
  return { save, busy };
}

// ───────────────────────── hero ─────────────────────────

export function HeroEditor({ initial }: { initial: HeroContent }) {
  const [v, setV] = useState(initial);
  const { save, busy } = useSave("hero", "Homepage hero");
  const lines = v.headlineLines.length ? v.headlineLines : [""];
  return (
    <Panel>
      <PanelHeader title="Homepage hero" description="Keep each headline line short (under ~16 characters) so it sets well on phones. The last line animates in last." />
      <form
        className="grid gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          save({ ...v, headlineLines: lines.map((l) => l.trim()).filter(Boolean) });
        }}
      >
        <Field label="Small line above the headline" htmlFor="hero-eyebrow">
          <Input id="hero-eyebrow" value={v.eyebrow} maxLength={120} onChange={(e) => setV({ ...v, eyebrow: e.target.value })} />
        </Field>
        <fieldset className="grid gap-2">
          <legend className="mb-1 text-[0.8rem] font-medium text-ink">Headline lines</legend>
          {lines.map((line, i) => (
            <div key={i} className="flex gap-2">
              <Input aria-label={`Headline line ${i + 1}`} value={line} maxLength={40} onChange={(e) => setV({ ...v, headlineLines: lines.map((l, j) => (j === i ? e.target.value : l)) })} />
              {lines.length > 1 ? (
                <Button type="button" variant="ghost" size="sm" aria-label={`Remove line ${i + 1}`} onClick={() => setV({ ...v, headlineLines: lines.filter((_, j) => j !== i) })}>
                  <X className="size-4" />
                </Button>
              ) : null}
            </div>
          ))}
          {lines.length < 4 ? (
            <Button type="button" variant="ghost" size="sm" className="justify-self-start" onClick={() => setV({ ...v, headlineLines: [...lines, ""] })}>
              <Plus className="size-3.5" /> Add line
            </Button>
          ) : null}
        </fieldset>
        <Field label="Supporting text" htmlFor="hero-subtext">
          <Textarea id="hero-subtext" rows={3} value={v.subtext} maxLength={400} onChange={(e) => setV({ ...v, subtext: e.target.value })} />
        </Field>
        <ImageField id="hero-image" label="Hero photograph" value={v.imageUrl} onChange={(imageUrl) => setV({ ...v, imageUrl })} />
        <div className="flex justify-end">
          <Button type="submit" loading={busy}>
            Save hero
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── about ─────────────────────────

export function AboutEditor({ initial }: { initial: AboutContent }) {
  const [v, setV] = useState(initial);
  const { save, busy } = useSave("about", "About page");
  return (
    <Panel>
      <PanelHeader title="About the studio" description="Shown on the About page and the homepage introduction." />
      <form
        className="grid gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          save({ ...v, values: v.values.filter((x) => x.title.trim() && x.text.trim()) });
        }}
      >
        <Field label="Heading" htmlFor="about-heading">
          <Input id="about-heading" value={v.heading} maxLength={160} onChange={(e) => setV({ ...v, heading: e.target.value })} />
        </Field>
        <Field label="Story" htmlFor="about-body" hint="Separate paragraphs with a blank line.">
          <Textarea id="about-body" rows={7} value={v.body} maxLength={4000} onChange={(e) => setV({ ...v, body: e.target.value })} />
        </Field>
        <ImageField id="about-image" label="Studio photograph" value={v.imageUrl} onChange={(imageUrl) => setV({ ...v, imageUrl })} />
        <fieldset className="grid gap-3">
          <legend className="mb-1 text-[0.8rem] font-medium text-ink">What you stand for (up to 6)</legend>
          {v.values.map((val, i) => (
            <div key={i} className="grid gap-2 rounded-[var(--radius-sm)] border border-line-soft p-3 sm:grid-cols-[180px_1fr_auto]">
              <Input aria-label={`Value ${i + 1} title`} value={val.title} maxLength={60} placeholder="Title" onChange={(e) => setV({ ...v, values: v.values.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)) })} />
              <Input aria-label={`Value ${i + 1} text`} value={val.text} maxLength={240} placeholder="One sentence" onChange={(e) => setV({ ...v, values: v.values.map((x, j) => (j === i ? { ...x, text: e.target.value } : x)) })} />
              <Button type="button" variant="ghost" size="sm" aria-label={`Remove value ${i + 1}`} onClick={() => setV({ ...v, values: v.values.filter((_, j) => j !== i) })}>
                <X className="size-4" />
              </Button>
            </div>
          ))}
          {v.values.length < 6 ? (
            <Button type="button" variant="ghost" size="sm" className="justify-self-start" onClick={() => setV({ ...v, values: [...v.values, { title: "", text: "" }] })}>
              <Plus className="size-3.5" /> Add value
            </Button>
          ) : null}
        </fieldset>
        <div className="flex justify-end">
          <Button type="submit" loading={busy}>
            Save about
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── stats ─────────────────────────

export function StatsEditor({ initial }: { initial: StatItem[] }) {
  const [rows, setRows] = useState<StatItem[]>(initial);
  const { save, busy } = useSave("stats", "Studio figures");
  return (
    <Panel>
      <PanelHeader title="Studio figures" description="Optional numbers shown on the homepage and About page, e.g. “120+ / Homes delivered”. Only publish figures you can stand behind — leave empty to hide the strip." />
      <form
        className="grid gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          save(rows.filter((r) => r.value.trim() && r.label.trim()));
        }}
      >
        {rows.map((r, i) => (
          <div key={i} className="grid gap-2 sm:grid-cols-[140px_1fr_auto]">
            <Input aria-label={`Figure ${i + 1} value`} value={r.value} maxLength={20} placeholder="120+" onChange={(e) => setRows(rows.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)))} />
            <Input aria-label={`Figure ${i + 1} label`} value={r.label} maxLength={60} placeholder="Homes delivered" onChange={(e) => setRows(rows.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} />
            <Button type="button" variant="ghost" size="sm" aria-label={`Remove figure ${i + 1}`} onClick={() => setRows(rows.filter((_, j) => j !== i))}>
              <X className="size-4" />
            </Button>
          </div>
        ))}
        <div className="flex flex-wrap items-center justify-between gap-2">
          {rows.length < 6 ? (
            <Button type="button" variant="ghost" size="sm" onClick={() => setRows([...rows, { value: "", label: "" }])}>
              <Plus className="size-3.5" /> Add figure
            </Button>
          ) : (
            <span />
          )}
          <Button type="submit" loading={busy}>
            Save figures
          </Button>
        </div>
      </form>
    </Panel>
  );
}

// ───────────────────────── portfolio ─────────────────────────

export type PortfolioView = { id: string; slug: string; title: string; roomType: string | null; style: string | null; location: string | null; areaSqft: number | null; description: string; coverImageUrl: string; images: string[]; isPublished: boolean; isFeatured: boolean; isSample: boolean; sortOrder: number };

export function PortfolioManager({ items: initial }: { items: PortfolioView[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [items, setItems] = useState(initial);
  const [editing, setEditing] = useState<PortfolioView | "new" | null>(null);
  useEffect(() => setItems(initial), [initial]);

  async function patch(p: PortfolioView, body: Partial<PortfolioView>, msg: string) {
    try {
      await api(`/api/content/portfolio/${p.id}`, { method: "PATCH", body });
      setItems((l) => l.map((x) => (x.id === p.id ? { ...x, ...body } : x)));
      toast(msg);
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }
  async function remove(p: PortfolioView) {
    if (!confirm(`Delete “${p.title}” from the portfolio?`)) return;
    try {
      await api(`/api/content/portfolio/${p.id}`, { method: "DELETE" });
      setItems((l) => l.filter((x) => x.id !== p.id));
      toast("Project removed from the portfolio");
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }

  return (
    <Panel>
      <PanelHeader
        title="Portfolio projects"
        description="Shown on Explore Designs and the homepage. Projects marked as sample are labelled “Sample” on the site — replace them with your own work."
        actions={
          <Button onClick={() => setEditing("new")}>
            <Plus className="size-4" /> Add project
          </Button>
        }
      />
      {items.length ? (
        <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((p) => (
            <li key={p.id} className="overflow-hidden rounded-[var(--radius-md)] border border-line bg-white/40">
              <SmartImage src={p.coverImageUrl} alt={p.title} className="aspect-[16/10]" />
              <div className="p-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  <p className="mr-auto font-medium text-charcoal">{p.title}</p>
                  {p.isSample ? <Badge tone="amber">Sample</Badge> : null}
                  {p.isFeatured ? <Badge tone="brass">Featured</Badge> : null}
                  {!p.isPublished ? <Badge>Hidden</Badge> : null}
                </div>
                <p className="mt-0.5 text-xs text-smoke">{[p.roomType ? ROOM_LABELS[p.roomType as RoomTypeKey] : null, p.style ? STYLE_INFO[p.style as DesignStyleKey]?.label : null, p.location].filter(Boolean).join(" · ") || "—"}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  <Button size="sm" variant="ghost" onClick={() => setEditing(p)}>
                    <Pencil className="size-3.5" /> Edit
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => patch(p, { isPublished: !p.isPublished }, p.isPublished ? "Hidden from the website" : "Published")}>
                    {p.isPublished ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />} {p.isPublished ? "Hide" : "Publish"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => patch(p, { isFeatured: !p.isFeatured }, p.isFeatured ? "Removed from homepage" : "Featured on the homepage")}>
                    <Star className="size-3.5" /> {p.isFeatured ? "Unfeature" : "Feature"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(p)} aria-label={`Delete ${p.title}`}>
                    <Trash2 className="size-3.5" />
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-smoke">No portfolio projects yet.</p>
      )}
      {editing ? (
        <PortfolioModal
          project={editing === "new" ? undefined : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            router.refresh();
          }}
        />
      ) : null}
    </Panel>
  );
}

function PortfolioModal({ project, onClose, onSaved }: { project?: PortfolioView; onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [cover, setCover] = useState(project?.coverImageUrl ?? "");
  const [gallery, setGallery] = useState<string[]>(project?.images ?? []);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const s = (k: string) => {
      const v = String(fd.get(k) ?? "").trim();
      return v === "" ? null : v;
    };
    if (!cover) return toast("Add a cover image", "error");
    const body = {
      title: s("title") ?? "",
      roomType: s("roomType"),
      style: s("style"),
      location: s("location"),
      areaSqft: s("areaSqft") ? Number(s("areaSqft")) : null,
      description: s("description") ?? "",
      coverImageUrl: cover,
      images: gallery,
      isPublished: fd.get("isPublished") === "on",
      isFeatured: fd.get("isFeatured") === "on",
      isSample: fd.get("isSample") === "on",
      sortOrder: Number(fd.get("sortOrder") ?? 0),
    };
    setBusy(true);
    setErrors({});
    try {
      if (project) await api(`/api/content/portfolio/${project.id}`, { method: "PATCH", body });
      else await api("/api/content/portfolio", { body });
      toast(project ? "Portfolio project updated" : "Portfolio project added");
      onSaved();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open onClose={onClose} title={project ? "Edit portfolio project" : "Add portfolio project"} size="lg">
      <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
        <Field label="Title" htmlFor="pf-title" required error={errors.title} className="sm:col-span-2">
          <Input id="pf-title" name="title" defaultValue={project?.title} required maxLength={120} />
        </Field>
        <Field label="Room / space" htmlFor="pf-room">
          <Select id="pf-room" name="roomType" defaultValue={project?.roomType ?? ""}>
            <option value="">Whole home / mixed</option>
            {ROOM_MODULES.map((m) => (
              <option key={m.type} value={m.type}>
                {m.label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Style" htmlFor="pf-style">
          <Select id="pf-style" name="style" defaultValue={project?.style ?? ""}>
            <option value="">Not specified</option>
            {DESIGN_STYLES.map((s) => (
              <option key={s} value={s}>
                {STYLE_INFO[s].label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Location" htmlFor="pf-location">
          <Input id="pf-location" name="location" defaultValue={project?.location ?? ""} maxLength={120} placeholder="e.g. Baner, Pune" />
        </Field>
        <Field label="Area (sq ft)" htmlFor="pf-area">
          <Input id="pf-area" name="areaSqft" type="number" min={0} defaultValue={project?.areaSqft ?? ""} />
        </Field>
        <Field label="Description" htmlFor="pf-desc" required error={errors.description} className="sm:col-span-2">
          <Textarea id="pf-desc" name="description" rows={5} defaultValue={project?.description} required minLength={10} maxLength={4000} />
        </Field>
        <div className="sm:col-span-2">
          <ImageField id="pf-cover" label="Cover image *" value={cover} onChange={setCover} />
        </div>
        <div className="sm:col-span-2">
          <p className="mb-1.5 text-[0.8rem] font-medium text-ink">Gallery ({gallery.length}/24)</p>
          {gallery.length ? (
            <ul className="mb-3 flex flex-wrap gap-2">
              {gallery.map((url, i) => (
                <li key={`${url}-${i}`} className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={url} alt="" className="h-16 w-24 rounded-[var(--radius-sm)] border border-line object-cover" />
                  <button type="button" onClick={() => setGallery(gallery.filter((_, j) => j !== i))} className="absolute -right-1.5 -top-1.5 grid size-5 place-items-center rounded-full bg-charcoal text-paper" aria-label={`Remove gallery image ${i + 1}`}>
                    <X className="size-3" />
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
          {gallery.length < 24 ? <GalleryAdder onAdd={(url) => setGallery((g) => [...g, url])} /> : null}
        </div>
        <Field label="Display order" htmlFor="pf-order" hint="Lower numbers appear first.">
          <Input id="pf-order" name="sortOrder" type="number" defaultValue={project?.sortOrder ?? 0} />
        </Field>
        <div className="flex flex-col justify-end gap-2">
          <Checkbox name="isPublished" label="Published on the website" defaultChecked={project?.isPublished ?? true} />
          <Checkbox name="isFeatured" label="Feature on the homepage" defaultChecked={project?.isFeatured ?? false} />
          <Checkbox name="isSample" label="Sample (not a real client project)" defaultChecked={project?.isSample ?? false} />
        </div>
        <div className="flex justify-end gap-2 border-t border-line-soft pt-4 sm:col-span-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={busy}>
            {project ? "Save changes" : "Add project"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}

function GalleryAdder({ onAdd }: { onAdd: (url: string) => void }) {
  const { toast } = useToast();
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  async function upload(files: FileList) {
    setBusy(true);
    try {
      for (const file of Array.from(files).slice(0, 12)) {
        const fd = new FormData();
        fd.set("file", file);
        const r = await api<{ url: string }>("/api/content/upload", { form: fd });
        onAdd(r.url);
      }
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="flex flex-wrap items-center gap-2">
      <label className={`inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-[var(--radius-sm)] border border-line bg-paper px-3 text-[0.8rem] font-medium text-charcoal hover:border-sand ${busy ? "pointer-events-none opacity-60" : ""}`}>
        <Plus className="size-3.5" /> {busy ? "Uploading…" : "Upload images"}
        <input type="file" multiple accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={(e) => e.target.files?.length && upload(e.target.files)} />
      </label>
      <Input aria-label="Gallery image URL" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="…or paste an image URL" className="min-w-0 flex-1 basis-56" />
      <Button
        type="button"
        size="sm"
        variant="secondary"
        disabled={!/^(https?:\/\/|\/api\/files\/)/.test(url.trim())}
        onClick={() => {
          onAdd(url.trim());
          setUrl("");
        }}
      >
        Add URL
      </Button>
    </div>
  );
}

// ───────────────────────── testimonials ─────────────────────────

export type TestimonialView = { id: string; name: string; location: string | null; projectType: string | null; quote: string; rating: number; isPublished: boolean; isSample: boolean; sortOrder: number };

export function TestimonialsManager({ items: initial }: { items: TestimonialView[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [items, setItems] = useState(initial);
  const [editing, setEditing] = useState<TestimonialView | "new" | null>(null);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  useEffect(() => setItems(initial), [initial]);

  async function patch(t: TestimonialView, body: Partial<TestimonialView>, msg: string) {
    try {
      await api(`/api/content/testimonials/${t.id}`, { method: "PATCH", body });
      setItems((l) => l.map((x) => (x.id === t.id ? { ...x, ...body } : x)));
      toast(msg);
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }
  async function remove(t: TestimonialView) {
    if (!confirm(`Delete the testimonial from ${t.name}?`)) return;
    try {
      await api(`/api/content/testimonials/${t.id}`, { method: "DELETE" });
      setItems((l) => l.filter((x) => x.id !== t.id));
      toast("Testimonial deleted");
    } catch (err) {
      toast(errorMessage(err), "error");
    }
  }
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const current = editing === "new" ? undefined : editing ?? undefined;
    const fd = new FormData(e.currentTarget);
    const s = (k: string) => {
      const v = String(fd.get(k) ?? "").trim();
      return v === "" ? null : v;
    };
    const body = { name: s("name") ?? "", location: s("location"), projectType: s("projectType"), quote: s("quote") ?? "", rating: Number(fd.get("rating") ?? 5), isPublished: fd.get("isPublished") === "on", isSample: fd.get("isSample") === "on", sortOrder: Number(fd.get("sortOrder") ?? 0) };
    setBusy(true);
    setErrors({});
    try {
      if (current) await api(`/api/content/testimonials/${current.id}`, { method: "PATCH", body });
      else await api("/api/content/testimonials", { body });
      toast(current ? "Testimonial updated" : "Testimonial added");
      setEditing(null);
      router.refresh();
    } catch (err) {
      if (err instanceof ApiClientError && err.fields) setErrors(err.fields);
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }
  const t = editing && editing !== "new" ? editing : undefined;

  return (
    <Panel>
      <PanelHeader
        title="Client testimonials"
        description="Only publish words a real client gave you, with their permission. Sample entries are labelled on the site."
        actions={
          <Button onClick={() => setEditing("new")}>
            <Plus className="size-4" /> Add testimonial
          </Button>
        }
      />
      {items.length ? (
        <ul className="divide-y divide-line-soft">
          {items.map((x) => (
            <li key={x.id} className="flex flex-wrap items-start gap-3 py-3">
              <div className="min-w-0 flex-1">
                <p className="text-sm text-ink">“{x.quote}”</p>
                <p className="mt-1 text-xs text-smoke">
                  {x.name}
                  {x.location ? ` · ${x.location}` : ""}
                  {x.projectType ? ` · ${x.projectType}` : ""} · {x.rating}/5
                </p>
              </div>
              <div className="flex items-center gap-1">
                {x.isSample ? <Badge tone="amber">Sample</Badge> : null}
                {!x.isPublished ? <Badge>Hidden</Badge> : null}
                <Button size="sm" variant="ghost" onClick={() => setEditing(x)} aria-label={`Edit testimonial from ${x.name}`}>
                  <Pencil className="size-3.5" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => patch(x, { isPublished: !x.isPublished }, x.isPublished ? "Hidden from the website" : "Published")} aria-label={x.isPublished ? "Hide" : "Publish"}>
                  {x.isPublished ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => remove(x)} aria-label={`Delete testimonial from ${x.name}`}>
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-smoke">No testimonials yet. The homepage hides the section until you add one.</p>
      )}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={t ? "Edit testimonial" : "Add testimonial"}>
        {editing ? (
          <form key={t?.id ?? "new"} onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
            <Field label="Client name" htmlFor="tm-name" required error={errors.name}>
              <Input id="tm-name" name="name" defaultValue={t?.name} required maxLength={100} />
            </Field>
            <Field label="Location" htmlFor="tm-location">
              <Input id="tm-location" name="location" defaultValue={t?.location ?? ""} maxLength={100} />
            </Field>
            <Field label="Project" htmlFor="tm-project" hint="e.g. 3BHK apartment">
              <Input id="tm-project" name="projectType" defaultValue={t?.projectType ?? ""} maxLength={100} />
            </Field>
            <Field label="Rating" htmlFor="tm-rating">
              <Select id="tm-rating" name="rating" defaultValue={String(t?.rating ?? 5)}>
                {[5, 4, 3, 2, 1].map((n) => (
                  <option key={n} value={n}>
                    {n} / 5
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Their words" htmlFor="tm-quote" required error={errors.quote} className="sm:col-span-2">
              <Textarea id="tm-quote" name="quote" rows={4} defaultValue={t?.quote} required minLength={10} maxLength={1200} />
            </Field>
            <Field label="Display order" htmlFor="tm-order">
              <Input id="tm-order" name="sortOrder" type="number" defaultValue={t?.sortOrder ?? 0} />
            </Field>
            <div className="flex flex-col justify-end gap-2">
              <Checkbox name="isPublished" label="Published" defaultChecked={t?.isPublished ?? true} />
              <Checkbox name="isSample" label="Sample (not a real client)" defaultChecked={t?.isSample ?? false} />
            </div>
            <div className="flex justify-end gap-2 border-t border-line-soft pt-4 sm:col-span-2">
              <Button type="button" variant="ghost" onClick={() => setEditing(null)}>
                Cancel
              </Button>
              <Button type="submit" loading={busy}>
                {t ? "Save changes" : "Add testimonial"}
              </Button>
            </div>
          </form>
        ) : null}
      </Modal>
    </Panel>
  );
}
