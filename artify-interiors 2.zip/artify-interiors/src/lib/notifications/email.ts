import "server-only";
import nodemailer, { type Transporter } from "nodemailer";
import { env } from "@/lib/env";

export type EmailAttachment = { filename: string; content: Buffer; contentType?: string };
export type SendResult = { status: "SENT" | "FAILED" | "SKIPPED"; providerMessageId?: string; error?: string };

let transporter: Transporter | null = null;

export async function sendEmail(to: string, subject: string, html: string, attachments: EmailAttachment[] = []): Promise<SendResult> {
  const cfg = env.email();
  if (!to) return { status: "SKIPPED", error: "No recipient email" };
  try {
    if (cfg.provider === "smtp") {
      if (!cfg.smtp.host || !cfg.smtp.user || !cfg.smtp.pass) return { status: "SKIPPED", error: "SMTP not configured" };
      transporter ??= nodemailer.createTransport({
        host: cfg.smtp.host,
        port: cfg.smtp.port,
        secure: cfg.smtp.secure,
        auth: { user: cfg.smtp.user, pass: cfg.smtp.pass },
      });
      const info = await transporter.sendMail({ from: cfg.from, to, subject, html, attachments });
      const accepted = (info.accepted ?? []).map(String);
      if (!accepted.includes(to)) return { status: "FAILED", error: `Rejected by SMTP server: ${(info.rejected ?? []).join(", ")}` };
      return { status: "SENT", providerMessageId: info.messageId };
    }
    if (cfg.provider === "resend") {
      if (!cfg.resendKey) return { status: "SKIPPED", error: "RESEND_API_KEY not set" };
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${cfg.resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: cfg.from,
          to: [to],
          subject,
          html,
          attachments: attachments.map((a) => ({ filename: a.filename, content: a.content.toString("base64") })),
        }),
      });
      const json = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
      if (!res.ok || !json.id) return { status: "FAILED", error: json.message ?? `Resend error ${res.status}` };
      return { status: "SENT", providerMessageId: json.id };
    }
    return { status: "SKIPPED", error: "Email provider not configured (EMAIL_PROVIDER=none)" };
  } catch (err) {
    return { status: "FAILED", error: (err as Error).message };
  }
}

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);

/** Branded, inline-styled HTML email. */
export function emailLayout(opts: { title: string; body: string; ctaLabel?: string; ctaUrl?: string; companyName?: string }) {
  const paragraphs = esc(opts.body)
    .split(/\n{2,}/)
    .map((p) => `<p style="margin:0 0 14px;line-height:1.6;color:#3b3632;font-size:15px">${p.replace(/\n/g, "<br/>")}</p>`)
    .join("");
  const cta =
    opts.ctaLabel && opts.ctaUrl
      ? `<p style="margin:24px 0 8px"><a href="${esc(opts.ctaUrl)}" style="background:#1f1c19;color:#f6f1ea;text-decoration:none;padding:12px 22px;border-radius:999px;font-size:14px;letter-spacing:.04em;display:inline-block">${esc(opts.ctaLabel)}</a></p>`
      : "";
  return `<!doctype html><html><body style="margin:0;background:#f4efe8;font-family:Helvetica,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4efe8;padding:32px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#fffdf9;border:1px solid #e6dccd;border-radius:14px;overflow:hidden">
<tr><td style="padding:22px 28px;border-bottom:1px solid #eee4d6;font-family:Georgia,serif;letter-spacing:.28em;font-size:14px;color:#1f1c19">${esc(opts.companyName ?? "ARTIFY INTERIORS")}</td></tr>
<tr><td style="padding:28px">
<h1 style="margin:0 0 16px;font-family:Georgia,serif;font-weight:normal;font-size:24px;color:#1f1c19">${esc(opts.title)}</h1>
${paragraphs}${cta}
</td></tr>
<tr><td style="padding:16px 28px;background:#f8f3ec;color:#8a8076;font-size:12px">This is an automated message from ${esc(opts.companyName ?? "Artify Interiors")}.</td></tr>
</table></td></tr></table></body></html>`;
}
