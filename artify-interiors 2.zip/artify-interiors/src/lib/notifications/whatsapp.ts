import "server-only";
import { env } from "@/lib/env";
import type { SendResult } from "@/lib/notifications/email";

/** Normalises an Indian / international number to digits with country code (default +91). */
export function normalisePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  let d = raw.replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.length === 10) d = `91${d}`;
  if (d.length === 11 && d.startsWith("0")) d = `91${d.slice(1)}`;
  return d.length >= 11 && d.length <= 15 ? d : null;
}

/**
 * Sends a pre-approved WhatsApp template through the Meta Cloud API.
 * Returns SENT only when the API confirms with a message id.
 */
export async function sendWhatsAppTemplate(event: string, toRaw: string | null | undefined, bodyParams: string[], override?: { template: string; language: string }): Promise<SendResult> {
  const cfg = env.whatsapp();
  if (!cfg.token || !cfg.phoneNumberId) return { status: "SKIPPED", error: "WhatsApp Cloud API not configured" };
  const template = override?.template ?? cfg.templates[event];
  if (!template) return { status: "SKIPPED", error: `No approved WhatsApp template mapped for ${event} (WHATSAPP_TEMPLATES)` };
  const to = normalisePhone(toRaw);
  if (!to) return { status: "SKIPPED", error: "No valid phone number" };
  try {
    const res = await fetch(`https://graph.facebook.com/${cfg.apiVersion}/${cfg.phoneNumberId}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "template",
        template: {
          name: template,
          language: { code: override?.language ?? cfg.language },
          ...(bodyParams.length
            ? { components: [{ type: "body", parameters: bodyParams.map((text) => ({ type: "text", text: text.slice(0, 1000) })) }] }
            : {}),
        },
      }),
    });
    const json = (await res.json().catch(() => ({}))) as { messages?: { id?: string }[]; error?: { message?: string } };
    const id = json.messages?.[0]?.id;
    if (!res.ok || !id) return { status: "FAILED", error: json.error?.message ?? `WhatsApp API error ${res.status}` };
    return { status: "SENT", providerMessageId: id };
  } catch (err) {
    return { status: "FAILED", error: (err as Error).message };
  }
}
