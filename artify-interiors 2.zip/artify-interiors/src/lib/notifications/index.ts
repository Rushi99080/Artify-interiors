import "server-only";
import { after } from "next/server";
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { logError } from "@/lib/logger";
import { emailLayout, sendEmail, type EmailAttachment } from "@/lib/notifications/email";
import { sendWhatsAppTemplate } from "@/lib/notifications/whatsapp";
import { getSettings } from "@/lib/settings";

export type NotificationEvent =
  | "NEW_ENQUIRY"
  | "DESIGN_COMPLETED"
  | "QUOTATION_GENERATED"
  | "QUOTATION_APPROVED"
  | "QUOTATION_CHANGES_REQUESTED"
  | "PAYMENT_REMINDER"
  | "PAYMENT_RECEIVED"
  | "MILESTONE_UPDATE"
  | "MATERIAL_APPROVAL"
  | "PROJECT_HANDOVER"
  | "NEW_MESSAGE"
  | "DESIGN_APPROVED";

export type Recipient = { userId?: string | null; email?: string | null; phone?: string | null };

export type NotifyInput = {
  event: NotificationEvent;
  title: string;
  body: string;
  /** Relative app link, e.g. /dashboard/projects/abc */
  link?: string;
  recipients?: Recipient[];
  /** Also notify all admins (in-app) plus ADMIN_NOTIFICATION_EMAIL / ADMIN_WHATSAPP_NUMBER */
  notifyAdmins?: boolean;
  channels?: { email?: boolean; whatsapp?: boolean };
  whatsappParams?: string[];
  attachments?: EmailAttachment[];
  ctaLabel?: string;
};

/**
 * Sends notifications on every channel and records the outcome of each attempt.
 * Email / WhatsApp rows are only marked SENT when the provider confirms delivery acceptance.
 */
export async function notify(input: NotifyInput) {
  const channels = { email: true, whatsapp: true, ...input.channels };
  const recipients: Recipient[] = [...(input.recipients ?? [])];
  const settings = await getSettings();

  if (input.notifyAdmins) {
    const admins = await prisma.user.findMany({ where: { role: "ADMIN", isActive: true }, select: { id: true } });
    for (const a of admins) recipients.push({ userId: a.id });
    const cfg = env.email();
    const wa = env.whatsapp();
    if (cfg.adminEmail || wa.adminNumber) recipients.push({ email: cfg.adminEmail || null, phone: wa.adminNumber || null });
  }

  const absoluteLink = input.link ? `${env.appUrl()}${input.link}` : undefined;
  const seenUsers = new Set<string>();
  const seenEmails = new Set<string>();
  const seenPhones = new Set<string>();

  for (const r of recipients) {
    if (r.userId && !seenUsers.has(r.userId)) {
      seenUsers.add(r.userId);
      await prisma.notification.create({
        data: { userId: r.userId, channel: "IN_APP", event: input.event, title: input.title, body: input.body, link: input.link, status: "SENT", sentAt: new Date() },
      });
    }

    if (channels.email && r.email && !seenEmails.has(r.email.toLowerCase())) {
      seenEmails.add(r.email.toLowerCase());
      const html = emailLayout({ title: input.title, body: input.body, ctaLabel: absoluteLink ? (input.ctaLabel ?? "Open in Artify") : undefined, ctaUrl: absoluteLink, companyName: settings.company.name });
      const res = await sendEmail(r.email, `${input.title} · ${settings.company.legalName}`, html, input.attachments);
      await prisma.notification.create({
        data: {
          userId: r.userId ?? null,
          channel: "EMAIL",
          event: input.event,
          title: input.title,
          body: input.body,
          link: input.link,
          recipient: r.email,
          status: res.status,
          providerMessageId: res.providerMessageId,
          error: res.error,
          sentAt: res.status === "SENT" ? new Date() : null,
          readAt: new Date(),
        },
      });
    }

    if (channels.whatsapp && r.phone && !seenPhones.has(r.phone)) {
      seenPhones.add(r.phone);
      const res = await sendWhatsAppTemplate(input.event, r.phone, input.whatsappParams ?? [input.title]);
      await prisma.notification.create({
        data: {
          userId: r.userId ?? null,
          channel: "WHATSAPP",
          event: input.event,
          title: input.title,
          body: input.body,
          link: input.link,
          recipient: r.phone,
          status: res.status,
          providerMessageId: res.providerMessageId,
          error: res.error,
          sentAt: res.status === "SENT" ? new Date() : null,
          readAt: new Date(),
        },
      });
    }
  }
}

/** Runs notify() after the response is sent (inside a request), or immediately otherwise. */
export function queueNotify(input: NotifyInput) {
  const run = () => notify(input).catch((err) => logError("notify", err, { event: input.event }));
  try {
    after(run);
  } catch {
    void run();
  }
}

/** Recipient info for a project's customer. */
export async function projectCustomerRecipient(projectId: string): Promise<Recipient & { name: string }> {
  const p = await prisma.project.findUnique({
    where: { id: projectId },
    select: { customer: { select: { fullName: true, email: true, phone: true, userId: true } } },
  });
  return { userId: p?.customer.userId ?? null, email: p?.customer.email ?? null, phone: p?.customer.phone ?? null, name: p?.customer.fullName ?? "" };
}
