import type { WizardPrefill } from "@/components/designs/project-wizard";
import { DESIGN_STYLES, ROOM_TYPES, type DesignStyleKey, type RoomTypeKey } from "@/lib/constants";

/** Builds wizard prefill from query parameters coming from room modules or the cost calculator. */
export function parsePrefill(sp: Record<string, string | string[] | undefined>): WizardPrefill | undefined {
  const get = (k: string) => (Array.isArray(sp[k]) ? sp[k]![0] : sp[k]) as string | undefined;
  const num = (v?: string) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 && n < 500 ? n : undefined;
  };
  const style = get("style");
  const out: WizardPrefill = {};
  if (style && (DESIGN_STYLES as readonly string[]).includes(style)) out.style = style as DesignStyleKey;
  const room = get("room");
  if (room && (ROOM_TYPES as readonly string[]).includes(room)) {
    out.rooms = [{ type: room as RoomTypeKey, lengthFt: num(get("l")), widthFt: num(get("w")), heightFt: num(get("h")) }];
  }
  const preset = get("preset");
  if (preset) {
    try {
      const arr = JSON.parse(preset) as { name?: string; type: string; lengthFt?: number; widthFt?: number; heightFt?: number }[];
      if (Array.isArray(arr)) {
        out.rooms = arr
          .filter((r) => (ROOM_TYPES as readonly string[]).includes(r.type))
          .slice(0, 30)
          .map((r) => ({ name: typeof r.name === "string" ? r.name.slice(0, 60) : undefined, type: r.type as RoomTypeKey, lengthFt: num(String(r.lengthFt)), widthFt: num(String(r.widthFt)), heightFt: num(String(r.heightFt)) }));
      }
    } catch {
      /* ignore malformed preset */
    }
  }
  return out.rooms || out.style ? out : undefined;
}
