// Plain, serialisable view models passed from server components to client components.

export type DesignView = {
  id: string;
  projectId: string;
  roomId: string | null;
  roomName: string | null;
  name: string;
  style: string;
  tier: string;
  summary: string | null;
  colorPalette: { name: string; hex: string }[];
  materials: { category: string; materialId: string | null; name: string; brand?: string | null; rate?: number | null; unit?: string | null; application?: string }[];
  furniture: { item: string; description?: string; placement?: string }[];
  furnitureLayout: string | null;
  wallFinish: string | null;
  ceilingDesign: string | null;
  lighting: string | null;
  flooring: string | null;
  decor: string[];
  estimatedBudgetMin: number | null;
  estimatedBudgetMax: number | null;
  imageStatus: string;
  imageUrl: string | null;
  imageError: string | null;
  imageProvider: string | null;
  isSaved: boolean;
  isFavorite: boolean;
  status: string;
  customerComment: string | null;
  adminNotes: string | null;
  revisionNo: number;
  createdAt: string;
};

type DesignRow = {
  id: string;
  projectId: string;
  roomId: string | null;
  room?: { name: string } | null;
  name: string;
  style: string;
  tier: string;
  summary: string | null;
  colorPalette: unknown;
  materialSuggestions: unknown;
  furnitureSuggestions: unknown;
  furnitureLayout: string | null;
  wallFinish: string | null;
  ceilingDesign: string | null;
  lighting: string | null;
  flooring: string | null;
  decor: unknown;
  estimatedBudgetMin: number | null;
  estimatedBudgetMax: number | null;
  imageStatus: string;
  imageFileId: string | null;
  imageError: string | null;
  imageProvider: string | null;
  isSaved: boolean;
  isFavorite: boolean;
  status: string;
  customerComment: string | null;
  adminNotes: string | null;
  revisionNo: number;
  createdAt: Date | string;
};

const arr = <T,>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);

export function toDesignView(d: DesignRow, opts: { hideAdminNotes?: boolean } = {}): DesignView {
  return {
    id: d.id,
    projectId: d.projectId,
    roomId: d.roomId,
    roomName: d.room?.name ?? null,
    name: d.name,
    style: d.style,
    tier: d.tier,
    summary: d.summary,
    colorPalette: arr(d.colorPalette),
    materials: arr(d.materialSuggestions),
    furniture: arr(d.furnitureSuggestions),
    furnitureLayout: d.furnitureLayout,
    wallFinish: d.wallFinish,
    ceilingDesign: d.ceilingDesign,
    lighting: d.lighting,
    flooring: d.flooring,
    decor: arr<string>(d.decor),
    estimatedBudgetMin: d.estimatedBudgetMin,
    estimatedBudgetMax: d.estimatedBudgetMax,
    imageStatus: d.imageStatus,
    imageUrl: d.imageFileId ? `/api/files/${d.imageFileId}` : null,
    imageError: d.imageError,
    imageProvider: d.imageProvider,
    isSaved: d.isSaved,
    isFavorite: d.isFavorite,
    status: d.status,
    customerComment: d.customerComment,
    adminNotes: opts.hideAdminNotes ? null : d.adminNotes,
    revisionNo: d.revisionNo,
    createdAt: typeof d.createdAt === "string" ? d.createdAt : d.createdAt.toISOString(),
  };
}

export type AIStatusView = {
  text: { configured: boolean; provider: string; model: string; detail: string };
  image: { configured: boolean; provider: string; model: string; detail: string };
  variations: number;
};
