// Pure money / BOQ total calculations. No database access — fully unit-tested (tests/calc.test.ts).

export type BOQItemTypeKey = "MATERIAL" | "LABOUR" | "SERVICE";

/** Round to paise (2 decimals) without floating point drift (e.g. 1.005 → 1.01). */
export function round2(value: number): number {
  if (!Number.isFinite(value)) return 0;
  const sign = value < 0 ? -1 : 1;
  return (sign * Math.round(Number(`${Math.abs(value)}e2`))) / 100;
}

/** Quantities keep up to 2 decimals as well (sqft, rft...). */
export const roundQty = round2;

/** Amount = Quantity × Rate */
export function lineAmount(quantity: number, rate: number): number {
  const q = Number(quantity);
  const r = Number(rate);
  if (!Number.isFinite(q) || !Number.isFinite(r)) return 0;
  return round2(q * r);
}

export type CalcItem = {
  section: string;
  quantity: number;
  rate: number;
  itemType: BOQItemTypeKey;
};

export type BOQCharges = {
  gstRate: number; // %
  wastagePercent: number; // % applied on material items
  profitMarginPercent: number; // % applied on (subtotal + wastage + transport + installation)
  transportCharges: number; // ₹ fixed
  installationCharges: number; // ₹ fixed
  discountAmount: number; // ₹ fixed
};

export type SectionTotal = { section: string; amount: number; items: number };

export type BOQTotals = {
  subtotal: number;
  materialCost: number;
  labourCost: number;
  serviceCost: number;
  wastageAmount: number;
  transportCharges: number;
  installationCharges: number;
  profitAmount: number;
  additionalCharges: number;
  discountAmount: number;
  taxableAmount: number;
  gstRate: number;
  gstAmount: number;
  grandTotal: number;
  sections: SectionTotal[];
};

function clampPercent(v: number, max = 100) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.min(n, max);
}
function nonNegative(v: number) {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

/**
 * BOQ calculation logic
 *   Amount            = Quantity × Rate                         (per line, rounded to paise)
 *   Subtotal          = Σ line amounts
 *   Wastage           = Material cost × wastage %
 *   Profit / overhead = (Subtotal + Wastage + Transport + Installation) × margin %
 *   Additional charges= Wastage + Transport + Installation + Profit
 *   Taxable value     = Subtotal + Additional charges − Discount
 *   GST               = Taxable value × GST %
 *   Grand Total       = Subtotal + GST + Additional charges − Discount
 */
export function computeBOQTotals(items: CalcItem[], charges: BOQCharges, sectionOrder: string[] = []): BOQTotals {
  let subtotal = 0;
  let materialCost = 0;
  let labourCost = 0;
  let serviceCost = 0;
  const sectionMap = new Map<string, SectionTotal>();

  for (const item of items) {
    const amount = lineAmount(nonNegative(item.quantity), nonNegative(item.rate));
    subtotal += amount;
    if (item.itemType === "LABOUR") labourCost += amount;
    else if (item.itemType === "SERVICE") serviceCost += amount;
    else materialCost += amount;
    const s = sectionMap.get(item.section) ?? { section: item.section, amount: 0, items: 0 };
    s.amount = round2(s.amount + amount);
    s.items += 1;
    sectionMap.set(item.section, s);
  }

  subtotal = round2(subtotal);
  materialCost = round2(materialCost);
  labourCost = round2(labourCost);
  serviceCost = round2(serviceCost);

  const wastageAmount = round2((materialCost * clampPercent(charges.wastagePercent)) / 100);
  const transportCharges = round2(nonNegative(charges.transportCharges));
  const installationCharges = round2(nonNegative(charges.installationCharges));
  const profitBase = subtotal + wastageAmount + transportCharges + installationCharges;
  const profitAmount = round2((profitBase * clampPercent(charges.profitMarginPercent, 500)) / 100);
  const additionalCharges = round2(wastageAmount + transportCharges + installationCharges + profitAmount);
  const discountAmount = round2(Math.min(nonNegative(charges.discountAmount), subtotal + additionalCharges));
  const taxableAmount = round2(subtotal + additionalCharges - discountAmount);
  const gstRate = clampPercent(charges.gstRate);
  const gstAmount = round2((taxableAmount * gstRate) / 100);
  const grandTotal = round2(subtotal + gstAmount + additionalCharges - discountAmount);

  const order = (s: string) => {
    const i = sectionOrder.indexOf(s);
    return i === -1 ? sectionOrder.length : i;
  };
  const sections = [...sectionMap.values()].sort((a, b) => order(a.section) - order(b.section));

  return {
    subtotal,
    materialCost,
    labourCost,
    serviceCost,
    wastageAmount,
    transportCharges,
    installationCharges,
    profitAmount,
    additionalCharges,
    discountAmount,
    taxableAmount,
    gstRate,
    gstAmount,
    grandTotal,
    sections,
  };
}

/** Split a contract value into payment milestones; the last one absorbs rounding so the sum is exact. */
export function splitPaymentSchedule(total: number, schedule: { name: string; percent: number }[]) {
  const pctSum = schedule.reduce((s, x) => s + x.percent, 0);
  if (schedule.length === 0) return [];
  if (Math.abs(pctSum - 100) > 0.001) throw new Error(`Payment schedule must add up to 100% (currently ${pctSum}%)`);
  let allocated = 0;
  return schedule.map((s, i) => {
    const amount = i === schedule.length - 1 ? round2(total - allocated) : round2((total * s.percent) / 100);
    allocated = round2(allocated + amount);
    return { ...s, amount };
  });
}

/** Payment milestone status from amount received against it. */
export function paymentMilestoneStatus(amount: number, received: number): "PENDING" | "PARTIAL" | "PAID" {
  if (received <= 0) return "PENDING";
  if (round2(received) + 0.009 >= round2(amount)) return "PAID";
  return "PARTIAL";
}
