// Pure payment allocation helpers (unit-tested).
import { round2 } from "@/lib/calc/boq";

export type MilestoneInput = { id: string; amount: number; sortOrder: number; dueDate?: Date | null };
export type AllocatedMilestone = MilestoneInput & { received: number; balance: number; status: "PENDING" | "PARTIAL" | "PAID"; overdue: boolean };

/** Allocates the total received across milestones in order (oldest first). */
export function allocatePayments(milestones: MilestoneInput[], totalReceived: number, now = new Date()): AllocatedMilestone[] {
  let remaining = round2(Math.max(0, totalReceived));
  return [...milestones]
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .map((m) => {
      const received = round2(Math.min(remaining, m.amount));
      remaining = round2(remaining - received);
      const balance = round2(m.amount - received);
      const status: AllocatedMilestone["status"] = received <= 0 ? "PENDING" : balance <= 0.009 ? "PAID" : "PARTIAL";
      const overdue = status !== "PAID" && !!m.dueDate && m.dueDate.getTime() < now.getTime();
      return { ...m, received, balance, status, overdue };
    });
}

export function paymentSummary(contractValue: number | null | undefined, payments: { amount: number; status: string }[]) {
  const received = round2(payments.filter((p) => p.status === "SUCCESS").reduce((s, p) => s + p.amount, 0));
  const contract = round2(contractValue ?? 0);
  const pending = round2(Math.max(0, contract - received));
  const percent = contract > 0 ? Math.min(100, Math.round((received / contract) * 100)) : 0;
  return { contract, received, pending, percent, status: contract === 0 ? "NO_CONTRACT" : pending <= 0.009 ? "PAID" : received > 0 ? "PARTIAL" : "PENDING" };
}
