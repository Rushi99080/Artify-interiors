import "server-only";
import { prisma } from "@/lib/db";
import { forbidden, notFound } from "@/lib/api";
import type { CurrentUser } from "@/lib/auth/session";
import { isTeamRole } from "@/lib/auth/token";

/**
 * Loads a project the user is allowed to see. Customers can only access their own projects;
 * staff and admins can access all projects. Throws ApiError (404 / 403).
 */
export async function assertProjectAccess(user: CurrentUser, projectId: string) {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: { id: true, customerId: true, name: true, code: true, status: true },
  });
  if (!project) throw notFound("Project not found.");
  if (isTeamRole(user.role)) return project;
  if (!user.customerId || project.customerId !== user.customerId) throw forbidden();
  return project;
}

/** Non-throwing variant for server components. */
export async function canAccessProject(user: CurrentUser, projectId: string) {
  try {
    return await assertProjectAccess(user, projectId);
  } catch {
    return null;
  }
}
