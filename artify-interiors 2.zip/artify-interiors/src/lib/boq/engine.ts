// BOQ generation engine — pure functions (no DB). Used by:
//  • the automatic BOQ generator (src/lib/services/boq.ts)
//  • the public cost calculator and room modules (client side)
//  • design concept budget estimates
// Quantities are derived from room dimensions with transparent formulas and are always marked
// as PRELIMINARY estimates until verified against site measurements.

import type { MaterialCategoryKey, PriceTierKey, RoomTypeKey } from "@/lib/constants";
import { ROOM_MODULE_BY_TYPE } from "@/lib/constants";
import { computeBOQTotals, lineAmount, roundQty, type BOQCharges, type BOQItemTypeKey, type BOQTotals } from "@/lib/calc/boq";

export const BOQ_SECTIONS = [
  "Entrance",
  "Living Room",
  "Dining",
  "Kitchen",
  "Bedrooms",
  "Wardrobes",
  "Bathrooms",
  "Balcony",
  "Office",
  "Commercial",
  "False Ceiling",
  "Electrical",
  "Painting",
  "Flooring",
  "Miscellaneous",
] as const;

export type TierRates = Record<PriceTierKey, number>;
export type RateCardEntry = { label: string; unit: string; itemType: BOQItemTypeKey; rates: TierRates };
export type RateCard = Record<string, RateCardEntry>;

const t = (e: number, s: number, p: number, l: number): TierRates => ({ ECONOMY: e, STANDARD: s, PREMIUM: p, LUXURY: l });

/** Default rate card (₹, Pune market, supply + installation unless marked labour). Admin-editable in Settings. */
export const DEFAULT_RATE_CARD: RateCard = {
  SHOE_RACK: { label: "Shoe rack unit", unit: "sqft", itemType: "MATERIAL", rates: t(1150, 1500, 2000, 2800) },
  FOYER_PANELING: { label: "Foyer wall paneling", unit: "sqft", itemType: "MATERIAL", rates: t(450, 700, 1100, 1800) },
  TV_UNIT: { label: "TV unit", unit: "sqft", itemType: "MATERIAL", rates: t(1300, 1700, 2300, 3200) },
  WALL_PANELING: { label: "Wall paneling", unit: "sqft", itemType: "MATERIAL", rates: t(450, 700, 1100, 1800) },
  WARDROBE: { label: "Wardrobe (shutters + carcass)", unit: "sqft", itemType: "MATERIAL", rates: t(1250, 1650, 2200, 3000) },
  WARDROBE_LOFT: { label: "Wardrobe loft", unit: "sqft", itemType: "MATERIAL", rates: t(900, 1150, 1500, 2000) },
  BED_STORAGE: { label: "Queen bed with hydraulic storage", unit: "nos", itemType: "MATERIAL", rates: t(38000, 52000, 72000, 110000) },
  KIDS_BED: { label: "Single / bunk bed with storage", unit: "nos", itemType: "MATERIAL", rates: t(26000, 36000, 50000, 75000) },
  SIDE_TABLE: { label: "Bedside table", unit: "nos", itemType: "MATERIAL", rates: t(7000, 10000, 15000, 24000) },
  DRESSER: { label: "Dresser with mirror", unit: "nos", itemType: "MATERIAL", rates: t(18000, 25000, 36000, 55000) },
  STUDY_TABLE: { label: "Study table with storage", unit: "nos", itemType: "MATERIAL", rates: t(16000, 22000, 32000, 48000) },
  BOOKSHELF: { label: "Bookshelf", unit: "sqft", itemType: "MATERIAL", rates: t(1100, 1450, 1900, 2600) },
  HEADBOARD_PANEL: { label: "Headboard / bed back paneling", unit: "sqft", itemType: "MATERIAL", rates: t(650, 950, 1400, 2200) },
  KITCHEN_BASE: { label: "Kitchen base cabinets", unit: "rft", itemType: "MATERIAL", rates: t(3500, 4800, 6500, 9500) },
  KITCHEN_WALL: { label: "Kitchen wall cabinets", unit: "rft", itemType: "MATERIAL", rates: t(2600, 3500, 4800, 7000) },
  KITCHEN_TALL: { label: "Kitchen tall unit", unit: "nos", itemType: "MATERIAL", rates: t(28000, 38000, 52000, 75000) },
  KITCHEN_ACCESSORIES: { label: "Kitchen accessories set", unit: "set", itemType: "MATERIAL", rates: t(12000, 22000, 38000, 65000) },
  CROCKERY_UNIT: { label: "Crockery unit", unit: "sqft", itemType: "MATERIAL", rates: t(1400, 1800, 2400, 3400) },
  VANITY: { label: "Vanity unit", unit: "nos", itemType: "MATERIAL", rates: t(18000, 26000, 38000, 60000) },
  LED_MIRROR: { label: "LED backlit mirror", unit: "nos", itemType: "MATERIAL", rates: t(4000, 7000, 12000, 22000) },
  BATH_ACCESSORIES: { label: "Bathroom accessories set", unit: "set", itemType: "MATERIAL", rates: t(6000, 10000, 16000, 28000) },
  WORKSTATION: { label: "Workstation", unit: "nos", itemType: "MATERIAL", rates: t(18000, 26000, 38000, 55000) },
  OFFICE_STORAGE: { label: "Office storage unit", unit: "sqft", itemType: "MATERIAL", rates: t(1100, 1450, 1900, 2600) },
  RECEPTION_COUNTER: { label: "Reception counter", unit: "nos", itemType: "MATERIAL", rates: t(65000, 95000, 150000, 250000) },
  DISPLAY_UNIT: { label: "Display unit", unit: "sqft", itemType: "MATERIAL", rates: t(1300, 1700, 2300, 3200) },
  PLANTER: { label: "Planter box", unit: "nos", itemType: "MATERIAL", rates: t(4000, 7000, 12000, 20000) },
  BALCONY_SEATING: { label: "Balcony seating", unit: "nos", itemType: "MATERIAL", rates: t(15000, 25000, 40000, 70000) },
  WALL_CLADDING: { label: "Wall cladding", unit: "sqft", itemType: "MATERIAL", rates: t(180, 260, 380, 600) },
  SOFA: { label: "Sofa (3+2 / L-shape)", unit: "nos", itemType: "MATERIAL", rates: t(55000, 85000, 140000, 250000) },
  COFFEE_TABLE: { label: "Coffee table", unit: "nos", itemType: "MATERIAL", rates: t(12000, 20000, 35000, 60000) },
  DINING_SET: { label: "Dining table with chairs", unit: "set", itemType: "MATERIAL", rates: t(45000, 75000, 120000, 220000) },
  CURTAINS: { label: "Curtains with tracks", unit: "rft", itemType: "MATERIAL", rates: t(650, 950, 1500, 2500) },
  PENDANT_LIGHT: { label: "Pendant light", unit: "nos", itemType: "MATERIAL", rates: t(3500, 6500, 12000, 25000) },
  PROFILE_LIGHT: { label: "LED profile / cove lighting", unit: "rft", itemType: "MATERIAL", rates: t(350, 550, 850, 1300) },
  FALSE_CEILING: { label: "Gypsum false ceiling", unit: "sqft", itemType: "SERVICE", rates: t(95, 120, 165, 240) },
  PAINTING: { label: "Painting (putty, primer, 2 coats)", unit: "sqft", itemType: "SERVICE", rates: t(22, 30, 42, 65) },
  ELECTRICAL_POINT: { label: "Electrical point", unit: "nos", itemType: "SERVICE", rates: t(900, 1200, 1600, 2200) },
  CONCEALED_WIRING: { label: "Concealed wiring for TV wall", unit: "lot", itemType: "SERVICE", rates: t(2500, 3500, 5000, 7500) },
  SITE_PROTECTION: { label: "Site protection & final cleaning", unit: "sqft", itemType: "SERVICE", rates: t(8, 10, 12, 15) },
  DEBRIS_REMOVAL: { label: "Debris removal", unit: "lot", itemType: "SERVICE", rates: t(6000, 8000, 10000, 15000) },
  TILE_LAYING: { label: "Tile laying", unit: "sqft", itemType: "LABOUR", rates: t(40, 50, 65, 90) },
  FLOORING_LAYING: { label: "Flooring installation", unit: "sqft", itemType: "LABOUR", rates: t(45, 55, 75, 110) },
  COUNTERTOP_FABRICATION: { label: "Countertop cutting & fixing", unit: "sqft", itemType: "LABOUR", rates: t(150, 200, 300, 450) },
  GLASS_INSTALL: { label: "Glass installation", unit: "sqft", itemType: "LABOUR", rates: t(120, 150, 200, 280) },
  LIGHT_INSTALL: { label: "Light fixture installation", unit: "nos", itemType: "LABOUR", rates: t(150, 200, 250, 350) },
  WALLPAPER_INSTALL: { label: "Wallpaper installation", unit: "roll", itemType: "LABOUR", rates: t(600, 800, 1100, 1500) },
};

/** Used when the material library has no matching material for a category. */
export const FALLBACK_MATERIALS: Partial<Record<MaterialCategoryKey, { name: string; unit: string; rates: TierRates }>> = {
  TILES: { name: "Vitrified tiles", unit: "sqft", rates: t(60, 90, 140, 220) },
  FLOORING: { name: "Laminate wooden flooring 8mm", unit: "sqft", rates: t(90, 140, 220, 380) },
  MARBLE: { name: "Marble", unit: "sqft", rates: t(180, 300, 550, 1200) },
  QUARTZ: { name: "Quartz slab 15mm", unit: "sqft", rates: t(250, 380, 550, 900) },
  GLASS: { name: "Toughened glass 10mm", unit: "sqft", rates: t(180, 260, 380, 600) },
  WALLPAPER: { name: "Designer wallpaper", unit: "roll", rates: t(1800, 2800, 4500, 8000) },
  LIGHTING: { name: "LED downlight 12W", unit: "nos", rates: t(450, 750, 1400, 3500) },
  HINGES: { name: "Soft-close hinge", unit: "nos", rates: t(120, 220, 450, 900) },
  CHANNELS: { name: "Telescopic / tandem channel", unit: "pair", rates: t(450, 900, 2200, 4500) },
  HANDLES: { name: "Profile handle", unit: "nos", rates: t(150, 300, 600, 1500) },
};

const BOARD_FALLBACK: Record<PriceTierKey, string> = {
  ECONOMY: "BWR plywood 18mm",
  STANDARD: "BWP plywood 18mm",
  PREMIUM: "Marine plywood 18mm (BWP 710)",
  LUXURY: "Marine plywood 19mm, gurjan face",
};
const FINISH_CATEGORY_BY_TIER: Record<PriceTierKey, MaterialCategoryKey> = {
  ECONOMY: "LAMINATE",
  STANDARD: "LAMINATE",
  PREMIUM: "ACRYLIC",
  LUXURY: "VENEER",
};
const FINISH_FALLBACK: Record<PriceTierKey, string> = {
  ECONOMY: "Matte laminate 1mm",
  STANDARD: "Textured laminate 1mm",
  PREMIUM: "High-gloss acrylic",
  LUXURY: "Natural veneer, PU lacquer",
};
const HARDWARE_TEXT: Record<PriceTierKey, string> = {
  ECONOMY: "Auto-close hinges, aluminium handles",
  STANDARD: "Soft-close hinges, profile handles",
  PREMIUM: "Branded soft-close hinges & tandem drawers",
  LUXURY: "Premium imported soft-close hardware",
};

export type MaterialPick = {
  id?: string;
  name: string;
  brand?: string | null;
  finish?: string | null;
  rate: number;
  unit: string;
  category?: MaterialCategoryKey;
};

export type MaterialContext = {
  /** Materials explicitly selected for this room (by category) */
  selected?: Partial<Record<MaterialCategoryKey, MaterialPick>>;
  /** Representative library material per category & tier */
  byTier?: Partial<Record<MaterialCategoryKey, Partial<Record<PriceTierKey, MaterialPick>>>>;
};

export type Dims = { lengthFt: number; widthFt: number; heightFt: number };

export type RoomInput = {
  id?: string;
  name: string;
  type: RoomTypeKey;
  lengthFt?: number | null;
  widthFt?: number | null;
  heightFt?: number | null;
  includeFlooring?: boolean;
};

export type GeneratedLine = {
  key: string;
  section: string;
  item: string;
  dimensions: string | null;
  primaryMaterial: string | null;
  finishBrand: string | null;
  hardware: string | null;
  accessories: string | null;
  quantity: number;
  unit: string;
  rate: number;
  amount: number;
  itemType: BOQItemTypeKey;
  materialId: string | null;
  isEstimated: true;
};

const TIER_ORDER: PriceTierKey[] = ["ECONOMY", "STANDARD", "PREMIUM", "LUXURY"];

export function normalizeUnit(unit: string) {
  const u = unit.trim().toLowerCase().replace(/[.\s]/g, "");
  if (["sqft", "sft", "squarefeet", "sqfeet", "ft2"].includes(u)) return "sqft";
  if (["no", "nos", "pc", "pcs", "piece", "pieces", "unit", "units", "each"].includes(u)) return "nos";
  if (["rft", "runningft", "rf"].includes(u)) return "rft";
  if (["pair", "pairs", "pr"].includes(u)) return "pair";
  if (["roll", "rolls"].includes(u)) return "roll";
  if (["ltr", "litre", "liter", "l"].includes(u)) return "litre";
  return u;
}

export function pickMaterial(category: MaterialCategoryKey, tier: PriceTierKey, ctx: MaterialContext): MaterialPick | null {
  const sel = ctx.selected?.[category];
  if (sel) return sel;
  const byTier = ctx.byTier?.[category];
  if (!byTier) return null;
  if (byTier[tier]) return byTier[tier]!;
  // nearest tier
  const idx = TIER_ORDER.indexOf(tier);
  for (let d = 1; d < TIER_ORDER.length; d++) {
    const lower = TIER_ORDER[idx - d];
    const upper = TIER_ORDER[idx + d];
    if (lower && byTier[lower]) return byTier[lower]!;
    if (upper && byTier[upper]) return byTier[upper]!;
  }
  return null;
}

export function materialLabel(m: MaterialPick | null | undefined) {
  if (!m) return null;
  return [m.brand, m.name].filter(Boolean).join(" ");
}

function boardName(tier: PriceTierKey, ctx: MaterialContext) {
  for (const c of ["PLYWOOD", "HDHMR", "MDF"] as MaterialCategoryKey[]) {
    if (ctx.selected?.[c]) return materialLabel(ctx.selected[c]);
  }
  return materialLabel(pickMaterial("PLYWOOD", tier, ctx)) ?? BOARD_FALLBACK[tier];
}

function finishName(tier: PriceTierKey, ctx: MaterialContext) {
  for (const c of ["VENEER", "ACRYLIC", "LAMINATE"] as MaterialCategoryKey[]) {
    if (ctx.selected?.[c]) return materialLabel(ctx.selected[c]);
  }
  return materialLabel(pickMaterial(FINISH_CATEGORY_BY_TIER[tier], tier, ctx)) ?? FINISH_FALLBACK[tier];
}

const clamp = (v: number, min: number, max: number) => Math.min(Math.max(v, min), max);
const r1 = (v: number) => Math.round(v * 10) / 10;
const fmtFt = (v: number) => `${r1(v)}'`;

export function resolveDims(room: RoomInput): Dims {
  const def = ROOM_MODULE_BY_TYPE[room.type]?.defaults ?? { lengthFt: 12, widthFt: 10, heightFt: 10 };
  const pos = (v: number | null | undefined, d: number) => (v && v > 0 && Number.isFinite(v) ? v : d);
  return {
    lengthFt: pos(room.lengthFt, def.lengthFt),
    widthFt: pos(room.widthFt, def.widthFt),
    heightFt: pos(room.heightFt, def.heightFt),
  };
}

export function roomSection(type: RoomTypeKey): string {
  switch (type) {
    case "ENTRANCE":
      return "Entrance";
    case "LIVING_ROOM":
    case "TV_UNIT":
      return "Living Room";
    case "DINING_ROOM":
      return "Dining";
    case "KITCHEN":
      return "Kitchen";
    case "MASTER_BEDROOM":
    case "KIDS_BEDROOM":
    case "GUEST_BEDROOM":
      return "Bedrooms";
    case "WARDROBE":
      return "Wardrobes";
    case "BATHROOM":
      return "Bathrooms";
    case "BALCONY":
      return "Balcony";
    case "OFFICE":
      return "Office";
    case "COMMERCIAL":
      return "Commercial";
    case "FALSE_CEILING":
      return "False Ceiling";
    default:
      return "Miscellaneous";
  }
}

type Spec = {
  key: string;
  section: string;
  item: string;
  qty: number;
  dimensions?: string;
  pricing: { kind: "ratecard"; key: string } | { kind: "material"; category: MaterialCategoryKey };
  primary?: string | null;
  finish?: string | null;
  hardware?: string | null;
  accessories?: string | null;
};

class Builder {
  specs: Spec[] = [];
  constructor(
    private room: string,
    private tier: PriceTierKey,
    private ctx: MaterialContext,
  ) {}
  board() {
    return boardName(this.tier, this.ctx);
  }
  finishText() {
    return finishName(this.tier, this.ctx);
  }
  hw() {
    return HARDWARE_TEXT[this.tier];
  }
  rc(key: string, section: string, qty: number, extra: Partial<Spec> = {}, itemName?: string) {
    if (qty <= 0) return;
    this.specs.push({ key, section, item: `${itemName ?? DEFAULT_RATE_CARD[key]?.label ?? key} — ${this.room}`, qty, pricing: { kind: "ratecard", key }, ...extra });
  }
  mat(key: string, section: string, category: MaterialCategoryKey, qty: number, itemName: string, extra: Partial<Spec> = {}) {
    if (qty <= 0) return;
    this.specs.push({ key, section, item: `${itemName} — ${this.room}`, qty, pricing: { kind: "material", category }, ...extra });
  }
  fabricated(key: string, section: string, qty: number, dims: string, accessories?: string, itemName?: string) {
    this.rc(key, section, qty, { dimensions: dims, primary: this.board(), finish: this.finishText(), hardware: this.hw(), accessories: accessories ?? null }, itemName);
  }
  lights(nos: number, label = "LED downlights") {
    this.mat("DOWNLIGHT", "Electrical", "LIGHTING", nos, label);
    this.rc("LIGHT_INSTALL", "Electrical", nos);
  }
  painting(sqft: number) {
    const paint = materialLabel(pickMaterial("PAINT", this.tier, this.ctx));
    this.rc("PAINTING", "Painting", roundQty(sqft), { primary: paint ?? "Premium emulsion", dimensions: "Walls (openings deducted 15%)" });
  }
  ceiling(sqft: number, cove: number) {
    const fc = materialLabel(pickMaterial("FALSE_CEILING", this.tier, this.ctx));
    this.rc("FALSE_CEILING", "False Ceiling", roundQty(sqft), { primary: fc ?? "Gypsum board 12.5mm with GI framing", dimensions: "Ceiling area" });
    if (cove > 0) this.rc("PROFILE_LIGHT", "Electrical", roundQty(cove), { dimensions: "Cove / profile run" }, "Cove profile lighting");
  }
  floor(sqft: number, category: MaterialCategoryKey = "FLOORING", label = "Flooring") {
    this.mat("FLOOR_MATERIAL", "Flooring", category, roundQty(sqft), `${label} — supply`);
    this.rc(category === "FLOORING" ? "FLOORING_LAYING" : "TILE_LAYING", "Flooring", roundQty(sqft), {}, `${label} — installation`);
  }
}

function roomSpecs(room: RoomInput, d: Dims, tier: PriceTierKey, ctx: MaterialContext): Spec[] {
  const { lengthFt: L, widthFt: W, heightFt: H } = d;
  const floorArea = L * W;
  const perim = 2 * (L + W);
  const wallArea = perim * H * 0.85;
  const sec = roomSection(room.type);
  const b = new Builder(room.name, tier, ctx);
  const flooringCategory: MaterialCategoryKey = ctx.selected?.MARBLE ? "MARBLE" : ctx.selected?.TILES ? "TILES" : "FLOORING";

  switch (room.type) {
    case "ENTRANCE": {
      const w = r1(clamp(W * 0.6, 3, 5));
      b.fabricated("SHOE_RACK", sec, roundQty(w * 3.5), `${fmtFt(w)} W × 3.5' H`, "Shoe shelves, cushioned seat top");
      const pw = r1(clamp(L * 0.7, 4, 8));
      const ph = r1(Math.min(H - 1, 8));
      b.fabricated("FOYER_PANELING", sec, roundQty(pw * ph), `${fmtFt(pw)} W × ${fmtFt(ph)} H`);
      b.lights(Math.ceil(floorArea / 25) + 1);
      b.painting(wallArea);
      break;
    }
    case "LIVING_ROOM": {
      const tw = r1(clamp(W * 0.6, 6, 10));
      b.fabricated("TV_UNIT", sec, roundQty(tw * 7), `${fmtFt(tw)} W × 7' H`, "Concealed wiring channel, display niches");
      const ph = r1(H - 1);
      b.fabricated("WALL_PANELING", sec, roundQty((tw + 2) * ph), `${fmtFt(tw + 2)} W × ${fmtFt(ph)} H`, undefined, "TV back wall paneling");
      b.rc("SOFA", sec, 1, { primary: materialLabel(pickMaterial("UPHOLSTERY", tier, ctx)) ?? "Fabric upholstery" });
      b.rc("COFFEE_TABLE", sec, 1);
      b.rc("CURTAINS", sec, r1(clamp(L * 0.5, 6, 14)));
      b.ceiling(floorArea, perim * 0.8);
      b.lights(Math.ceil(floorArea / 25));
      b.rc("ELECTRICAL_POINT", "Electrical", Math.ceil(floorArea / 30) + 4);
      b.painting(wallArea);
      if (room.includeFlooring) b.floor(floorArea, flooringCategory);
      break;
    }
    case "TV_UNIT": {
      b.fabricated("TV_UNIT", sec, roundQty(L * H), `${fmtFt(L)} W × ${fmtFt(H)} H`, "Concealed wiring channel, display niches");
      const bw = L + 2;
      const bh = Math.min(H + 2, 9);
      b.fabricated("WALL_PANELING", sec, roundQty(bw * bh), `${fmtFt(bw)} W × ${fmtFt(bh)} H`, undefined, "Back paneling");
      b.rc("CONCEALED_WIRING", "Electrical", 1);
      b.rc("PROFILE_LIGHT", "Electrical", r1(L), {}, "Profile lighting");
      break;
    }
    case "MASTER_BEDROOM":
    case "GUEST_BEDROOM": {
      const master = room.type === "MASTER_BEDROOM";
      const ww = r1(master ? clamp(L * 0.5, 5, 10) : clamp(L * 0.4, 4, 7));
      b.fabricated("WARDROBE", "Wardrobes", roundQty(ww * 7), `${fmtFt(ww)} W × 7' H`, "Hanging rods, internal drawers, mirror", "Wardrobe");
      const shutters = Math.ceil(ww / 1.5);
      if (H >= 9.5) b.fabricated("WARDROBE_LOFT", "Wardrobes", roundQty(ww * 2), `${fmtFt(ww)} W × 2' H`, undefined, "Wardrobe loft");
      b.mat("HINGES", "Wardrobes", "HINGES", shutters * (H >= 9.5 ? 4 : 3), "Hinges");
      b.mat("HANDLES", "Wardrobes", "HANDLES", shutters, "Handles");
      b.mat("CHANNELS", "Wardrobes", "CHANNELS", 2, "Drawer channels");
      b.rc("BED_STORAGE", sec, 1, { primary: b.board(), finish: b.finishText(), hardware: "Hydraulic lift-up mechanism" });
      b.rc("SIDE_TABLE", sec, master ? 2 : 1);
      if (master) b.rc("DRESSER", sec, 1);
      const hw = r1(clamp(W * 0.8, 6, 11));
      b.fabricated("HEADBOARD_PANEL", sec, roundQty(hw * 4.5), `${fmtFt(hw)} W × 4.5' H`);
      b.rc("CURTAINS", sec, r1(clamp(L * 0.5, 5, 12)));
      b.ceiling(floorArea, perim * 0.6);
      b.lights(Math.ceil(floorArea / 30));
      b.rc("ELECTRICAL_POINT", "Electrical", Math.ceil(floorArea / 30) + 3);
      b.painting(wallArea);
      if (room.includeFlooring) b.floor(floorArea, flooringCategory);
      break;
    }
    case "KIDS_BEDROOM": {
      const ww = r1(clamp(L * 0.4, 4, 7));
      b.fabricated("WARDROBE", "Wardrobes", roundQty(ww * 7), `${fmtFt(ww)} W × 7' H`, "Child-safe rounded edges", "Wardrobe");
      const shutters = Math.ceil(ww / 1.5);
      b.mat("HINGES", "Wardrobes", "HINGES", shutters * 3, "Hinges");
      b.mat("HANDLES", "Wardrobes", "HANDLES", shutters, "Handles");
      b.rc("KIDS_BED", sec, 1, { primary: b.board(), finish: b.finishText() });
      b.rc("STUDY_TABLE", sec, 1, { primary: b.board(), finish: b.finishText() });
      b.fabricated("BOOKSHELF", sec, 12, "3' W × 4' H");
      const rolls = Math.ceil((W * H) / 50);
      b.mat("WALLPAPER", sec, "WALLPAPER", rolls, "Feature wall wallpaper", { dimensions: `${fmtFt(W)} × ${fmtFt(H)} wall` });
      b.rc("WALLPAPER_INSTALL", sec, rolls);
      b.ceiling(floorArea, perim * 0.5);
      b.lights(Math.ceil(floorArea / 30));
      b.rc("ELECTRICAL_POINT", "Electrical", Math.ceil(floorArea / 30) + 3);
      b.painting(wallArea - W * H);
      if (room.includeFlooring) b.floor(floorArea, flooringCategory);
      break;
    }
    case "KITCHEN": {
      const base = r1(clamp(L + W - 2, 6, 24));
      const wall = r1(base * 0.8);
      b.fabricated("KITCHEN_BASE", sec, base, `${fmtFt(base)} run × 2.8' H × 2' D`, "Cutlery & plate organisers in drawers");
      b.fabricated("KITCHEN_WALL", sec, wall, `${fmtFt(wall)} run × 2.5' H × 1.2' D`);
      if (floorArea >= 70) b.fabricated("KITCHEN_TALL", sec, 1, "2' W × 7' H", "Pull-out pantry");
      b.rc("KITCHEN_ACCESSORIES", sec, 1);
      const counter = roundQty(base * 2.1);
      b.mat("QUARTZ", sec, "QUARTZ", counter, "Countertop", { dimensions: `${fmtFt(base)} × 2.1' deep` });
      b.rc("COUNTERTOP_FABRICATION", sec, counter);
      const splash = roundQty(base * 2);
      b.mat("BACKSPLASH", sec, "TILES", splash, "Backsplash tiles", { dimensions: `${fmtFt(base)} × 2' H` });
      b.rc("TILE_LAYING", sec, splash, {}, "Backsplash tile laying");
      const baseShutters = Math.ceil(base / 2.5);
      const wallShutters = Math.ceil(wall / 1.5);
      const drawers = Math.ceil(base / 2);
      b.mat("CHANNELS", sec, "CHANNELS", drawers, "Drawer channels");
      b.mat("HINGES", sec, "HINGES", (baseShutters + wallShutters) * 2, "Hinges");
      b.mat("HANDLES", sec, "HANDLES", baseShutters + wallShutters + drawers, "Handles");
      b.rc("PROFILE_LIGHT", "Electrical", wall, {}, "Under-cabinet profile lighting");
      b.ceiling(floorArea, 0);
      b.lights(Math.ceil(floorArea / 30) + 1);
      b.rc("ELECTRICAL_POINT", "Electrical", 8);
      b.painting(wallArea * 0.4);
      if (room.includeFlooring) b.floor(floorArea, "TILES", "Floor tiles");
      break;
    }
    case "DINING_ROOM": {
      const cw = r1(clamp(L * 0.4, 4, 7));
      b.fabricated("CROCKERY_UNIT", sec, roundQty(cw * 7), `${fmtFt(cw)} W × 7' H`, "Fluted glass shutters, display lighting");
      b.rc("DINING_SET", sec, 1, { primary: materialLabel(pickMaterial("UPHOLSTERY", tier, ctx)) ?? "Solid wood with upholstered chairs" });
      b.rc("PENDANT_LIGHT", "Electrical", floorArea < 80 ? 2 : 3);
      const pw = r1(clamp(W * 0.6, 5, 9));
      b.fabricated("WALL_PANELING", sec, roundQty(pw * (H - 1)), `${fmtFt(pw)} W × ${fmtFt(H - 1)} H`, undefined, "Accent wall paneling");
      b.ceiling(floorArea, perim * 0.5);
      b.rc("ELECTRICAL_POINT", "Electrical", Math.ceil(floorArea / 40) + 2);
      b.painting(wallArea);
      if (room.includeFlooring) b.floor(floorArea, flooringCategory);
      break;
    }
    case "BATHROOM": {
      b.rc("VANITY", sec, 1, { primary: materialLabel(pickMaterial("QUARTZ", tier, ctx)) ?? "Quartz top, BWP carcass", hardware: "Soft-close hinges" });
      b.rc("LED_MIRROR", sec, 1);
      const wallTiles = roundQty(perim * Math.min(H, 8) * 0.9);
      b.mat("WALL_TILES", sec, "TILES", wallTiles, "Wall tiles", { dimensions: `${fmtFt(perim)} perimeter × ${fmtFt(Math.min(H, 8))} H` });
      b.rc("TILE_LAYING", sec, wallTiles, {}, "Wall tile laying");
      b.mat("FLOOR_TILES", sec, "TILES", roundQty(floorArea), "Anti-skid floor tiles", { dimensions: `${fmtFt(L)} × ${fmtFt(W)}` });
      b.rc("TILE_LAYING", sec, roundQty(floorArea), {}, "Floor tile laying");
      if (floorArea >= 30) {
        b.mat("SHOWER_GLASS", sec, "GLASS", 19.5, "Shower glass partition", { dimensions: "3' W × 6.5' H" });
        b.rc("GLASS_INSTALL", sec, 19.5, {}, "Shower partition fixing");
      }
      b.rc("BATH_ACCESSORIES", sec, 1);
      b.rc("FALSE_CEILING", "False Ceiling", roundQty(floorArea), { primary: "Moisture-resistant grid / PVC ceiling" }, "Bathroom ceiling");
      b.lights(2);
      b.rc("ELECTRICAL_POINT", "Electrical", 3);
      break;
    }
    case "WARDROBE": {
      const mainH = Math.min(H, 7.5);
      const loftH = Math.max(H - 7.5, 0);
      b.fabricated("WARDROBE", sec, roundQty(L * mainH), `${fmtFt(L)} W × ${fmtFt(mainH)} H × ${fmtFt(W)} D`, "Hanging rods, internal drawers", "Wardrobe");
      if (loftH > 0) b.fabricated("WARDROBE_LOFT", sec, roundQty(L * loftH), `${fmtFt(L)} W × ${fmtFt(loftH)} H`, undefined, "Wardrobe loft");
      const shutters = Math.ceil(L / 1.5);
      b.mat("HINGES", sec, "HINGES", shutters * (loftH > 0 ? 4 : 3), "Hinges");
      b.mat("HANDLES", sec, "HANDLES", shutters, "Handles");
      b.mat("CHANNELS", sec, "CHANNELS", 3, "Drawer channels");
      b.rc("PROFILE_LIGHT", "Electrical", r1(L), {}, "Internal wardrobe lighting");
      break;
    }
    case "FALSE_CEILING": {
      b.ceiling(floorArea, perim);
      b.lights(Math.ceil(floorArea / 25));
      break;
    }
    case "BALCONY": {
      b.floor(floorArea, ctx.selected?.TILES ? "TILES" : "FLOORING", "Deck / outdoor flooring");
      b.rc("PLANTER", sec, 2);
      const cl = roundQty(L * H * 0.5);
      b.rc("WALL_CLADDING", sec, cl, { dimensions: `${fmtFt(L)} × ${fmtFt(H * 0.5)}` });
      b.rc("BALCONY_SEATING", sec, 1);
      b.lights(2, "Outdoor wall lights");
      break;
    }
    case "OFFICE": {
      const ws = Math.max(2, Math.floor(floorArea / 60));
      b.rc("WORKSTATION", sec, ws, { primary: b.board(), finish: b.finishText(), hardware: "Modesty panel, cable manager, pedestal drawers" });
      const glass = roundQty(W * Math.min(H, 9));
      b.mat("GLASS_PARTITION", sec, "GLASS", glass, "Glass cabin partition", { dimensions: `${fmtFt(W)} × ${fmtFt(Math.min(H, 9))}` });
      b.rc("GLASS_INSTALL", sec, glass, {}, "Glass partition installation");
      const st = r1(clamp(L * 0.4, 6, 16));
      b.fabricated("OFFICE_STORAGE", sec, roundQty(st * 3), `${fmtFt(st)} W × 3' H`);
      b.ceiling(floorArea, 0);
      b.lights(Math.ceil(floorArea / 40), "LED panel lights");
      b.rc("ELECTRICAL_POINT", "Electrical", ws * 3 + 6, {}, "Electrical & data point");
      b.floor(floorArea, ctx.selected?.TILES ? "TILES" : "FLOORING", "Office flooring");
      b.painting(wallArea);
      break;
    }
    case "COMMERCIAL": {
      b.rc("RECEPTION_COUNTER", sec, 1, { primary: b.board(), finish: b.finishText() });
      const dw = r1(clamp(perim * 0.4, 10, 80));
      b.fabricated("DISPLAY_UNIT", sec, roundQty(dw * 7), `${fmtFt(dw)} run × 7' H`, "Adjustable shelves, display lighting");
      b.ceiling(floorArea, perim * 0.5);
      b.lights(Math.ceil(floorArea / 30), "LED track / downlights");
      b.rc("ELECTRICAL_POINT", "Electrical", Math.ceil(floorArea / 40) + 6);
      b.floor(floorArea, ctx.selected?.MARBLE ? "MARBLE" : "TILES", "Commercial flooring");
      b.painting(wallArea);
      break;
    }
  }
  return b.specs;
}

function priceSpec(spec: Spec, tier: PriceTierKey, rateCard: RateCard, ctx: MaterialContext): GeneratedLine {
  let rate = 0;
  let unit = "nos";
  let itemType: BOQItemTypeKey = "MATERIAL";
  let materialId: string | null = null;
  let primary = spec.primary ?? null;
  let finish = spec.finish ?? null;

  if (spec.pricing.kind === "ratecard") {
    const entry = rateCard[spec.pricing.key] ?? DEFAULT_RATE_CARD[spec.pricing.key];
    rate = entry?.rates[tier] ?? 0;
    unit = entry?.unit ?? "nos";
    itemType = entry?.itemType ?? "MATERIAL";
  } else {
    const cat = spec.pricing.category;
    const fb = FALLBACK_MATERIALS[cat];
    const pick = pickMaterial(cat, tier, ctx);
    const expectedUnit = fb?.unit ?? "nos";
    if (pick && normalizeUnit(pick.unit) === expectedUnit) {
      rate = pick.rate;
      materialId = pick.id ?? null;
      primary = primary ?? materialLabel(pick);
      finish = finish ?? pick.finish ?? null;
    } else {
      rate = fb?.rates[tier] ?? 0;
      primary = primary ?? fb?.name ?? null;
    }
    unit = expectedUnit;
    itemType = "MATERIAL";
  }

  const quantity = roundQty(spec.qty);
  return {
    key: spec.key,
    section: spec.section,
    item: spec.item,
    dimensions: spec.dimensions ?? null,
    primaryMaterial: primary,
    finishBrand: finish,
    hardware: spec.hardware ?? null,
    accessories: spec.accessories ?? null,
    quantity,
    unit,
    rate,
    amount: lineAmount(quantity, rate),
    itemType,
    materialId,
    isEstimated: true,
  };
}

export function generateRoomLines(room: RoomInput, tier: PriceTierKey, rateCard: RateCard = DEFAULT_RATE_CARD, ctx: MaterialContext = {}): GeneratedLine[] {
  const dims = resolveDims(room);
  return roomSpecs(room, dims, tier, ctx).map((s) => priceSpec(s, tier, rateCard, ctx));
}

export function generateProjectExtras(totalFloorAreaSqft: number, tier: PriceTierKey, rateCard: RateCard = DEFAULT_RATE_CARD): GeneratedLine[] {
  const specs: Spec[] = [];
  if (totalFloorAreaSqft > 0) {
    specs.push({ key: "SITE_PROTECTION", section: "Miscellaneous", item: "Site protection & final cleaning", qty: roundQty(totalFloorAreaSqft), pricing: { kind: "ratecard", key: "SITE_PROTECTION" } });
  }
  specs.push({ key: "DEBRIS_REMOVAL", section: "Miscellaneous", item: "Debris removal", qty: 1, pricing: { kind: "ratecard", key: "DEBRIS_REMOVAL" } });
  return specs.map((s) => priceSpec(s, tier, rateCard, {}));
}

export function floorAreaOf(room: RoomInput) {
  if (["WARDROBE", "TV_UNIT"].includes(room.type)) return 0;
  const d = resolveDims(room);
  return d.lengthFt * d.widthFt;
}

export const DEFAULT_CHARGES: BOQCharges = {
  gstRate: 18,
  wastagePercent: 5,
  profitMarginPercent: 15,
  transportCharges: 0,
  installationCharges: 0,
  discountAmount: 0,
};

export type Estimate = { lines: GeneratedLine[]; totals: BOQTotals };

/** Full estimate for a set of rooms (used by cost calculator and design budgets). */
export function estimateRooms(
  rooms: RoomInput[],
  tier: PriceTierKey,
  opts: { rateCard?: RateCard; ctx?: MaterialContext; charges?: Partial<BOQCharges>; includeExtras?: boolean } = {},
): Estimate {
  const rateCard = opts.rateCard ?? DEFAULT_RATE_CARD;
  const lines = rooms.flatMap((r) => generateRoomLines(r, tier, rateCard, opts.ctx ?? {}));
  if (opts.includeExtras !== false) {
    const area = rooms.reduce((s, r) => s + floorAreaOf(r), 0);
    lines.push(...generateProjectExtras(area, tier, rateCard));
  }
  const totals = computeBOQTotals(lines, { ...DEFAULT_CHARGES, ...opts.charges }, [...BOQ_SECTIONS]);
  return { lines, totals };
}

/** Suggest a tier from budget per sqft of carpet area. */
export function tierFromBudget(budgetMax: number | null | undefined, carpetAreaSqft: number | null | undefined): PriceTierKey {
  if (!budgetMax || !carpetAreaSqft || carpetAreaSqft <= 0) return "STANDARD";
  const perSqft = budgetMax / carpetAreaSqft;
  if (perSqft < 1100) return "ECONOMY";
  if (perSqft < 1800) return "STANDARD";
  if (perSqft < 2800) return "PREMIUM";
  return "LUXURY";
}

/** Merge a stored (possibly partial / outdated) rate card over the defaults. */
export function mergeRateCard(stored: unknown): RateCard {
  const merged: RateCard = JSON.parse(JSON.stringify(DEFAULT_RATE_CARD));
  if (stored && typeof stored === "object") {
    for (const [key, val] of Object.entries(stored as Record<string, Partial<RateCardEntry>>)) {
      if (!merged[key] || !val || typeof val !== "object") continue;
      if (val.rates) {
        for (const tier of TIER_ORDER) {
          const n = Number((val.rates as Partial<TierRates>)[tier]);
          if (Number.isFinite(n) && n >= 0) merged[key].rates[tier] = n;
        }
      }
    }
  }
  return merged;
}
