import type { PropertyTypeKey, RoomTypeKey } from "@/lib/constants";

export type PresetRoom = { name: string; type: RoomTypeKey; lengthFt: number; widthFt: number; heightFt: number };

const r = (name: string, type: RoomTypeKey, l: number, w: number, h = 10): PresetRoom => ({ name, type, lengthFt: l, widthFt: w, heightFt: h });

/** Typical Pune apartment / villa / office layouts used by the cost calculator. */
export const LAYOUT_PRESETS: { key: string; label: string; propertyType: PropertyTypeKey; carpetArea: number; rooms: PresetRoom[] }[] = [
  {
    key: "1BHK",
    label: "1 BHK",
    propertyType: "APARTMENT",
    carpetArea: 450,
    rooms: [r("Living Room", "LIVING_ROOM", 14, 11), r("Master Bedroom", "MASTER_BEDROOM", 12, 11), r("Kitchen", "KITCHEN", 8, 7), r("Bathroom", "BATHROOM", 7, 5, 9)],
  },
  {
    key: "2BHK",
    label: "2 BHK",
    propertyType: "APARTMENT",
    carpetArea: 750,
    rooms: [
      r("Entrance", "ENTRANCE", 6, 4),
      r("Living Room", "LIVING_ROOM", 15, 12),
      r("Master Bedroom", "MASTER_BEDROOM", 13, 11),
      r("Bedroom 2", "GUEST_BEDROOM", 12, 10),
      r("Kitchen", "KITCHEN", 9, 8),
      r("Bathroom 1", "BATHROOM", 7, 5, 9),
      r("Bathroom 2", "BATHROOM", 7, 5, 9),
    ],
  },
  {
    key: "3BHK",
    label: "3 BHK",
    propertyType: "APARTMENT",
    carpetArea: 1100,
    rooms: [
      r("Entrance", "ENTRANCE", 6, 5),
      r("Living Room", "LIVING_ROOM", 17, 13),
      r("Dining", "DINING_ROOM", 10, 9),
      r("Master Bedroom", "MASTER_BEDROOM", 14, 12),
      r("Kids Bedroom", "KIDS_BEDROOM", 12, 10),
      r("Guest Bedroom", "GUEST_BEDROOM", 12, 11),
      r("Kitchen", "KITCHEN", 10, 8),
      r("Bathroom 1", "BATHROOM", 8, 5, 9),
      r("Bathroom 2", "BATHROOM", 7, 5, 9),
      r("Balcony", "BALCONY", 10, 4),
    ],
  },
  {
    key: "4BHK",
    label: "4 BHK / Villa",
    propertyType: "VILLA",
    carpetArea: 1900,
    rooms: [
      r("Entrance", "ENTRANCE", 8, 6, 11),
      r("Living Room", "LIVING_ROOM", 20, 15, 11),
      r("Dining", "DINING_ROOM", 12, 11, 11),
      r("Master Bedroom", "MASTER_BEDROOM", 16, 13, 11),
      r("Kids Bedroom", "KIDS_BEDROOM", 13, 11, 11),
      r("Guest Bedroom", "GUEST_BEDROOM", 13, 12, 11),
      r("Bedroom 4", "GUEST_BEDROOM", 12, 11, 11),
      r("Kitchen", "KITCHEN", 12, 10, 11),
      r("Bathroom 1", "BATHROOM", 9, 6, 9),
      r("Bathroom 2", "BATHROOM", 8, 5, 9),
      r("Bathroom 3", "BATHROOM", 8, 5, 9),
      r("Balcony", "BALCONY", 14, 5, 11),
    ],
  },
  {
    key: "OFFICE",
    label: "Office (1,500 sqft)",
    propertyType: "OFFICE",
    carpetArea: 1500,
    rooms: [r("Workspace", "OFFICE", 40, 30, 11), r("Reception", "COMMERCIAL", 12, 10, 11), r("Washroom", "BATHROOM", 8, 6, 9)],
  },
];
