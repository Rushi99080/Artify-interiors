import { z } from "zod";
import { DESIGN_STYLES, MATERIAL_CATEGORIES, PRICE_TIERS, PROPERTY_TYPES, ROOM_TYPES } from "@/lib/constants";

// Shared request schemas (server validation; also usable on the client).

const trimmed = (max = 200) => z.string().trim().max(max);
// `.optional()` on the outside so an absent key is accepted (and left undefined — "unchanged" on PATCH).
const optionalText = (max = 2000) =>
  z
    .union([z.string(), z.null()])
    .transform((v) => (typeof v === "string" ? v.trim() : ""))
    .pipe(z.string().max(max))
    .transform((v) => (v === "" ? null : v))
    .optional();
const optionalNumber = (min = 0, max = 1e9) =>
  z
    .union([z.number(), z.string(), z.null()])
    .transform((v) => (v === "" || v === null ? null : Number(v)))
    .refine((v) => v === null || (Number.isFinite(v) && v >= min && v <= max), { message: `Must be between ${min} and ${max}` })
    .optional();
const money = z.coerce.number().min(0, "Cannot be negative").max(1e10);

export const phoneSchema = z
  .string()
  .trim()
  .min(8, "Enter a valid phone number")
  .max(20)
  .regex(/^[+\d][\d\s-]{7,19}$/, "Enter a valid phone number");

export const emailSchema = z.string().trim().toLowerCase().email("Enter a valid email address").max(160);

export const registerSchema = z.object({
  name: trimmed(100).min(2, "Enter your full name"),
  email: emailSchema,
  phone: phoneSchema,
  password: z.string().min(8, "At least 8 characters").max(128),
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Enter your password").max(128),
});

export const roomSchema = z.object({
  id: z.string().optional(),
  name: optionalText(80),
  type: z.enum(ROOM_TYPES),
  lengthFt: optionalNumber(1, 500),
  widthFt: optionalNumber(1, 500),
  heightFt: optionalNumber(6, 40),
  style: z.enum(DESIGN_STYLES).nullable().optional(),
  tier: z.enum(PRICE_TIERS).nullable().optional(),
  preferences: optionalText(1000),
});

export const projectSchema = z.object({
  name: trimmed(120).min(2, "Enter a project name"),
  fullName: trimmed(100).min(2, "Enter your full name"),
  phone: phoneSchema,
  email: z.union([emailSchema, z.literal(""), z.null(), z.undefined()]).transform((v) => v || null),
  location: trimmed(160).min(2, "Enter the project location"),
  address: optionalText(300),
  propertyType: z.enum(PROPERTY_TYPES),
  carpetAreaSqft: optionalNumber(50, 1_000_000),
  numberOfRooms: optionalNumber(1, 200),
  designStyle: z.enum(DESIGN_STYLES),
  budgetMin: optionalNumber(0, 1e10),
  budgetMax: optionalNumber(0, 1e10),
  colorPalette: optionalText(300),
  materialPreferences: optionalText(1000),
  timeline: optionalText(100),
  notes: optionalText(2000),
  rooms: z.array(roomSchema).min(1, "Add at least one room").max(40),
});

export const projectUpdateSchema = projectSchema
  .omit({ fullName: true, phone: true, email: true, rooms: true })
  .partial()
  .extend({ status: z.enum(["DRAFT", "DESIGN", "QUOTATION", "ACTIVE", "ON_HOLD", "COMPLETED", "CANCELLED"]).optional() });

export const leadSchema = z.object({
  name: trimmed(100).min(2, "Enter your name"),
  phone: phoneSchema,
  email: z.union([emailSchema, z.literal(""), z.null(), z.undefined()]).transform((v) => v || null),
  city: optionalText(80),
  projectType: z.enum(PROPERTY_TYPES).nullable().optional(),
  budget: optionalText(80),
  source: z.enum(["WEBSITE", "AI_DESIGNER", "COST_CALCULATOR", "REFERRAL", "WALK_IN", "INSTAGRAM", "FACEBOOK", "GOOGLE", "OTHER"]).optional(),
  message: optionalText(2000),
  meta: z.record(z.string(), z.unknown()).optional(),
  // honeypot — must stay empty
  website: z.string().max(0).optional().or(z.literal("")),
});

export const leadUpdateSchema = z.object({
  status: z.enum(["NEW", "CONTACTED", "CONSULTATION", "QUOTATION_SENT", "CONVERTED", "LOST"]).optional(),
  followUpDate: z.union([z.string(), z.null()]).optional(),
  assignedToId: z.string().nullable().optional(),
  lostReason: optionalText(300),
  note: optionalText(2000),
});

export const materialSchema = z.object({
  name: trimmed(140).min(2, "Enter the material name"),
  category: z.enum(MATERIAL_CATEGORIES),
  brand: optionalText(80),
  productCode: optionalText(60),
  finish: optionalText(80),
  color: optionalText(60),
  unit: trimmed(20).min(1, "Enter a unit"),
  rate: money,
  imageUrl: optionalText(500),
  specifications: optionalText(2000),
  availability: z.enum(["IN_STOCK", "LIMITED", "ON_ORDER", "DISCONTINUED"]).default("IN_STOCK"),
  supplierId: z.string().nullable().optional(),
  tier: z.enum(PRICE_TIERS).default("STANDARD"),
  durability: z.coerce.number().int().min(1).max(5).default(3),
  maintenance: z.coerce.number().int().min(1).max(5).default(3),
  styles: z.array(z.enum(DESIGN_STYLES)).default([]),
  isActive: z.boolean().default(true),
});

export const supplierSchema = z.object({
  name: trimmed(140).min(2, "Enter the supplier name"),
  contactPerson: optionalText(100),
  phone: optionalText(30),
  email: optionalText(160),
  address: optionalText(300),
  gstin: optionalText(20),
  categories: z.array(z.string()).default([]),
  notes: optionalText(1000),
  isActive: z.boolean().default(true),
});

export const boqItemSchema = z.object({
  section: trimmed(60).min(1, "Section is required"),
  item: trimmed(200).min(1, "Item is required"),
  dimensions: optionalText(120),
  primaryMaterial: optionalText(160),
  finishBrand: optionalText(160),
  hardware: optionalText(200),
  accessories: optionalText(200),
  quantity: z.coerce.number().min(0, "Quantity cannot be negative").max(1e7),
  unit: trimmed(20).min(1),
  rate: money,
  itemType: z.enum(["MATERIAL", "LABOUR", "SERVICE"]).default("MATERIAL"),
  materialId: z.string().nullable().optional(),
  notes: optionalText(500),
});

export const boqSettingsSchema = z.object({
  title: trimmed(160).optional(),
  gstRate: z.coerce.number().min(0).max(28).optional(),
  wastagePercent: z.coerce.number().min(0).max(50).optional(),
  profitMarginPercent: z.coerce.number().min(0).max(200).optional(),
  transportCharges: money.optional(),
  installationCharges: money.optional(),
  discountAmount: money.optional(),
  notes: optionalText(2000),
  status: z.enum(["PRELIMINARY", "VERIFIED", "FINAL"]).optional(),
});

export const paymentSchema = z.object({
  amount: z.coerce.number().positive("Enter an amount").max(1e10),
  method: z.enum(["CASH", "UPI", "BANK_TRANSFER", "CHEQUE", "CARD"]),
  reference: optionalText(120),
  paidAt: z.string().optional(),
  notes: optionalText(500),
  paymentMilestoneId: z.string().nullable().optional(),
});

export const expenseSchema = z.object({
  category: z.enum(["MATERIAL", "LABOUR", "TRANSPORT", "SUBCONTRACT", "OTHER"]),
  description: trimmed(200).min(2),
  amount: z.coerce.number().positive().max(1e10),
  paidTo: optionalText(120),
  supplierId: z.string().nullable().optional(),
  spentAt: z.string().optional(),
});

export const teamMemberSchema = z.object({
  name: trimmed(100).min(2),
  designation: trimmed(80).min(2),
  department: optionalText(80),
  phone: optionalText(30),
  email: z.union([emailSchema, z.literal(""), z.null(), z.undefined()]).transform((v) => v || null),
  isActive: z.boolean().default(true),
  /** create a login for this member */
  createLogin: z.boolean().optional(),
  loginRole: z.enum(["STAFF", "ADMIN"]).optional(),
  password: z.string().min(8).max(128).optional(),
});

export const messageSchema = z.object({ body: trimmed(4000).min(1, "Write a message") });

export const customerSchema = z.object({
  fullName: z.string().trim().min(2).max(100),
  phone: phoneSchema,
  email: z.union([emailSchema, z.literal(""), z.null()]).optional().transform((v) => v || null),
  address: z.string().trim().max(300).nullable().optional(),
  city: z.string().trim().max(80).nullable().optional(),
  notes: z.string().trim().max(2000).nullable().optional(),
});


export const portfolioSchema = z.object({
  title: z.string().trim().min(2).max(120),
  slug: z.string().trim().max(120).optional(),
  roomType: z.enum(ROOM_TYPES).nullable().optional(),
  style: z.enum(DESIGN_STYLES).nullable().optional(),
  location: z.string().trim().max(120).nullable().optional(),
  areaSqft: z.coerce.number().min(0).max(1_000_000).nullable().optional(),
  description: z.string().trim().min(10).max(4000),
  coverImageUrl: z.string().trim().min(1).max(500),
  images: z.array(z.string().max(500)).max(24).default([]),
  isPublished: z.boolean().default(true),
  isFeatured: z.boolean().default(false),
  isSample: z.boolean().default(false),
  sortOrder: z.coerce.number().int().default(0),
});


export const testimonialSchema = z.object({
  name: z.string().trim().min(2).max(100),
  location: z.string().trim().max(100).nullable().optional(),
  projectType: z.string().trim().max(100).nullable().optional(),
  quote: z.string().trim().min(10).max(1200),
  rating: z.coerce.number().int().min(1).max(5).default(5),
  isPublished: z.boolean().default(true),
  isSample: z.boolean().default(false),
  sortOrder: z.coerce.number().int().default(0),
});
