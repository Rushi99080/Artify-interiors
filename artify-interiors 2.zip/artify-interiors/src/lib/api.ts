import "server-only";
import { NextResponse, type NextRequest } from "next/server";
import { ZodError, type ZodType } from "zod";
import { getCurrentUser, type CurrentUser } from "@/lib/auth/session";
import { can, type Permission } from "@/lib/auth/permissions";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { logError } from "@/lib/logger";

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

export const badRequest = (msg: string, details?: unknown) => new ApiError(400, msg, "BAD_REQUEST", details);
export const unauthorized = (msg = "Please sign in to continue.") => new ApiError(401, msg, "UNAUTHORIZED");
export const forbidden = (msg = "You do not have access to this resource.") => new ApiError(403, msg, "FORBIDDEN");
export const notFound = (msg = "Not found.") => new ApiError(404, msg, "NOT_FOUND");
export const conflict = (msg: string) => new ApiError(409, msg, "CONFLICT");
export const notConfigured = (msg: string, details?: unknown) => new ApiError(503, msg, "NOT_CONFIGURED", details);

type AuthMode = "public" | "user" | Permission;

type RouteOptions = {
  auth?: AuthMode;
  /** e.g. { key: "login", limit: 10, windowSec: 60 } — keyed by client IP (and user when signed in) */
  rateLimit?: { key: string; limit: number; windowSec: number };
  /** Skip same-origin check (only for server-to-server webhooks with their own signature checks). */
  allowCrossOrigin?: boolean;
  /** Do not rate-limit signed-in team members (e.g. staff entering walk-in leads). */
  skipRateLimitForTeam?: boolean;
};

type Handler<P, U> = (req: NextRequest, ctx: { params: P; user: U; ip: string }) => Promise<unknown>;

type UserFor<A extends AuthMode | undefined> = A extends "public" | undefined ? CurrentUser | null : CurrentUser;

/**
 * Wraps a route handler with: same-origin (CSRF) protection, rate limiting, authentication / RBAC,
 * consistent JSON responses and error handling.
 */
export function route<P = Record<string, string>, A extends AuthMode | undefined = undefined>(
  handler: Handler<P, UserFor<A>>,
  opts: RouteOptions & { auth?: A } = {},
) {
  return async (req: NextRequest, context: { params: Promise<P> }) => {
    const ip = clientIp(req.headers);
    try {
      if (!opts.allowCrossOrigin && !["GET", "HEAD", "OPTIONS"].includes(req.method)) {
        const origin = req.headers.get("origin");
        const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
        if (origin && host && new URL(origin).host !== host) {
          throw forbidden("Cross-origin request blocked.");
        }
      }

      const user = await getCurrentUser();

      if (opts.rateLimit && !(opts.skipRateLimitForTeam && (user?.role === "ADMIN" || user?.role === "STAFF"))) {
        const rl = await rateLimit(`${opts.rateLimit.key}:${user?.id ?? ip}`, opts.rateLimit.limit, opts.rateLimit.windowSec);
        if (!rl.ok) {
          return NextResponse.json(
            { error: `Too many requests. Please try again in ${rl.resetInSeconds} seconds.`, code: "RATE_LIMITED" },
            { status: 429, headers: { "Retry-After": String(rl.resetInSeconds) } },
          );
        }
      }

      const mode = opts.auth ?? "public";
      if (mode !== "public") {
        if (!user) throw unauthorized();
        if (mode !== "user" && !can(user.role, mode)) throw forbidden();
      }

      const params = (context?.params ? await context.params : {}) as P;
      const result = await handler(req, { params, user: user as UserFor<A>, ip });
      if (result instanceof Response) return result;
      return NextResponse.json(result ?? { ok: true });
    } catch (err) {
      return errorResponse(err, req);
    }
  };
}

export function errorResponse(err: unknown, req?: NextRequest) {
  if (err instanceof ApiError) {
    return NextResponse.json({ error: err.message, code: err.code, details: err.details }, { status: err.status });
  }
  if (err instanceof ZodError) {
    return NextResponse.json({ error: "Please check the highlighted fields.", code: "VALIDATION", details: zodFieldErrors(err) }, { status: 400 });
  }
  const e = err as { code?: string; message?: string };
  if (e?.code === "P2025") return NextResponse.json({ error: "Record not found.", code: "NOT_FOUND" }, { status: 404 });
  if (e?.code === "P2002") return NextResponse.json({ error: "A record with these details already exists.", code: "CONFLICT" }, { status: 409 });
  logError("api", err, { path: req?.nextUrl.pathname, method: req?.method });
  return NextResponse.json({ error: "Something went wrong. Please try again.", code: "INTERNAL" }, { status: 500 });
}

export function zodFieldErrors(err: ZodError) {
  const out: Record<string, string> = {};
  for (const issue of err.issues) {
    const key = issue.path.join(".") || "_";
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

export async function parseJson<T>(req: NextRequest, schema: ZodType<T>): Promise<T> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw badRequest("Invalid JSON body.");
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    throw new ApiError(400, "Please check the highlighted fields.", "VALIDATION", zodFieldErrors(parsed.error));
  }
  return parsed.data;
}

export function parseQuery<T>(req: NextRequest, schema: ZodType<T>): T {
  const obj = Object.fromEntries(req.nextUrl.searchParams.entries());
  const parsed = schema.safeParse(obj);
  if (!parsed.success) throw new ApiError(400, "Invalid query parameters.", "VALIDATION", zodFieldErrors(parsed.error));
  return parsed.data;
}
