import "server-only";
import { PROPERTY_TYPE_LABELS, ROOM_LABELS, STYLE_INFO, TIER_LABELS, MATERIAL_CATEGORY_LABELS, DESIGN_STYLES, PRICE_TIERS, type DesignStyleKey, type PriceTierKey, type RoomTypeKey, type MaterialCategoryKey } from "@/lib/constants";
import { formatINR } from "@/lib/format";
import type { Recommendation } from "@/lib/materials/recommend";

export const DESIGN_SYSTEM_PROMPT = `You are the principal interior architect at ARTIFY INTERIORS, a luxury interior design studio in Pune, India.
You design for Indian homes, offices and commercial spaces: generous practical storage, Indian cooking and climate, locally available materials and finishes, and sensible Vastu-friendly placement where it does not compromise the design.
Your concepts are specific and buildable: name real material types, finishes, dimensions and placements rather than vague adjectives.
You respond with a single valid JSON object only — no markdown, no commentary.`;

export type PromptContext = {
  project: {
    propertyType: string;
    carpetAreaSqft: number | null;
    location: string;
    budgetText: string;
    colorPalette: string | null;
    materialPreferences: string | null;
    timeline: string | null;
  };
  room: { name: string; type: RoomTypeKey; lengthFt: number; widthFt: number; heightFt: number; preferences: string | null };
  style: DesignStyleKey;
  tier: PriceTierKey;
  variations: number;
  photoNotes: string[];
  instructions?: string | null;
  shortlist: Partial<Record<MaterialCategoryKey, Recommendation[]>>;
};

function shortlistText(shortlist: PromptContext["shortlist"]) {
  const lines: string[] = [];
  for (const [cat, recs] of Object.entries(shortlist)) {
    for (const r of recs ?? []) {
      const m = r.material;
      lines.push(
        `[${m.id}] ${MATERIAL_CATEGORY_LABELS[cat as MaterialCategoryKey] ?? cat} · ${[m.brand, m.name].filter(Boolean).join(" ")}${m.finish ? ` · ${m.finish}` : ""}${m.color ? ` · ${m.color}` : ""} · ${formatINR(m.rate)}/${m.unit} · ${m.tier}`,
      );
    }
  }
  return lines.length ? lines.join("\n") : "(library is empty — suggest generic materials with materialId null)";
}

const JSON_SHAPE = `{
  "roomAnalysis": {
    "detectedRoomType": "string",
    "observations": "2-4 sentences about the existing space from the photos (or 'No photos provided')",
    "existingFeatures": ["windows, doors, beams, existing flooring..."],
    "lightingConditions": "string",
    "constraints": ["string"]
  },
  "concepts": [
    {
      "name": "Evocative 2-4 word concept name",
      "style": "one of ${DESIGN_STYLES.join(" | ")}",
      "tier": "one of ${PRICE_TIERS.join(" | ")}",
      "summary": "Two sentences describing the idea and mood",
      "colorPalette": [{ "name": "Warm Linen", "hex": "#EDE6DA" }],
      "materials": [{ "category": "LAMINATE", "materialId": "id from the shortlist or null", "name": "material name", "application": "where it is used" }],
      "furniture": [{ "item": "Queen bed with upholstered headboard", "description": "size, finish", "placement": "where in the room" }],
      "furnitureLayout": "How the room is zoned and furniture arranged (3-4 sentences)",
      "wallFinish": "string",
      "ceilingDesign": "string",
      "lighting": "Layered lighting plan: ambient, task, accent",
      "flooring": "string",
      "decor": ["string"],
      "imagePrompt": "Max 110 words describing the finished room for a photorealistic render"
    }
  ]
}`;

export function buildConceptPrompt(ctx: PromptContext) {
  const r = ctx.room;
  const area = Math.round(r.lengthFt * r.widthFt);
  const hasPhotos = ctx.photoNotes.length > 0;
  return `PROJECT
- Property: ${PROPERTY_TYPE_LABELS[ctx.project.propertyType as keyof typeof PROPERTY_TYPE_LABELS] ?? ctx.project.propertyType}${ctx.project.carpetAreaSqft ? `, ${ctx.project.carpetAreaSqft} sqft carpet area` : ""}, ${ctx.project.location}
- Overall budget: ${ctx.project.budgetText}
- Target finish level for this room: ${TIER_LABELS[ctx.tier]} (${ctx.tier})
- Preferred style: ${STYLE_INFO[ctx.style].label} — ${STYLE_INFO[ctx.style].description}
- Preferred colour palette: ${ctx.project.colorPalette || "open to suggestions"}
- Material preferences: ${ctx.project.materialPreferences || "none stated"}
- Timeline: ${ctx.project.timeline || "not specified"}

ROOM
- ${r.name} (${ROOM_LABELS[r.type]})
- Dimensions: ${r.lengthFt} ft × ${r.widthFt} ft, ceiling ${r.heightFt} ft (≈${area} sqft)
- Customer notes: ${r.preferences || "none"}
${ctx.instructions ? `- Additional instructions: ${ctx.instructions}\n` : ""}
ATTACHED IMAGES
${hasPhotos ? ctx.photoNotes.map((n, i) => `${i + 1}. ${n}`).join("\n") : "None — design from the dimensions and preferences."}

MATERIAL LIBRARY SHORTLIST (prefer these; copy the exact id in square brackets into materialId; use null for anything not in the list)
${shortlistText(ctx.shortlist)}

TASK
1. ${hasPhotos ? "Study the attached images: identify the room, openings (windows/doors), natural light, existing finishes and any constraints." : "Infer sensible openings and constraints for this room type."}
2. Create exactly ${ctx.variations} distinctly different design concepts for this room. Vary the layout idea, colour palette and material approach while staying true to the preferred style and within the budget level. Make one concept a value-engineered option.
3. Each concept needs 4-5 palette colours, 4-8 materials, 4-8 furniture pieces with placement, and specific wall, ceiling, lighting and flooring treatments.
4. Write an imagePrompt for a photorealistic visualization${hasPhotos ? " that redesigns the attached room photo while keeping its architecture and camera angle" : ""}.

Return JSON exactly in this shape:
${JSON_SHAPE}`;
}

export function buildRevisionPrompt(ctx: PromptContext, previous: unknown, changeRequest: string) {
  return `${buildConceptPrompt({ ...ctx, variations: 1 })}

REVISION
This is a revision of an existing concept. Keep what works and apply the requested changes precisely.
Previous concept:
${JSON.stringify(previous, null, 2)}

Requested changes: ${changeRequest || "Explore a fresh variation with the same brief."}

Return the same JSON shape with exactly one concept.`;
}

export function buildImagePrompt(opts: {
  concept: { name: string; imagePrompt: string | null; colorPalette: { name: string; hex: string }[]; materials: { name: string; application?: string }[]; lighting?: string | null; flooring?: string | null };
  roomLabel: string;
  dims: { lengthFt: number; widthFt: number; heightFt: number };
  propertyType: string;
  hasReference: boolean;
}) {
  const palette = opts.concept.colorPalette.map((c) => c.name).join(", ");
  const materials = opts.concept.materials
    .slice(0, 6)
    .map((m) => (m.application ? `${m.name} (${m.application})` : m.name))
    .join("; ");
  const base = opts.hasReference
    ? `Redesign the room in this photograph as a finished, professionally styled ${opts.roomLabel.toLowerCase()}. Keep the exact same camera angle, room geometry, walls, windows, doors and ceiling height.`
    : `Photorealistic interior design visualization of a ${opts.roomLabel.toLowerCase()} (${opts.dims.lengthFt} × ${opts.dims.widthFt} ft, ${opts.dims.heightFt} ft ceiling) in an Indian ${opts.propertyType.toLowerCase()}, eye-level wide-angle view.`;
  return [
    base,
    opts.concept.imagePrompt ?? "",
    palette ? `Colour palette: ${palette}.` : "",
    materials ? `Materials: ${materials}.` : "",
    opts.concept.flooring ? `Flooring: ${opts.concept.flooring}.` : "",
    opts.concept.lighting ? `Lighting: ${opts.concept.lighting}.` : "",
    "Architectural interior photography, natural daylight with warm accent lighting, realistic materials and proportions, sharp detail, no people, no text, no watermark.",
  ]
    .filter(Boolean)
    .join(" ")
    .slice(0, 3800);
}
