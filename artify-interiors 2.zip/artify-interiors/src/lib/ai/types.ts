// Provider-independent AI contracts. Add a new provider by implementing one of these interfaces
// in src/lib/ai/providers/ and registering it in src/lib/ai/index.ts.

export type AIImageInput = { mimeType: string; base64: string };

export interface TextProvider {
  readonly name: string;
  readonly model: string;
  /** Returns the raw model text, which must contain a JSON object. */
  generateJSON(opts: { system: string; prompt: string; images?: AIImageInput[]; maxTokens?: number }): Promise<string>;
}

export interface ImageProvider {
  readonly name: string;
  readonly model: string;
  /** true when the provider can redesign an uploaded room photo (image-to-image). */
  readonly supportsEditing: boolean;
  generate(opts: { prompt: string; referenceImage?: AIImageInput }): Promise<{ data: Buffer; mimeType: string }>;
}

export class AINotConfiguredError extends Error {
  constructor(
    public kind: "text" | "image",
    message: string,
  ) {
    super(message);
  }
}

export class AIProviderError extends Error {
  constructor(
    public provider: string,
    message: string,
    public status?: number,
  ) {
    super(message);
  }
}

/** Reads an error message out of a provider's JSON error body. */
export async function providerErrorMessage(res: Response): Promise<string> {
  const text = await res.text().catch(() => "");
  try {
    const j = JSON.parse(text);
    return j?.error?.message ?? j?.error ?? j?.detail ?? j?.message ?? text.slice(0, 300);
  } catch {
    return text.slice(0, 300) || res.statusText;
  }
}

export async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs: number) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal, cache: "no-store" });
  } catch (err) {
    if ((err as Error).name === "AbortError") throw new Error(`Request timed out after ${Math.round(timeoutMs / 1000)}s`);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}
