import "server-only";
import { aiImageStatus, aiTextStatus, env } from "@/lib/env";
import { AINotConfiguredError, type ImageProvider, type TextProvider } from "@/lib/ai/types";
import { OpenAIImageProvider, OpenAITextProvider } from "@/lib/ai/providers/openai";
import { GeminiImageProvider, GeminiTextProvider } from "@/lib/ai/providers/gemini";
import { AnthropicTextProvider } from "@/lib/ai/providers/anthropic";
import { ReplicateImageProvider } from "@/lib/ai/providers/replicate";

// Provider registry. To add a provider: implement TextProvider / ImageProvider and add a case below
// plus its keys in src/lib/env.ts and .env.example.

export function getTextProvider(): TextProvider {
  const status = aiTextStatus();
  if (!status.configured) {
    throw new AINotConfiguredError("text", `AI design generation is not configured: ${status.detail}. Add the key to your environment variables (see README → AI providers).`);
  }
  const a = env.ai();
  switch (status.provider) {
    case "openai":
      return new OpenAITextProvider(a.openai);
    case "gemini":
      return new GeminiTextProvider(a.gemini);
    case "anthropic":
      return new AnthropicTextProvider(a.anthropic);
    default:
      throw new AINotConfiguredError("text", status.detail);
  }
}

export function getImageProvider(): ImageProvider {
  const status = aiImageStatus();
  if (!status.configured) {
    throw new AINotConfiguredError("image", `AI visualization is not configured: ${status.detail}.`);
  }
  const a = env.ai();
  switch (status.provider) {
    case "openai":
      return new OpenAIImageProvider(a.openai);
    case "gemini":
      return new GeminiImageProvider(a.gemini);
    case "replicate":
      return new ReplicateImageProvider(a.replicate);
    default:
      throw new AINotConfiguredError("image", status.detail);
  }
}

export function aiConfig() {
  const text = aiTextStatus();
  const image = aiImageStatus();
  return {
    text: { configured: text.configured, provider: text.provider, model: text.model, detail: text.detail },
    image: { configured: image.configured, provider: image.provider, model: image.model, detail: image.detail },
    variations: env.ai().variations,
  };
}
