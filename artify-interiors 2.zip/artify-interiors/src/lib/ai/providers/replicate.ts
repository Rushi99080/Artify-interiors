import "server-only";
import { AIProviderError, fetchWithTimeout, providerErrorMessage, type ImageProvider } from "@/lib/ai/types";

type Cfg = { apiToken: string; imageModel: string };
type Prediction = { id: string; status: string; output?: unknown; error?: string | null; urls?: { get?: string } };

const API = "https://api.replicate.com/v1";

/**
 * Replicate image provider. Works with interior redesign models that take an `image` and a `prompt`
 * (e.g. "adirik/interior-design"). Model format: "owner/name" or "owner/name:versionHash".
 */
export class ReplicateImageProvider implements ImageProvider {
  readonly name = "replicate";
  readonly supportsEditing = true;
  constructor(private cfg: Cfg) {}
  get model() {
    return this.cfg.imageModel;
  }

  private headers(wait = true) {
    return {
      Authorization: `Bearer ${this.cfg.apiToken}`,
      "Content-Type": "application/json",
      ...(wait ? { Prefer: "wait=60" } : {}),
    };
  }

  private async resolveVersion(): Promise<string | null> {
    const [ref, version] = this.cfg.imageModel.split(":");
    if (version) return version;
    const res = await fetchWithTimeout(`${API}/models/${ref}`, { headers: this.headers(false) }, 30_000);
    if (!res.ok) throw new AIProviderError("replicate", await providerErrorMessage(res), res.status);
    const json = (await res.json()) as { latest_version?: { id?: string } };
    return json.latest_version?.id ?? null;
  }

  async generate({ prompt, referenceImage }: Parameters<ImageProvider["generate"]>[0]) {
    const input: Record<string, unknown> = {
      prompt,
      negative_prompt: "lowres, watermark, text, logo, people, distorted perspective, cartoon, blurry",
    };
    if (referenceImage) input.image = `data:${referenceImage.mimeType};base64,${referenceImage.base64}`;

    const version = await this.resolveVersion();
    let res = await fetchWithTimeout(`${API}/predictions`, { method: "POST", headers: this.headers(), body: JSON.stringify({ version, input }) }, 90_000);
    if (!res.ok) throw new AIProviderError("replicate", await providerErrorMessage(res), res.status);
    let pred = (await res.json()) as Prediction;

    const started = Date.now();
    while (["starting", "processing"].includes(pred.status)) {
      if (Date.now() - started > 240_000) throw new AIProviderError("replicate", "Image generation timed out.");
      await new Promise((r) => setTimeout(r, 2500));
      res = await fetchWithTimeout(pred.urls?.get ?? `${API}/predictions/${pred.id}`, { headers: this.headers(false) }, 30_000);
      if (!res.ok) throw new AIProviderError("replicate", await providerErrorMessage(res), res.status);
      pred = (await res.json()) as Prediction;
    }
    if (pred.status !== "succeeded") throw new AIProviderError("replicate", pred.error ?? `Prediction ${pred.status}`);

    const out = Array.isArray(pred.output) ? pred.output[pred.output.length - 1] : pred.output;
    if (typeof out !== "string") throw new AIProviderError("replicate", "The model returned no image URL.");
    const img = await fetchWithTimeout(out, {}, 60_000);
    if (!img.ok) throw new AIProviderError("replicate", `Could not download generated image (${img.status})`);
    return { data: Buffer.from(await img.arrayBuffer()), mimeType: img.headers.get("content-type") ?? "image/png" };
  }
}
