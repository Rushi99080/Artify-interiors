import "server-only";
import { AIProviderError, fetchWithTimeout, providerErrorMessage, type TextProvider } from "@/lib/ai/types";

type Cfg = { apiKey: string; model: string };

/** Anthropic Claude — text & vision (used for room analysis and concept writing). */
export class AnthropicTextProvider implements TextProvider {
  readonly name = "anthropic";
  constructor(private cfg: Cfg) {}
  get model() {
    return this.cfg.model;
  }

  async generateJSON({ system, prompt, images = [], maxTokens = 8000 }: Parameters<TextProvider["generateJSON"]>[0]) {
    const content: unknown[] = [
      ...images.map((i) => ({ type: "image", source: { type: "base64", media_type: i.mimeType, data: i.base64 } })),
      { type: "text", text: `${prompt}\n\nRespond with the JSON object only.` },
    ];
    const res = await fetchWithTimeout(
      "https://api.anthropic.com/v1/messages",
      {
        method: "POST",
        headers: { "x-api-key": this.cfg.apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model: this.cfg.model, max_tokens: maxTokens, system, messages: [{ role: "user", content }] }),
      },
      120_000,
    );
    if (!res.ok) throw new AIProviderError("anthropic", await providerErrorMessage(res), res.status);
    const json = (await res.json()) as { content?: { type: string; text?: string }[]; stop_reason?: string };
    const text = (json.content ?? []).filter((c) => c.type === "text").map((c) => c.text ?? "").join("");
    if (!text) throw new AIProviderError("anthropic", `Empty response (stop reason: ${json.stop_reason ?? "unknown"}).`);
    return text;
  }
}
