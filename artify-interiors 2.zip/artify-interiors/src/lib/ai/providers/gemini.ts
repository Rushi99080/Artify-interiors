import "server-only";
import { AIProviderError, fetchWithTimeout, providerErrorMessage, type ImageProvider, type TextProvider } from "@/lib/ai/types";

type Cfg = { apiKey: string; textModel: string; imageModel: string };
const BASE = "https://generativelanguage.googleapis.com/v1beta/models";

type GeminiPart = { text?: string; inlineData?: { mimeType?: string; data?: string }; inline_data?: { mime_type?: string; data?: string } };
type GeminiResponse = {
  candidates?: { content?: { parts?: GeminiPart[] }; finishReason?: string }[];
  promptFeedback?: { blockReason?: string };
};

async function call(cfg: Cfg, model: string, body: unknown, timeoutMs: number): Promise<GeminiResponse> {
  const res = await fetchWithTimeout(
    `${BASE}/${encodeURIComponent(model)}:generateContent`,
    { method: "POST", headers: { "x-goog-api-key": cfg.apiKey, "Content-Type": "application/json" }, body: JSON.stringify(body) },
    timeoutMs,
  );
  if (!res.ok) throw new AIProviderError("gemini", await providerErrorMessage(res), res.status);
  const json = (await res.json()) as GeminiResponse;
  if (json.promptFeedback?.blockReason) throw new AIProviderError("gemini", `Request blocked: ${json.promptFeedback.blockReason}`);
  return json;
}

export class GeminiTextProvider implements TextProvider {
  readonly name = "gemini";
  constructor(private cfg: Cfg) {}
  get model() {
    return this.cfg.textModel;
  }

  async generateJSON({ system, prompt, images = [], maxTokens = 8000 }: Parameters<TextProvider["generateJSON"]>[0]) {
    const parts: unknown[] = [{ text: prompt }, ...images.map((i) => ({ inlineData: { mimeType: i.mimeType, data: i.base64 } }))];
    const json = await call(
      this.cfg,
      this.cfg.textModel,
      {
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts }],
        generationConfig: { responseMimeType: "application/json", maxOutputTokens: maxTokens, temperature: 0.9 },
      },
      120_000,
    );
    const text = (json.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? "").join("");
    if (!text) throw new AIProviderError("gemini", `Empty response (finish reason: ${json.candidates?.[0]?.finishReason ?? "unknown"}).`);
    return text;
  }
}

export class GeminiImageProvider implements ImageProvider {
  readonly name = "gemini";
  readonly supportsEditing = true;
  constructor(private cfg: Cfg) {}
  get model() {
    return this.cfg.imageModel;
  }

  async generate({ prompt, referenceImage }: Parameters<ImageProvider["generate"]>[0]) {
    const parts: unknown[] = [{ text: prompt }];
    if (referenceImage) parts.push({ inlineData: { mimeType: referenceImage.mimeType, data: referenceImage.base64 } });
    const json = await call(
      this.cfg,
      this.cfg.imageModel,
      { contents: [{ role: "user", parts }], generationConfig: { responseModalities: ["TEXT", "IMAGE"] } },
      240_000,
    );
    for (const p of json.candidates?.[0]?.content?.parts ?? []) {
      const inline = p.inlineData ?? (p.inline_data ? { mimeType: p.inline_data.mime_type, data: p.inline_data.data } : undefined);
      if (inline?.data) return { data: Buffer.from(inline.data, "base64"), mimeType: inline.mimeType ?? "image/png" };
    }
    const text = (json.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? "").join(" ").slice(0, 200);
    throw new AIProviderError("gemini", `The image model returned no image${text ? `: ${text}` : "."}`);
  }
}
