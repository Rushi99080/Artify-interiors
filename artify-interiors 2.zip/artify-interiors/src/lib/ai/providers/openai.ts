import "server-only";
import { AIProviderError, fetchWithTimeout, providerErrorMessage, type ImageProvider, type TextProvider } from "@/lib/ai/types";

type Cfg = { apiKey: string; baseUrl: string; textModel: string; imageModel: string; imageSize: string };

export class OpenAITextProvider implements TextProvider {
  readonly name = "openai";
  constructor(private cfg: Cfg) {}
  get model() {
    return this.cfg.textModel;
  }

  async generateJSON({ system, prompt, images = [], maxTokens = 6000 }: Parameters<TextProvider["generateJSON"]>[0]) {
    const content: unknown[] = [{ type: "text", text: prompt }];
    for (const img of images) content.push({ type: "image_url", image_url: { url: `data:${img.mimeType};base64,${img.base64}` } });
    const res = await fetchWithTimeout(
      `${this.cfg.baseUrl}/chat/completions`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${this.cfg.apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: this.cfg.textModel,
          messages: [
            { role: "system", content: system },
            { role: "user", content },
          ],
          response_format: { type: "json_object" },
          max_completion_tokens: maxTokens,
        }),
      },
      120_000,
    );
    if (!res.ok) throw new AIProviderError("openai", await providerErrorMessage(res), res.status);
    const json = (await res.json()) as { choices?: { message?: { content?: string; refusal?: string } }[] };
    const msg = json.choices?.[0]?.message;
    if (msg?.refusal) throw new AIProviderError("openai", `Model declined: ${msg.refusal}`);
    if (!msg?.content) throw new AIProviderError("openai", "Empty response from model.");
    return msg.content;
  }
}

export class OpenAIImageProvider implements ImageProvider {
  readonly name = "openai";
  readonly supportsEditing = true;
  constructor(private cfg: Cfg) {}
  get model() {
    return this.cfg.imageModel;
  }

  async generate({ prompt, referenceImage }: Parameters<ImageProvider["generate"]>[0]) {
    let res: Response;
    if (referenceImage) {
      const form = new FormData();
      form.append("model", this.cfg.imageModel);
      form.append("prompt", prompt);
      form.append("size", this.cfg.imageSize);
      form.append("n", "1");
      const bytes = Buffer.from(referenceImage.base64, "base64");
      form.append("image", new Blob([bytes], { type: referenceImage.mimeType }), `room.${referenceImage.mimeType.split("/")[1] ?? "jpg"}`);
      res = await fetchWithTimeout(`${this.cfg.baseUrl}/images/edits`, { method: "POST", headers: { Authorization: `Bearer ${this.cfg.apiKey}` }, body: form }, 240_000);
    } else {
      res = await fetchWithTimeout(
        `${this.cfg.baseUrl}/images/generations`,
        {
          method: "POST",
          headers: { Authorization: `Bearer ${this.cfg.apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({ model: this.cfg.imageModel, prompt, size: this.cfg.imageSize, n: 1 }),
        },
        240_000,
      );
    }
    if (!res.ok) throw new AIProviderError("openai", await providerErrorMessage(res), res.status);
    const json = (await res.json()) as { data?: { b64_json?: string; url?: string }[] };
    const item = json.data?.[0];
    if (item?.b64_json) return { data: Buffer.from(item.b64_json, "base64"), mimeType: "image/png" };
    if (item?.url) {
      const img = await fetchWithTimeout(item.url, {}, 60_000);
      if (!img.ok) throw new AIProviderError("openai", `Could not download generated image (${img.status})`);
      return { data: Buffer.from(await img.arrayBuffer()), mimeType: img.headers.get("content-type") ?? "image/png" };
    }
    throw new AIProviderError("openai", "The image model returned no image.");
  }
}
