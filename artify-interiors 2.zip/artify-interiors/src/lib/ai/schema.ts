import { z } from "zod";
import { DESIGN_STYLES, PRICE_TIERS, type DesignStyleKey, type PriceTierKey } from "@/lib/constants";

// Schema for the structured design concepts returned by the text model.
// Deliberately lenient (models vary) — values are normalised after parsing.

const str = z.string().trim();
const optStr = z
  .union([z.string(), z.null()])
  .optional()
  .transform((v) => (v ?? "").toString().trim());

const colour = z.object({
  name: str.max(60).default("Colour"),
  hex: str.transform((v) => {
    const m = /#?([0-9a-fA-F]{6})/.exec(v);
    return m ? `#${m[1]!.toUpperCase()}` : "#CCCCCC";
  }),
});

const material = z.object({
  category: str.default("OTHER"),
  materialId: z.union([z.string(), z.null()]).optional(),
  name: str.min(1),
  application: optStr,
});

const furniture = z.object({
  item: str.min(1),
  description: optStr,
  placement: optStr,
});

export const conceptSchema = z.object({
  name: str.min(1).max(80),
  style: str,
  tier: optStr,
  summary: optStr,
  colorPalette: z.array(colour).min(1).max(8),
  materials: z.array(material).max(20).default([]),
  furniture: z.array(furniture).max(20).default([]),
  furnitureLayout: optStr,
  wallFinish: optStr,
  ceilingDesign: optStr,
  lighting: optStr,
  flooring: optStr,
  decor: z.array(str).max(15).default([]),
  imagePrompt: str.min(10),
});

export const designOutputSchema = z.object({
  roomAnalysis: z
    .object({
      detectedRoomType: optStr,
      observations: optStr,
      existingFeatures: z.array(str).optional().default([]),
      lightingConditions: optStr,
      constraints: z.array(str).optional().default([]),
    })
    .optional(),
  concepts: z.array(conceptSchema).min(1).max(6),
});

export type DesignOutput = z.infer<typeof designOutputSchema>;
export type ConceptOutput = z.infer<typeof conceptSchema>;

/** Extracts the first JSON object from a model response (handles ```json fences and chatter). */
export function extractJson(text: string): unknown {
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  const candidate = fenced ? fenced[1]! : text;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end <= start) throw new Error("The AI response did not contain a JSON object.");
  return JSON.parse(candidate.slice(start, end + 1));
}

export function parseDesignOutput(text: string): DesignOutput {
  const raw = extractJson(text);
  const parsed = designOutputSchema.safeParse(raw);
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    throw new Error(`The AI response was not in the expected format (${first?.path.join(".")}: ${first?.message}).`);
  }
  return parsed.data;
}

export function normaliseStyle(value: string, fallback: DesignStyleKey): DesignStyleKey {
  const v = value.toUpperCase().replace(/[\s-]+/g, "_");
  if ((DESIGN_STYLES as readonly string[]).includes(v)) return v as DesignStyleKey;
  if (v.includes("NEO")) return "NEO_CLASSICAL";
  for (const s of DESIGN_STYLES) if (v.includes(s)) return s;
  return fallback;
}

export function normaliseTier(value: string, fallback: PriceTierKey): PriceTierKey {
  const v = value.toUpperCase();
  for (const t of PRICE_TIERS) if (v.includes(t)) return t;
  if (v.includes("ESSENTIAL") || v.includes("BUDGET")) return "ECONOMY";
  if (v.includes("SIGNATURE") || v.includes("MID")) return "STANDARD";
  if (v.includes("LUXE")) return "LUXURY";
  return fallback;
}
