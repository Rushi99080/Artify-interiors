import "server-only";
import { prisma } from "@/lib/db";
import type { Prisma } from "@/generated/prisma/client";

type Tx = Prisma.TransactionClient | typeof prisma;

/** Atomically increments a named counter and returns the new value. */
export async function nextCounter(key: string, tx: Tx = prisma): Promise<number> {
  const row = await tx.counter.upsert({
    where: { key },
    create: { key, value: 1 },
    update: { value: { increment: 1 } },
  });
  return row.value;
}

/** Indian financial year label, e.g. "2026-27" for dates from 1 Apr 2026 to 31 Mar 2027. */
export function financialYear(date = new Date()) {
  const y = date.getFullYear();
  const start = date.getMonth() >= 3 ? y : y - 1;
  return `${start}-${String((start + 1) % 100).padStart(2, "0")}`;
}

const pad = (n: number, w = 4) => String(n).padStart(w, "0");

export async function nextProjectCode(tx: Tx = prisma) {
  const year = new Date().getFullYear();
  return `ART-${year}-${pad(await nextCounter(`project:${year}`, tx))}`;
}

export async function nextLeadCode(tx: Tx = prisma) {
  const year = new Date().getFullYear();
  return `LD-${year}-${pad(await nextCounter(`lead:${year}`, tx))}`;
}

export async function nextQuotationBaseNumber(prefix: string, tx: Tx = prisma) {
  const fy = financialYear();
  return `${prefix}/${fy}/${pad(await nextCounter(`quotation:${fy}`, tx))}`;
}

export async function nextReceiptNumber(tx: Tx = prisma) {
  const fy = financialYear();
  return `RCPT/${fy}/${pad(await nextCounter(`receipt:${fy}`, tx), 5)}`;
}
