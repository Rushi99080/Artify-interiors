// Project workflow — pure helpers (unit-tested). DB operations live in src/lib/services/workflow.ts.

export type StageKey =
  | "LEAD_RECEIVED"
  | "INITIAL_CONSULTATION"
  | "SITE_MEASUREMENT"
  | "CONCEPT_DESIGN"
  | "DESIGN_3D"
  | "DESIGN_APPROVAL"
  | "MATERIAL_SELECTION"
  | "FINAL_BOQ"
  | "QUOTATION_APPROVAL"
  | "ADVANCE_PAYMENT"
  | "PRODUCTION"
  | "MATERIAL_DELIVERY"
  | "SITE_EXECUTION"
  | "QUALITY_INSPECTION"
  | "FINAL_HANDOVER";

export const DEFAULT_STAGES: { key: StageKey; name: string; defaultDurationDays: number; customerVisible: boolean }[] = [
  { key: "LEAD_RECEIVED", name: "Lead Received", defaultDurationDays: 0, customerVisible: true },
  { key: "INITIAL_CONSULTATION", name: "Initial Consultation", defaultDurationDays: 2, customerVisible: true },
  { key: "SITE_MEASUREMENT", name: "Site Measurement", defaultDurationDays: 3, customerVisible: true },
  { key: "CONCEPT_DESIGN", name: "Concept Design", defaultDurationDays: 5, customerVisible: true },
  { key: "DESIGN_3D", name: "3D Design", defaultDurationDays: 7, customerVisible: true },
  { key: "DESIGN_APPROVAL", name: "Design Approval", defaultDurationDays: 3, customerVisible: true },
  { key: "MATERIAL_SELECTION", name: "Material Selection", defaultDurationDays: 4, customerVisible: true },
  { key: "FINAL_BOQ", name: "Final BOQ", defaultDurationDays: 2, customerVisible: true },
  { key: "QUOTATION_APPROVAL", name: "Quotation Approval", defaultDurationDays: 3, customerVisible: true },
  { key: "ADVANCE_PAYMENT", name: "Advance Payment", defaultDurationDays: 2, customerVisible: true },
  { key: "PRODUCTION", name: "Production", defaultDurationDays: 21, customerVisible: true },
  { key: "MATERIAL_DELIVERY", name: "Material Delivery", defaultDurationDays: 5, customerVisible: true },
  { key: "SITE_EXECUTION", name: "Site Execution", defaultDurationDays: 20, customerVisible: true },
  { key: "QUALITY_INSPECTION", name: "Quality Inspection", defaultDurationDays: 3, customerVisible: true },
  { key: "FINAL_HANDOVER", name: "Final Handover", defaultDurationDays: 1, customerVisible: true },
];

/** Stages that are auto-completed when a quotation is approved (everything before advance payment). */
export const PRE_APPROVAL_STAGES: StageKey[] = [
  "LEAD_RECEIVED",
  "INITIAL_CONSULTATION",
  "SITE_MEASUREMENT",
  "CONCEPT_DESIGN",
  "DESIGN_3D",
  "DESIGN_APPROVAL",
  "MATERIAL_SELECTION",
  "FINAL_BOQ",
  "QUOTATION_APPROVAL",
];

export type MilestoneLike = { stageKey: string; sortOrder: number; status: "PENDING" | "IN_PROGRESS" | "COMPLETED" | "SKIPPED" | "BLOCKED" };

export function computeProgress(milestones: MilestoneLike[]) {
  const counted = milestones.filter((m) => m.status !== "SKIPPED");
  const done = counted.filter((m) => m.status === "COMPLETED").length;
  const total = counted.length;
  const current = [...milestones].sort((a, b) => a.sortOrder - b.sortOrder).find((m) => m.status === "IN_PROGRESS" || m.status === "BLOCKED" || m.status === "PENDING") ?? null;
  return { done, total, percent: total === 0 ? 0 : Math.round((done / total) * 100), current };
}

/** The stage that should become IN_PROGRESS after the given stages complete (first PENDING by order). */
export function nextStageToStart(milestones: MilestoneLike[]) {
  const sorted = [...milestones].sort((a, b) => a.sortOrder - b.sortOrder);
  if (sorted.some((m) => m.status === "IN_PROGRESS" || m.status === "BLOCKED")) return null;
  return sorted.find((m) => m.status === "PENDING") ?? null;
}

/** Sequential due dates for remaining stages starting from a date, skipping completed ones. */
export function planDueDates<T extends MilestoneLike & { durationDays: number }>(milestones: T[], start: Date) {
  const sorted = [...milestones].sort((a, b) => a.sortOrder - b.sortOrder);
  let cursor = new Date(start);
  const out: { stageKey: string; dueDate: Date }[] = [];
  for (const m of sorted) {
    if (m.status === "COMPLETED" || m.status === "SKIPPED") continue;
    cursor = new Date(cursor.getTime() + Math.max(m.durationDays, 1) * 86400000);
    out.push({ stageKey: m.stageKey, dueDate: cursor });
  }
  return out;
}

export function stageKeyFromName(name: string) {
  return (
    name
      .toUpperCase()
      .replace(/[^A-Z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "")
      .slice(0, 40) || "STAGE"
  );
}
