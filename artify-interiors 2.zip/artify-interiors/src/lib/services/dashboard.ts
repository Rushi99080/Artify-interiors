import "server-only";
import { prisma } from "@/lib/db";
import { computeProgress } from "@/lib/workflow/stages";

/** Everything the customer overview needs, computed from stored data. */
export async function customerDashboard(customerId: string | null) {
  if (!customerId) return { projects: [], stats: { total: 0, active: 0, savedDesigns: 0, pendingQuotes: 0, approvedQuotes: 0, estimatedBudget: 0 } };
  const projects = await prisma.project.findMany({
    where: { customerId },
    orderBy: { updatedAt: "desc" },
    include: {
      milestones: { select: { stageKey: true, sortOrder: true, status: true, name: true, customerVisible: true } },
      quotations: { where: { status: { not: "DRAFT" } }, orderBy: { createdAt: "desc" }, select: { id: true, number: true, status: true, grandTotal: true, isPreliminary: true, createdAt: true } },
      boqs: { orderBy: { version: "desc" }, take: 1, select: { grandTotal: true } },
      _count: { select: { designs: { where: { isSaved: true } }, rooms: true } },
    },
  });
  const views = projects.map((p) => {
    const visible = p.milestones.filter((m) => m.customerVisible);
    const progress = computeProgress(visible);
    const latestQuote = p.quotations.find((q) => q.status !== "SUPERSEDED") ?? null;
    const estimate = p.contractValue ?? latestQuote?.grandTotal ?? p.boqs[0]?.grandTotal ?? p.budgetMax ?? 0;
    return { id: p.id, code: p.code, name: p.name, status: p.status, location: p.location, updatedAt: p.updatedAt, progress, currentStage: (progress.current as { name?: string } | null)?.name ?? null, latestQuote, estimate, savedDesigns: p._count.designs, rooms: p._count.rooms };
  });
  const quotes = projects.flatMap((p) => p.quotations);
  return {
    projects: views,
    stats: {
      total: projects.length,
      active: projects.filter((p) => p.status === "ACTIVE").length,
      savedDesigns: projects.reduce((s, p) => s + p._count.designs, 0),
      pendingQuotes: quotes.filter((q) => q.status === "SENT" || q.status === "CHANGES_REQUESTED").length,
      approvedQuotes: quotes.filter((q) => q.status === "APPROVED").length,
      estimatedBudget: views.reduce((s, v) => s + (v.estimate ?? 0), 0),
    },
  };
}
