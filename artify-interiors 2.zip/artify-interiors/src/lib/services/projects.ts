import "server-only";
import { prisma } from "@/lib/db";
import { nextLeadCode, nextProjectCode } from "@/lib/counters";
import { completeStage, ensureWorkflow } from "@/lib/services/workflow";
import { queueNotify } from "@/lib/notifications";
import type { CurrentUser } from "@/lib/auth/session";
import type { DesignStyleKey, PropertyTypeKey, RoomTypeKey } from "@/lib/constants";
import { ROOM_LABELS } from "@/lib/constants";
import { formatINR } from "@/lib/format";
import { badRequest } from "@/lib/api";

export type RoomDraft = { name?: string | null; type: RoomTypeKey; lengthFt?: number | null; widthFt?: number | null; heightFt?: number | null; preferences?: string | null };

export type ProjectDraft = {
  name: string;
  location: string;
  address?: string | null;
  propertyType: PropertyTypeKey;
  carpetAreaSqft?: number | null;
  numberOfRooms?: number | null;
  designStyle?: DesignStyleKey | null;
  budgetMin?: number | null;
  budgetMax?: number | null;
  colorPalette?: string | null;
  materialPreferences?: string | null;
  timeline?: string | null;
  notes?: string | null;
  rooms: RoomDraft[];
};

export type CustomerDraft = { fullName: string; phone: string; email?: string | null; address?: string | null; city?: string | null };

/** Finds or creates the Customer profile for a signed-in customer. */
export async function customerForUser(user: CurrentUser, details?: Partial<CustomerDraft>) {
  if (user.customerId) {
    if (details?.phone || details?.fullName) {
      await prisma.customer.update({
        where: { id: user.customerId },
        data: { ...(details.phone ? { phone: details.phone } : {}), ...(details.fullName ? { fullName: details.fullName } : {}), ...(details.city ? { city: details.city } : {}) },
      });
    }
    return prisma.customer.findUniqueOrThrow({ where: { id: user.customerId } });
  }
  return prisma.customer.create({
    data: { userId: user.id, fullName: details?.fullName || user.name, email: user.email, phone: details?.phone || user.phone || "", city: details?.city ?? null },
  });
}

/** Creates a project with its rooms and workflow. Records a CRM lead when a customer starts it themselves. */
export async function createProject(opts: { draft: ProjectDraft; customerId: string; createdBy: CurrentUser; source?: "AI_DESIGNER" | "WEBSITE" | "OTHER" }) {
  const { draft } = opts;
  if (draft.rooms.length === 0) throw badRequest("Add at least one room.");
  const project = await prisma.$transaction(async (tx) => {
    const code = await nextProjectCode(tx);
    return tx.project.create({
      data: {
        code,
        name: draft.name,
        customerId: opts.customerId,
        location: draft.location,
        address: draft.address ?? null,
        propertyType: draft.propertyType,
        carpetAreaSqft: draft.carpetAreaSqft ?? null,
        numberOfRooms: draft.numberOfRooms ?? draft.rooms.length,
        designStyle: draft.designStyle ?? null,
        budgetMin: draft.budgetMin ?? null,
        budgetMax: draft.budgetMax ?? null,
        colorPalette: draft.colorPalette ?? null,
        materialPreferences: draft.materialPreferences ?? null,
        timeline: draft.timeline ?? null,
        notes: draft.notes ?? null,
        status: "DRAFT",
        rooms: {
          create: draft.rooms.map((r, i) => ({
            name: r.name?.trim() || nameFor(r.type, draft.rooms, i),
            type: r.type,
            lengthFt: r.lengthFt ?? null,
            widthFt: r.widthFt ?? null,
            heightFt: r.heightFt ?? 10,
            preferences: r.preferences ?? null,
            sortOrder: i,
          })),
        },
      },
      include: { rooms: true, customer: true },
    });
  });

  await ensureWorkflow(project.id);
  await completeStage(project.id, "LEAD_RECEIVED");

  if (opts.createdBy.role === "CUSTOMER") {
    const lead = await prisma.lead.create({
      data: {
        leadCode: await nextLeadCode(),
        name: project.customer.fullName,
        phone: project.customer.phone,
        email: project.customer.email,
        city: draft.location,
        projectType: draft.propertyType,
        budget: draft.budgetMax ? `${formatINR(draft.budgetMin ?? 0)} – ${formatINR(draft.budgetMax)}` : null,
        source: opts.source ?? "AI_DESIGNER",
        message: `Started project “${draft.name}” online with ${draft.rooms.length} room(s).`,
        status: "NEW",
        customerId: project.customerId,
        projectId: project.id,
      },
    });
    queueNotify({
      event: "NEW_ENQUIRY",
      title: `New online project: ${project.name}`,
      body: `${project.customer.fullName} (${project.customer.phone || project.customer.email}) started “${project.name}” in ${draft.location} — ${draft.rooms.length} room(s). Lead ${lead.leadCode}.`,
      link: `/admin/projects/${project.id}`,
      notifyAdmins: true,
      whatsappParams: [project.customer.fullName, project.name, draft.location],
    });
  }
  return project;
}

function nameFor(type: RoomTypeKey, rooms: RoomDraft[], index: number) {
  const same = rooms.filter((r) => r.type === type);
  if (same.length <= 1) return ROOM_LABELS[type];
  const n = rooms.slice(0, index + 1).filter((r) => r.type === type).length;
  return `${ROOM_LABELS[type]} ${n}`;
}

/** Public enquiry → CRM lead (+ admin notification). */
export async function createLead(input: {
  name: string;
  phone: string;
  email?: string | null;
  city?: string | null;
  projectType?: PropertyTypeKey | null;
  budget?: string | null;
  source?: "WEBSITE" | "AI_DESIGNER" | "COST_CALCULATOR" | "REFERRAL" | "WALK_IN" | "INSTAGRAM" | "FACEBOOK" | "GOOGLE" | "OTHER";
  message?: string | null;
  meta?: Record<string, unknown>;
}) {
  const lead = await prisma.lead.create({
    data: {
      leadCode: await nextLeadCode(),
      name: input.name,
      phone: input.phone,
      email: input.email ?? null,
      city: input.city ?? null,
      projectType: input.projectType ?? null,
      budget: input.budget ?? null,
      source: input.source ?? "WEBSITE",
      message: input.message ?? null,
      status: "NEW",
      followUpDate: new Date(Date.now() + 86400000),
      meta: (input.meta ?? undefined) as object | undefined,
    },
  });
  queueNotify({
    event: "NEW_ENQUIRY",
    title: `New enquiry ${lead.leadCode}: ${lead.name}`,
    body: `${lead.name} · ${lead.phone}${lead.email ? ` · ${lead.email}` : ""}\nProject: ${lead.projectType ?? "—"} · Budget: ${lead.budget ?? "—"} · Source: ${lead.source}\n\n${lead.message ?? ""}`,
    link: `/admin/leads/${lead.id}`,
    notifyAdmins: true,
    whatsappParams: [lead.name, lead.phone, lead.projectType ?? "Interior project"],
  });
  return lead;
}
