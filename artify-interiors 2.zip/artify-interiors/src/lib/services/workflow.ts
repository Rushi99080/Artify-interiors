import "server-only";
import { prisma } from "@/lib/db";
import { DEFAULT_STAGES, PRE_APPROVAL_STAGES, nextStageToStart, planDueDates, type StageKey } from "@/lib/workflow/stages";
import { queueNotify, projectCustomerRecipient } from "@/lib/notifications";

/** Active stage templates (seeded from DEFAULT_STAGES, editable in Admin → Settings → Workflow). */
export async function getStageTemplates() {
  const rows = await prisma.workflowStage.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } });
  if (rows.length) return rows;
  return DEFAULT_STAGES.map((s, i) => ({ ...s, id: s.key, sortOrder: i + 1, isActive: true }));
}

/** Creates any missing milestones for a project from the stage templates. Idempotent. */
export async function ensureWorkflow(projectId: string) {
  const [templates, existing] = await Promise.all([
    getStageTemplates(),
    prisma.projectMilestone.findMany({ where: { projectId }, select: { stageKey: true } }),
  ]);
  const have = new Set(existing.map((e) => e.stageKey));
  const missing = templates.filter((t) => !have.has(t.key));
  if (missing.length) {
    await prisma.projectMilestone.createMany({
      data: missing.map((t) => ({ projectId, stageKey: t.key, name: t.name, sortOrder: t.sortOrder, customerVisible: t.customerVisible })),
      skipDuplicates: true,
    });
  }
  await startNextStage(projectId);
}

async function startNextStage(projectId: string) {
  const all = await prisma.projectMilestone.findMany({ where: { projectId } });
  const next = nextStageToStart(all);
  if (next) {
    await prisma.projectMilestone.updateMany({ where: { projectId, stageKey: next.stageKey, status: "PENDING" }, data: { status: "IN_PROGRESS", startedAt: new Date() } });
  }
}

/**
 * Marks a stage complete (if it is not already) and starts the next one.
 * Used by automation hooks (design generated, quotation approved, payment received...).
 */
export async function completeStage(projectId: string, key: StageKey | string, opts: { note?: string; notifyCustomer?: boolean } = {}) {
  const ms = await prisma.projectMilestone.findUnique({ where: { projectId_stageKey: { projectId, stageKey: key } } });
  if (!ms || ms.status === "COMPLETED" || ms.status === "SKIPPED") return false;
  await prisma.projectMilestone.update({
    where: { id: ms.id },
    data: { status: "COMPLETED", completedAt: new Date(), startedAt: ms.startedAt ?? new Date(), notes: opts.note ?? ms.notes },
  });
  await startNextStage(projectId);
  if (opts.notifyCustomer && ms.customerVisible) await notifyMilestone(projectId, ms.name, "COMPLETED");
  if (key === "FINAL_HANDOVER") await markProjectCompleted(projectId);
  return true;
}

export async function markProjectCompleted(projectId: string) {
  const p = await prisma.project.update({ where: { id: projectId }, data: { status: "COMPLETED" }, select: { name: true, code: true } });
  const customer = await projectCustomerRecipient(projectId);
  queueNotify({
    event: "PROJECT_HANDOVER",
    title: "Your project has been handed over",
    body: `${p.name} (${p.code}) is complete. Thank you for choosing us — your project documents remain available in your dashboard.`,
    link: `/dashboard/projects/${projectId}`,
    recipients: [customer],
    notifyAdmins: true,
    whatsappParams: [customer.name || "there", p.name],
  });
}

export async function notifyMilestone(projectId: string, stageName: string, status: string) {
  const p = await prisma.project.findUnique({ where: { id: projectId }, select: { name: true } });
  const customer = await projectCustomerRecipient(projectId);
  const statusText = status === "COMPLETED" ? "has been completed" : status === "IN_PROGRESS" ? "has started" : `is now ${status.toLowerCase().replace("_", " ")}`;
  queueNotify({
    event: "MILESTONE_UPDATE",
    title: `${stageName} ${statusText}`,
    body: `Project update for ${p?.name ?? "your project"}: the “${stageName}” stage ${statusText}.`,
    link: `/dashboard/projects/${projectId}`,
    recipients: [customer],
    whatsappParams: [customer.name || "there", p?.name ?? "your project", stageName],
  });
}

/** Called when a quotation is approved: closes pre-approval stages and plans due dates for the rest. */
export async function onQuotationApproved(projectId: string) {
  await ensureWorkflow(projectId);
  await prisma.projectMilestone.updateMany({
    where: { projectId, stageKey: { in: PRE_APPROVAL_STAGES }, status: { in: ["PENDING", "IN_PROGRESS", "BLOCKED"] } },
    data: { status: "COMPLETED", completedAt: new Date(), notes: "Completed on quotation approval" },
  });
  const [milestones, templates] = await Promise.all([prisma.projectMilestone.findMany({ where: { projectId } }), getStageTemplates()]);
  const durations = new Map(templates.map((t) => [t.key, t.defaultDurationDays]));
  const plan = planDueDates(
    milestones.map((m) => ({ ...m, durationDays: durations.get(m.stageKey) ?? 3 })),
    new Date(),
  );
  for (const p of plan) {
    await prisma.projectMilestone.updateMany({ where: { projectId, stageKey: p.stageKey, dueDate: null }, data: { dueDate: p.dueDate } });
  }
  const last = plan[plan.length - 1];
  await prisma.project.update({ where: { id: projectId }, data: { startDate: new Date(), targetDate: last?.dueDate ?? null } });
  await startNextStage(projectId);
}
