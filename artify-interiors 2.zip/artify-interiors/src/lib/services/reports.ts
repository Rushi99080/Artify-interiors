import "server-only";
import { prisma } from "@/lib/db";
import { round2 } from "@/lib/calc/boq";

export const REPORT_PERIODS = {
  fy: "This financial year",
  lastfy: "Last financial year",
  "12m": "Last 12 months",
  all: "All time",
} as const;
export type ReportPeriod = keyof typeof REPORT_PERIODS;

/** Start/end of a reporting period (Indian financial year runs April → March). */
export function periodRange(period: ReportPeriod, now = new Date()): { from: Date | null; to: Date } {
  const fyStartYear = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  switch (period) {
    case "fy":
      return { from: new Date(fyStartYear, 3, 1), to: now };
    case "lastfy":
      return { from: new Date(fyStartYear - 1, 3, 1), to: new Date(fyStartYear, 3, 1) };
    case "12m":
      return { from: new Date(now.getFullYear(), now.getMonth() - 11, 1), to: now };
    default:
      return { from: null, to: now };
  }
}

const monthKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;

function monthsBetween(from: Date, to: Date) {
  const out: string[] = [];
  const d = new Date(from.getFullYear(), from.getMonth(), 1);
  while (d < to && out.length < 120) {
    out.push(monthKey(d));
    d.setMonth(d.getMonth() + 1);
  }
  return out;
}

const monthLabel = (key: string) => {
  const [y, m] = key.split("-").map(Number);
  return new Date(y!, m! - 1, 1).toLocaleDateString("en-IN", { month: "short", year: "2-digit" });
};

/** Business reports for a period — every figure is computed from stored records. */
export async function buildReports(period: ReportPeriod) {
  const { from, to } = periodRange(period);
  const inRange = from ? { gte: from, lt: to } : { lt: to };

  const [payments, expenses, leads, quotations, designs, projects, boqLines] = await Promise.all([
    prisma.payment.findMany({ where: { status: "SUCCESS", paidAt: inRange }, select: { amount: true, paidAt: true, method: true } }),
    prisma.expense.findMany({ where: { spentAt: inRange }, select: { amount: true, category: true, spentAt: true } }),
    prisma.lead.findMany({ where: { createdAt: inRange }, select: { status: true, source: true, createdAt: true } }),
    prisma.quotation.findMany({ where: { createdAt: inRange, status: { not: "DRAFT" } }, select: { baseNumber: true, status: true, grandTotal: true, approvedAt: true } }),
    prisma.generatedDesign.groupBy({ by: ["status"], where: { createdAt: inRange }, _count: { _all: true } }),
    prisma.project.findMany({
      where: { contractValue: { gt: 0 }, ...(from ? { OR: [{ createdAt: inRange }, { updatedAt: inRange }] } : {}) },
      orderBy: { updatedAt: "desc" },
      take: 100,
      select: {
        id: true,
        code: true,
        name: true,
        status: true,
        contractValue: true,
        customer: { select: { fullName: true } },
        payments: { where: { status: "SUCCESS" }, select: { amount: true } },
        expenses: { select: { amount: true, category: true } },
        approvedQuotation: { select: { gstAmount: true, snapshot: true } },
      },
    }),
    prisma.bOQItem.findMany({
      where: { materialId: { not: null }, boq: { quotations: { some: { status: "APPROVED", ...(from ? { approvedAt: inRange } : {}) } } } },
      select: { materialId: true, amount: true, quantity: true, unit: true, material: { select: { name: true, brand: true, category: true } } },
    }),
  ]);

  // Monthly revenue vs expenses
  const months = from ? monthsBetween(from, to) : monthsBetween(new Date(Math.min(...[...payments.map((p) => p.paidAt.getTime()), ...expenses.map((e) => e.spentAt.getTime()), to.getTime()])), to);
  const rev = new Map(months.map((m) => [m, 0]));
  const exp = new Map(months.map((m) => [m, 0]));
  for (const p of payments) rev.set(monthKey(p.paidAt), (rev.get(monthKey(p.paidAt)) ?? 0) + p.amount);
  for (const e of expenses) exp.set(monthKey(e.spentAt), (exp.get(monthKey(e.spentAt)) ?? 0) + e.amount);
  const monthly = months.map((m) => ({ month: monthLabel(m), revenue: round2(rev.get(m) ?? 0), expenses: round2(exp.get(m) ?? 0) }));

  const revenue = round2(payments.reduce((s, p) => s + p.amount, 0));
  const spend = round2(expenses.reduce((s, e) => s + e.amount, 0));

  const byCategory = new Map<string, number>();
  for (const e of expenses) byCategory.set(e.category, (byCategory.get(e.category) ?? 0) + e.amount);
  const byMethod = new Map<string, number>();
  for (const p of payments) byMethod.set(p.method, (byMethod.get(p.method) ?? 0) + p.amount);

  // Leads: funnel and source performance
  const leadStatus = new Map<string, number>();
  const sources = new Map<string, { total: number; converted: number }>();
  for (const l of leads) {
    leadStatus.set(l.status, (leadStatus.get(l.status) ?? 0) + 1);
    const s = sources.get(l.source) ?? { total: 0, converted: 0 };
    s.total++;
    if (l.status === "CONVERTED") s.converted++;
    sources.set(l.source, s);
  }

  // Quotations: unique proposals (base numbers), approved if any revision was approved
  const proposals = new Map<string, { approved: boolean; value: number }>();
  for (const q of quotations) {
    const cur = proposals.get(q.baseNumber) ?? { approved: false, value: 0 };
    if (q.status === "APPROVED") {
      cur.approved = true;
      cur.value = q.grandTotal;
    }
    proposals.set(q.baseNumber, cur);
  }
  const approvedProposals = [...proposals.values()].filter((p) => p.approved);

  // Project profitability
  const projectRows = projects.map((p) => {
    const received = round2(p.payments.reduce((s, x) => s + x.amount, 0));
    const spent = round2(p.expenses.reduce((s, e) => s + e.amount, 0));
    const gst = p.approvedQuotation?.gstAmount ?? 0;
    const snapshot = p.approvedQuotation?.snapshot as { totals?: { profitAmount?: number } } | undefined;
    const revenueExGst = round2((p.contractValue ?? 0) - gst);
    return {
      id: p.id,
      code: p.code,
      name: p.name,
      customer: p.customer.fullName,
      status: p.status,
      contract: p.contractValue ?? 0,
      received,
      pending: round2(Math.max(0, (p.contractValue ?? 0) - received)),
      expenses: spent,
      plannedMargin: round2(snapshot?.totals?.profitAmount ?? 0),
      // final profit only once the project is complete; while running, show spend as a share of contract value (ex-GST)
      actualProfit: p.status === "COMPLETED" ? round2(revenueExGst - spent) : null,
      marginPct: p.status === "COMPLETED" && revenueExGst > 0 ? Math.round(((revenueExGst - spent) / revenueExGst) * 100) : null,
      costShare: revenueExGst > 0 ? Math.round((spent / revenueExGst) * 100) : null,
    };
  });

  // Top materials in approved quotations
  const mats = new Map<string, { name: string; brand: string | null; category: string; amount: number; quantity: number; unit: string }>();
  for (const l of boqLines) {
    if (!l.materialId || !l.material) continue;
    const m = mats.get(l.materialId) ?? { name: l.material.name, brand: l.material.brand, category: l.material.category, amount: 0, quantity: 0, unit: l.unit };
    m.amount += l.amount;
    m.quantity += l.quantity;
    mats.set(l.materialId, m);
  }
  const topMaterials = [...mats.values()].sort((a, b) => b.amount - a.amount).slice(0, 12).map((m) => ({ ...m, amount: round2(m.amount), quantity: round2(m.quantity) }));

  return {
    period,
    from,
    to,
    kpis: {
      revenue,
      spend,
      cashMargin: round2(revenue - spend),
      leads: leads.length,
      convertedLeads: leadStatus.get("CONVERTED") ?? 0,
      proposals: proposals.size,
      approvedProposals: approvedProposals.length,
      approvedValue: round2(approvedProposals.reduce((s, p) => s + p.value, 0)),
      conceptsGenerated: designs.reduce((s, d) => s + d._count._all, 0),
      conceptsApproved: designs.find((d) => d.status === "APPROVED")?._count._all ?? 0,
    },
    monthly,
    expensesByCategory: [...byCategory.entries()].map(([category, amount]) => ({ category, amount: round2(amount) })).sort((a, b) => b.amount - a.amount),
    paymentsByMethod: [...byMethod.entries()].map(([method, amount]) => ({ method, amount: round2(amount) })).sort((a, b) => b.amount - a.amount),
    leadFunnel: ["NEW", "CONTACTED", "CONSULTATION", "QUOTATION_SENT", "CONVERTED", "LOST"].map((s) => ({ status: s, count: leadStatus.get(s) ?? 0 })),
    leadSources: [...sources.entries()].map(([source, v]) => ({ source, ...v, rate: v.total ? Math.round((v.converted / v.total) * 100) : 0 })).sort((a, b) => b.total - a.total),
    projects: projectRows,
    topMaterials,
  };
}
