import "server-only";
import sharp from "sharp";
import { prisma } from "@/lib/db";
import { badRequest } from "@/lib/api";
import { saveBuffer, readBuffer, type FileRef } from "@/lib/storage";
import { MIME_BY_EXT, checkUploadMeta, extOf, isImageExt, sniffMatches, type UploadCategory } from "@/lib/storage/rules";
import type { AIImageInput } from "@/lib/ai/types";

/**
 * Validates (extension, size, magic bytes), sanitises images (EXIF/GPS stripped, auto-rotated,
 * capped at 4096px) and stores the file. Returns the UploadedFile record.
 */
export async function storeUpload(opts: {
  buffer: Buffer;
  originalName: string;
  category: UploadCategory;
  projectId?: string | null;
  roomId?: string | null;
  uploadedById?: string | null;
  isPublic?: boolean;
}) {
  const name = opts.originalName.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").slice(0, 180) || "file";
  const problem = checkUploadMeta(opts.category, name, opts.buffer.length);
  if (problem) throw badRequest(problem);
  let ext = extOf(name);
  if (!sniffMatches(ext, opts.buffer.subarray(0, 4096))) throw badRequest(`${name}: the file content does not match its extension.`);

  let data = opts.buffer;
  if (isImageExt(ext)) {
    try {
      const img = sharp(opts.buffer, { failOn: "error" }).rotate().resize({ width: 4096, height: 4096, fit: "inside", withoutEnlargement: true });
      if (ext === "png") data = await img.png({ compressionLevel: 8 }).toBuffer();
      else if (ext === "webp") data = await img.webp({ quality: 90 }).toBuffer();
      else {
        data = await img.jpeg({ quality: 88, mozjpeg: true }).toBuffer();
        ext = "jpg";
      }
    } catch {
      throw badRequest(`${name}: the image could not be read. Please upload a valid JPG, PNG or WEBP.`);
    }
  }

  const stored = await saveBuffer(data, { ext, scope: opts.projectId ? `projects/${opts.projectId}` : opts.category === "CONTENT" ? "content" : "misc", isPublic: opts.isPublic });
  return prisma.uploadedFile.create({
    data: {
      projectId: opts.projectId ?? null,
      roomId: opts.roomId ?? null,
      uploadedById: opts.uploadedById ?? null,
      category: opts.category,
      originalName: name,
      mimeType: MIME_BY_EXT[ext] ?? "application/octet-stream",
      sizeBytes: data.length,
      storageProvider: stored.provider,
      storageKey: stored.storageKey,
      resourceType: stored.resourceType,
      isPublic: !!opts.isPublic,
    },
  });
}

export function fileUrl(id: string | null | undefined) {
  return id ? `/api/files/${id}` : null;
}

/** Downscaled JPEG for AI providers (smaller payloads, consistent format). */
export async function toAIImage(file: FileRef, maxSize = 1536): Promise<AIImageInput> {
  const buf = await readBuffer(file);
  const out = await sharp(buf).rotate().resize({ width: maxSize, height: maxSize, fit: "inside", withoutEnlargement: true }).jpeg({ quality: 85 }).toBuffer();
  return { mimeType: "image/jpeg", base64: out.toString("base64") };
}
