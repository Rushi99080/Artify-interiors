import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import { prisma } from "@/lib/db";
import { badRequest, notConfigured, notFound } from "@/lib/api";
import { env } from "@/lib/env";
import { round2, splitPaymentSchedule } from "@/lib/calc/boq";
import { allocatePayments, paymentSummary } from "@/lib/calc/payments";
import { nextReceiptNumber } from "@/lib/counters";
import { getSettings } from "@/lib/settings";
import { completeStage } from "@/lib/services/workflow";
import { queueNotify, projectCustomerRecipient } from "@/lib/notifications";
import { formatINR } from "@/lib/format";

/** Creates payment milestones from the configured schedule (only if none exist). */
export async function ensurePaymentSchedule(projectId: string, contractValue: number) {
  const existing = await prisma.paymentMilestone.count({ where: { projectId } });
  if (existing > 0) return;
  const { paymentSchedule } = await getSettings();
  const split = splitPaymentSchedule(contractValue, paymentSchedule);
  await prisma.paymentMilestone.createMany({
    data: split.map((s, i) => ({ projectId, name: s.name, percent: s.percent, amount: s.amount, sortOrder: i, dueDate: i === 0 ? new Date() : null })),
  });
}

/** Re-scales milestone amounts when the contract value changes (keeps percentages). */
export async function rescalePaymentSchedule(projectId: string, contractValue: number) {
  const ms = await prisma.paymentMilestone.findMany({ where: { projectId }, orderBy: { sortOrder: "asc" } });
  if (!ms.length) return ensurePaymentSchedule(projectId, contractValue);
  const pct = ms.reduce((s, m) => s + m.percent, 0);
  if (Math.abs(pct - 100) > 0.01) return;
  const split = splitPaymentSchedule(contractValue, ms.map((m) => ({ name: m.name, percent: m.percent })));
  for (let i = 0; i < ms.length; i++) await prisma.paymentMilestone.update({ where: { id: ms[i]!.id }, data: { amount: split[i]!.amount } });
  await refreshPaymentMilestones(projectId);
}

/** Recomputes milestone statuses from successful payments (allocated oldest milestone first). */
export async function refreshPaymentMilestones(projectId: string) {
  const [ms, payments] = await Promise.all([
    prisma.paymentMilestone.findMany({ where: { projectId } }),
    prisma.payment.findMany({ where: { projectId, status: "SUCCESS" }, select: { amount: true } }),
  ]);
  const total = payments.reduce((s, p) => s + p.amount, 0);
  const allocated = allocatePayments(ms, total);
  for (const a of allocated) {
    const current = ms.find((m) => m.id === a.id);
    if (current && current.status !== a.status) await prisma.paymentMilestone.update({ where: { id: a.id }, data: { status: a.status } });
  }
  return allocated;
}

export async function getPaymentOverview(projectId: string) {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: { contractValue: true, payments: { orderBy: { paidAt: "desc" } }, paymentMilestones: { orderBy: { sortOrder: "asc" } } },
  });
  if (!project) throw notFound("Project not found.");
  const summary = paymentSummary(project.contractValue, project.payments);
  const milestones = allocatePayments(project.paymentMilestones, summary.received).map((a) => ({ ...project.paymentMilestones.find((m) => m.id === a.id)!, ...a }));
  return { summary, milestones, payments: project.payments };
}

async function afterPaymentSuccess(projectId: string, paymentId: string) {
  const allocated = await refreshPaymentMilestones(projectId);
  if (allocated[0]?.status === "PAID") await completeStage(projectId, "ADVANCE_PAYMENT", { notifyCustomer: true });
  const payment = await prisma.payment.findUnique({ where: { id: paymentId }, include: { project: { select: { name: true } } } });
  if (!payment) return;
  const customer = await projectCustomerRecipient(projectId);
  queueNotify({
    event: "PAYMENT_RECEIVED",
    title: `Payment of ${formatINR(payment.amount)} received`,
    body: `We have received ${formatINR(payment.amount)} for ${payment.project.name}. Receipt ${payment.receiptNo} is available in your dashboard.`,
    link: `/dashboard/projects/${projectId}/payments`,
    recipients: [customer],
    notifyAdmins: true,
    whatsappParams: [customer.name || "there", formatINR(payment.amount), payment.project.name],
    ctaLabel: "View receipt",
  });
}

export async function recordPayment(input: {
  projectId: string;
  amount: number;
  method: "CASH" | "UPI" | "BANK_TRANSFER" | "CHEQUE" | "CARD" | "RAZORPAY";
  reference?: string | null;
  paidAt?: Date;
  notes?: string | null;
  paymentMilestoneId?: string | null;
  recordedById?: string | null;
}) {
  if (!(input.amount > 0)) throw badRequest("Amount must be greater than zero.");
  const payment = await prisma.$transaction(async (tx) => {
    const receiptNo = await nextReceiptNumber(tx);
    return tx.payment.create({
      data: {
        projectId: input.projectId,
        amount: round2(input.amount),
        method: input.method,
        reference: input.reference ?? null,
        paidAt: input.paidAt ?? new Date(),
        notes: input.notes ?? null,
        paymentMilestoneId: input.paymentMilestoneId ?? null,
        recordedById: input.recordedById ?? null,
        status: "SUCCESS",
        receiptNo,
      },
    });
  });
  await afterPaymentSuccess(input.projectId, payment.id);
  return payment;
}

/** Sends a payment reminder for the next unpaid milestone. */
export async function sendPaymentReminder(projectId: string) {
  const overview = await getPaymentOverview(projectId);
  const next = overview.milestones.find((m) => m.status !== "PAID");
  if (!next) throw badRequest("All payment milestones are fully paid.");
  const project = await prisma.project.findUnique({ where: { id: projectId }, select: { name: true } });
  const customer = await projectCustomerRecipient(projectId);
  queueNotify({
    event: "PAYMENT_REMINDER",
    title: `Payment reminder: ${next.name}`,
    body: `A payment of ${formatINR(next.balance)} is due for “${next.name}” on ${project?.name ?? "your project"}. You can view the schedule${env.razorpay().keyId ? " and pay online" : ""} from your dashboard.`,
    link: `/dashboard/projects/${projectId}/payments`,
    recipients: [customer],
    whatsappParams: [customer.name || "there", formatINR(next.balance), next.name],
    ctaLabel: "View payment schedule",
  });
  return next;
}

// ── Razorpay (optional) ─────────────────────────────────────────

function razorpayCfg() {
  const r = env.razorpay();
  if (!r.keyId || !r.keySecret) throw notConfigured("Online payments are not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to enable them.");
  return r;
}

export async function createRazorpayOrder(projectId: string, amount: number, milestoneId: string | null) {
  const cfg = razorpayCfg();
  if (!(amount >= 1)) throw badRequest("Minimum online payment is ₹1.");
  const paise = Math.round(round2(amount) * 100);
  const res = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: { Authorization: `Basic ${Buffer.from(`${cfg.keyId}:${cfg.keySecret}`).toString("base64")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ amount: paise, currency: "INR", receipt: `prj_${projectId.slice(-10)}_${Date.now().toString(36)}`, notes: { projectId, milestoneId: milestoneId ?? "" } }),
  });
  const json = (await res.json().catch(() => ({}))) as { id?: string; error?: { description?: string } };
  if (!res.ok || !json.id) throw badRequest(json.error?.description ?? "Could not create the online payment order.");
  await prisma.payment.create({
    data: { projectId, amount: round2(amount), method: "RAZORPAY", status: "PENDING", gatewayOrderId: json.id, paymentMilestoneId: milestoneId, notes: "Online payment initiated" },
  });
  return { orderId: json.id, amount: paise, currency: "INR", keyId: cfg.keyId };
}

function safeEqualHex(a: string, b: string) {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

export function verifyRazorpaySignature(orderId: string, paymentId: string, signature: string, secret: string) {
  const expected = createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  return safeEqualHex(expected, signature);
}

export function verifyRazorpayWebhook(rawBody: string, signature: string, secret: string) {
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  return safeEqualHex(expected, signature);
}

/** Marks a gateway payment successful (idempotent). */
export async function confirmGatewayPayment(orderId: string, paymentId: string) {
  const payment = await prisma.payment.findUnique({ where: { gatewayOrderId: orderId } });
  if (!payment) throw notFound("Payment order not found.");
  if (payment.status === "SUCCESS") return payment;
  const updated = await prisma.$transaction(async (tx) => {
    const receiptNo = await nextReceiptNumber(tx);
    return tx.payment.update({ where: { id: payment.id }, data: { status: "SUCCESS", gatewayPaymentId: paymentId, reference: paymentId, receiptNo, paidAt: new Date(), notes: "Paid online via Razorpay" } });
  });
  await afterPaymentSuccess(payment.projectId, payment.id);
  return updated;
}

export async function verifyAndConfirm(orderId: string, paymentId: string, signature: string) {
  const cfg = razorpayCfg();
  if (!verifyRazorpaySignature(orderId, paymentId, signature, cfg.keySecret)) throw badRequest("Payment signature verification failed.");
  return confirmGatewayPayment(orderId, paymentId);
}
