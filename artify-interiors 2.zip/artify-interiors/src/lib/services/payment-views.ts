import "server-only";
import { getPaymentOverview } from "@/lib/services/payments";
import type { PaymentsData } from "@/components/payments/payments-panel";

export async function loadPaymentsData(projectId: string): Promise<PaymentsData> {
  const o = await getPaymentOverview(projectId);
  return {
    summary: o.summary,
    milestones: o.milestones.map((m) => ({ id: m.id, name: m.name, percent: m.percent, amount: m.amount, received: m.received, balance: m.balance, status: m.status, overdue: m.overdue, dueDate: m.dueDate ? new Date(m.dueDate).toISOString() : null })),
    payments: o.payments.map((p) => ({ id: p.id, receiptNo: p.receiptNo, amount: p.amount, method: p.method, reference: p.reference, status: p.status, paidAt: p.paidAt.toISOString(), notes: p.notes })),
  };
}
