import "server-only";
import { prisma } from "@/lib/db";
import type { QuotationRow } from "@/components/quotations/quotations-panel";

export async function loadQuotationRows(projectId: string, opts: { includeDrafts: boolean }): Promise<QuotationRow[]> {
  const rows = await prisma.quotation.findMany({
    where: { projectId, ...(opts.includeDrafts ? {} : { status: { not: "DRAFT" } }) },
    orderBy: { createdAt: "desc" },
    include: { boq: { select: { version: true } } },
  });
  return rows.map((q) => ({
    id: q.id,
    number: q.number,
    revision: q.revision,
    status: q.status,
    isPreliminary: q.isPreliminary,
    grandTotal: q.grandTotal,
    gstAmount: q.gstAmount,
    subtotal: q.subtotal,
    createdAt: q.createdAt.toISOString(),
    validUntil: q.validUntil.toISOString(),
    sentAt: q.sentAt?.toISOString() ?? null,
    emailedAt: q.emailedAt?.toISOString() ?? null,
    approvedAt: q.approvedAt?.toISOString() ?? null,
    approvedByName: q.approvedByName,
    clientComment: q.clientComment,
    boqVersion: q.boq?.version ?? null,
  }));
}
