import "server-only";
import sharp from "sharp";
import { prisma } from "@/lib/db";
import { badRequest, notConfigured, notFound } from "@/lib/api";
import { getImageProvider, getTextProvider } from "@/lib/ai";
import { AINotConfiguredError } from "@/lib/ai/types";
import { DESIGN_SYSTEM_PROMPT, buildConceptPrompt, buildImagePrompt, buildRevisionPrompt, type PromptContext } from "@/lib/ai/prompts";
import { normaliseStyle, normaliseTier, parseDesignOutput, type ConceptOutput } from "@/lib/ai/schema";
import { aiImageStatus, env } from "@/lib/env";
import { estimateRooms, resolveDims, tierFromBudget, type MaterialPick } from "@/lib/boq/engine";
import { BUDGET_RANGES, ROOM_LABELS, ROOM_MODULE_BY_TYPE, type DesignStyleKey, type MaterialCategoryKey, type PriceTierKey, type RoomTypeKey } from "@/lib/constants";
import { formatINR } from "@/lib/format";
import { recommendMaterials, type RecMaterial } from "@/lib/materials/recommend";
import { loadActiveMaterials, loadRoomSelections, loadTierContext } from "@/lib/services/materials";
import { toAIImage } from "@/lib/services/files";
import { saveBuffer } from "@/lib/storage";
import { getSettings } from "@/lib/settings";
import { completeStage } from "@/lib/services/workflow";
import { queueNotify, projectCustomerRecipient } from "@/lib/notifications";
import { logError } from "@/lib/logger";
import type { CurrentUser } from "@/lib/auth/session";

type MaterialSuggestion = { category: string; materialId: string | null; name: string; brand?: string | null; rate?: number | null; unit?: string | null; application: string };

function budgetText(min: number | null, max: number | null) {
  const match = BUDGET_RANGES.find((b) => b.min === min && b.max === max);
  if (match) return match.label;
  if (min || max) return `${formatINR(min ?? 0)} – ${formatINR(max ?? 0)}`;
  return "not specified";
}

async function buildContext(projectId: string, roomId: string | null, fileIds: string[], variations: number, instructions?: string | null) {
  const project = await prisma.project.findUnique({ where: { id: projectId }, include: { rooms: { orderBy: { sortOrder: "asc" } } } });
  if (!project) throw notFound("Project not found.");
  const room = roomId ? project.rooms.find((r) => r.id === roomId) : project.rooms[0];
  if (!room) throw badRequest("Add a room to this project before generating designs.");

  const dims = resolveDims({ name: room.name, type: room.type as RoomTypeKey, lengthFt: room.lengthFt, widthFt: room.widthFt, heightFt: room.heightFt });
  const style = (room.style ?? project.designStyle ?? "MODERN") as DesignStyleKey;
  const tier = (room.tier ?? tierFromBudget(project.budgetMax, project.carpetAreaSqft)) as PriceTierKey;

  // Images: chosen files, otherwise the latest room photos / references / plans for this room
  const files = await prisma.uploadedFile.findMany({
    where: fileIds.length
      ? { id: { in: fileIds }, projectId }
      : { projectId, category: { in: ["ROOM_PHOTO", "REFERENCE", "FLOOR_PLAN"] }, OR: [{ roomId: room.id }, { roomId: null }] },
    orderBy: { createdAt: "desc" },
    take: 12,
  });
  const imageFiles = files
    .filter((f) => f.mimeType.startsWith("image/"))
    .sort((a, b) => order(a.category) - order(b.category))
    .slice(0, 3);

  const materials = await loadActiveMaterials();
  const categories = (ROOM_MODULE_BY_TYPE[room.type as RoomTypeKey]?.materialCategories ?? []) as MaterialCategoryKey[];
  const shortlist = recommendMaterials(materials, { style, tier, preferences: [project.materialPreferences, room.preferences].filter(Boolean).join(". ") }, { perCategory: 3, categories });

  const ctx: PromptContext = {
    project: {
      propertyType: project.propertyType,
      carpetAreaSqft: project.carpetAreaSqft,
      location: project.location,
      budgetText: budgetText(project.budgetMin, project.budgetMax),
      colorPalette: project.colorPalette,
      materialPreferences: project.materialPreferences,
      timeline: project.timeline,
    },
    room: { name: room.name, type: room.type as RoomTypeKey, ...dims, preferences: room.preferences },
    style,
    tier,
    variations,
    photoNotes: imageFiles.map((f) => (f.category === "ROOM_PHOTO" ? "Photograph of the existing room" : f.category === "FLOOR_PLAN" ? "Floor plan" : "Reference image the customer likes")),
    instructions,
    shortlist,
  };
  return { project, room, dims, style, tier, imageFiles, materials, shortlist, ctx };
}

function order(cat: string) {
  return cat === "ROOM_PHOTO" ? 0 : cat === "REFERENCE" ? 1 : 2;
}

function mapMaterials(concept: ConceptOutput, library: Map<string, RecMaterial>): MaterialSuggestion[] {
  return concept.materials.map((m) => {
    const lib = m.materialId ? library.get(m.materialId) : undefined;
    return {
      category: lib?.category ?? m.category.toUpperCase(),
      materialId: lib?.id ?? null,
      name: lib ? lib.name : m.name,
      brand: lib?.brand ?? null,
      rate: lib?.rate ?? null,
      unit: lib?.unit ?? null,
      application: m.application,
    };
  });
}

async function conceptBudget(
  room: { name: string; type: string; lengthFt: number | null; widthFt: number | null; heightFt: number | null; id: string },
  tier: PriceTierKey,
  materials: MaterialSuggestion[],
  library: Map<string, RecMaterial>,
) {
  const settings = await getSettings();
  const selected: Partial<Record<MaterialCategoryKey, MaterialPick>> = { ...(await loadRoomSelections(room.id)) };
  for (const s of materials) {
    const lib = s.materialId ? library.get(s.materialId) : undefined;
    if (lib && !selected[lib.category]) selected[lib.category] = { id: lib.id, name: lib.name, brand: lib.brand, finish: lib.finish, rate: lib.rate, unit: lib.unit };
  }
  const est = estimateRooms([{ name: room.name, type: room.type as RoomTypeKey, lengthFt: room.lengthFt, widthFt: room.widthFt, heightFt: room.heightFt }], tier, {
    rateCard: settings.rateCard,
    ctx: { selected, byTier: await loadTierContext([...library.values()]) },
    charges: { gstRate: settings.tax.gstRate, wastagePercent: settings.boqDefaults.wastagePercent, profitMarginPercent: settings.boqDefaults.profitMarginPercent },
    includeExtras: false,
  });
  const total = est.totals.grandTotal;
  return { min: Math.round((total * 0.9) / 1000) * 1000, max: Math.round((total * 1.15) / 1000) * 1000 };
}

/** Step 3 of the AI designer: analyse photos + preferences and create design concepts. */
export async function generateConcepts(opts: { projectId: string; roomId: string | null; fileIds: string[]; instructions?: string | null; variations?: number; user: CurrentUser }) {
  const variations = Math.min(Math.max(opts.variations ?? env.ai().variations, 1), 4);
  const base = await buildContext(opts.projectId, opts.roomId, opts.fileIds, variations, opts.instructions);

  const request = await prisma.aIDesignRequest.create({
    data: {
      projectId: opts.projectId,
      roomId: base.room.id,
      requestedById: opts.user.id,
      status: "PROCESSING",
      variationsRequested: variations,
      inputFileIds: base.imageFiles.map((f) => f.id),
      instructions: opts.instructions ?? null,
    },
  });

  let provider;
  try {
    provider = getTextProvider();
  } catch (err) {
    if (err instanceof AINotConfiguredError) {
      await prisma.aIDesignRequest.update({ where: { id: request.id }, data: { status: "NOT_CONFIGURED", errorMessage: err.message, completedAt: new Date() } });
      throw notConfigured(err.message, { requestId: request.id });
    }
    throw err;
  }

  const started = Date.now();
  try {
    const images = await Promise.all(base.imageFiles.map((f) => toAIImage(f)));
    const prompt = buildConceptPrompt(base.ctx);
    let output;
    try {
      output = parseDesignOutput(await provider.generateJSON({ system: DESIGN_SYSTEM_PROMPT, prompt, images }));
    } catch (firstErr) {
      // one retry — models occasionally return malformed JSON
      logError("ai.generate.retry", firstErr, { requestId: request.id });
      output = parseDesignOutput(await provider.generateJSON({ system: DESIGN_SYSTEM_PROMPT, prompt: `${prompt}\n\nIMPORTANT: return strictly valid JSON in the exact shape above.`, images }));
    }

    const library = new Map(base.materials.map((m) => [m.id, m]));
    const imageReady = aiImageStatus().configured;
    const designs = [];
    for (const concept of output.concepts.slice(0, variations)) {
      const tier = normaliseTier(concept.tier, base.tier);
      const materials = mapMaterials(concept, library);
      const budget = await conceptBudget(base.room, tier, materials, library);
      designs.push(
        await prisma.generatedDesign.create({
          data: {
            projectId: opts.projectId,
            roomId: base.room.id,
            requestId: request.id,
            name: concept.name,
            style: normaliseStyle(concept.style, base.style),
            tier,
            summary: concept.summary,
            colorPalette: concept.colorPalette,
            materialSuggestions: materials,
            furnitureSuggestions: concept.furniture,
            furnitureLayout: concept.furnitureLayout,
            wallFinish: concept.wallFinish,
            ceilingDesign: concept.ceilingDesign,
            lighting: concept.lighting,
            flooring: concept.flooring,
            decor: concept.decor,
            estimatedBudgetMin: budget.min,
            estimatedBudgetMax: budget.max,
            imagePrompt: concept.imagePrompt,
            imageStatus: imageReady ? "PENDING" : "NOT_CONFIGURED",
            imageError: imageReady ? null : aiImageStatus().detail,
          },
        }),
      );
    }

    await prisma.aIDesignRequest.update({
      where: { id: request.id },
      data: {
        status: "COMPLETED",
        textProvider: provider.name,
        textModel: provider.model,
        imageProvider: imageReady ? aiImageStatus().provider : null,
        analysis: output.roomAnalysis ?? undefined,
        durationMs: Date.now() - started,
        completedAt: new Date(),
      },
    });
    if (base.project.status === "DRAFT") await prisma.project.update({ where: { id: opts.projectId }, data: { status: "DESIGN" } });
    await completeStage(opts.projectId, "CONCEPT_DESIGN");

    const customer = await projectCustomerRecipient(opts.projectId);
    queueNotify({
      event: "DESIGN_COMPLETED",
      title: `${designs.length} new design concepts are ready`,
      body: `Your AI design concepts for ${base.room.name} in ${base.project.name} are ready to review and compare.`,
      link: `/dashboard/projects/${opts.projectId}/designs`,
      recipients: customer.userId === opts.user.id ? [{ userId: customer.userId }] : [customer],
      channels: { whatsapp: false, email: customer.userId !== opts.user.id },
      ctaLabel: "View designs",
    });

    return { requestId: request.id, analysis: output.roomAnalysis ?? null, designs };
  } catch (err) {
    const message = (err as Error).message ?? "AI generation failed";
    await prisma.aIDesignRequest.update({ where: { id: request.id }, data: { status: "FAILED", errorMessage: message.slice(0, 1000), durationMs: Date.now() - started, completedAt: new Date() } });
    throw err;
  }
}

/** Renders (or re-renders) the visualization image for one design. */
export async function renderDesignImage(designId: string) {
  const design = await prisma.generatedDesign.findUnique({ where: { id: designId }, include: { request: true, room: true, project: true } });
  if (!design) throw notFound("Design not found.");

  let provider;
  try {
    provider = getImageProvider();
  } catch (err) {
    if (err instanceof AINotConfiguredError) {
      await prisma.generatedDesign.update({ where: { id: designId }, data: { imageStatus: "NOT_CONFIGURED", imageError: err.message } });
      throw notConfigured(err.message);
    }
    throw err;
  }

  await prisma.generatedDesign.update({ where: { id: designId }, data: { imageStatus: "PROCESSING", imageError: null } });
  try {
    const inputIds = design.request?.inputFileIds ?? [];
    const photo = inputIds.length
      ? await prisma.uploadedFile.findFirst({ where: { id: { in: inputIds }, category: "ROOM_PHOTO" } })
      : await prisma.uploadedFile.findFirst({ where: { projectId: design.projectId, category: "ROOM_PHOTO", roomId: design.roomId ?? undefined }, orderBy: { createdAt: "desc" } });
    const reference = photo && provider.supportsEditing ? await toAIImage(photo, 1536) : undefined;

    const roomType = (design.room?.type ?? "LIVING_ROOM") as RoomTypeKey;
    const dims = resolveDims({ name: design.room?.name ?? "Room", type: roomType, lengthFt: design.room?.lengthFt, widthFt: design.room?.widthFt, heightFt: design.room?.heightFt });
    const prompt = buildImagePrompt({
      concept: {
        name: design.name,
        imagePrompt: design.imagePrompt,
        colorPalette: (design.colorPalette as { name: string; hex: string }[]) ?? [],
        materials: (design.materialSuggestions as { name: string; application?: string }[]) ?? [],
        lighting: design.lighting,
        flooring: design.flooring,
      },
      roomLabel: ROOM_LABELS[roomType],
      dims,
      propertyType: design.project.propertyType,
      hasReference: !!reference,
    });

    const result = await provider.generate({ prompt, referenceImage: reference });
    const jpg = await sharp(result.data).jpeg({ quality: 88, mozjpeg: true }).toBuffer();
    const stored = await saveBuffer(jpg, { ext: "jpg", scope: `projects/${design.projectId}/generated` });
    const file = await prisma.uploadedFile.create({
      data: {
        projectId: design.projectId,
        roomId: design.roomId,
        category: "GENERATED",
        originalName: `${design.name.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}.jpg`,
        mimeType: "image/jpeg",
        sizeBytes: jpg.length,
        storageProvider: stored.provider,
        storageKey: stored.storageKey,
        resourceType: stored.resourceType,
      },
    });
    return prisma.generatedDesign.update({
      where: { id: designId },
      data: { imageStatus: "COMPLETED", imageFileId: file.id, imageProvider: `${provider.name} · ${provider.model}`, imageError: null },
    });
  } catch (err) {
    const message = (err as Error).message ?? "Image generation failed";
    await prisma.generatedDesign.update({ where: { id: designId }, data: { imageStatus: "FAILED", imageError: message.slice(0, 500) } });
    throw err;
  }
}

/** Regenerates one design: snapshots the current version as a revision, then asks the AI for a revised concept. */
export async function regenerateDesign(designId: string, changeRequest: string, user: CurrentUser) {
  const design = await prisma.generatedDesign.findUnique({ where: { id: designId }, include: { request: true } });
  if (!design) throw notFound("Design not found.");
  const provider = (() => {
    try {
      return getTextProvider();
    } catch (err) {
      if (err instanceof AINotConfiguredError) throw notConfigured(err.message);
      throw err;
    }
  })();

  const base = await buildContext(design.projectId, design.roomId, design.request?.inputFileIds ?? [], 1, changeRequest);
  const previous = {
    name: design.name,
    style: design.style,
    tier: design.tier,
    summary: design.summary,
    colorPalette: design.colorPalette,
    materials: design.materialSuggestions,
    furniture: design.furnitureSuggestions,
    furnitureLayout: design.furnitureLayout,
    wallFinish: design.wallFinish,
    ceilingDesign: design.ceilingDesign,
    lighting: design.lighting,
    flooring: design.flooring,
    decor: design.decor,
  };
  const images = await Promise.all(base.imageFiles.map((f) => toAIImage(f)));
  const output = parseDesignOutput(await provider.generateJSON({ system: DESIGN_SYSTEM_PROMPT, prompt: buildRevisionPrompt(base.ctx, previous, changeRequest), images }));
  const concept = output.concepts[0]!;
  const library = new Map(base.materials.map((m) => [m.id, m]));
  const tier = normaliseTier(concept.tier, design.tier as PriceTierKey);
  const materials = mapMaterials(concept, library);
  const budget = await conceptBudget(base.room, tier, materials, library);
  const imageReady = aiImageStatus().configured;

  return prisma.$transaction(async (tx) => {
    await tx.designRevision.create({
      data: {
        designId,
        revisionNo: design.revisionNo,
        changeRequest,
        createdById: user.id,
        snapshot: { ...previous, imageFileId: design.imageFileId, estimatedBudgetMin: design.estimatedBudgetMin, estimatedBudgetMax: design.estimatedBudgetMax },
      },
    });
    return tx.generatedDesign.update({
      where: { id: designId },
      data: {
        name: concept.name,
        style: normaliseStyle(concept.style, design.style as DesignStyleKey),
        tier,
        summary: concept.summary,
        colorPalette: concept.colorPalette,
        materialSuggestions: materials,
        furnitureSuggestions: concept.furniture,
        furnitureLayout: concept.furnitureLayout,
        wallFinish: concept.wallFinish,
        ceilingDesign: concept.ceilingDesign,
        lighting: concept.lighting,
        flooring: concept.flooring,
        decor: concept.decor,
        estimatedBudgetMin: budget.min,
        estimatedBudgetMax: budget.max,
        imagePrompt: concept.imagePrompt,
        imageStatus: imageReady ? "PENDING" : "NOT_CONFIGURED",
        imageFileId: null,
        imageError: imageReady ? null : aiImageStatus().detail,
        status: "GENERATED",
        revisionNo: design.revisionNo + 1,
      },
    });
  });
}
