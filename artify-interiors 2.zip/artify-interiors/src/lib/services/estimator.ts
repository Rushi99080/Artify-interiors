import "server-only";
import type { MaterialContext, RateCard } from "@/lib/boq/engine";
import type { BOQCharges } from "@/lib/calc/boq";
import { getSettings } from "@/lib/settings";
import { loadTierContext } from "@/lib/services/materials";

export type EstimatorData = { rateCard: RateCard; byTier: MaterialContext["byTier"]; charges: BOQCharges };

/** Everything the client-side estimators need (public pricing data only — no margins exposed separately). */
export async function getEstimatorData(): Promise<EstimatorData> {
  const settings = await getSettings();
  let byTier: MaterialContext["byTier"] = {};
  try {
    byTier = await loadTierContext();
  } catch {
    byTier = {};
  }
  return {
    rateCard: settings.rateCard,
    byTier,
    charges: {
      gstRate: settings.tax.gstRate,
      wastagePercent: settings.boqDefaults.wastagePercent,
      profitMarginPercent: settings.boqDefaults.profitMarginPercent,
      transportCharges: 0,
      installationCharges: 0,
      discountAmount: 0,
    },
  };
}
