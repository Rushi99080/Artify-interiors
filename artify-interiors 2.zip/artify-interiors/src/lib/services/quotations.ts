import "server-only";
import { prisma } from "@/lib/db";
import { badRequest, forbidden, notFound } from "@/lib/api";
import { getSettings } from "@/lib/settings";
import { nextQuotationBaseNumber } from "@/lib/counters";
import { buildQuotationSnapshot, type QuotationSnapshot } from "@/lib/quotation/snapshot";
import { renderQuotationPdf } from "@/lib/pdf/quotation";
import { queueNotify, projectCustomerRecipient, notify } from "@/lib/notifications";
import { ensurePaymentSchedule, rescalePaymentSchedule } from "@/lib/services/payments";
import { completeStage, onQuotationApproved } from "@/lib/services/workflow";
import { formatINR } from "@/lib/format";
import { readBuffer } from "@/lib/storage";
import type { CurrentUser } from "@/lib/auth/session";
import { isTeamRole } from "@/lib/auth/token";

/** Creates a quotation (or a revision of an existing one) from a BOQ, freezing a snapshot. */
export async function createQuotation(opts: { boqId: string; user: CurrentUser | null; send?: boolean; parentId?: string | null; overrides?: Partial<{ scopeOfWork: string; paymentTerms: string; timelineText: string; terms: string; validityDays: number }> }) {
  const boq = await prisma.bOQ.findUnique({
    where: { id: opts.boqId },
    include: { items: true, project: { include: { customer: true } } },
  });
  if (!boq) throw notFound("BOQ not found.");
  if (boq.items.length === 0) throw badRequest("This BOQ has no items.");
  const settings = await getSettings();
  const project = boq.project;

  const materialIds = [...new Set(boq.items.map((i) => i.materialId).filter(Boolean))] as string[];
  const specs = materialIds.length ? Object.fromEntries((await prisma.material.findMany({ where: { id: { in: materialIds } }, select: { id: true, specifications: true } })).map((m) => [m.id, m.specifications])) : {};

  const snapshot = buildQuotationSnapshot({
    company: {
      name: settings.company.name,
      legalName: settings.company.legalName,
      tagline: settings.company.tagline,
      address: settings.company.address,
      phone: settings.company.phone,
      email: settings.company.email,
      website: settings.company.website,
      gstin: settings.company.gstin,
      logoUrl: settings.company.logoUrl,
      bankDetails: settings.company.bankDetails,
    },
    client: { name: project.customer.fullName, email: project.customer.email, phone: project.customer.phone, address: project.customer.address },
    project: { name: project.name, code: project.code, location: project.location, address: project.address, propertyType: project.propertyType, carpetAreaSqft: project.carpetAreaSqft },
    marginLabel: settings.boqDefaults.marginLabel,
    boq,
    specs,
  });

  const validityDays = opts.overrides?.validityDays ?? settings.quotation.validityDays;
  const parent = opts.parentId ? await prisma.quotation.findUnique({ where: { id: opts.parentId } }) : null;
  if (opts.parentId && !parent) throw notFound("Original quotation not found.");
  if (parent && parent.projectId !== project.id) throw badRequest("Revision must belong to the same project.");

  const quotation = await prisma.$transaction(async (tx) => {
    let baseNumber: string;
    let revision = 0;
    if (parent) {
      baseNumber = parent.baseNumber;
      const agg = await tx.quotation.aggregate({ where: { baseNumber }, _max: { revision: true } });
      revision = (agg._max.revision ?? 0) + 1;
      await tx.quotation.updateMany({ where: { baseNumber, status: { in: ["DRAFT", "SENT", "CHANGES_REQUESTED"] } }, data: { status: "SUPERSEDED" } });
    } else {
      baseNumber = await nextQuotationBaseNumber(settings.quotation.prefix, tx);
    }
    return tx.quotation.create({
      data: {
        number: revision ? `${baseNumber}-R${revision}` : baseNumber,
        baseNumber,
        revision,
        projectId: project.id,
        boqId: boq.id,
        parentId: parent?.id ?? null,
        status: opts.send ? "SENT" : "DRAFT",
        sentAt: opts.send ? new Date() : null,
        isPreliminary: boq.status === "PRELIMINARY",
        snapshot: snapshot as unknown as object,
        subtotal: snapshot.totals.subtotal,
        taxableAmount: snapshot.totals.taxableAmount,
        gstAmount: snapshot.totals.gstAmount,
        grandTotal: snapshot.totals.grandTotal,
        validUntil: new Date(Date.now() + validityDays * 86400000),
        scopeOfWork: opts.overrides?.scopeOfWork ?? settings.quotation.scopeOfWork,
        paymentTerms: opts.overrides?.paymentTerms ?? settings.quotation.paymentTerms,
        timelineText: opts.overrides?.timelineText ?? settings.quotation.timelineText,
        terms: opts.overrides?.terms ?? settings.quotation.terms,
        createdById: opts.user?.id ?? null,
      },
    });
  });

  if (["DRAFT", "DESIGN"].includes(project.status)) await prisma.project.update({ where: { id: project.id }, data: { status: "QUOTATION" } });
  if (opts.send) await announceQuotation(quotation.id);
  return quotation;
}

/** Marks a draft as sent and notifies the client (in-app, email with PDF, WhatsApp template). */
export async function sendQuotation(quotationId: string) {
  const q = await prisma.quotation.findUnique({ where: { id: quotationId } });
  if (!q) throw notFound("Quotation not found.");
  if (!["DRAFT", "SENT", "CHANGES_REQUESTED"].includes(q.status)) throw badRequest(`A ${q.status.toLowerCase()} quotation cannot be sent.`);
  await prisma.quotation.update({ where: { id: quotationId }, data: { status: "SENT", sentAt: new Date() } });
  await announceQuotation(quotationId);
}

async function announceQuotation(quotationId: string) {
  const q = await prisma.quotation.findUnique({ where: { id: quotationId }, include: { project: { select: { id: true, name: true } } } });
  if (!q) return;
  await prisma.lead.updateMany({ where: { projectId: q.projectId, status: { in: ["NEW", "CONTACTED", "CONSULTATION"] } }, data: { status: "QUOTATION_SENT" } });
  const customer = await projectCustomerRecipient(q.projectId);
  queueNotify({
    event: "QUOTATION_GENERATED",
    title: `${q.isPreliminary ? "Preliminary quotation" : "Quotation"} ${q.number} is ready`,
    body: `Your ${q.isPreliminary ? "preliminary " : ""}quotation for ${q.project.name} totals ${formatINR(q.grandTotal)} including GST. Review the room-wise BOQ and ${q.isPreliminary ? "request a final quotation" : "approve it"} from your dashboard.`,
    link: `/dashboard/projects/${q.projectId}/quotations`,
    recipients: [customer],
    whatsappParams: [customer.name || "there", q.number, formatINR(q.grandTotal)],
    ctaLabel: "View quotation",
  });
}

export async function quotationPdfData(quotationId: string) {
  const q = await prisma.quotation.findUnique({ where: { id: quotationId } });
  if (!q) throw notFound("Quotation not found.");
  const snapshot = q.snapshot as unknown as QuotationSnapshot;
  let logo: { data: Buffer; format: "png" | "jpg" } | null = null;
  const logoUrl = snapshot.company.logoUrl;
  if (logoUrl) {
    try {
      const fileId = /\/api\/files\/([a-z0-9]+)/i.exec(logoUrl)?.[1];
      if (fileId) {
        const f = await prisma.uploadedFile.findUnique({ where: { id: fileId } });
        if (f) logo = { data: await readBuffer(f), format: f.mimeType === "image/png" ? "png" : "jpg" };
      } else if (/^https?:\/\//.test(logoUrl)) {
        const res = await fetch(logoUrl);
        if (res.ok) logo = { data: Buffer.from(await res.arrayBuffer()), format: logoUrl.toLowerCase().includes(".png") ? "png" : "jpg" };
      }
    } catch {
      logo = null;
    }
  }
  return { q, data: { number: q.number, revision: q.revision, status: q.status, isPreliminary: q.isPreliminary, createdAt: q.createdAt, validUntil: q.validUntil, scopeOfWork: q.scopeOfWork, paymentTerms: q.paymentTerms, timelineText: q.timelineText, terms: q.terms, approvedAt: q.approvedAt, approvedByName: q.approvedByName, snapshot, logo } };
}

export async function quotationPdf(quotationId: string) {
  const { q, data } = await quotationPdfData(quotationId);
  const buffer = await renderQuotationPdf(data);
  return { buffer, filename: `${q.number.replace(/\//g, "-")}.pdf` };
}

/** Emails the quotation PDF to the client (awaits the provider so the UI can show the real result). */
export async function emailQuotation(quotationId: string) {
  const q = await prisma.quotation.findUnique({ where: { id: quotationId }, include: { project: { select: { name: true } } } });
  if (!q) throw notFound("Quotation not found.");
  const customer = await projectCustomerRecipient(q.projectId);
  if (!customer.email) throw badRequest("The client has no email address on file.");
  const { buffer, filename } = await quotationPdf(quotationId);
  await notify({
    event: "QUOTATION_GENERATED",
    title: `Quotation ${q.number}`,
    body: `Please find attached the quotation for ${q.project.name}. Total project cost: ${formatINR(q.grandTotal)} including GST.\n\nYou can also review and approve it online from your dashboard.`,
    link: `/dashboard/projects/${q.projectId}/quotations`,
    recipients: [{ email: customer.email }],
    channels: { whatsapp: false },
    attachments: [{ filename, content: buffer, contentType: "application/pdf" }],
    ctaLabel: "Open quotation",
  });
  const last = await prisma.notification.findFirst({ where: { event: "QUOTATION_GENERATED", channel: "EMAIL", recipient: customer.email }, orderBy: { createdAt: "desc" } });
  if (last?.status === "SENT") {
    await prisma.quotation.update({ where: { id: quotationId }, data: { emailedAt: new Date(), ...(q.status === "DRAFT" ? { status: "SENT", sentAt: new Date() } : {}) } });
  }
  return { status: last?.status ?? "FAILED", error: last?.error ?? null, to: customer.email };
}

/**
 * Approves a quotation and converts the project into an active project:
 * contract value set, payment schedule created, workflow advanced, team notified.
 */
export async function approveQuotation(quotationId: string, user: CurrentUser, opts: { approvedByName?: string; comment?: string }) {
  const q = await prisma.quotation.findUnique({ where: { id: quotationId }, include: { project: { include: { customer: true } } } });
  if (!q) throw notFound("Quotation not found.");
  const team = isTeamRole(user.role);
  if (!team && q.project.customer.userId !== user.id) throw forbidden();
  if (q.status === "APPROVED") return q;
  if (!["SENT", "CHANGES_REQUESTED", ...(team ? ["DRAFT"] : [])].includes(q.status)) throw badRequest(`A ${q.status.toLowerCase().replace("_", " ")} quotation cannot be approved.`);
  if (q.validUntil.getTime() < Date.now() && !team) throw badRequest("This quotation has expired. Please request a revised quotation.");
  if (q.isPreliminary && !team) {
    throw badRequest("This is a preliminary estimate. Request a final quotation — our team will verify site measurements first.");
  }

  const approved = await prisma.$transaction(async (tx) => {
    const updated = await tx.quotation.update({
      where: { id: quotationId },
      data: { status: "APPROVED", approvedAt: new Date(), approvedByName: opts.approvedByName || (team ? `${user.name} (on behalf of client)` : user.name), clientComment: opts.comment ?? q.clientComment },
    });
    await tx.quotation.updateMany({ where: { projectId: q.projectId, id: { not: quotationId }, status: { in: ["DRAFT", "SENT", "CHANGES_REQUESTED"] } }, data: { status: "SUPERSEDED" } });
    if (q.boqId) await tx.bOQ.update({ where: { id: q.boqId }, data: { status: "FINAL" } });
    await tx.lead.updateMany({ where: { projectId: q.projectId, status: { not: "CONVERTED" } }, data: { status: "CONVERTED" } });
    return updated;
  });

  await activateProjectFromQuotation(quotationId);

  queueNotify({
    event: "QUOTATION_APPROVED",
    title: `Quotation ${q.number} approved`,
    body: `${q.project.customer.fullName} approved quotation ${q.number} for ${q.project.name} (${formatINR(q.grandTotal)}). The project is now active.${opts.comment ? `\n\nClient comment: ${opts.comment}` : ""}`,
    link: `/admin/projects/${q.projectId}`,
    notifyAdmins: true,
    whatsappParams: [q.project.customer.fullName, q.number, formatINR(q.grandTotal)],
  });
  const customer = await projectCustomerRecipient(q.projectId);
  queueNotify({
    event: "QUOTATION_APPROVED",
    title: "Thank you — your project is confirmed",
    body: `Quotation ${q.number} for ${q.project.name} has been approved. Your payment schedule and project timeline are now available in your dashboard.`,
    link: `/dashboard/projects/${q.projectId}`,
    recipients: [customer],
    channels: { whatsapp: false },
  });
  return approved;
}

/** Idempotent: make sure an approved quotation has an active project with contract, schedule and workflow. */
export async function activateProjectFromQuotation(quotationId: string) {
  const q = await prisma.quotation.findUnique({ where: { id: quotationId } });
  if (!q) throw notFound("Quotation not found.");
  if (q.status !== "APPROVED") throw badRequest("Only approved quotations can be converted into an active project.");
  const project = await prisma.project.findUnique({ where: { id: q.projectId } });
  if (!project) throw notFound("Project not found.");
  const contractChanged = project.contractValue !== q.grandTotal;
  await prisma.project.update({
    where: { id: q.projectId },
    data: { status: ["COMPLETED", "CANCELLED"].includes(project.status) ? project.status : "ACTIVE", contractValue: q.grandTotal, approvedQuotationId: q.id },
  });
  if (contractChanged && project.contractValue) await rescalePaymentSchedule(q.projectId, q.grandTotal);
  else await ensurePaymentSchedule(q.projectId, q.grandTotal);
  await onQuotationApproved(q.projectId);
  return prisma.project.findUnique({ where: { id: q.projectId } });
}

export async function requestQuotationChanges(quotationId: string, user: CurrentUser, comment: string) {
  const q = await prisma.quotation.findUnique({ where: { id: quotationId }, include: { project: { include: { customer: true } } } });
  if (!q) throw notFound("Quotation not found.");
  if (!isTeamRole(user.role) && q.project.customer.userId !== user.id) throw forbidden();
  if (!["SENT", "DRAFT"].includes(q.status)) throw badRequest("Changes can only be requested on a sent quotation.");
  const updated = await prisma.quotation.update({ where: { id: quotationId }, data: { status: "CHANGES_REQUESTED", clientComment: comment } });
  queueNotify({
    event: "QUOTATION_CHANGES_REQUESTED",
    title: `${q.isPreliminary ? "Final quotation requested" : "Changes requested"} — ${q.number}`,
    body: `${q.project.customer.fullName} ${q.isPreliminary ? "requested a final quotation (site measurement)" : "requested changes"} for ${q.project.name}.\n\n“${comment}”`,
    link: `/admin/projects/${q.projectId}`,
    notifyAdmins: true,
    channels: { whatsapp: false },
  });
  if (q.isPreliminary) await completeStage(q.projectId, "INITIAL_CONSULTATION");
  return updated;
}
