import "server-only";
import { prisma } from "@/lib/db";
import { round2 } from "@/lib/calc/boq";

const monthKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const monthLabel = (key: string) => {
  const [y, m] = key.split("-").map(Number);
  return new Date(y!, m! - 1, 1).toLocaleDateString("en-IN", { month: "short", year: "2-digit" });
};

function lastMonths(n: number) {
  const out: string[] = [];
  const d = new Date();
  d.setDate(1);
  for (let i = n - 1; i >= 0; i--) {
    const x = new Date(d.getFullYear(), d.getMonth() - i, 1);
    out.push(monthKey(x));
  }
  return out;
}

/** Admin overview analytics — all figures computed from stored records. */
export async function adminAnalytics() {
  const since = new Date();
  since.setMonth(since.getMonth() - 11, 1);
  since.setHours(0, 0, 0, 0);
  const thirtyDays = new Date(Date.now() - 30 * 86400000);

  const [payments, expenses, activeProjects, leads30, newLeads, leadsBySource, leadMonthly, quotes, projects, statusGroups, followUps, recentLeads, pendingDesigns, aiRequests] = await Promise.all([
    prisma.payment.findMany({ where: { status: "SUCCESS" }, select: { amount: true, paidAt: true } }),
    prisma.expense.findMany({ select: { amount: true, category: true, spentAt: true } }),
    prisma.project.count({ where: { status: "ACTIVE" } }),
    prisma.lead.count({ where: { createdAt: { gte: thirtyDays } } }),
    prisma.lead.count({ where: { status: "NEW" } }),
    prisma.lead.groupBy({ by: ["source"], _count: true, where: { createdAt: { gte: since } } }),
    prisma.lead.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
    prisma.quotation.findMany({ where: { status: { not: "DRAFT" } }, select: { baseNumber: true, status: true } }),
    prisma.project.findMany({
      where: { contractValue: { not: null } },
      select: {
        id: true,
        code: true,
        name: true,
        status: true,
        contractValue: true,
        payments: { where: { status: "SUCCESS" }, select: { amount: true } },
        expenses: { select: { amount: true, category: true } },
        approvedQuotation: { select: { snapshot: true, gstAmount: true } },
      },
      orderBy: { updatedAt: "desc" },
    }),
    prisma.project.groupBy({ by: ["status"], _count: true }),
    prisma.lead.findMany({ where: { followUpDate: { lte: new Date(Date.now() + 86400000) }, status: { notIn: ["CONVERTED", "LOST"] } }, orderBy: { followUpDate: "asc" }, take: 6, select: { id: true, leadCode: true, name: true, phone: true, followUpDate: true, status: true } }),
    prisma.lead.findMany({ orderBy: { createdAt: "desc" }, take: 5, select: { id: true, leadCode: true, name: true, source: true, status: true, createdAt: true } }),
    prisma.generatedDesign.count({ where: { status: { in: ["APPROVED", "CHANGES_REQUESTED"] }, adminNotes: null } }),
    prisma.aIDesignRequest.groupBy({ by: ["status"], _count: true, where: { createdAt: { gte: thirtyDays } } }),
  ]);

  const totalRevenue = round2(payments.reduce((s, p) => s + p.amount, 0));
  const months = lastMonths(12);
  const revenueByMonth = new Map(months.map((m) => [m, 0]));
  for (const p of payments) {
    const k = monthKey(p.paidAt);
    if (revenueByMonth.has(k)) revenueByMonth.set(k, revenueByMonth.get(k)! + p.amount);
  }
  const expenseByMonth = new Map(months.map((m) => [m, 0]));
  for (const e of expenses) {
    const k = monthKey(e.spentAt);
    if (expenseByMonth.has(k)) expenseByMonth.set(k, expenseByMonth.get(k)! + e.amount);
  }
  const leadsByMonth = new Map(months.map((m) => [m, 0]));
  for (const l of leadMonthly) {
    const k = monthKey(l.createdAt);
    if (leadsByMonth.has(k)) leadsByMonth.set(k, leadsByMonth.get(k)! + 1);
  }

  const pendingPayments = round2(
    projects.filter((p) => !["CANCELLED"].includes(p.status)).reduce((s, p) => s + Math.max(0, (p.contractValue ?? 0) - p.payments.reduce((a, x) => a + x.amount, 0)), 0),
  );

  // Conversion: share of quoted proposals (unique base numbers) that were approved
  const bases = new Map<string, boolean>();
  for (const q of quotes) bases.set(q.baseNumber, (bases.get(q.baseNumber) ?? false) || q.status === "APPROVED");
  const quoted = bases.size;
  const approved = [...bases.values()].filter(Boolean).length;

  const projectProfit = projects.map((p) => {
    const gst = p.approvedQuotation?.gstAmount ?? 0;
    const revenueExGst = round2((p.contractValue ?? 0) - gst);
    const spent = round2(p.expenses.reduce((s, e) => s + e.amount, 0));
    const received = round2(p.payments.reduce((s, x) => s + x.amount, 0));
    const snapshot = p.approvedQuotation?.snapshot as { totals?: { profitAmount?: number; materialCost?: number } } | undefined;
    return {
      id: p.id,
      code: p.code,
      name: p.name,
      status: p.status,
      contract: p.contractValue ?? 0,
      received,
      expenses: spent,
      estimatedMargin: round2(snapshot?.totals?.profitAmount ?? 0),
      estimatedMaterial: round2(snapshot?.totals?.materialCost ?? 0),
      // final profit is only meaningful once the project is complete; until then show cost to date
      actualProfit: p.status === "COMPLETED" ? round2(revenueExGst - spent) : null,
      costShare: revenueExGst > 0 ? Math.round((spent / revenueExGst) * 100) : null,
    };
  });

  const materialCostActual = round2(expenses.filter((e) => e.category === "MATERIAL").reduce((s, e) => s + e.amount, 0));
  const materialCostEstimated = round2(projectProfit.reduce((s, p) => s + p.estimatedMaterial, 0));

  return {
    kpis: {
      totalRevenue,
      pendingPayments,
      activeProjects,
      newLeads,
      leads30,
      conversion: quoted ? Math.round((approved / quoted) * 100) : 0,
      quoted,
      approved,
      materialCostActual,
      materialCostEstimated,
      pendingDesigns,
    },
    revenueMonthly: months.map((m) => ({ month: monthLabel(m), revenue: round2(revenueByMonth.get(m)!), expenses: round2(expenseByMonth.get(m)!) })),
    leadsMonthly: months.map((m) => ({ month: monthLabel(m), leads: leadsByMonth.get(m)! })),
    leadsBySource: leadsBySource.map((g) => ({ source: g.source, count: g._count })).sort((a, b) => b.count - a.count),
    projectsByStatus: statusGroups.map((g) => ({ status: g.status, count: g._count })),
    projectProfit,
    followUps,
    recentLeads,
    aiRequests: aiRequests.map((g) => ({ status: g.status, count: g._count })),
  };
}
