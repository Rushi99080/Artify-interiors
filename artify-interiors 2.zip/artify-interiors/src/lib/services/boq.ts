import "server-only";
import { prisma } from "@/lib/db";
import { badRequest, notFound } from "@/lib/api";
import { BOQ_SECTIONS, floorAreaOf, generateProjectExtras, generateRoomLines, tierFromBudget, type MaterialPick, type RoomInput } from "@/lib/boq/engine";
import { computeBOQTotals, lineAmount, type BOQTotals } from "@/lib/calc/boq";
import type { MaterialCategoryKey, PriceTierKey, RoomTypeKey } from "@/lib/constants";
import { getSettings } from "@/lib/settings";
import { loadActiveMaterials, loadRoomSelections, loadTierContext } from "@/lib/services/materials";

const sectionIndex = (s: string) => {
  const i = (BOQ_SECTIONS as readonly string[]).indexOf(s);
  return i === -1 ? BOQ_SECTIONS.length : i;
};

/** Materials picked in the customer's approved (or saved/favourite) design for a room. */
async function designSelections(roomId: string): Promise<Partial<Record<MaterialCategoryKey, MaterialPick>>> {
  const design =
    (await prisma.generatedDesign.findFirst({ where: { roomId, status: "APPROVED" }, orderBy: { updatedAt: "desc" } })) ??
    (await prisma.generatedDesign.findFirst({ where: { roomId, OR: [{ isFavorite: true }, { isSaved: true }] }, orderBy: { updatedAt: "desc" } }));
  if (!design) return {};
  const picks = ((design.materialSuggestions as { materialId?: string | null }[]) ?? []).map((m) => m.materialId).filter(Boolean) as string[];
  if (!picks.length) return {};
  const mats = await prisma.material.findMany({ where: { id: { in: picks }, isActive: true } });
  const out: Partial<Record<MaterialCategoryKey, MaterialPick>> = {};
  for (const m of mats) out[m.category as MaterialCategoryKey] ??= { id: m.id, name: m.name, brand: m.brand, finish: m.finish, rate: m.rate, unit: m.unit };
  return out;
}

/**
 * Generates a preliminary BOQ for a project from room dimensions, selected design materials,
 * room material selections and the admin rate card. Every generated line is flagged as an estimate.
 */
export async function generateBOQ(projectId: string, opts: { tier?: PriceTierKey } = {}) {
  const project = await prisma.project.findUnique({ where: { id: projectId }, include: { rooms: { orderBy: { sortOrder: "asc" } }, boqs: { select: { version: true } } } });
  if (!project) throw notFound("Project not found.");
  if (project.rooms.length === 0) throw badRequest("Add at least one room with dimensions before generating a BOQ.");

  const settings = await getSettings();
  const tier = opts.tier ?? (tierFromBudget(project.budgetMax, project.carpetAreaSqft) as PriceTierKey);
  const byTier = await loadTierContext(await loadActiveMaterials());

  const lines = [];
  let totalArea = 0;
  for (const room of project.rooms) {
    const selected = { ...(await designSelections(room.id)), ...(await loadRoomSelections(room.id)) };
    const input: RoomInput = {
      name: room.name,
      type: room.type as RoomTypeKey,
      lengthFt: room.lengthFt,
      widthFt: room.widthFt,
      heightFt: room.heightFt,
      includeFlooring: !!(selected.FLOORING || selected.TILES || selected.MARBLE),
    };
    lines.push(...generateRoomLines(input, (room.tier as PriceTierKey) ?? tier, settings.rateCard, { selected, byTier }));
    totalArea += floorAreaOf(input);
  }
  lines.push(...generateProjectExtras(project.carpetAreaSqft ?? totalArea, tier, settings.rateCard));

  const ordered = lines.map((l, i) => ({ l, i })).sort((a, b) => sectionIndex(a.l.section) - sectionIndex(b.l.section) || a.i - b.i);
  const charges = {
    gstRate: settings.tax.gstRate,
    wastagePercent: settings.boqDefaults.wastagePercent,
    profitMarginPercent: settings.boqDefaults.profitMarginPercent,
    transportCharges: settings.boqDefaults.transportCharges,
    installationCharges: settings.boqDefaults.installationCharges,
    discountAmount: 0,
  };
  const totals = computeBOQTotals(lines, charges, [...BOQ_SECTIONS]);
  const version = Math.max(0, ...project.boqs.map((b) => b.version)) + 1;

  return prisma.bOQ.create({
    data: {
      projectId,
      version,
      title: `BOQ v${version} — ${project.name}`,
      status: "PRELIMINARY",
      tier,
      ...charges,
      subtotal: totals.subtotal,
      grandTotal: totals.grandTotal,
      notes: "Preliminary estimate generated from room dimensions. Quantities must be verified against site measurements and approved drawings before production.",
      items: {
        create: ordered.map(({ l }, idx) => ({
          sortOrder: idx,
          section: l.section,
          item: l.item,
          dimensions: l.dimensions,
          primaryMaterial: l.primaryMaterial,
          finishBrand: l.finishBrand,
          hardware: l.hardware,
          accessories: l.accessories,
          quantity: l.quantity,
          unit: l.unit,
          rate: l.rate,
          amount: l.amount,
          itemType: l.itemType,
          materialId: l.materialId,
          isEstimated: true,
        })),
      },
    },
  });
}

export type BOQWithTotals = Awaited<ReturnType<typeof loadBOQ>>;

export async function loadBOQ(boqId: string) {
  const boq = await prisma.bOQ.findUnique({ where: { id: boqId }, include: { items: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] }, project: { select: { id: true, name: true, code: true, customerId: true } } } });
  if (!boq) throw notFound("BOQ not found.");
  const totals = totalsFor(boq);
  return { ...boq, totals };
}

export function totalsFor(boq: { gstRate: number; wastagePercent: number; profitMarginPercent: number; transportCharges: number; installationCharges: number; discountAmount: number; items: { section: string; quantity: number; rate: number; itemType: string }[] }): BOQTotals {
  return computeBOQTotals(
    boq.items.map((i) => ({ section: i.section, quantity: i.quantity, rate: i.rate, itemType: i.itemType as "MATERIAL" | "LABOUR" | "SERVICE" })),
    boq,
    [...BOQ_SECTIONS],
  );
}

/** Recomputes line amounts and cached totals after any edit. */
export async function recalcBOQ(boqId: string) {
  const boq = await prisma.bOQ.findUnique({ where: { id: boqId }, include: { items: true } });
  if (!boq) throw notFound("BOQ not found.");
  for (const item of boq.items) {
    const amount = lineAmount(item.quantity, item.rate);
    if (amount !== item.amount) await prisma.bOQItem.update({ where: { id: item.id }, data: { amount } });
  }
  const totals = totalsFor(boq);
  await prisma.bOQ.update({ where: { id: boqId }, data: { subtotal: totals.subtotal, grandTotal: totals.grandTotal } });
  return totals;
}
