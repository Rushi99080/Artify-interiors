import "server-only";
import { prisma } from "@/lib/db";
import { toDesignView } from "@/lib/views";
import type { PhotoView } from "@/components/designs/generate-panel";

/** Designs, rooms and photos for a project's designs board. */
export async function loadDesignsData(projectId: string, opts: { hideAdminNotes?: boolean } = {}) {
  const [designs, rooms, files] = await Promise.all([
    prisma.generatedDesign.findMany({ where: { projectId, ...(opts.hideAdminNotes ? { status: { not: "REJECTED" } } : {}) }, orderBy: { createdAt: "desc" }, include: { room: { select: { name: true } } } }),
    prisma.room.findMany({ where: { projectId }, orderBy: { sortOrder: "asc" }, select: { id: true, name: true } }),
    prisma.uploadedFile.findMany({ where: { projectId, category: { in: ["ROOM_PHOTO", "REFERENCE", "FLOOR_PLAN"] } }, orderBy: { createdAt: "desc" }, take: 60 }),
  ]);
  const photos: PhotoView[] = files.filter((f) => f.mimeType.startsWith("image/")).map((f) => ({ id: f.id, url: `/api/files/${f.id}`, roomId: f.roomId, category: f.category, originalName: f.originalName, mimeType: f.mimeType }));
  return { designs: designs.map((d) => toDesignView(d, opts)), rooms, photos };
}
