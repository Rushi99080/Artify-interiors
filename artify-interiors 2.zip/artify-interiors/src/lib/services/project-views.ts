import "server-only";
import { prisma } from "@/lib/db";
import type { PickerMaterial, RoomView } from "@/components/projects/rooms-panel";

/** Rooms (with selections) and the active material catalogue for the rooms panel. */
export async function loadRoomsData(projectId: string): Promise<{ rooms: RoomView[]; materials: PickerMaterial[] }> {
  const [rooms, materials] = await Promise.all([
    prisma.room.findMany({ where: { projectId }, orderBy: { sortOrder: "asc" }, include: { materials: { select: { materialId: true, application: true } } } }),
    prisma.material.findMany({ where: { isActive: true, availability: { not: "DISCONTINUED" } }, orderBy: [{ category: "asc" }, { rate: "asc" }], select: { id: true, name: true, brand: true, category: true, rate: true, unit: true, finish: true, color: true, tier: true, imageUrl: true } }),
  ]);
  return {
    rooms: rooms.map((r) => ({ id: r.id, name: r.name, type: r.type, lengthFt: r.lengthFt, widthFt: r.widthFt, heightFt: r.heightFt, style: r.style, tier: r.tier, preferences: r.preferences, selections: r.materials })),
    materials,
  };
}
