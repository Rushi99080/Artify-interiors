import "server-only";
import { prisma } from "@/lib/db";
import type { MaterialContext, MaterialPick } from "@/lib/boq/engine";
import { representativeByTier, type RecMaterial } from "@/lib/materials/recommend";
import type { MaterialCategoryKey } from "@/lib/constants";

export async function loadActiveMaterials(): Promise<RecMaterial[]> {
  const rows = await prisma.material.findMany({
    where: { isActive: true, availability: { not: "DISCONTINUED" } },
    select: { id: true, name: true, category: true, brand: true, finish: true, color: true, unit: true, rate: true, tier: true, durability: true, maintenance: true, styles: true, availability: true },
  });
  return rows as RecMaterial[];
}

/** Representative library material per category & tier, for BOQ pricing and estimates. */
export async function loadTierContext(materials?: RecMaterial[]): Promise<MaterialContext["byTier"]> {
  return representativeByTier(materials ?? (await loadActiveMaterials()));
}

/** Materials explicitly chosen for a room, keyed by category. */
export async function loadRoomSelections(roomId: string): Promise<Partial<Record<MaterialCategoryKey, MaterialPick>>> {
  const rows = await prisma.roomMaterial.findMany({
    where: { roomId },
    include: { material: { select: { id: true, name: true, brand: true, finish: true, rate: true, unit: true, category: true } } },
    orderBy: { createdAt: "asc" },
  });
  const out: Partial<Record<MaterialCategoryKey, MaterialPick>> = {};
  for (const r of rows) {
    const m = r.material;
    out[m.category as MaterialCategoryKey] = { id: m.id, name: m.name, brand: m.brand, finish: m.finish, rate: m.rate, unit: m.unit, category: m.category as MaterialCategoryKey };
  }
  return out;
}
