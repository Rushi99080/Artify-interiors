// Default business settings & website content (no server-only imports — also used by the seed script).
import type { RateCard } from "@/lib/boq/engine";

export type CompanySettings = {
  name: string;
  legalName: string;
  tagline: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  gstin: string;
  logoUrl: string;
  bankDetails: string;
  whatsappNumber: string;
  instagramUrl: string;
};

export type QuotationSettings = {
  validityDays: number;
  prefix: string;
  scopeOfWork: string;
  paymentTerms: string;
  timelineText: string;
  terms: string;
};

export type BoqDefaults = {
  wastagePercent: number;
  profitMarginPercent: number;
  transportCharges: number;
  installationCharges: number;
  marginLabel: string;
};

export type PaymentScheduleItem = { name: string; percent: number };

export type AutomationSettings = {
  autoPreliminaryQuotation: boolean;
  paymentReminderDays: number;
};

export type HeroContent = {
  eyebrow: string;
  headlineLines: string[];
  subtext: string;
  imageUrl: string;
};

export type AboutContent = {
  heading: string;
  body: string;
  imageUrl: string;
  values: { title: string; text: string }[];
};

export type StatItem = { value: string; label: string };

export type AllSettings = {
  company: CompanySettings;
  tax: { gstRate: number };
  boqDefaults: BoqDefaults;
  quotation: QuotationSettings;
  paymentSchedule: PaymentScheduleItem[];
  rateCard: RateCard;
  automation: AutomationSettings;
  hero: HeroContent;
  about: AboutContent;
  stats: StatItem[];
};

export const DEFAULT_SETTINGS: Omit<AllSettings, "rateCard"> = {
  company: {
    name: "ARTIFY INTERIORS",
    legalName: "Artify Interiors",
    tagline: "Luxury Interior Design Studio",
    address: "Pune, Maharashtra, India",
    phone: "",
    email: "",
    website: "",
    gstin: "",
    logoUrl: "",
    bankDetails: "",
    whatsappNumber: "",
    instagramUrl: "",
  },
  tax: { gstRate: 18 },
  boqDefaults: {
    wastagePercent: 5,
    profitMarginPercent: 15,
    transportCharges: 0,
    installationCharges: 0,
    marginLabel: "Design, supervision & project management",
  },
  quotation: {
    validityDays: 15,
    prefix: "AIQ",
    scopeOfWork:
      "Design, supply, fabrication and installation of interior works as detailed in the room-wise Bill of Quantities, including site supervision, coordination with vendors and final cleaning before handover.",
    paymentTerms:
      "10% booking advance on quotation approval\n40% on design sign-off and start of production\n40% on delivery of materials and modules at site\n10% on final handover",
    timelineText:
      "Design finalisation: 2–3 weeks from booking.\nProduction & site execution: 45–60 working days from design sign-off and receipt of the production payment.\nTimelines exclude delays caused by site readiness, scope changes or third-party approvals.",
    terms:
      "1. Prices are valid for the period mentioned above and are subject to final site measurements.\n2. Quantities marked as estimates are preliminary and will be verified on site before production.\n3. Any work not mentioned in the BOQ will be charged extra after mutual approval.\n4. Civil, plumbing and electrical works are excluded unless listed in the BOQ.\n5. Colour and texture of natural materials (veneer, stone, wood) may vary from samples.\n6. Warranty: 10 years on carcass against manufacturing defects, as per manufacturer terms on hardware and appliances.\n7. The client shall provide electricity, water and secure storage at site during execution.\n8. Payments once made are non-refundable after production has started.",
  },
  paymentSchedule: [
    { name: "Booking advance", percent: 10 },
    { name: "Design sign-off & production start", percent: 40 },
    { name: "Material delivery at site", percent: 40 },
    { name: "Final handover", percent: 10 },
  ],
  automation: { autoPreliminaryQuotation: true, paymentReminderDays: 3 },
  hero: {
    eyebrow: "Luxury interior design studio in Pune",
    headlineLines: ["Rooms that", "fit your life,", "to the inch."],
    subtext:
      "From the first sketch to the final handover — design concepts, transparent estimates and project tracking in one place, crafted by the Artify studio.",
    imageUrl: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=2000&q=80",
  },
  about: {
    heading: "A studio built on craft, clarity and calm execution.",
    body:
      "Artify Interiors designs and builds homes, offices and commercial spaces with an obsessive eye for detail. Our designers, site supervisors and craftsmen work as one team, so the space you approve on screen is the space we hand over.\n\nWe combine AI-assisted concept design with the judgement of experienced interior architects — giving you faster ideas, honest estimates and a project you can track at every stage.",
    imageUrl: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=80",
    values: [
      { title: "Design-led", text: "Every space starts with how you live, not with a catalogue." },
      { title: "Transparent", text: "Itemised BOQs and quotations — no hidden extras." },
      { title: "Accountable", text: "One team from concept to handover, with live project tracking." },
    ],
  },
  stats: [],
};

