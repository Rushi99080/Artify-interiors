import "server-only";
import path from "node:path";
import { Font } from "@react-pdf/renderer";

let registered = false;

/** Registers bundled fonts (with ₹ glyph support) for PDF rendering. */
export function registerPdfFonts() {
  if (registered) return;
  const dir = path.join(process.cwd(), "src", "assets", "fonts");
  Font.register({
    family: "Inter",
    fonts: [
      { src: path.join(dir, "Inter_400Regular.ttf"), fontWeight: 400 },
      { src: path.join(dir, "Inter_600SemiBold.ttf"), fontWeight: 600 },
    ],
  });
  Font.register({
    family: "Cormorant",
    fonts: [
      { src: path.join(dir, "CormorantGaramond_500Medium.ttf"), fontWeight: 500 },
      { src: path.join(dir, "CormorantGaramond_600SemiBold.ttf"), fontWeight: 600 },
    ],
  });
  // Disable automatic hyphenation (keeps material names intact)
  Font.registerHyphenationCallback((word) => [word]);
  registered = true;
}

export const PDF_COLORS = {
  ink: "#1F1C19",
  text: "#3B3632",
  muted: "#7A7067",
  gold: "#A88A5A",
  goldSoft: "#E9DFCC",
  beige: "#F6F1EA",
  line: "#E4DACB",
  warn: "#9A5B13",
  warnBg: "#FBF0DF",
};

export const inr = (v: number) =>
  `₹${Number(v ?? 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const qty = (v: number) => Number(v ?? 0).toLocaleString("en-IN", { maximumFractionDigits: 2 });
export const pdfDate = (d: Date | string) => new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "Asia/Kolkata" });
