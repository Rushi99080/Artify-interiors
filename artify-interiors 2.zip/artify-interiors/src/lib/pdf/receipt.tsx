import "server-only";
import React from "react";
import { Document, Page, Path, StyleSheet, Svg, Text, View, renderToBuffer } from "@react-pdf/renderer";
import { PDF_COLORS as C, inr, pdfDate, registerPdfFonts } from "@/lib/pdf/common";
import { amountInWordsINR } from "@/lib/quotation/snapshot";

export type ReceiptPdfData = {
  receiptNo: string;
  paidAt: Date;
  amount: number;
  method: string;
  reference: string | null;
  milestoneName: string | null;
  company: { name: string; legalName: string; tagline: string; address: string; phone: string; email: string; gstin: string };
  client: { name: string; phone: string | null; email: string | null };
  project: { name: string; code: string; contractValue: number | null; totalReceived: number; balance: number };
};

const s = StyleSheet.create({
  page: { padding: 32, paddingBottom: 48, fontFamily: "Inter", fontSize: 9, color: C.text, lineHeight: 1.45 },
  header: { flexDirection: "row", justifyContent: "space-between", paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.line },
  brand: { fontFamily: "Cormorant", fontWeight: 600, fontSize: 15, letterSpacing: 2.6, color: C.ink, lineHeight: 1.1 },
  tag: { fontSize: 7, letterSpacing: 1.6, color: C.gold, textTransform: "uppercase" },
  title: { fontFamily: "Cormorant", fontWeight: 600, fontSize: 26, color: C.ink, marginTop: 20, lineHeight: 1.1 },
  amountBox: { backgroundColor: C.ink, color: "#F6F1EA", paddingVertical: 14, paddingHorizontal: 16, borderRadius: 4, marginVertical: 14 },
  row: { flexDirection: "row", paddingVertical: 6, borderBottomWidth: 0.5, borderBottomColor: C.line },
  label: { width: 112, color: C.muted },
  value: { flex: 1, color: C.ink },
  footer: { position: "absolute", bottom: 24, left: 32, right: 32, fontSize: 7.5, color: C.muted, textAlign: "center" },
});

const METHOD: Record<string, string> = { CASH: "Cash", UPI: "UPI", BANK_TRANSFER: "Bank transfer / RTGS", CHEQUE: "Cheque", CARD: "Card", RAZORPAY: "Online (Razorpay)" };

function ReceiptDocument({ d }: { d: ReceiptPdfData }) {
  const rows: [string, string][] = [
    ["Received from", d.client.name],
    ["Project", `${d.project.name} (${d.project.code})`],
    ["Payment towards", d.milestoneName ?? "Project payment"],
    ["Payment method", METHOD[d.method] ?? d.method],
    ["Reference", d.reference ?? "—"],
    ["Date of payment", pdfDate(d.paidAt)],
  ];
  return (
    <Document title={`Receipt ${d.receiptNo}`} author={d.company.legalName}>
      <Page size="A5" style={s.page}>
        <View style={s.header}>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Svg width={26} height={26} viewBox="0 0 40 40" style={{ marginRight: 8 }}>
              <Path d="M4 38 V18 A16 16 0 0 1 36 18 V38" stroke={C.gold} strokeWidth={1.6} fill="none" />
              <Path d="M12 34 L20 12 L28 34 M15 27 H25" stroke={C.ink} strokeWidth={1.8} fill="none" />
            </Svg>
            <View>
              <Text style={s.brand}>{d.company.name}</Text>
              <Text style={s.tag}>{d.company.tagline}</Text>
            </View>
          </View>
          <View style={{ textAlign: "right", fontSize: 7, color: C.muted, maxWidth: 140 }}>
            <Text style={{ color: C.ink }}>{d.company.legalName}</Text>
            <Text>{d.company.address}</Text>
            {d.company.phone ? <Text>{d.company.phone}</Text> : null}
            {d.company.gstin ? <Text>GSTIN: {d.company.gstin}</Text> : null}
          </View>
        </View>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" }}>
          <Text style={s.title}>Payment Receipt</Text>
          <Text style={{ color: C.ink, fontWeight: 600 }}>{d.receiptNo}</Text>
        </View>
        <View style={s.amountBox}>
          <Text style={{ fontSize: 8, letterSpacing: 1, color: C.goldSoft, lineHeight: 1.2 }}>AMOUNT RECEIVED</Text>
          <Text style={{ fontSize: 20, fontWeight: 600, marginTop: 6, lineHeight: 1.2 }}>{inr(d.amount)}</Text>
          <Text style={{ fontSize: 8, color: C.goldSoft, marginTop: 6, lineHeight: 1.3 }}>{amountInWordsINR(d.amount)}</Text>
        </View>
        {rows.map(([l, v]) => (
          <View key={l} style={s.row}>
            <Text style={s.label}>{l}</Text>
            <Text style={s.value}>{v}</Text>
          </View>
        ))}
        {d.project.contractValue ? (
          <View style={[s.row, { borderBottomWidth: 0 }]}>
            <Text style={s.label}>Account summary</Text>
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.ink }}>Contract value: {inr(d.project.contractValue)}</Text>
              <Text style={{ color: C.ink }}>Received to date: {inr(d.project.totalReceived)}</Text>
              <Text style={{ color: C.ink }}>Balance: {inr(d.project.balance)}</Text>
            </View>
          </View>
        ) : null}
        <Text style={s.footer}>This is a computer-generated receipt and does not require a signature.</Text>
      </Page>
    </Document>
  );
}

export async function renderReceiptPdf(d: ReceiptPdfData): Promise<Buffer> {
  registerPdfFonts();
  return renderToBuffer(<ReceiptDocument d={d} />);
}
