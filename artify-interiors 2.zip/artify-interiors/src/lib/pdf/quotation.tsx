import "server-only";
import React from "react";
import { Document, Image, Page, Path, StyleSheet, Svg, Text, View, renderToBuffer } from "@react-pdf/renderer";
import type { QuotationSnapshot } from "@/lib/quotation/snapshot";
import { amountInWordsINR } from "@/lib/quotation/snapshot";
import { PDF_COLORS as C, inr, pdfDate, qty, registerPdfFonts } from "@/lib/pdf/common";

export type QuotationPdfData = {
  number: string;
  revision: number;
  status: string;
  isPreliminary: boolean;
  createdAt: Date;
  validUntil: Date;
  scopeOfWork: string;
  paymentTerms: string;
  timelineText: string;
  terms: string;
  approvedAt?: Date | null;
  approvedByName?: string | null;
  snapshot: QuotationSnapshot;
  logo?: { data: Buffer; format: "png" | "jpg" } | null;
};

const s = StyleSheet.create({
  page: { paddingTop: 36, paddingBottom: 54, paddingHorizontal: 36, fontFamily: "Inter", fontSize: 8.5, color: C.text, lineHeight: 1.45 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.line },
  brandRow: { flexDirection: "row", alignItems: "center" },
  brandName: { fontFamily: "Cormorant", fontWeight: 600, fontSize: 17, letterSpacing: 3.2, color: C.ink, lineHeight: 1.1 },
  brandTag: { fontSize: 6.5, letterSpacing: 1.6, color: C.gold, marginTop: 3, textTransform: "uppercase", lineHeight: 1.2 },
  companyBlock: { textAlign: "right", fontSize: 7.5, color: C.muted, maxWidth: 220 },
  titleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginTop: 18, marginBottom: 12 },
  title: { fontFamily: "Cormorant", fontWeight: 600, fontSize: 26, color: C.ink, letterSpacing: 1, lineHeight: 1.1 },
  metaLabel: { fontSize: 6.8, color: C.muted, textTransform: "uppercase", letterSpacing: 0.8 },
  metaValue: { fontSize: 9, color: C.ink, fontWeight: 600 },
  banner: { backgroundColor: C.warnBg, borderLeftWidth: 3, borderLeftColor: C.warn, padding: 8, marginBottom: 12, color: C.warn, fontSize: 8 },
  twoCol: { flexDirection: "row", gap: 12, marginBottom: 14 },
  card: { flex: 1, backgroundColor: C.beige, borderRadius: 4, padding: 10 },
  cardTitle: { fontSize: 6.8, letterSpacing: 1.2, color: C.gold, textTransform: "uppercase", marginBottom: 5, fontWeight: 600 },
  cardStrong: { fontSize: 10, color: C.ink, fontWeight: 600, marginBottom: 2 },
  h2: { fontFamily: "Cormorant", fontWeight: 600, fontSize: 15, color: C.ink, marginBottom: 6, marginTop: 10, lineHeight: 1.2 },
  para: { fontSize: 8.5, marginBottom: 6 },
  tableHead: { flexDirection: "row", backgroundColor: C.ink, color: "#F6F1EA", paddingVertical: 5, paddingHorizontal: 4, fontSize: 7, fontWeight: 600, letterSpacing: 0.3 },
  row: { flexDirection: "row", paddingVertical: 4.5, paddingHorizontal: 4, borderBottomWidth: 0.5, borderBottomColor: C.line },
  sectionRow: { flexDirection: "row", paddingVertical: 5, paddingHorizontal: 4, backgroundColor: C.goldSoft, marginTop: 4 },
  sectionName: { flex: 1, fontWeight: 600, color: C.ink, fontSize: 8.5 },
  small: { fontSize: 7, color: C.muted },
  totalsBox: { marginLeft: "auto", width: 250, marginTop: 8 },
  totalLine: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 3, borderBottomWidth: 0.5, borderBottomColor: C.line },
  grand: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 7, paddingHorizontal: 8, backgroundColor: C.ink, color: "#F6F1EA", marginTop: 4, borderRadius: 3 },
  words: { fontSize: 7.5, color: C.muted, marginTop: 6, textAlign: "right" },
  footer: { position: "absolute", bottom: 22, left: 36, right: 36, flexDirection: "row", justifyContent: "space-between", fontSize: 7, color: C.muted, borderTopWidth: 0.5, borderTopColor: C.line, paddingTop: 6 },
  signRow: { flexDirection: "row", gap: 24, marginTop: 28 },
  signBox: { flex: 1, borderTopWidth: 0.8, borderTopColor: C.ink, paddingTop: 5 },
  estimate: { fontSize: 6, color: C.warn, marginTop: 1 },
});

const COLS = { sr: 22, item: 150, material: 120, hw: 92, qty: 34, unit: 30, rate: 52, amount: 62 };

function Monogram() {
  return (
    <Svg width={30} height={30} viewBox="0 0 40 40" style={{ marginRight: 9 }}>
      <Path d="M4 38 V18 A16 16 0 0 1 36 18 V38" stroke={C.gold} strokeWidth={1.6} fill="none" />
      <Path d="M12 34 L20 12 L28 34 M15 27 H25" stroke={C.ink} strokeWidth={1.8} fill="none" />
    </Svg>
  );
}

function Header({ d }: { d: QuotationPdfData }) {
  const c = d.snapshot.company;
  return (
    <View style={s.header}>
      <View style={s.brandRow}>
        {d.logo ? <Image src={d.logo} style={{ height: 34, marginRight: 9 }} /> : <Monogram />}
        <View>
          <Text style={s.brandName}>{c.name}</Text>
          <Text style={s.brandTag}>{c.tagline}</Text>
        </View>
      </View>
      <View style={s.companyBlock}>
        <Text style={{ color: C.ink, fontWeight: 600 }}>{c.legalName}</Text>
        <Text>{c.address}</Text>
        {c.phone ? <Text>Phone: {c.phone}</Text> : null}
        {c.email ? <Text>{c.email}</Text> : null}
        {c.website ? <Text>{c.website}</Text> : null}
        {c.gstin ? <Text>GSTIN: {c.gstin}</Text> : null}
      </View>
    </View>
  );
}

function Footer({ d }: { d: QuotationPdfData }) {
  return (
    <View style={s.footer} fixed>
      <Text>
        {d.number} · {d.snapshot.project.name}
      </Text>
      <Text render={({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`} />
    </View>
  );
}

function Multiline({ text }: { text: string }) {
  return (
    <View>
      {text
        .split(/\n/)
        .filter((l) => l.trim())
        .map((line, i) => (
          <Text key={i} style={s.para}>
            {line}
          </Text>
        ))}
    </View>
  );
}

function QuotationDocument({ d }: { d: QuotationPdfData }) {
  const snap = d.snapshot;
  const t = snap.totals;
  const prelim = d.isPreliminary;
  return (
    <Document title={`Quotation ${d.number}`} author={snap.company.legalName} subject={snap.project.name} creator="Artify Interiors Platform">
      {/* ── Page 1: summary ── */}
      <Page size="A4" style={s.page}>
        <Header d={d} />
        <View style={s.titleRow}>
          <View>
            <Text style={s.title}>Quotation</Text>
            <Text style={{ fontSize: 8, color: C.muted, marginTop: 3 }}>{snap.boq.title}</Text>
          </View>
          <View style={{ flexDirection: "row", gap: 18 }}>
            <View>
              <Text style={s.metaLabel}>Quotation no.</Text>
              <Text style={s.metaValue}>{d.number}</Text>
            </View>
            <View>
              <Text style={s.metaLabel}>Date</Text>
              <Text style={s.metaValue}>{pdfDate(d.createdAt)}</Text>
            </View>
            <View>
              <Text style={s.metaLabel}>Valid until</Text>
              <Text style={s.metaValue}>{pdfDate(d.validUntil)}</Text>
            </View>
          </View>
        </View>

        {prelim ? (
          <Text style={s.banner}>
            PRELIMINARY ESTIMATE — quantities marked “estimate” were derived from room dimensions and must be verified against site measurements and approved drawings. The final quotation may differ.
          </Text>
        ) : null}

        <View style={s.twoCol}>
          <View style={s.card}>
            <Text style={s.cardTitle}>Client</Text>
            <Text style={s.cardStrong}>{snap.client.name}</Text>
            {snap.client.phone ? <Text>{snap.client.phone}</Text> : null}
            {snap.client.email ? <Text>{snap.client.email}</Text> : null}
            {snap.client.address ? <Text>{snap.client.address}</Text> : null}
          </View>
          <View style={s.card}>
            <Text style={s.cardTitle}>Project</Text>
            <Text style={s.cardStrong}>{snap.project.name}</Text>
            <Text>Ref: {snap.project.code}</Text>
            <Text>{snap.project.address || snap.project.location}</Text>
            <Text>
              {snap.project.propertyType.charAt(0) + snap.project.propertyType.slice(1).toLowerCase()}
              {snap.project.carpetAreaSqft ? ` · ${snap.project.carpetAreaSqft} sqft carpet area` : ""}
            </Text>
          </View>
        </View>

        <Text style={s.h2}>Scope of work</Text>
        <Multiline text={d.scopeOfWork} />

        <Text style={s.h2}>Summary</Text>
        <View style={s.tableHead}>
          <Text style={{ width: 24 }}>#</Text>
          <Text style={{ flex: 1 }}>Section</Text>
          <Text style={{ width: 50, textAlign: "right" }}>Items</Text>
          <Text style={{ width: 90, textAlign: "right" }}>Amount</Text>
        </View>
        {snap.sections.map((sec, i) => (
          <View key={sec.section} style={s.row} wrap={false}>
            <Text style={{ width: 24 }}>{i + 1}</Text>
            <Text style={{ flex: 1 }}>{sec.section}</Text>
            <Text style={{ width: 50, textAlign: "right" }}>{sec.items.length}</Text>
            <Text style={{ width: 90, textAlign: "right" }}>{inr(sec.amount)}</Text>
          </View>
        ))}

        <View style={s.totalsBox} wrap={false}>
          <View style={s.totalLine}>
            <Text>Subtotal</Text>
            <Text>{inr(t.subtotal)}</Text>
          </View>
          {t.wastageAmount > 0 ? (
            <View style={s.totalLine}>
              <Text>Material wastage allowance ({snap.charges.wastagePercent}%)</Text>
              <Text>{inr(t.wastageAmount)}</Text>
            </View>
          ) : null}
          {t.transportCharges > 0 ? (
            <View style={s.totalLine}>
              <Text>Transportation</Text>
              <Text>{inr(t.transportCharges)}</Text>
            </View>
          ) : null}
          {t.installationCharges > 0 ? (
            <View style={s.totalLine}>
              <Text>Installation charges</Text>
              <Text>{inr(t.installationCharges)}</Text>
            </View>
          ) : null}
          {t.profitAmount > 0 ? (
            <View style={s.totalLine}>
              <Text>{snap.charges.marginLabel}</Text>
              <Text>{inr(t.profitAmount)}</Text>
            </View>
          ) : null}
          {t.discountAmount > 0 ? (
            <View style={s.totalLine}>
              <Text>Discount</Text>
              <Text>− {inr(t.discountAmount)}</Text>
            </View>
          ) : null}
          <View style={s.totalLine}>
            <Text style={{ fontWeight: 600 }}>Taxable value</Text>
            <Text style={{ fontWeight: 600 }}>{inr(t.taxableAmount)}</Text>
          </View>
          <View style={s.totalLine}>
            <Text>GST @ {t.gstRate}%</Text>
            <Text>{inr(t.gstAmount)}</Text>
          </View>
          <View style={s.grand}>
            <Text style={{ fontWeight: 600 }}>Total project cost</Text>
            <Text style={{ fontWeight: 600 }}>{inr(t.grandTotal)}</Text>
          </View>
          <Text style={s.words}>{amountInWordsINR(t.grandTotal)}</Text>
        </View>
        <Footer d={d} />
      </Page>

      {/* ── Room-wise BOQ ── */}
      <Page size="A4" style={s.page}>
        <Header d={d} />
        <Text style={[s.h2, { marginTop: 12 }]}>Room-wise Bill of Quantities</Text>
        <View style={s.tableHead} fixed>
          <Text style={{ width: COLS.sr }}>Sr</Text>
          <Text style={{ width: COLS.item }}>Item & dimensions</Text>
          <Text style={{ width: COLS.material }}>Material / finish</Text>
          <Text style={{ width: COLS.hw }}>Hardware / accessories</Text>
          <Text style={{ width: COLS.qty, textAlign: "right" }}>Qty</Text>
          <Text style={{ width: COLS.unit, textAlign: "center" }}>Unit</Text>
          <Text style={{ width: COLS.rate, textAlign: "right" }}>Rate</Text>
          <Text style={{ width: COLS.amount, textAlign: "right" }}>Amount</Text>
        </View>
        {snap.sections.map((sec) => (
          <View key={sec.section}>
            <View style={s.sectionRow} wrap={false} minPresenceAhead={30}>
              <Text style={s.sectionName}>{sec.section}</Text>
              <Text style={{ fontWeight: 600, color: C.ink }}>{inr(sec.amount)}</Text>
            </View>
            {sec.items.map((it) => (
              <View key={it.srNo} style={s.row} wrap={false}>
                <Text style={{ width: COLS.sr }}>{it.srNo}</Text>
                <View style={{ width: COLS.item, paddingRight: 4 }}>
                  <Text style={{ color: C.ink }}>{it.item}</Text>
                  {it.dimensions ? <Text style={s.small}>{it.dimensions}</Text> : null}
                  {it.isEstimated && prelim ? <Text style={s.estimate}>estimate — verify on site</Text> : null}
                </View>
                <View style={{ width: COLS.material, paddingRight: 4 }}>
                  <Text>{it.primaryMaterial ?? "—"}</Text>
                  {it.finishBrand ? <Text style={s.small}>{it.finishBrand}</Text> : null}
                </View>
                <View style={{ width: COLS.hw, paddingRight: 4 }}>
                  <Text style={s.small}>{[it.hardware, it.accessories].filter(Boolean).join(" · ") || "—"}</Text>
                </View>
                <Text style={{ width: COLS.qty, textAlign: "right" }}>{qty(it.quantity)}</Text>
                <Text style={{ width: COLS.unit, textAlign: "center" }}>{it.unit}</Text>
                <Text style={{ width: COLS.rate, textAlign: "right" }}>{inr(it.rate)}</Text>
                <Text style={{ width: COLS.amount, textAlign: "right", color: C.ink }}>{inr(it.amount)}</Text>
              </View>
            ))}
          </View>
        ))}
        <View style={s.totalsBox} wrap={false}>
          <View style={s.totalLine}>
            <Text style={{ fontWeight: 600 }}>BOQ subtotal</Text>
            <Text style={{ fontWeight: 600 }}>{inr(t.subtotal)}</Text>
          </View>
        </View>
        <Footer d={d} />
      </Page>

      {/* ── Specifications, terms & approval ── */}
      <Page size="A4" style={s.page}>
        <Header d={d} />
        <Text style={[s.h2, { marginTop: 12 }]}>Material specifications</Text>
        <View style={s.tableHead}>
          <Text style={{ width: 190 }}>Material</Text>
          <Text style={{ width: 130 }}>Used in</Text>
          <Text style={{ flex: 1 }}>Specification</Text>
        </View>
        {snap.materialSpecs.map((m, i) => (
          <View key={i} style={s.row} wrap={false}>
            <Text style={{ width: 190, color: C.ink, paddingRight: 6 }}>{m.name}</Text>
            <Text style={{ width: 130, paddingRight: 6 }}>{m.usedIn.join(", ")}</Text>
            <Text style={{ flex: 1, color: C.muted }}>{m.specifications ?? (m.finish ? `${m.finish} finish, as per approved sample` : "As per approved sample")}</Text>
          </View>
        ))}

        <Text style={s.h2}>Payment terms</Text>
        <Multiline text={d.paymentTerms} />
        {snap.company.bankDetails ? (
          <View style={[s.card, { marginBottom: 8 }]}>
            <Text style={s.cardTitle}>Bank details</Text>
            <Multiline text={snap.company.bankDetails} />
          </View>
        ) : null}

        <Text style={s.h2}>Project timeline</Text>
        <Multiline text={d.timelineText} />

        <Text style={s.h2}>Terms & conditions</Text>
        <Multiline text={d.terms} />

        <View wrap={false}>
          <Text style={s.h2}>Client approval</Text>
          <Text style={s.para}>
            I/We have read and accept this quotation ({d.number}) for a total project cost of {inr(t.grandTotal)} including GST, along with the payment terms, timeline and terms & conditions stated above.
          </Text>
          {d.approvedAt ? (
            <View style={[s.card, { marginTop: 6 }]}>
              <Text style={s.cardTitle}>Approved online</Text>
              <Text>
                Approved by {d.approvedByName ?? snap.client.name} on {pdfDate(d.approvedAt)}
              </Text>
            </View>
          ) : null}
          <View style={s.signRow}>
            <View style={s.signBox}>
              <Text style={{ fontWeight: 600, color: C.ink }}>Client signature</Text>
              <Text style={s.small}>Name: {snap.client.name}</Text>
              <Text style={s.small}>Date:</Text>
            </View>
            <View style={s.signBox}>
              <Text style={{ fontWeight: 600, color: C.ink }}>For {snap.company.legalName}</Text>
              <Text style={s.small}>Authorised signatory</Text>
              <Text style={s.small}>Date:</Text>
            </View>
          </View>
        </View>
        <Footer d={d} />
      </Page>
    </Document>
  );
}

export async function renderQuotationPdf(d: QuotationPdfData): Promise<Buffer> {
  registerPdfFonts();
  return renderToBuffer(<QuotationDocument d={d} />);
}
