// Quotation snapshot — an immutable copy of the BOQ, client and company details at the moment a
// quotation is generated, so quotation history never changes when the BOQ is edited later.

import type { BOQTotals } from "@/lib/calc/boq";
import { computeBOQTotals, lineAmount } from "@/lib/calc/boq";
import { BOQ_SECTIONS } from "@/lib/boq/engine";

export type SnapshotItem = {
  srNo: number;
  section: string;
  item: string;
  dimensions: string | null;
  primaryMaterial: string | null;
  finishBrand: string | null;
  hardware: string | null;
  accessories: string | null;
  quantity: number;
  unit: string;
  rate: number;
  amount: number;
  isEstimated: boolean;
};

export type QuotationSnapshot = {
  version: 1;
  generatedAt: string;
  company: {
    name: string;
    legalName: string;
    tagline: string;
    address: string;
    phone: string;
    email: string;
    website: string;
    gstin: string;
    logoUrl: string;
    bankDetails: string;
  };
  client: { name: string; email: string | null; phone: string | null; address: string | null };
  project: { name: string; code: string; location: string; address: string | null; propertyType: string; carpetAreaSqft: number | null };
  boq: { id: string; title: string; version: number; status: string; tier: string; isPreliminary: boolean };
  sections: { section: string; amount: number; items: SnapshotItem[] }[];
  totals: BOQTotals;
  charges: { gstRate: number; wastagePercent: number; profitMarginPercent: number; marginLabel: string };
  materialSpecs: { name: string; finish: string | null; usedIn: string[]; specifications: string | null }[];
};

export type SnapshotInput = {
  company: QuotationSnapshot["company"];
  client: QuotationSnapshot["client"];
  project: QuotationSnapshot["project"];
  marginLabel: string;
  boq: {
    id: string;
    title: string;
    version: number;
    status: string;
    tier: string;
    gstRate: number;
    wastagePercent: number;
    profitMarginPercent: number;
    transportCharges: number;
    installationCharges: number;
    discountAmount: number;
    items: {
      section: string;
      item: string;
      dimensions: string | null;
      primaryMaterial: string | null;
      finishBrand: string | null;
      hardware: string | null;
      accessories: string | null;
      quantity: number;
      unit: string;
      rate: number;
      itemType: string;
      isEstimated: boolean;
      materialId: string | null;
      sortOrder: number;
    }[];
  };
  /** Library specifications by material id */
  specs?: Record<string, string | null | undefined>;
  now?: Date;
};

export function buildQuotationSnapshot(input: SnapshotInput): QuotationSnapshot {
  const order = (s: string) => {
    const i = (BOQ_SECTIONS as readonly string[]).indexOf(s);
    return i === -1 ? 999 : i;
  };
  const items = [...input.boq.items].sort((a, b) => order(a.section) - order(b.section) || a.sortOrder - b.sortOrder);
  const totals = computeBOQTotals(
    items.map((i) => ({ section: i.section, quantity: i.quantity, rate: i.rate, itemType: i.itemType as "MATERIAL" | "LABOUR" | "SERVICE" })),
    input.boq,
    [...BOQ_SECTIONS],
  );

  let sr = 0;
  const sectionMap = new Map<string, SnapshotItem[]>();
  for (const i of items) {
    sr += 1;
    const list = sectionMap.get(i.section) ?? [];
    list.push({
      srNo: sr,
      section: i.section,
      item: i.item,
      dimensions: i.dimensions,
      primaryMaterial: i.primaryMaterial,
      finishBrand: i.finishBrand,
      hardware: i.hardware,
      accessories: i.accessories,
      quantity: i.quantity,
      unit: i.unit,
      rate: i.rate,
      amount: lineAmount(i.quantity, i.rate),
      isEstimated: i.isEstimated,
    });
    sectionMap.set(i.section, list);
  }
  const sections = totals.sections.map((s) => ({ section: s.section, amount: s.amount, items: sectionMap.get(s.section) ?? [] }));

  const specMap = new Map<string, { name: string; finish: string | null; usedIn: Set<string>; specifications: string | null }>();
  for (const i of items) {
    // Library-priced items carry their finish in finishBrand; fabricated items carry the finish material there.
    const pairs: [string | null, string | null][] = i.materialId
      ? [[i.primaryMaterial, i.finishBrand]]
      : [
          [i.primaryMaterial, null],
          [i.finishBrand, null],
        ];
    for (const [name, finish] of pairs) {
      if (!name) continue;
      const key = name.toLowerCase();
      const entry = specMap.get(key) ?? { name, finish, usedIn: new Set<string>(), specifications: null };
      entry.usedIn.add(i.section);
      if (i.materialId && input.specs?.[i.materialId] && name === i.primaryMaterial) entry.specifications = input.specs[i.materialId] ?? null;
      specMap.set(key, entry);
    }
  }

  return {
    version: 1,
    generatedAt: (input.now ?? new Date()).toISOString(),
    company: input.company,
    client: input.client,
    project: input.project,
    boq: { id: input.boq.id, title: input.boq.title, version: input.boq.version, status: input.boq.status, tier: input.boq.tier, isPreliminary: input.boq.status === "PRELIMINARY" },
    sections,
    totals,
    charges: { gstRate: input.boq.gstRate, wastagePercent: input.boq.wastagePercent, profitMarginPercent: input.boq.profitMarginPercent, marginLabel: input.marginLabel },
    materialSpecs: [...specMap.values()].slice(0, 40).map((s) => ({ name: s.name, finish: s.finish, usedIn: [...s.usedIn], specifications: s.specifications })),
  };
}

// ── Amount in words (Indian numbering) ─────────────────────────

const ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
const TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

function twoDigits(n: number) {
  if (n < 20) return ONES[n]!;
  const t = TENS[Math.floor(n / 10)]!;
  const o = ONES[n % 10]!;
  return o ? `${t}-${o}` : t;
}
function threeDigits(n: number) {
  const h = Math.floor(n / 100);
  const rest = n % 100;
  return [h ? `${ONES[h]} Hundred` : "", rest ? twoDigits(rest) : ""].filter(Boolean).join(" ");
}

export function numberToIndianWords(n: number): string {
  n = Math.floor(Math.abs(n));
  if (n === 0) return "Zero";
  const parts: string[] = [];
  const crore = Math.floor(n / 1e7);
  n %= 1e7;
  const lakh = Math.floor(n / 1e5);
  n %= 1e5;
  const thousand = Math.floor(n / 1e3);
  n %= 1e3;
  if (crore) parts.push(`${crore >= 100 ? numberToIndianWords(crore) : twoDigits(crore)} Crore`);
  if (lakh) parts.push(`${twoDigits(lakh)} Lakh`);
  if (thousand) parts.push(`${twoDigits(thousand)} Thousand`);
  if (n) parts.push(threeDigits(n));
  return parts.join(" ");
}

export function amountInWordsINR(amount: number) {
  const totalPaise = Math.round(Math.abs(amount) * 100);
  const rupees = Math.floor(totalPaise / 100);
  const paise = totalPaise % 100;
  return `Rupees ${numberToIndianWords(rupees)}${paise ? ` and ${twoDigits(paise)} Paise` : ""} Only`;
}
