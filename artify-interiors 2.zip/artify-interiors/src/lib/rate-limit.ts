import "server-only";
import { env } from "@/lib/env";

// Fixed-window rate limiter. Uses Upstash Redis REST when configured (works across serverless
// instances), otherwise an in-memory map (per instance — fine for a single server / development).

type Bucket = { count: number; resetAt: number };
const memory = new Map<string, Bucket>();

export type RateLimitResult = { ok: boolean; remaining: number; resetInSeconds: number };

async function upstashHit(key: string, windowSec: number): Promise<number | null> {
  const { url, token } = env.upstash();
  if (!url || !token) return null;
  try {
    const res = await fetch(`${url}/pipeline`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify([
        ["INCR", key],
        ["EXPIRE", key, String(windowSec), "NX"],
      ]),
      cache: "no-store",
    });
    if (!res.ok) return null;
    const data = (await res.json()) as Array<{ result?: number }>;
    return Number(data?.[0]?.result ?? 0);
  } catch {
    return null; // fail open to in-memory
  }
}

export async function rateLimit(key: string, limit: number, windowSec: number): Promise<RateLimitResult> {
  const fullKey = `rl:${key}`;
  const remote = await upstashHit(fullKey, windowSec);
  if (remote !== null) {
    return { ok: remote <= limit, remaining: Math.max(0, limit - remote), resetInSeconds: windowSec };
  }
  const now = Date.now();
  let bucket = memory.get(fullKey);
  if (!bucket || bucket.resetAt <= now) {
    bucket = { count: 0, resetAt: now + windowSec * 1000 };
    memory.set(fullKey, bucket);
  }
  bucket.count += 1;
  if (memory.size > 10_000) {
    for (const [k, b] of memory) if (b.resetAt <= now) memory.delete(k);
  }
  return { ok: bucket.count <= limit, remaining: Math.max(0, limit - bucket.count), resetInSeconds: Math.ceil((bucket.resetAt - now) / 1000) };
}

export function clientIp(headers: Headers) {
  return headers.get("x-forwarded-for")?.split(",")[0]?.trim() || headers.get("x-real-ip") || "unknown";
}
