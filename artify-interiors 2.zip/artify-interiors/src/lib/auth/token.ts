// Edge-safe JWT helpers (used by proxy.ts and server code). No Node-only imports here.
import { SignJWT, jwtVerify } from "jose";

export const SESSION_COOKIE = "artify_session";
export const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 7; // 7 days

export type SessionRole = "CUSTOMER" | "STAFF" | "ADMIN";
export type SessionPayload = { sub: string; role: SessionRole; name: string };

function secretKey() {
  const secret = process.env.AUTH_SECRET ?? "";
  if (secret.length < 32) {
    throw new Error("AUTH_SECRET must be set to a random string of at least 32 characters.");
  }
  return new TextEncoder().encode(secret);
}

export async function signSession(payload: SessionPayload, maxAgeSeconds = SESSION_MAX_AGE_SECONDS) {
  return new SignJWT({ role: payload.role, name: payload.name })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(payload.sub)
    .setIssuedAt()
    .setIssuer("artify-interiors")
    .setExpirationTime(`${maxAgeSeconds}s`)
    .sign(secretKey());
}

export async function verifySession(token: string | undefined | null): Promise<SessionPayload | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secretKey(), { issuer: "artify-interiors", algorithms: ["HS256"] });
    const role = payload.role as SessionRole;
    if (!payload.sub || !["CUSTOMER", "STAFF", "ADMIN"].includes(role)) return null;
    return { sub: payload.sub, role, name: String(payload.name ?? "") };
  } catch {
    return null;
  }
}

export const isTeamRole = (role: string | undefined | null) => role === "ADMIN" || role === "STAFF";
