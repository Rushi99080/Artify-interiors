import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { SESSION_COOKIE, SESSION_MAX_AGE_SECONDS, signSession, verifySession } from "@/lib/auth/token";
import { can, type Permission, type Role } from "@/lib/auth/permissions";

export type CurrentUser = {
  id: string;
  email: string;
  name: string;
  phone: string | null;
  role: Role;
  customerId: string | null;
  teamMemberId: string | null;
};

/** Reads and verifies the session cookie, then loads the (active) user from the database. Cached per request. */
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const store = await cookies();
  const session = await verifySession(store.get(SESSION_COOKIE)?.value);
  if (!session) return null;
  const user = await prisma.user.findUnique({
    where: { id: session.sub },
    select: {
      id: true,
      email: true,
      name: true,
      phone: true,
      role: true,
      isActive: true,
      customer: { select: { id: true } },
      teamMember: { select: { id: true } },
    },
  });
  if (!user || !user.isActive) return null;
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    phone: user.phone,
    role: user.role as Role,
    customerId: user.customer?.id ?? null,
    teamMemberId: user.teamMember?.id ?? null,
  };
});

export async function createSessionCookie(user: { id: string; role: Role; name: string }) {
  const token = await signSession({ sub: user.id, role: user.role, name: user.name });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE_SECONDS,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

/** For server components / pages: redirects to login when not signed in. */
export async function requireUser(nextPath?: string): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect(`/login${nextPath ? `?next=${encodeURIComponent(nextPath)}` : ""}`);
  return user;
}

/** For admin pages: team members only, optionally checking a specific permission. */
export async function requireTeam(permission: Permission = "admin.access"): Promise<CurrentUser> {
  const user = await requireUser("/admin");
  if (!can(user.role, "admin.access")) redirect("/dashboard");
  if (!can(user.role, permission)) redirect("/admin?denied=1");
  return user;
}

export const isTeam = (user: Pick<CurrentUser, "role"> | null | undefined) => !!user && (user.role === "ADMIN" || user.role === "STAFF");
