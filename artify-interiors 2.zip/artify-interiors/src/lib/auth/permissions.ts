// Role-based access control.
// ADMIN  — full access including settings, team, website content, payments and reports.
// STAFF  — day-to-day operations: leads, projects, designs, BOQ, quotations, materials.
// CUSTOMER — only their own projects.

export type Role = "CUSTOMER" | "STAFF" | "ADMIN";

export const PERMISSIONS = {
  "admin.access": ["ADMIN", "STAFF"],
  "leads.manage": ["ADMIN", "STAFF"],
  "customers.manage": ["ADMIN", "STAFF"],
  "projects.manage": ["ADMIN", "STAFF"],
  "designs.manage": ["ADMIN", "STAFF"],
  "materials.manage": ["ADMIN", "STAFF"],
  "materials.delete": ["ADMIN"],
  "suppliers.manage": ["ADMIN", "STAFF"],
  "boq.manage": ["ADMIN", "STAFF"],
  "quotations.manage": ["ADMIN", "STAFF"],
  "payments.record": ["ADMIN", "STAFF"],
  "payments.delete": ["ADMIN"],
  "expenses.manage": ["ADMIN"],
  "reports.view": ["ADMIN"],
  "team.manage": ["ADMIN"],
  "content.manage": ["ADMIN"],
  "settings.manage": ["ADMIN"],
} as const satisfies Record<string, readonly Role[]>;

export type Permission = keyof typeof PERMISSIONS;

export function can(role: Role | null | undefined, permission: Permission) {
  if (!role) return false;
  return (PERMISSIONS[permission] as readonly Role[]).includes(role);
}
