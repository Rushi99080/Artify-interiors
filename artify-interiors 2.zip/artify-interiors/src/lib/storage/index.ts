import "server-only";
import { randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import { v2 as cloudinary } from "cloudinary";
import { env } from "@/lib/env";
import { isImageExt } from "@/lib/storage/rules";

// Storage abstraction. "local" writes to ./storage (outside /public, served through
// /api/files/[id] with access checks). "cloudinary" stores private ("authenticated") assets
// and serves them via signed URLs after the same access checks.

export type StoredObject = { provider: "LOCAL" | "CLOUDINARY"; storageKey: string; resourceType: string | null };
export type FileRef = { storageProvider: "LOCAL" | "CLOUDINARY"; storageKey: string; resourceType: string | null; mimeType: string; isPublic: boolean };

const LOCAL_ROOT = path.join(process.cwd(), "storage", "uploads");

let cloudinaryConfigured = false;
function cld() {
  const c = env.cloudinary();
  if (!c.cloudName || !c.apiKey || !c.apiSecret) {
    throw new Error("Cloudinary is selected (STORAGE_PROVIDER=cloudinary) but CLOUDINARY_CLOUD_NAME / API_KEY / API_SECRET are missing.");
  }
  if (!cloudinaryConfigured) {
    cloudinary.config({ cloud_name: c.cloudName, api_key: c.apiKey, api_secret: c.apiSecret, secure: true });
    cloudinaryConfigured = true;
  }
  return { sdk: cloudinary, cfg: c };
}

export function activeProvider() {
  return env.storageProvider();
}

function cloudinaryResourceType(ext: string) {
  return isImageExt(ext) ? "image" : "raw";
}

export function buildCloudinaryPublicId(scope: string, ext: string) {
  const { cfg } = cld();
  const id = randomUUID();
  const resourceType = cloudinaryResourceType(ext);
  // raw assets keep the extension in the public id so they download with the right name
  return { publicId: `${cfg.folder}/${scope}/${id}${resourceType === "raw" ? `.${ext}` : ""}`, resourceType };
}

export async function saveBuffer(buffer: Buffer, opts: { ext: string; scope: string; isPublic?: boolean }): Promise<StoredObject> {
  if (activeProvider() === "cloudinary") {
    const { sdk } = cld();
    const { publicId, resourceType } = buildCloudinaryPublicId(opts.scope, opts.ext);
    const result = await new Promise<{ public_id: string; resource_type: string }>((resolve, reject) => {
      const stream = sdk.uploader.upload_stream(
        {
          public_id: publicId,
          resource_type: resourceType as "image" | "raw",
          type: opts.isPublic ? "upload" : "authenticated",
          overwrite: false,
        },
        (err, res) => (err || !res ? reject(err ?? new Error("Cloudinary upload failed")) : resolve(res as { public_id: string; resource_type: string })),
      );
      stream.end(buffer);
    });
    return { provider: "CLOUDINARY", storageKey: result.public_id, resourceType: result.resource_type };
  }

  const now = new Date();
  const rel = path.posix.join(opts.scope.replace(/[^a-zA-Z0-9/_-]/g, ""), `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}`, `${randomUUID()}.${opts.ext}`);
  const abs = path.join(LOCAL_ROOT, rel);
  await fs.mkdir(path.dirname(abs), { recursive: true });
  await fs.writeFile(abs, buffer);
  return { provider: "LOCAL", storageKey: rel, resourceType: null };
}

function localPath(key: string) {
  const abs = path.resolve(LOCAL_ROOT, key);
  if (!abs.startsWith(path.resolve(LOCAL_ROOT) + path.sep)) throw new Error("Invalid storage key");
  return abs;
}

const extFromMime = (mime: string) => (mime === "image/png" ? "png" : mime === "image/webp" ? "webp" : "jpg");

/** URL the browser can be redirected to (Cloudinary). Local files are streamed instead. */
export function deliveryUrl(file: FileRef): string | null {
  if (file.storageProvider !== "CLOUDINARY") return null;
  const { sdk } = cld();
  const resourceType = file.resourceType ?? "image";
  return sdk.url(file.storageKey, {
    resource_type: resourceType,
    type: file.isPublic ? "upload" : "authenticated",
    sign_url: !file.isPublic,
    secure: true,
    ...(resourceType === "image" ? { format: extFromMime(file.mimeType) } : {}),
  });
}

export async function readBuffer(file: FileRef): Promise<Buffer> {
  if (file.storageProvider === "CLOUDINARY") {
    const url = deliveryUrl(file);
    if (!url) throw new Error("No delivery URL");
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) throw new Error(`Could not fetch file from Cloudinary (${res.status})`);
    return Buffer.from(await res.arrayBuffer());
  }
  return fs.readFile(localPath(file.storageKey));
}

export async function removeObject(file: FileRef) {
  try {
    if (file.storageProvider === "CLOUDINARY") {
      const { sdk } = cld();
      await sdk.uploader.destroy(file.storageKey, { resource_type: file.resourceType ?? "image", type: file.isPublic ? "upload" : "authenticated", invalidate: true });
    } else {
      await fs.unlink(localPath(file.storageKey));
    }
  } catch {
    // already gone — ignore
  }
}

/** Parameters for a signed direct browser → Cloudinary upload (bypasses serverless body limits). */
export function signedUploadParams(scope: string, ext: string, isPublic = false) {
  const { sdk, cfg } = cld();
  const { publicId, resourceType } = buildCloudinaryPublicId(scope, ext);
  const timestamp = Math.round(Date.now() / 1000);
  const params: Record<string, string | number> = { public_id: publicId, timestamp, type: isPublic ? "upload" : "authenticated" };
  const signature = sdk.utils.api_sign_request(params, cfg.apiSecret);
  return {
    uploadUrl: `https://api.cloudinary.com/v1_1/${cfg.cloudName}/${resourceType}/upload`,
    fields: { ...params, api_key: cfg.apiKey, signature },
    publicId,
    resourceType,
  };
}

/** Verifies the signature Cloudinary returns after a direct upload. */
export function verifyCloudinaryUpload(publicId: string, version: string | number, signature: string) {
  const { sdk, cfg } = cld();
  const expected = sdk.utils.api_sign_request({ public_id: publicId, version: String(version) }, cfg.apiSecret);
  return expected === signature;
}
