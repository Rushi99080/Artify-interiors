// Upload validation rules (shared by client and server).

export type UploadCategory =
  | "ROOM_PHOTO"
  | "FLOOR_PLAN"
  | "DRAWING_PDF"
  | "CAD"
  | "MEASUREMENT"
  | "REFERENCE"
  | "DOCUMENT"
  | "SITE_PHOTO"
  | "CONTENT"
  | "GENERATED";

const IMAGE = ["jpg", "jpeg", "png", "webp"];

export const UPLOAD_RULES: Record<UploadCategory, { exts: string[]; maxMB: number; label: string }> = {
  ROOM_PHOTO: { exts: IMAGE, maxMB: 15, label: "Room photographs (JPG, PNG, WEBP)" },
  REFERENCE: { exts: IMAGE, maxMB: 15, label: "Reference images (JPG, PNG, WEBP)" },
  SITE_PHOTO: { exts: IMAGE, maxMB: 15, label: "Site photos" },
  CONTENT: { exts: IMAGE, maxMB: 10, label: "Website images" },
  GENERATED: { exts: IMAGE, maxMB: 25, label: "AI visualizations" },
  FLOOR_PLAN: { exts: [...IMAGE, "pdf"], maxMB: 20, label: "Floor plans (image or PDF)" },
  DRAWING_PDF: { exts: ["pdf"], maxMB: 25, label: "Architectural drawings (PDF)" },
  CAD: { exts: ["dwg", "dxf", "pdf"], maxMB: 50, label: "CAD files (DWG, DXF)" },
  MEASUREMENT: { exts: [...IMAGE, "pdf", "xlsx", "csv", "txt"], maxMB: 15, label: "Measurements (image, PDF, Excel, CSV)" },
  DOCUMENT: { exts: [...IMAGE, "pdf", "docx", "xlsx"], maxMB: 25, label: "Documents" },
};

export const MIME_BY_EXT: Record<string, string> = {
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  pdf: "application/pdf",
  dwg: "image/vnd.dwg",
  dxf: "image/vnd.dxf",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  csv: "text/csv",
  txt: "text/plain",
};

export function extOf(filename: string) {
  const m = /\.([a-z0-9]+)$/i.exec(filename.trim());
  return m ? m[1]!.toLowerCase() : "";
}

export function isImageExt(ext: string) {
  return IMAGE.includes(ext);
}

/** Pre-check on the client and server before reading bytes. */
export function checkUploadMeta(category: UploadCategory, filename: string, size: number): string | null {
  const rule = UPLOAD_RULES[category];
  if (!rule) return "Unknown upload category.";
  const ext = extOf(filename);
  if (!rule.exts.includes(ext)) return `${filename}: allowed types are ${rule.exts.join(", ").toUpperCase()}.`;
  if (size <= 0) return `${filename} is empty.`;
  if (size > rule.maxMB * 1024 * 1024) return `${filename} is larger than ${rule.maxMB} MB.`;
  return null;
}

/** Verifies the file's real content matches its extension (magic bytes). */
export function sniffMatches(ext: string, bytes: Uint8Array): boolean {
  const b = bytes;
  const starts = (...sig: number[]) => sig.every((v, i) => b[i] === v);
  const ascii = (s: string, offset = 0) => [...s].every((ch, i) => b[offset + i] === ch.charCodeAt(0));
  switch (ext) {
    case "jpg":
    case "jpeg":
      return starts(0xff, 0xd8, 0xff);
    case "png":
      return starts(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a);
    case "webp":
      return ascii("RIFF") && ascii("WEBP", 8);
    case "pdf":
      return ascii("%PDF");
    case "dwg":
      return ascii("AC10");
    case "xlsx":
    case "docx":
      return starts(0x50, 0x4b, 0x03, 0x04);
    case "csv":
    case "txt":
    case "dxf": {
      const n = Math.min(b.length, 2048);
      for (let i = 0; i < n; i++) if (b[i] === 0) return false;
      return true;
    }
    default:
      return false;
  }
}
