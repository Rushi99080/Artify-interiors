// Structured error logging. Logs are JSON lines so Vercel / any log drain can index them.
// To forward errors to Sentry or similar, add the call inside logError().

export function logError(scope: string, err: unknown, meta: Record<string, unknown> = {}) {
  const e = err as { message?: string; stack?: string; code?: string };
  console.error(
    JSON.stringify({
      level: "error",
      scope,
      message: e?.message ?? String(err),
      code: e?.code,
      stack: process.env.NODE_ENV === "production" ? undefined : e?.stack?.split("\n").slice(0, 6).join("\n"),
      time: new Date().toISOString(),
      ...meta,
    }),
  );
}

export function logInfo(scope: string, message: string, meta: Record<string, unknown> = {}) {
  console.log(JSON.stringify({ level: "info", scope, message, time: new Date().toISOString(), ...meta }));
}
