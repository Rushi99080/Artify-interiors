// Shared labels, options and metadata used across the app.
// Kept free of server-only imports so client components can use it.

export const DESIGN_STYLES = [
  "MODERN",
  "CONTEMPORARY",
  "MINIMALIST",
  "LUXURY",
  "SCANDINAVIAN",
  "INDUSTRIAL",
  "TRADITIONAL",
  "NEO_CLASSICAL",
  "JAPANDI",
] as const;
export type DesignStyleKey = (typeof DESIGN_STYLES)[number];

export const STYLE_INFO: Record<DesignStyleKey, { label: string; description: string; palette: string[] }> = {
  MODERN: {
    label: "Modern",
    description: "Clean lines, flat surfaces and a restrained palette with bold accents.",
    palette: ["#F4F1EC", "#2B2B2B", "#B8A07E", "#7A8B8C"],
  },
  CONTEMPORARY: {
    label: "Contemporary",
    description: "Current, fluid and curved forms with layered textures and statement lighting.",
    palette: ["#EFEAE3", "#3C3A36", "#C2A27C", "#9AA5A0"],
  },
  MINIMALIST: {
    label: "Minimalist",
    description: "Only what matters — hidden storage, negative space and calm monochrome surfaces.",
    palette: ["#FAF8F5", "#E5E0D8", "#8A8178", "#1F1F1F"],
  },
  LUXURY: {
    label: "Luxury",
    description: "Marble, fluted veneers, brass detailing and indulgent upholstery.",
    palette: ["#F2ECE2", "#1E1B18", "#B08D57", "#5A4A3A"],
  },
  SCANDINAVIAN: {
    label: "Scandinavian",
    description: "Light woods, soft whites and cosy textiles designed around daylight.",
    palette: ["#FFFFFF", "#E8E2D6", "#C9B79C", "#6E7F80"],
  },
  INDUSTRIAL: {
    label: "Industrial",
    description: "Exposed textures, metal frames, concrete finishes and warm leather.",
    palette: ["#D8D3CC", "#4A4744", "#8C5B3F", "#2E2E2E"],
  },
  TRADITIONAL: {
    label: "Traditional",
    description: "Rich woods, carved details and heritage motifs with warm, earthy tones.",
    palette: ["#F3E9D8", "#7B4B2A", "#A8763E", "#3E2C1F"],
  },
  NEO_CLASSICAL: {
    label: "Neo-Classical",
    description: "Symmetry, mouldings, soft pastels and refined gold accents.",
    palette: ["#F6F1EA", "#D9CBB7", "#B99A6B", "#4B4540"],
  },
  JAPANDI: {
    label: "Japandi",
    description: "Japanese restraint meets Scandinavian warmth — natural materials, low profiles.",
    palette: ["#F1ECE4", "#CBBBA6", "#8B7A66", "#2F2C28"],
  },
};

export const PROPERTY_TYPES = ["APARTMENT", "VILLA", "OFFICE", "COMMERCIAL"] as const;
export type PropertyTypeKey = (typeof PROPERTY_TYPES)[number];
export const PROPERTY_TYPE_LABELS: Record<PropertyTypeKey, string> = {
  APARTMENT: "Apartment",
  VILLA: "Villa",
  OFFICE: "Office",
  COMMERCIAL: "Commercial",
};

export const PRICE_TIERS = ["ECONOMY", "STANDARD", "PREMIUM", "LUXURY"] as const;
export type PriceTierKey = (typeof PRICE_TIERS)[number];
export const TIER_LABELS: Record<PriceTierKey, string> = {
  ECONOMY: "Essential",
  STANDARD: "Signature",
  PREMIUM: "Premium",
  LUXURY: "Luxe",
};
export const TIER_DESCRIPTIONS: Record<PriceTierKey, string> = {
  ECONOMY: "Durable BWR ply, matte laminates, standard hardware.",
  STANDARD: "BWP ply / HDHMR, premium laminates, soft-close hardware.",
  PREMIUM: "Marine ply, acrylic & veneer finishes, branded imported hardware.",
  LUXURY: "Bespoke veneers, lacquer, natural stone and designer lighting.",
};

export const ROOM_TYPES = [
  "ENTRANCE",
  "LIVING_ROOM",
  "MASTER_BEDROOM",
  "KIDS_BEDROOM",
  "GUEST_BEDROOM",
  "KITCHEN",
  "DINING_ROOM",
  "BATHROOM",
  "WARDROBE",
  "TV_UNIT",
  "FALSE_CEILING",
  "BALCONY",
  "OFFICE",
  "COMMERCIAL",
] as const;
export type RoomTypeKey = (typeof ROOM_TYPES)[number];

export type RoomModule = {
  type: RoomTypeKey;
  slug: string;
  label: string;
  short: string;
  description: string;
  includes: string[];
  /** What L / W / H mean for this module */
  dimensionLabels: { length: string; width: string; height: string };
  defaults: { lengthFt: number; widthFt: number; heightFt: number };
  materialCategories: string[];
  showInServices: boolean;
};

export const ROOM_MODULES: RoomModule[] = [
  {
    type: "LIVING_ROOM",
    slug: "living-room",
    label: "Living Room",
    short: "The heart of the home, composed for conversation and calm.",
    description:
      "Media walls, statement paneling, layered ceilings and curated loose furniture planned around how your family actually lives.",
    includes: ["TV unit & media wall", "Wall paneling", "False ceiling with cove lighting", "Sofa & coffee table", "Curtains", "Painting & electrical"],
    dimensionLabels: { length: "Room length", width: "Room width", height: "Ceiling height" },
    defaults: { lengthFt: 16, widthFt: 12, heightFt: 10 },
    materialCategories: ["LAMINATE", "VENEER", "HDHMR", "PAINT", "WALLPAPER", "FLOORING", "LIGHTING", "UPHOLSTERY"],
    showInServices: true,
  },
  {
    type: "MASTER_BEDROOM",
    slug: "master-bedroom",
    label: "Master Bedroom",
    short: "A private retreat with generous storage and soft light.",
    description: "Floor-to-ceiling wardrobes, upholstered headboards, bedside lighting and a ceiling that sets the mood.",
    includes: ["Wardrobe with soft-close hardware", "Bed with hydraulic storage", "Side tables & dresser", "Headboard paneling", "False ceiling", "Curtains, painting & electrical"],
    dimensionLabels: { length: "Room length", width: "Room width", height: "Ceiling height" },
    defaults: { lengthFt: 14, widthFt: 12, heightFt: 10 },
    materialCategories: ["PLYWOOD", "LAMINATE", "ACRYLIC", "VENEER", "HINGES", "HANDLES", "UPHOLSTERY", "LIGHTING"],
    showInServices: true,
  },
  {
    type: "KIDS_BEDROOM",
    slug: "kids-bedroom",
    label: "Kids Bedroom",
    short: "Playful, safe and ready to grow with them.",
    description: "Rounded edges, study corners, smart storage and a feature wall they will love.",
    includes: ["Wardrobe", "Bed / bunk bed", "Study table & bookshelf", "Feature wallpaper", "False ceiling", "Painting & electrical"],
    dimensionLabels: { length: "Room length", width: "Room width", height: "Ceiling height" },
    defaults: { lengthFt: 12, widthFt: 10, heightFt: 10 },
    materialCategories: ["PLYWOOD", "LAMINATE", "WALLPAPER", "HINGES", "HANDLES", "LIGHTING"],
    showInServices: true,
  },
  {
    type: "KITCHEN",
    slug: "kitchen",
    label: "Kitchen",
    short: "Ergonomic modular kitchens engineered for Indian cooking.",
    description: "Work-triangle planning, waterproof carcasses, quartz counters and organised drawers for daily use.",
    includes: ["Base & wall cabinets", "Tall unit", "Quartz countertop", "Backsplash tiles", "Channels, hinges & handles", "Under-cabinet lighting"],
    dimensionLabels: { length: "Kitchen length", width: "Kitchen width", height: "Ceiling height" },
    defaults: { lengthFt: 10, widthFt: 8, heightFt: 10 },
    materialCategories: ["PLYWOOD", "HDHMR", "LAMINATE", "ACRYLIC", "QUARTZ", "TILES", "CHANNELS", "HINGES", "HANDLES"],
    showInServices: true,
  },
  {
    type: "DINING_ROOM",
    slug: "dining-room",
    label: "Dining Room",
    short: "Gather well — crockery, lighting and table in harmony.",
    description: "Crockery units with glass shutters, pendant lighting and dining sets proportioned to your space.",
    includes: ["Crockery unit", "Dining table set", "Pendant lights", "Accent paneling", "False ceiling", "Painting"],
    dimensionLabels: { length: "Room length", width: "Room width", height: "Ceiling height" },
    defaults: { lengthFt: 10, widthFt: 10, heightFt: 10 },
    materialCategories: ["VENEER", "LAMINATE", "GLASS", "LIGHTING", "UPHOLSTERY"],
    showInServices: true,
  },
  {
    type: "BATHROOM",
    slug: "bathroom",
    label: "Bathroom",
    short: "Spa-like bathrooms with waterproof detailing.",
    description: "Vanities, backlit mirrors, large-format tiles and glass shower partitions detailed for wet areas.",
    includes: ["Vanity unit", "LED mirror", "Wall & floor tiles", "Shower partition", "Accessories", "Ceiling"],
    dimensionLabels: { length: "Bathroom length", width: "Bathroom width", height: "Ceiling height" },
    defaults: { lengthFt: 8, widthFt: 5, heightFt: 9 },
    materialCategories: ["TILES", "MARBLE", "GLASS", "QUARTZ", "LIGHTING"],
    showInServices: true,
  },
  {
    type: "WARDROBE",
    slug: "wardrobe",
    label: "Wardrobe",
    short: "Sliding or hinged — storage designed to your wardrobe.",
    description: "Internal layouts for hanging, drawers, lofts and accessories with finishes from matte laminate to lacquered glass.",
    includes: ["Carcass & shutters", "Loft", "Internal drawers", "Hinges / sliding channels", "Handles", "Profile lighting"],
    dimensionLabels: { length: "Wardrobe width", width: "Depth", height: "Wardrobe height" },
    defaults: { lengthFt: 8, widthFt: 2, heightFt: 8 },
    materialCategories: ["PLYWOOD", "HDHMR", "LAMINATE", "ACRYLIC", "GLASS", "HINGES", "CHANNELS", "HANDLES"],
    showInServices: true,
  },
  {
    type: "TV_UNIT",
    slug: "tv-unit",
    label: "TV Unit",
    short: "Media walls that hide the clutter and frame the screen.",
    description: "Floating consoles, fluted or stone-clad backdrops, concealed wiring and display niches.",
    includes: ["Console & storage", "Back paneling", "Concealed wiring", "Profile lighting"],
    dimensionLabels: { length: "Unit width", width: "Depth", height: "Unit height" },
    defaults: { lengthFt: 8, widthFt: 1.5, heightFt: 7 },
    materialCategories: ["HDHMR", "LAMINATE", "VENEER", "MARBLE", "LIGHTING"],
    showInServices: true,
  },
  {
    type: "FALSE_CEILING",
    slug: "false-ceiling",
    label: "False Ceiling",
    short: "Layered gypsum ceilings with cove and accent lighting.",
    description: "Peripheral, island and coffered designs in gypsum or POP, finished with concealed profile lighting.",
    includes: ["Gypsum ceiling with framing", "Cove profile lighting", "LED downlights", "Ceiling paint"],
    dimensionLabels: { length: "Room length", width: "Room width", height: "Ceiling height" },
    defaults: { lengthFt: 14, widthFt: 12, heightFt: 10 },
    materialCategories: ["FALSE_CEILING", "LIGHTING", "PAINT"],
    showInServices: true,
  },
  {
    type: "BALCONY",
    slug: "balcony",
    label: "Balcony",
    short: "An outdoor room — deck, greens and a place to sit.",
    description: "Weather-proof deck tiles, planters, cladding and seating that turn a balcony into a retreat.",
    includes: ["Deck / outdoor flooring", "Planters", "Wall cladding", "Seating", "Outdoor lighting"],
    dimensionLabels: { length: "Balcony length", width: "Balcony depth", height: "Height" },
    defaults: { lengthFt: 10, widthFt: 4, heightFt: 10 },
    materialCategories: ["FLOORING", "TILES", "LIGHTING", "UPHOLSTERY"],
    showInServices: true,
  },
  {
    type: "OFFICE",
    slug: "office-interiors",
    label: "Office Interiors",
    short: "Workplaces that support focus and brand.",
    description: "Workstations, glass cabins, acoustic ceilings and data-ready electrical for productive teams.",
    includes: ["Workstations", "Glass partitions", "Storage", "Ceiling & lighting", "Flooring", "Electrical & data points"],
    dimensionLabels: { length: "Floor length", width: "Floor width", height: "Ceiling height" },
    defaults: { lengthFt: 30, widthFt: 20, heightFt: 11 },
    materialCategories: ["LAMINATE", "GLASS", "FLOORING", "FALSE_CEILING", "LIGHTING", "UPHOLSTERY"],
    showInServices: true,
  },
  {
    type: "COMMERCIAL",
    slug: "commercial-interiors",
    label: "Commercial Interiors",
    short: "Retail, hospitality and showrooms built for footfall.",
    description: "Reception counters, display systems, durable flooring and lighting that sells.",
    includes: ["Reception counter", "Display units", "Ceiling & lighting", "Commercial flooring", "Painting", "Electrical"],
    dimensionLabels: { length: "Floor length", width: "Floor width", height: "Ceiling height" },
    defaults: { lengthFt: 30, widthFt: 25, heightFt: 12 },
    materialCategories: ["LAMINATE", "ACRYLIC", "GLASS", "TILES", "MARBLE", "LIGHTING"],
    showInServices: true,
  },
  {
    type: "ENTRANCE",
    slug: "entrance-foyer",
    label: "Entrance & Foyer",
    short: "First impressions — shoe storage and a statement wall.",
    description: "Shoe cabinets, seating, mirrors and paneling that make arriving home feel considered.",
    includes: ["Shoe rack", "Foyer paneling", "Lighting", "Painting"],
    dimensionLabels: { length: "Foyer length", width: "Foyer width", height: "Ceiling height" },
    defaults: { lengthFt: 6, widthFt: 5, heightFt: 10 },
    materialCategories: ["LAMINATE", "VENEER", "LIGHTING"],
    showInServices: false,
  },
  {
    type: "GUEST_BEDROOM",
    slug: "guest-bedroom",
    label: "Guest Bedroom",
    short: "Comfortable, flexible rooms for family and guests.",
    description: "Compact wardrobes, a comfortable bed and flexible storage.",
    includes: ["Wardrobe", "Bed with storage", "Side table", "Painting & electrical"],
    dimensionLabels: { length: "Room length", width: "Room width", height: "Ceiling height" },
    defaults: { lengthFt: 12, widthFt: 11, heightFt: 10 },
    materialCategories: ["PLYWOOD", "LAMINATE", "HINGES", "HANDLES"],
    showInServices: false,
  },
];

export const ROOM_MODULE_BY_TYPE = Object.fromEntries(ROOM_MODULES.map((m) => [m.type, m])) as Record<RoomTypeKey, RoomModule>;
export const ROOM_MODULE_BY_SLUG = Object.fromEntries(ROOM_MODULES.map((m) => [m.slug, m])) as Record<string, RoomModule>;
export const ROOM_LABELS = Object.fromEntries(ROOM_MODULES.map((m) => [m.type, m.label])) as Record<RoomTypeKey, string>;

export const MATERIAL_CATEGORIES = [
  "PLYWOOD",
  "MDF",
  "HDHMR",
  "LAMINATE",
  "ACRYLIC",
  "VENEER",
  "PAINT",
  "WALLPAPER",
  "FLOORING",
  "TILES",
  "MARBLE",
  "QUARTZ",
  "HARDWARE",
  "HINGES",
  "CHANNELS",
  "HANDLES",
  "LIGHTING",
  "FALSE_CEILING",
  "GLASS",
  "UPHOLSTERY",
] as const;
export type MaterialCategoryKey = (typeof MATERIAL_CATEGORIES)[number];
export const MATERIAL_CATEGORY_LABELS: Record<MaterialCategoryKey, string> = {
  PLYWOOD: "Plywood",
  MDF: "MDF",
  HDHMR: "HDHMR",
  LAMINATE: "Laminates",
  ACRYLIC: "Acrylic",
  VENEER: "Veneer",
  PAINT: "Paint",
  WALLPAPER: "Wallpaper",
  FLOORING: "Flooring",
  TILES: "Tiles",
  MARBLE: "Marble",
  QUARTZ: "Quartz",
  HARDWARE: "Hardware",
  HINGES: "Hinges",
  CHANNELS: "Channels",
  HANDLES: "Handles",
  LIGHTING: "Lighting",
  FALSE_CEILING: "False Ceiling",
  GLASS: "Glass",
  UPHOLSTERY: "Upholstery",
};

export const AVAILABILITY_LABELS = {
  IN_STOCK: "In stock",
  LIMITED: "Limited stock",
  ON_ORDER: "On order",
  DISCONTINUED: "Discontinued",
} as const;

export const MATERIAL_UNITS = ["sqft", "sheet", "nos", "pair", "set", "rft", "litre", "roll", "sqm", "rmt", "kg"] as const;

export const PROJECT_STATUS_LABELS = {
  DRAFT: "Draft",
  DESIGN: "Design",
  QUOTATION: "Quotation",
  ACTIVE: "Active",
  ON_HOLD: "On hold",
  COMPLETED: "Completed",
  CANCELLED: "Cancelled",
} as const;

export const LEAD_STATUS_LABELS = {
  NEW: "New",
  CONTACTED: "Contacted",
  CONSULTATION: "Consultation",
  QUOTATION_SENT: "Quotation Sent",
  CONVERTED: "Converted",
  LOST: "Lost",
} as const;

export const LEAD_SOURCE_LABELS = {
  WEBSITE: "Website",
  AI_DESIGNER: "AI Designer",
  COST_CALCULATOR: "Cost Calculator",
  REFERRAL: "Referral",
  WALK_IN: "Walk-in",
  INSTAGRAM: "Instagram",
  FACEBOOK: "Facebook",
  GOOGLE: "Google",
  OTHER: "Other",
} as const;

export const QUOTATION_STATUS_LABELS = {
  DRAFT: "Draft",
  SENT: "Sent",
  CHANGES_REQUESTED: "Changes requested",
  APPROVED: "Approved",
  REJECTED: "Rejected",
  SUPERSEDED: "Superseded",
} as const;

export const DESIGN_STATUS_LABELS = {
  GENERATED: "Generated",
  SAVED: "Saved",
  APPROVED: "Approved",
  CHANGES_REQUESTED: "Changes requested",
  REJECTED: "Rejected",
} as const;

export const MILESTONE_STATUS_LABELS = {
  PENDING: "Pending",
  IN_PROGRESS: "In progress",
  COMPLETED: "Completed",
  SKIPPED: "Skipped",
  BLOCKED: "Blocked",
} as const;

export const PAYMENT_METHOD_LABELS = {
  CASH: "Cash",
  UPI: "UPI",
  BANK_TRANSFER: "Bank transfer / RTGS",
  CHEQUE: "Cheque",
  CARD: "Card",
  RAZORPAY: "Razorpay (online)",
} as const;

export const EXPENSE_CATEGORY_LABELS = {
  MATERIAL: "Material",
  LABOUR: "Labour",
  TRANSPORT: "Transport",
  SUBCONTRACT: "Subcontract",
  OTHER: "Other",
} as const;

export const FILE_CATEGORY_LABELS = {
  ROOM_PHOTO: "Room photograph",
  FLOOR_PLAN: "Floor plan",
  DRAWING_PDF: "Architectural drawing (PDF)",
  CAD: "CAD file",
  MEASUREMENT: "Room measurements",
  REFERENCE: "Reference image",
  DOCUMENT: "Project document",
  GENERATED: "AI visualization",
  SITE_PHOTO: "Site photo",
  CONTENT: "Website content",
  OTHER: "Other",
} as const;

export const BUDGET_RANGES = [
  { label: "Under ₹3 Lakh", min: 0, max: 300000 },
  { label: "₹3 – 6 Lakh", min: 300000, max: 600000 },
  { label: "₹6 – 10 Lakh", min: 600000, max: 1000000 },
  { label: "₹10 – 20 Lakh", min: 1000000, max: 2000000 },
  { label: "₹20 – 40 Lakh", min: 2000000, max: 4000000 },
  { label: "₹40 Lakh +", min: 4000000, max: 8000000 },
];

export const TIMELINE_OPTIONS = ["Within 1 month", "1 – 3 months", "3 – 6 months", "Just exploring"];

export function labelOf(map: Record<string, string>, key: string | null | undefined, fallback = "—") {
  if (!key) return fallback;
  return map[key] ?? key.replace(/_/g, " ").toLowerCase().replace(/^\w/, (c) => c.toUpperCase());
}
