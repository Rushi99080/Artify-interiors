import "server-only";

// Central place to read configuration. Nothing here is ever sent to the browser except the
// boolean "configured" flags returned by integrationStatus().

const str = (key: string, fallback = "") => (process.env[key] ?? fallback).trim();

export const env = {
  appUrl: () => str("APP_URL", "http://localhost:3000").replace(/\/$/, ""),
  authSecret: () => str("AUTH_SECRET"),
  storageProvider: () => (str("STORAGE_PROVIDER", "local").toLowerCase() === "cloudinary" ? "cloudinary" : "local") as "local" | "cloudinary",
  cloudinary: () => ({
    cloudName: str("CLOUDINARY_CLOUD_NAME"),
    apiKey: str("CLOUDINARY_API_KEY"),
    apiSecret: str("CLOUDINARY_API_SECRET"),
    folder: str("CLOUDINARY_FOLDER", "artify"),
  }),
  ai: () => ({
    textProvider: str("AI_TEXT_PROVIDER", "openai").toLowerCase(),
    imageProvider: str("AI_IMAGE_PROVIDER", "openai").toLowerCase(),
    variations: Math.min(Math.max(Number(str("AI_VARIATIONS", "3")) || 3, 1), 4),
    openai: {
      apiKey: str("OPENAI_API_KEY"),
      baseUrl: str("OPENAI_BASE_URL", "https://api.openai.com/v1").replace(/\/$/, ""),
      textModel: str("OPENAI_TEXT_MODEL", "gpt-6-luna"),
      imageModel: str("OPENAI_IMAGE_MODEL", "gpt-image-2.5-flare"),
      imageSize: str("OPENAI_IMAGE_SIZE", "1536x1024"),
    },
    gemini: {
      apiKey: str("GEMINI_API_KEY"),
      textModel: str("GEMINI_TEXT_MODEL", "gemini-3.8-flash"),
      imageModel: str("GEMINI_IMAGE_MODEL", "gemini-3.1-flash-image"),
    },
    anthropic: {
      apiKey: str("ANTHROPIC_API_KEY"),
      model: str("ANTHROPIC_MODEL", "claude-sonnet-5-5"),
    },
    replicate: {
      apiToken: str("REPLICATE_API_TOKEN"),
      imageModel: str("REPLICATE_IMAGE_MODEL", "adirik/interior-design"),
    },
  }),
  email: () => ({
    provider: str("EMAIL_PROVIDER", "none").toLowerCase(),
    from: str("EMAIL_FROM", "Artify Interiors <no-reply@example.com>"),
    adminEmail: str("ADMIN_NOTIFICATION_EMAIL"),
    smtp: {
      host: str("SMTP_HOST"),
      port: Number(str("SMTP_PORT", "587")) || 587,
      secure: str("SMTP_SECURE", "false") === "true",
      user: str("SMTP_USER"),
      pass: str("SMTP_PASS"),
    },
    resendKey: str("RESEND_API_KEY"),
  }),
  whatsapp: () => {
    let templates: Record<string, string> = {};
    try {
      templates = JSON.parse(str("WHATSAPP_TEMPLATES", "{}") || "{}");
    } catch {
      templates = {};
    }
    return {
      token: str("WHATSAPP_ACCESS_TOKEN"),
      phoneNumberId: str("WHATSAPP_PHONE_NUMBER_ID"),
      apiVersion: str("WHATSAPP_API_VERSION", "v23.0"),
      language: str("WHATSAPP_TEMPLATE_LANGUAGE", "en"),
      templates,
      adminNumber: str("ADMIN_WHATSAPP_NUMBER").replace(/\D/g, ""),
    };
  },
  razorpay: () => ({
    keyId: str("RAZORPAY_KEY_ID"),
    keySecret: str("RAZORPAY_KEY_SECRET"),
    webhookSecret: str("RAZORPAY_WEBHOOK_SECRET"),
  }),
  upstash: () => ({ url: str("UPSTASH_REDIS_REST_URL"), token: str("UPSTASH_REDIS_REST_TOKEN") }),
};

export type IntegrationState = { configured: boolean; detail: string };

export function aiTextStatus(): IntegrationState & { provider: string; model: string } {
  const a = env.ai();
  switch (a.textProvider) {
    case "openai":
      return { provider: "openai", model: a.openai.textModel, configured: !!a.openai.apiKey, detail: a.openai.apiKey ? `OpenAI · ${a.openai.textModel}` : "Set OPENAI_API_KEY" };
    case "gemini":
      return { provider: "gemini", model: a.gemini.textModel, configured: !!a.gemini.apiKey, detail: a.gemini.apiKey ? `Gemini · ${a.gemini.textModel}` : "Set GEMINI_API_KEY" };
    case "anthropic":
      return { provider: "anthropic", model: a.anthropic.model, configured: !!a.anthropic.apiKey, detail: a.anthropic.apiKey ? `Claude · ${a.anthropic.model}` : "Set ANTHROPIC_API_KEY" };
    default:
      return { provider: a.textProvider, model: "", configured: false, detail: `Unknown AI_TEXT_PROVIDER "${a.textProvider}" (use openai, gemini or anthropic)` };
  }
}

export function aiImageStatus(): IntegrationState & { provider: string; model: string } {
  const a = env.ai();
  switch (a.imageProvider) {
    case "openai":
      return { provider: "openai", model: a.openai.imageModel, configured: !!a.openai.apiKey, detail: a.openai.apiKey ? `OpenAI · ${a.openai.imageModel}` : "Set OPENAI_API_KEY" };
    case "gemini":
      return { provider: "gemini", model: a.gemini.imageModel, configured: !!a.gemini.apiKey, detail: a.gemini.apiKey ? `Gemini · ${a.gemini.imageModel}` : "Set GEMINI_API_KEY" };
    case "replicate":
      return { provider: "replicate", model: a.replicate.imageModel, configured: !!a.replicate.apiToken, detail: a.replicate.apiToken ? `Replicate · ${a.replicate.imageModel}` : "Set REPLICATE_API_TOKEN" };
    case "none":
    case "":
      return { provider: "none", model: "", configured: false, detail: "Image generation disabled (AI_IMAGE_PROVIDER=none)" };
    default:
      return { provider: a.imageProvider, model: "", configured: false, detail: `Unknown AI_IMAGE_PROVIDER "${a.imageProvider}" (use openai, gemini, replicate or none)` };
  }
}

export function integrationStatus() {
  const c = env.cloudinary();
  const e = env.email();
  const w = env.whatsapp();
  const r = env.razorpay();
  const u = env.upstash();
  const cloudinaryReady = !!(c.cloudName && c.apiKey && c.apiSecret);
  const emailReady =
    e.provider === "smtp" ? !!(e.smtp.host && e.smtp.user && e.smtp.pass) : e.provider === "resend" ? !!e.resendKey : false;
  return {
    aiText: aiTextStatus(),
    aiImage: aiImageStatus(),
    storage: {
      configured: env.storageProvider() === "local" ? true : cloudinaryReady,
      provider: env.storageProvider(),
      detail:
        env.storageProvider() === "local"
          ? "Local disk (./storage) — development only, not persistent on Vercel"
          : cloudinaryReady
            ? `Cloudinary · ${c.cloudName}`
            : "STORAGE_PROVIDER=cloudinary but Cloudinary keys are missing",
    },
    email: {
      configured: emailReady,
      detail: emailReady ? `${e.provider.toUpperCase()} · from ${e.from}` : e.provider === "none" ? "Disabled (EMAIL_PROVIDER=none)" : `EMAIL_PROVIDER=${e.provider} but credentials are missing`,
    },
    whatsapp: {
      configured: !!(w.token && w.phoneNumberId),
      detail:
        w.token && w.phoneNumberId
          ? `Cloud API · ${Object.keys(w.templates).length} template(s) mapped`
          : "Set WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID",
    },
    razorpay: { configured: !!(r.keyId && r.keySecret), detail: r.keyId && r.keySecret ? `Razorpay · ${r.keyId.startsWith("rzp_test") ? "test mode" : "live mode"}` : "Optional — set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET" },
    rateLimit: { configured: true, detail: u.url && u.token ? "Upstash Redis (shared across instances)" : "In-memory (per server instance)" },
  };
}
