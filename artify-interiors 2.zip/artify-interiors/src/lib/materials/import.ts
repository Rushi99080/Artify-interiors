// Material import (CSV / Excel) — pure row parsing & validation, unit-tested in tests/materials.test.ts.
import { DESIGN_STYLES, MATERIAL_CATEGORIES, MATERIAL_CATEGORY_LABELS, PRICE_TIERS, type DesignStyleKey, type MaterialCategoryKey, type PriceTierKey } from "@/lib/constants";

export const IMPORT_COLUMNS = [
  "Material Name",
  "Category",
  "Brand",
  "Product Code",
  "Finish",
  "Color",
  "Unit",
  "Rate",
  "Image URL",
  "Specifications",
  "Availability",
  "Supplier",
  "Tier",
  "Durability (1-5)",
  "Maintenance (1-5)",
  "Styles",
] as const;

export type ImportedMaterial = {
  name: string;
  category: MaterialCategoryKey;
  brand: string | null;
  productCode: string | null;
  finish: string | null;
  color: string | null;
  unit: string;
  rate: number;
  imageUrl: string | null;
  specifications: string | null;
  availability: "IN_STOCK" | "LIMITED" | "ON_ORDER" | "DISCONTINUED";
  supplierName: string | null;
  tier: PriceTierKey;
  durability: number;
  maintenance: number;
  styles: DesignStyleKey[];
};

const ALIASES: Record<string, keyof ImportedMaterial> = {
  "material name": "name",
  name: "name",
  material: "name",
  category: "category",
  brand: "brand",
  "product code": "productCode",
  code: "productCode",
  sku: "productCode",
  finish: "finish",
  color: "color",
  colour: "color",
  unit: "unit",
  uom: "unit",
  rate: "rate",
  price: "rate",
  "rate (inr)": "rate",
  "image url": "imageUrl",
  image: "imageUrl",
  specifications: "specifications",
  specs: "specifications",
  specification: "specifications",
  availability: "availability",
  stock: "availability",
  supplier: "supplierName",
  tier: "tier",
  "price tier": "tier",
  "durability (1-5)": "durability",
  durability: "durability",
  "maintenance (1-5)": "maintenance",
  maintenance: "maintenance",
  styles: "styles",
  style: "styles",
};

const norm = (s: unknown) =>
  String(s ?? "")
    .trim()
    .toLowerCase();

function toCategory(v: unknown): MaterialCategoryKey | null {
  const s = norm(v).replace(/[\s-]+/g, "_").toUpperCase();
  if ((MATERIAL_CATEGORIES as readonly string[]).includes(s)) return s as MaterialCategoryKey;
  const byLabel = Object.entries(MATERIAL_CATEGORY_LABELS).find(([, label]) => norm(label) === norm(v) || norm(label).replace(/s$/, "") === norm(v).replace(/s$/, ""));
  return (byLabel?.[0] as MaterialCategoryKey) ?? null;
}

function toTier(v: unknown): PriceTierKey {
  const s = norm(v).toUpperCase();
  if ((PRICE_TIERS as readonly string[]).includes(s)) return s as PriceTierKey;
  if (["ESSENTIAL", "BUDGET", "BASIC"].includes(s)) return "ECONOMY";
  if (["SIGNATURE", "MID", "MEDIUM"].includes(s)) return "STANDARD";
  if (["LUXE", "HIGH"].includes(s)) return "LUXURY";
  return "STANDARD";
}

function toAvailability(v: unknown): ImportedMaterial["availability"] {
  const s = norm(v).replace(/[\s-]+/g, "_").toUpperCase();
  if (["IN_STOCK", "LIMITED", "ON_ORDER", "DISCONTINUED"].includes(s)) return s as ImportedMaterial["availability"];
  if (s === "YES" || s === "AVAILABLE") return "IN_STOCK";
  if (s === "NO" || s === "OUT_OF_STOCK") return "ON_ORDER";
  return "IN_STOCK";
}

function toScore(v: unknown) {
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= 1 && n <= 5 ? n : 3;
}

function toNumber(v: unknown) {
  if (typeof v === "number") return v;
  const n = Number(String(v ?? "").replace(/[₹,\s]/g, "").replace(/^rs\.?/i, ""));
  return Number.isFinite(n) ? n : NaN;
}

const opt = (v: unknown) => {
  const s = String(v ?? "").trim();
  return s ? s : null;
};

export function parseMaterialRows(rows: Record<string, unknown>[]) {
  const valid: ImportedMaterial[] = [];
  const errors: { row: number; message: string }[] = [];
  const seenCodes = new Set<string>();

  rows.forEach((raw, idx) => {
    const rowNo = idx + 2; // header is row 1
    const r: Partial<Record<keyof ImportedMaterial, unknown>> = {};
    for (const [k, v] of Object.entries(raw)) {
      const key = ALIASES[norm(k)];
      if (key) r[key] = v;
    }
    if (Object.values(raw).every((v) => String(v ?? "").trim() === "")) return; // blank line

    const name = opt(r.name);
    const category = toCategory(r.category);
    const unit = opt(r.unit);
    const rate = toNumber(r.rate);
    const problems: string[] = [];
    if (!name) problems.push("Material Name is required");
    if (!category) problems.push(`Unknown category "${String(r.category ?? "")}"`);
    if (!unit) problems.push("Unit is required");
    if (!Number.isFinite(rate) || rate < 0) problems.push("Rate must be a positive number");
    const code = opt(r.productCode);
    if (code) {
      if (seenCodes.has(code.toLowerCase())) problems.push(`Duplicate product code ${code} in file`);
      seenCodes.add(code.toLowerCase());
    }
    if (problems.length) {
      errors.push({ row: rowNo, message: problems.join("; ") });
      return;
    }
    const styles = String(r.styles ?? "")
      .split(/[,;|]/)
      .map((s) => s.trim().toUpperCase().replace(/[\s-]+/g, "_"))
      .filter((s): s is DesignStyleKey => (DESIGN_STYLES as readonly string[]).includes(s));

    valid.push({
      name: name!,
      category: category!,
      brand: opt(r.brand),
      productCode: code,
      finish: opt(r.finish),
      color: opt(r.color),
      unit: unit!,
      rate: Math.round(rate * 100) / 100,
      imageUrl: opt(r.imageUrl),
      specifications: opt(r.specifications),
      availability: toAvailability(r.availability),
      supplierName: opt(r.supplierName),
      tier: toTier(r.tier),
      durability: toScore(r.durability),
      maintenance: toScore(r.maintenance),
      styles,
    });
  });
  return { valid, errors };
}
