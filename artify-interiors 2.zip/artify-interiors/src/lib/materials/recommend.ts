// Material recommendation engine — deterministic scoring used on its own (Materials Library →
// "Recommend for me") and to build the shortlist the AI chooses from when writing concepts.

import type { DesignStyleKey, MaterialCategoryKey, PriceTierKey } from "@/lib/constants";

export type RecMaterial = {
  id: string;
  name: string;
  category: MaterialCategoryKey;
  brand: string | null;
  finish: string | null;
  color: string | null;
  unit: string;
  rate: number;
  tier: PriceTierKey;
  durability: number; // 1-5
  maintenance: number; // 1-5 (5 = very low maintenance)
  styles: DesignStyleKey[];
  availability: string;
  isActive?: boolean;
};

export type RecPrefs = {
  style?: DesignStyleKey | null;
  tier?: PriceTierKey | null;
  /** 0-1 weight on durability / low maintenance */
  durabilityWeight?: number;
  maintenanceWeight?: number;
  /** Free text from the customer, e.g. "prefer matte finishes, walnut, no high gloss" */
  preferences?: string | null;
};

export type Recommendation = { material: RecMaterial; score: number; reasons: string[] };

const TIERS: PriceTierKey[] = ["ECONOMY", "STANDARD", "PREMIUM", "LUXURY"];

function keywords(text: string) {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 4 && !["prefer", "with", "that", "like", "want", "need", "should", "would", "finish", "finishes"].includes(w));
}

export function scoreMaterial(m: RecMaterial, prefs: RecPrefs): Recommendation | null {
  if (m.availability === "DISCONTINUED" || m.isActive === false) return null;
  const reasons: string[] = [];
  let score = 0;

  if (prefs.style) {
    if (m.styles.includes(prefs.style)) {
      score += 3;
      reasons.push("Matches your design style");
    } else if (m.styles.length === 0) {
      score += 1;
    }
  }

  if (prefs.tier) {
    const diff = Math.abs(TIERS.indexOf(m.tier) - TIERS.indexOf(prefs.tier));
    score += 3 - diff * 1.5;
    if (diff === 0) reasons.push("Fits your budget level");
    else if (TIERS.indexOf(m.tier) < TIERS.indexOf(prefs.tier)) reasons.push("Saves budget");
  }

  const dw = prefs.durabilityWeight ?? 0.5;
  const mw = prefs.maintenanceWeight ?? 0.5;
  score += (m.durability - 3) * dw * 1.2 + (m.maintenance - 3) * mw * 1.2;
  if (m.durability >= 4 && dw >= 0.5) reasons.push("High durability");
  if (m.maintenance >= 4 && mw >= 0.5) reasons.push("Low maintenance");

  if (prefs.preferences) {
    const hay = `${m.name} ${m.brand ?? ""} ${m.finish ?? ""} ${m.color ?? ""}`.toLowerCase();
    const hits = keywords(prefs.preferences).filter((k) => hay.includes(k));
    if (hits.length) {
      score += 2 * Math.min(hits.length, 2);
      reasons.push(`Matches “${hits.slice(0, 2).join(", ")}”`);
    }
  }

  if (m.availability === "IN_STOCK") score += 0.5;
  if (m.availability === "ON_ORDER") {
    score -= 0.5;
    reasons.push("On order — check lead time");
  }

  return { material: m, score: Math.round(score * 100) / 100, reasons };
}

export function recommendMaterials(materials: RecMaterial[], prefs: RecPrefs, opts: { perCategory?: number; categories?: MaterialCategoryKey[] } = {}) {
  const per = opts.perCategory ?? 3;
  const byCat = new Map<MaterialCategoryKey, Recommendation[]>();
  for (const m of materials) {
    if (opts.categories && !opts.categories.includes(m.category)) continue;
    const r = scoreMaterial(m, prefs);
    if (!r) continue;
    const list = byCat.get(m.category) ?? [];
    list.push(r);
    byCat.set(m.category, list);
  }
  const out: Partial<Record<MaterialCategoryKey, Recommendation[]>> = {};
  for (const [cat, list] of byCat) {
    out[cat] = list.sort((a, b) => b.score - a.score || a.material.rate - b.material.rate).slice(0, per);
  }
  return out;
}

/** Representative material per category & tier (median rate) — feeds the BOQ engine. */
export function representativeByTier(materials: RecMaterial[]) {
  const out: Partial<Record<MaterialCategoryKey, Partial<Record<PriceTierKey, { id: string; name: string; brand: string | null; finish: string | null; rate: number; unit: string }>>>> = {};
  const groups = new Map<string, RecMaterial[]>();
  for (const m of materials) {
    if (m.availability === "DISCONTINUED" || m.isActive === false) continue;
    const key = `${m.category}|${m.tier}`;
    groups.set(key, [...(groups.get(key) ?? []), m]);
  }
  for (const [key, list] of groups) {
    const [cat, tier] = key.split("|") as [MaterialCategoryKey, PriceTierKey];
    const sorted = [...list].sort((a, b) => a.rate - b.rate);
    const m = sorted[Math.floor((sorted.length - 1) / 2)]!;
    out[cat] = out[cat] ?? {};
    out[cat]![tier] = { id: m.id, name: m.name, brand: m.brand, finish: m.finish, rate: m.rate, unit: m.unit };
  }
  return out;
}
