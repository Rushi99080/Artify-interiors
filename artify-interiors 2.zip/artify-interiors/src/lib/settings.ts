import "server-only";
import { cache } from "react";
import { prisma } from "@/lib/db";
import { mergeRateCard } from "@/lib/boq/engine";

export * from "@/lib/settings-defaults";
import { DEFAULT_SETTINGS, type AllSettings, type PaymentScheduleItem, type StatItem } from "@/lib/settings-defaults";

const SETTING_KEYS = ["company", "tax", "boqDefaults", "quotation", "paymentSchedule", "rateCard", "automation", "hero", "about", "stats"] as const;
export type SettingKey = (typeof SETTING_KEYS)[number];

function mergeObject<T extends object>(defaults: T, stored: unknown): T {
  if (!stored || typeof stored !== "object" || Array.isArray(stored)) return defaults;
  const out: Record<string, unknown> = { ...(defaults as Record<string, unknown>) };
  for (const [k, v] of Object.entries(stored as Record<string, unknown>)) {
    if (k in defaults && v !== undefined && v !== null) {
      const d = (defaults as Record<string, unknown>)[k];
      if (typeof d === "number") out[k] = Number.isFinite(Number(v)) ? Number(v) : d;
      else if (typeof d === "boolean") out[k] = Boolean(v);
      else out[k] = v;
    }
  }
  return out as T;
}

export const getSettings = cache(async (): Promise<AllSettings> => {
  let rows: { key: string; value: unknown }[] = [];
  try {
    rows = await prisma.setting.findMany({ where: { key: { in: [...SETTING_KEYS] } } });
  } catch {
    rows = [];
  }
  const map = new Map(rows.map((r) => [r.key, r.value]));
  const schedule = map.get("paymentSchedule");
  const stats = map.get("stats");
  return {
    company: mergeObject(DEFAULT_SETTINGS.company, map.get("company")),
    tax: mergeObject(DEFAULT_SETTINGS.tax, map.get("tax")),
    boqDefaults: mergeObject(DEFAULT_SETTINGS.boqDefaults, map.get("boqDefaults")),
    quotation: mergeObject(DEFAULT_SETTINGS.quotation, map.get("quotation")),
    paymentSchedule: Array.isArray(schedule) && schedule.length > 0 ? (schedule as PaymentScheduleItem[]) : DEFAULT_SETTINGS.paymentSchedule,
    rateCard: mergeRateCard(map.get("rateCard")),
    automation: mergeObject(DEFAULT_SETTINGS.automation, map.get("automation")),
    hero: mergeObject(DEFAULT_SETTINGS.hero, map.get("hero")),
    about: mergeObject(DEFAULT_SETTINGS.about, map.get("about")),
    stats: Array.isArray(stats) ? (stats as StatItem[]) : DEFAULT_SETTINGS.stats,
  };
});

export async function saveSetting(key: SettingKey, value: unknown) {
  await prisma.setting.upsert({
    where: { key },
    create: { key, value: value as object },
    update: { value: value as object },
  });
}
