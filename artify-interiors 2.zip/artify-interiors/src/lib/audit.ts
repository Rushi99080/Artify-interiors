import "server-only";
import { prisma } from "@/lib/db";
import { logError } from "@/lib/logger";

/** Records who did what. Never throws — auditing must not break the main action. */
export async function audit(entry: {
  userId?: string | null;
  action: string;
  entity: string;
  entityId?: string | null;
  meta?: Record<string, unknown>;
  ip?: string | null;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: entry.userId ?? null,
        action: entry.action,
        entity: entry.entity,
        entityId: entry.entityId ?? null,
        meta: (entry.meta ?? undefined) as object | undefined,
        ip: entry.ip ?? null,
      },
    });
  } catch (err) {
    logError("audit", err, { action: entry.action });
  }
}
