import { z } from "zod";
import { parseJson, route } from "@/lib/api";
import { approveQuotation } from "@/lib/services/quotations";
import { audit } from "@/lib/audit";

const schema = z.object({
  approvedByName: z.string().trim().max(120).optional(),
  comment: z.string().trim().max(1000).optional(),
  accept: z.literal(true, { message: "Please confirm that you accept the quotation terms." }),
});

/** Client (or team on the client's behalf) approves a quotation → project becomes active. */
export const POST = route<{ id: string }, "user">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, schema);
    const q = await approveQuotation(params.id, user, { approvedByName: body.approvedByName, comment: body.comment });
    await audit({ userId: user.id, action: "quotation.approved", entity: "Quotation", entityId: params.id, meta: { number: q.number }, ip });
    return { ok: true, projectId: q.projectId };
  },
  { auth: "user", rateLimit: { key: "quote-approve", limit: 10, windowSec: 600 } },
);
