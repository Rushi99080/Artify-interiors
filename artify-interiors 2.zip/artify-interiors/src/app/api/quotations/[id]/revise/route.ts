import { z } from "zod";
import { prisma } from "@/lib/db";
import { badRequest, notFound, parseJson, route } from "@/lib/api";
import { createQuotation } from "@/lib/services/quotations";
import { audit } from "@/lib/audit";

const schema = z.object({ boqId: z.string().optional(), send: z.boolean().default(false) });

/** Creates a revised quotation (R1, R2…) from the latest — or a chosen — BOQ version. The old one is superseded. */
export const POST = route<{ id: string }, "quotations.manage">(
  async (req, { params, user, ip }) => {
    const { boqId, send } = await parseJson(req, schema);
    const q = await prisma.quotation.findUnique({ where: { id: params.id } });
    if (!q) throw notFound("Quotation not found.");
    if (q.status === "APPROVED") throw badRequest("An approved quotation cannot be revised. Create a new quotation for additional work.");
    const latestBoq = boqId ?? q.boqId ?? (await prisma.bOQ.findFirst({ where: { projectId: q.projectId }, orderBy: { version: "desc" } }))?.id;
    if (!latestBoq) throw badRequest("No BOQ found for this project.");
    const revised = await createQuotation({ boqId: latestBoq, user, send, parentId: q.id, overrides: { scopeOfWork: q.scopeOfWork, paymentTerms: q.paymentTerms, timelineText: q.timelineText, terms: q.terms } });
    await audit({ userId: user.id, action: "quotation.revised", entity: "Quotation", entityId: revised.id, meta: { from: q.number, to: revised.number }, ip });
    return { quotation: { id: revised.id, number: revised.number } };
  },
  { auth: "quotations.manage" },
);
