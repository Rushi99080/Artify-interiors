import { route } from "@/lib/api";
import { emailQuotation } from "@/lib/services/quotations";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";
export const maxDuration = 60;

/** Emails the PDF to the client and reports the real provider result (SENT / FAILED / SKIPPED). */
export const POST = route<{ id: string }, "quotations.manage">(
  async (_req, { params, user, ip }) => {
    const result = await emailQuotation(params.id);
    await audit({ userId: user.id, action: "quotation.emailed", entity: "Quotation", entityId: params.id, meta: result, ip });
    return result;
  },
  { auth: "quotations.manage", rateLimit: { key: "quote-email", limit: 30, windowSec: 3600 } },
);
