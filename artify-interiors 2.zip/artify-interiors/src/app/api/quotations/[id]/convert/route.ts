import { route } from "@/lib/api";
import { activateProjectFromQuotation } from "@/lib/services/quotations";
import { audit } from "@/lib/audit";

/** Converts an approved quotation into an active project (idempotent: contract value, payment schedule, workflow). */
export const POST = route<{ id: string }, "quotations.manage">(
  async (_req, { params, user, ip }) => {
    const project = await activateProjectFromQuotation(params.id);
    await audit({ userId: user.id, action: "quotation.converted", entity: "Quotation", entityId: params.id, ip });
    return { projectId: project?.id };
  },
  { auth: "quotations.manage" },
);
