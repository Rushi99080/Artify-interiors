import { z } from "zod";
import { parseJson, route } from "@/lib/api";
import { requestQuotationChanges } from "@/lib/services/quotations";
import { audit } from "@/lib/audit";

const schema = z.object({ comment: z.string().trim().min(3, "Tell us what you would like to change").max(2000) });

export const POST = route<{ id: string }, "user">(
  async (req, { params, user, ip }) => {
    const { comment } = await parseJson(req, schema);
    await requestQuotationChanges(params.id, user, comment);
    await audit({ userId: user.id, action: "quotation.changes_requested", entity: "Quotation", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "user", rateLimit: { key: "quote-changes", limit: 10, windowSec: 600 } },
);
