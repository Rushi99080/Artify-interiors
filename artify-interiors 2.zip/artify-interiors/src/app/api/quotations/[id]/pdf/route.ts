import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { notFound, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { quotationPdf } from "@/lib/services/quotations";

export const runtime = "nodejs";
export const maxDuration = 60;

/** Branded quotation PDF. ?download=1 forces a download; otherwise it opens inline (print from the viewer). */
export const GET = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    const q = await prisma.quotation.findUnique({ where: { id: params.id }, select: { projectId: true, status: true } });
    if (!q) throw notFound("Quotation not found.");
    await assertProjectAccess(user, q.projectId);
    if (user.role === "CUSTOMER" && q.status === "DRAFT") throw notFound("Quotation not found.");
    const { buffer, filename } = await quotationPdf(params.id);
    const download = req.nextUrl.searchParams.get("download") === "1";
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${filename}"`,
        "Cache-Control": "private, no-store",
      },
    });
  },
  { auth: "user" },
);
