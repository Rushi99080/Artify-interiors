import { route } from "@/lib/api";
import { sendQuotation } from "@/lib/services/quotations";
import { audit } from "@/lib/audit";

/** Marks the quotation as sent and notifies the client (in-app, email, WhatsApp template if configured). */
export const POST = route<{ id: string }, "quotations.manage">(
  async (_req, { params, user, ip }) => {
    await sendQuotation(params.id);
    await audit({ userId: user.id, action: "quotation.sent", entity: "Quotation", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "quotations.manage" },
);
