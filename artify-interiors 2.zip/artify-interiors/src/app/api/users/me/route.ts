import { z } from "zod";
import { prisma } from "@/lib/db";
import { ApiError, badRequest, parseJson, route } from "@/lib/api";
import { hashPassword, passwordProblem, verifyPassword } from "@/lib/auth/password";
import { phoneSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

const schema = z.object({
  name: z.string().trim().min(2).max(100).optional(),
  phone: phoneSchema.optional(),
  currentPassword: z.string().max(128).optional(),
  newPassword: z.string().max(128).optional(),
});

/** Update own profile / change password. */
export const PATCH = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, schema);
    const data: { name?: string; phone?: string; passwordHash?: string } = {};
    if (body.name) data.name = body.name;
    if (body.phone) data.phone = body.phone;
    if (body.newPassword) {
      const problem = passwordProblem(body.newPassword);
      if (problem) throw badRequest(problem, { newPassword: problem });
      const current = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });
      if (!(await verifyPassword(body.currentPassword ?? "", current.passwordHash))) throw new ApiError(400, "Current password is incorrect.", "VALIDATION", { currentPassword: "Incorrect password" });
      data.passwordHash = await hashPassword(body.newPassword);
    }
    await prisma.user.update({ where: { id: user.id }, data });
    if (user.customerId && (body.name || body.phone)) {
      await prisma.customer.update({ where: { id: user.customerId }, data: { ...(body.name ? { fullName: body.name } : {}), ...(body.phone ? { phone: body.phone } : {}) } });
    }
    await audit({ userId: user.id, action: body.newPassword ? "user.password_changed" : "user.profile_updated", entity: "User", entityId: user.id, ip });
    return { ok: true };
  },
  { auth: "user", rateLimit: { key: "profile", limit: 20, windowSec: 600 } },
);
