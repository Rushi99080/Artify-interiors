import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { sendPaymentReminder, getPaymentOverview } from "@/lib/services/payments";
import { logError, logInfo } from "@/lib/logger";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

/**
 * Daily job (Vercel Cron — see vercel.json): sends payment reminders for unpaid milestones that are
 * due within N days or overdue, at most once every N days per project. Protected by CRON_SECRET.
 */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.get("authorization") !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { automation } = await getSettings();
  const days = automation.paymentReminderDays;
  const horizon = new Date(Date.now() + days * 86400000);
  const since = new Date(Date.now() - days * 86400000);

  const due = await prisma.paymentMilestone.findMany({
    where: { status: { not: "PAID" }, dueDate: { not: null, lte: horizon }, project: { status: { in: ["ACTIVE", "ON_HOLD"] } } },
    select: { projectId: true },
    distinct: ["projectId"],
  });

  let sent = 0;
  for (const { projectId } of due) {
    try {
      const recent = await prisma.notification.findFirst({ where: { event: "PAYMENT_REMINDER", link: `/dashboard/projects/${projectId}/payments`, createdAt: { gte: since } } });
      if (recent) continue;
      const overview = await getPaymentOverview(projectId);
      if (overview.summary.pending <= 0) continue;
      await sendPaymentReminder(projectId);
      sent++;
    } catch (err) {
      logError("cron.payment-reminders", err, { projectId });
    }
  }
  logInfo("cron.payment-reminders", "done", { candidates: due.length, sent });
  return NextResponse.json({ ok: true, candidates: due.length, sent });
}
