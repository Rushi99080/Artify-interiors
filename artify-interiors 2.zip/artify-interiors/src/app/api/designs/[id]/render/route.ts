import { prisma } from "@/lib/db";
import { notFound, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { renderDesignImage } from "@/lib/services/ai-design";
import { fileUrl } from "@/lib/services/files";

export const runtime = "nodejs";
export const maxDuration = 300;

/** Renders the AI visualization for one design concept. */
export const POST = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    const design = await prisma.generatedDesign.findUnique({ where: { id: params.id }, select: { projectId: true } });
    if (!design) throw notFound("Design not found.");
    await assertProjectAccess(user, design.projectId);
    const updated = await renderDesignImage(params.id);
    return { design: { ...updated, imageUrl: fileUrl(updated.imageFileId) } };
  },
  { auth: "user", rateLimit: { key: "ai-render", limit: 40, windowSec: 3600 } },
);
