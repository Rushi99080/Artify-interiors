import { z } from "zod";
import { prisma } from "@/lib/db";
import { notFound, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { regenerateDesign } from "@/lib/services/ai-design";
import { fileUrl } from "@/lib/services/files";

export const runtime = "nodejs";
export const maxDuration = 300;

const schema = z.object({ changeRequest: z.string().trim().max(1000).default("") });

/** Regenerates a concept (the previous version is kept as a revision). */
export const POST = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    const design = await prisma.generatedDesign.findUnique({ where: { id: params.id }, select: { projectId: true } });
    if (!design) throw notFound("Design not found.");
    await assertProjectAccess(user, design.projectId);
    const { changeRequest } = await parseJson(req, schema);
    const updated = await regenerateDesign(params.id, changeRequest, user);
    return { design: { ...updated, imageUrl: fileUrl(updated.imageFileId) } };
  },
  { auth: "user", rateLimit: { key: "ai-generate", limit: 12, windowSec: 3600 } },
);
