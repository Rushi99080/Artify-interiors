import { z } from "zod";
import { prisma } from "@/lib/db";
import { forbidden, notFound, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { isTeamRole } from "@/lib/auth/token";
import { completeStage } from "@/lib/services/workflow";
import { queueNotify, projectCustomerRecipient } from "@/lib/notifications";
import { fileUrl } from "@/lib/services/files";
import { audit } from "@/lib/audit";

const schema = z.object({
  action: z.enum(["save", "unsave", "favorite", "unfavorite", "approve", "request_changes", "reject", "reset"]).optional(),
  comment: z.string().trim().max(1000).optional(),
  adminNotes: z.string().trim().max(2000).optional(),
});

export const PATCH = route<{ id: string }, "user">(
  async (req, { params, user, ip }) => {
    const design = await prisma.generatedDesign.findUnique({ where: { id: params.id }, include: { project: { select: { id: true, name: true } }, room: { select: { name: true } } } });
    if (!design) throw notFound("Design not found.");
    await assertProjectAccess(user, design.projectId);
    const body = await parseJson(req, schema);
    const team = isTeamRole(user.role);
    const data: Record<string, unknown> = {};

    switch (body.action) {
      case "save":
        data.isSaved = true;
        if (design.status === "GENERATED") data.status = "SAVED";
        break;
      case "unsave":
        data.isSaved = false;
        data.isFavorite = false;
        if (design.status === "SAVED") data.status = "GENERATED";
        break;
      case "favorite":
        data.isFavorite = true;
        data.isSaved = true;
        if (design.status === "GENERATED") data.status = "SAVED";
        break;
      case "unfavorite":
        data.isFavorite = false;
        break;
      case "approve":
        data.status = "APPROVED";
        data.isSaved = true;
        data.customerComment = body.comment ?? design.customerComment;
        break;
      case "request_changes":
        data.status = "CHANGES_REQUESTED";
        data.customerComment = body.comment ?? null;
        break;
      case "reject":
        if (!team) throw forbidden();
        data.status = "REJECTED";
        break;
      case "reset":
        if (!team) throw forbidden();
        data.status = design.isSaved ? "SAVED" : "GENERATED";
        break;
    }
    if (body.adminNotes !== undefined) {
      if (!team) throw forbidden();
      data.adminNotes = body.adminNotes;
    }

    const updated = await prisma.generatedDesign.update({ where: { id: params.id }, data });

    if (body.action === "approve") {
      await completeStage(design.projectId, "DESIGN_APPROVAL");
      if (team) {
        const customer = await projectCustomerRecipient(design.projectId);
        queueNotify({ event: "DESIGN_APPROVED", title: `Design “${design.name}” approved`, body: `The design team has finalised “${design.name}” for ${design.room?.name ?? "your room"}.`, link: `/dashboard/projects/${design.projectId}/designs`, recipients: [customer], channels: { whatsapp: false } });
      } else {
        queueNotify({ event: "DESIGN_APPROVED", title: `Client approved “${design.name}”`, body: `${user.name} approved the concept “${design.name}” for ${design.room?.name ?? "a room"} in ${design.project.name}.${body.comment ? `\n\n“${body.comment}”` : ""}`, link: `/admin/designs`, notifyAdmins: true, channels: { whatsapp: false } });
      }
    }
    if (body.action === "request_changes" && !team) {
      queueNotify({ event: "DESIGN_APPROVED", title: `Changes requested on “${design.name}”`, body: `${user.name}: ${body.comment ?? "(no comment)"}`, link: `/admin/designs`, notifyAdmins: true, channels: { whatsapp: false, email: false } });
    }
    await audit({ userId: user.id, action: `design.${body.action ?? "notes"}`, entity: "GeneratedDesign", entityId: params.id, ip });
    return { design: { ...updated, imageUrl: fileUrl(updated.imageFileId) } };
  },
  { auth: "user" },
);

export const DELETE = route<{ id: string }, "designs.manage">(
  async (_req, { params, user, ip }) => {
    await prisma.generatedDesign.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "design.deleted", entity: "GeneratedDesign", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "designs.manage" },
);
