import { z } from "zod";
import { prisma } from "@/lib/db";
import { notFound, parseJson, route } from "@/lib/api";
import { completeStage, notifyMilestone } from "@/lib/services/workflow";
import { audit } from "@/lib/audit";

const schema = z.object({
  status: z.enum(["PENDING", "IN_PROGRESS", "COMPLETED", "SKIPPED", "BLOCKED"]).optional(),
  assigneeId: z.string().nullable().optional(),
  dueDate: z.string().nullable().optional(),
  notes: z.string().trim().max(2000).nullable().optional(),
  customerVisible: z.boolean().optional(),
  notifyCustomer: z.boolean().default(true),
});

/** Team: update a workflow stage (status, assignee, due date, notes). Customers are notified of visible changes. */
export const PATCH = route<{ id: string }, "projects.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, schema);
    const ms = await prisma.projectMilestone.findUnique({ where: { id: params.id } });
    if (!ms) throw notFound("Stage not found.");
    await prisma.projectMilestone.update({
      where: { id: params.id },
      data: {
        ...(body.assigneeId !== undefined ? { assigneeId: body.assigneeId } : {}),
        ...(body.dueDate !== undefined ? { dueDate: body.dueDate ? new Date(body.dueDate) : null } : {}),
        ...(body.notes !== undefined ? { notes: body.notes } : {}),
        ...(body.customerVisible !== undefined ? { customerVisible: body.customerVisible } : {}),
      },
    });
    if (body.status && body.status !== ms.status) {
      if (body.status === "COMPLETED") {
        await completeStage(ms.projectId, ms.stageKey, { notifyCustomer: body.notifyCustomer });
      } else {
        await prisma.projectMilestone.update({
          where: { id: params.id },
          data: { status: body.status, ...(body.status === "IN_PROGRESS" && !ms.startedAt ? { startedAt: new Date() } : {}), completedAt: null },
        });
        if (body.notifyCustomer && ms.customerVisible && body.status === "IN_PROGRESS") await notifyMilestone(ms.projectId, ms.name, "IN_PROGRESS");
      }
      await prisma.message.create({ data: { projectId: ms.projectId, kind: "UPDATE", fromTeam: true, senderId: user.id, body: `Stage “${ms.name}” marked ${body.status.replace("_", " ").toLowerCase()}.${body.notes ? ` ${body.notes}` : ""}` } });
    }
    await audit({ userId: user.id, action: "milestone.updated", entity: "ProjectMilestone", entityId: params.id, meta: body, ip });
    return { ok: true };
  },
  { auth: "projects.manage" },
);
