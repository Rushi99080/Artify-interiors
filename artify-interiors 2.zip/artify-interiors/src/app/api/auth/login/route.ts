import { prisma } from "@/lib/db";
import { ApiError, parseJson, route } from "@/lib/api";
import { loginSchema } from "@/lib/validation";
import { verifyPassword } from "@/lib/auth/password";
import { createSessionCookie } from "@/lib/auth/session";
import { audit } from "@/lib/audit";
import { rateLimit } from "@/lib/rate-limit";

// Constant-time-ish response for unknown emails (compare against a throwaway hash)
const DUMMY_HASH = "$2b$12$fqg9REyoPjQz.KiFz4xVG.DYczh5aGqLy1/6Ze7MphkrB03tJUoF6";

export const POST = route(
  async (req, { ip }) => {
    const body = await parseJson(req, loginSchema);
    // Per-account throttle on top of the per-IP limit (slows down password guessing)
    const perAccount = await rateLimit(`login-account:${body.email}`, 10, 900);
    if (!perAccount.ok) throw new ApiError(429, "Too many attempts for this account. Please try again in 15 minutes.", "RATE_LIMITED");

    const user = await prisma.user.findUnique({ where: { email: body.email } });
    const ok = user ? await verifyPassword(body.password, user.passwordHash) : await verifyPassword(body.password, DUMMY_HASH);
    if (!user || !ok) {
      await audit({ action: "auth.login_failed", entity: "User", entityId: user?.id ?? null, meta: { email: body.email }, ip });
      throw new ApiError(401, "Incorrect email or password.", "INVALID_CREDENTIALS");
    }
    if (!user.isActive) throw new ApiError(403, "This account has been deactivated. Please contact the studio.", "INACTIVE");

    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    await createSessionCookie({ id: user.id, role: user.role, name: user.name });
    await audit({ userId: user.id, action: "auth.login", entity: "User", entityId: user.id, ip });
    return { ok: true, redirect: user.role === "CUSTOMER" ? "/dashboard" : "/admin" };
  },
  { rateLimit: { key: "login", limit: 20, windowSec: 300 } },
);
