import { prisma } from "@/lib/db";
import { conflict, parseJson, route, badRequest } from "@/lib/api";
import { registerSchema } from "@/lib/validation";
import { hashPassword, passwordProblem } from "@/lib/auth/password";
import { createSessionCookie } from "@/lib/auth/session";
import { audit } from "@/lib/audit";

export const POST = route(
  async (req, { ip }) => {
    const body = await parseJson(req, registerSchema);
    const problem = passwordProblem(body.password);
    if (problem) throw badRequest(problem, { password: problem });
    const existing = await prisma.user.findUnique({ where: { email: body.email } });
    if (existing) throw conflict("An account with this email already exists. Please log in instead.");

    const user = await prisma.$transaction(async (tx) => {
      const u = await tx.user.create({
        data: { email: body.email, name: body.name, phone: body.phone, role: "CUSTOMER", passwordHash: await hashPassword(body.password), lastLoginAt: new Date() },
      });
      // Link to an existing customer record created by the team (same email) or create a new one
      const prior = await tx.customer.findFirst({ where: { email: body.email, userId: null } });
      if (prior) await tx.customer.update({ where: { id: prior.id }, data: { userId: u.id, phone: prior.phone || body.phone } });
      else await tx.customer.create({ data: { userId: u.id, fullName: body.name, email: body.email, phone: body.phone } });
      return u;
    });

    await createSessionCookie({ id: user.id, role: "CUSTOMER", name: user.name });
    await audit({ userId: user.id, action: "auth.register", entity: "User", entityId: user.id, ip });
    return { ok: true, redirect: "/dashboard" };
  },
  { rateLimit: { key: "register", limit: 8, windowSec: 600 } },
);
