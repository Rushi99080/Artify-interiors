import { prisma } from "@/lib/db";
import { route } from "@/lib/api";

/** In-app notifications for the signed-in user (latest 30) with unread count. */
export const GET = route(
  async (_req, { user }) => {
    const [items, unread] = await Promise.all([
      prisma.notification.findMany({ where: { userId: user.id, channel: "IN_APP" }, orderBy: { createdAt: "desc" }, take: 30 }),
      prisma.notification.count({ where: { userId: user.id, channel: "IN_APP", readAt: null } }),
    ]);
    return { items, unread };
  },
  { auth: "user" },
);
