import { z } from "zod";
import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { env } from "@/lib/env";
import { getSettings } from "@/lib/settings";
import { emailLayout, sendEmail } from "@/lib/notifications/email";
import { sendWhatsAppTemplate } from "@/lib/notifications/whatsapp";
import { audit } from "@/lib/audit";

const schema = z.object({ channel: z.enum(["email", "whatsapp"]), to: z.string().trim().min(5).max(160) });

/**
 * Admin: send a real test message through the configured provider and log the outcome.
 * WhatsApp uses the template mapped to "TEST" in WHATSAPP_TEMPLATES, or Meta's default "hello_world" (en_US).
 */
export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, schema);
    const settings = await getSettings();
    const title = `Test message from ${settings.company.name}`;
    let res;
    if (body.channel === "email") {
      const html = emailLayout({ title, body: "If you can read this, email notifications from your Artify platform are working.", companyName: settings.company.name });
      res = await sendEmail(body.to, title, html);
    } else {
      const cfg = env.whatsapp();
      const mapped = cfg.templates.TEST;
      res = await sendWhatsAppTemplate("TEST", body.to, [], { template: mapped ?? "hello_world", language: mapped ? cfg.language : "en_US" });
    }
    await prisma.notification.create({
      data: {
        userId: user.id,
        channel: body.channel === "email" ? "EMAIL" : "WHATSAPP",
        event: "TEST",
        title,
        body: "Test message",
        recipient: body.to,
        status: res.status,
        providerMessageId: res.providerMessageId,
        error: res.error,
        sentAt: res.status === "SENT" ? new Date() : null,
        readAt: new Date(),
      },
    });
    await audit({ userId: user.id, action: `notifications.test_${body.channel}`, entity: "Notification", meta: { status: res.status }, ip });
    return { status: res.status, providerMessageId: res.providerMessageId ?? null, error: res.error ?? null };
  },
  { auth: "settings.manage", rateLimit: { key: "notify-test", limit: 10, windowSec: 600 } },
);
