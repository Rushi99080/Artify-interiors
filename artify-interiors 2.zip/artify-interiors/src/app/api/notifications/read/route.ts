import { z } from "zod";
import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";

const schema = z.object({ ids: z.array(z.string()).max(200).optional() });

/** Mark notifications as read (all when no ids are given). */
export const POST = route(
  async (req, { user }) => {
    const { ids } = await parseJson(req, schema);
    await prisma.notification.updateMany({ where: { userId: user.id, readAt: null, ...(ids ? { id: { in: ids } } : {}) }, data: { readAt: new Date() } });
    return { ok: true };
  },
  { auth: "user" },
);
