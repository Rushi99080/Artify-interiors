import { prisma } from "@/lib/db";
import { route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const DELETE = route<{ id: string }, "expenses.manage">(
  async (_req, { params, user, ip }) => {
    await prisma.expense.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "expense.deleted", entity: "Expense", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "expenses.manage" },
);
