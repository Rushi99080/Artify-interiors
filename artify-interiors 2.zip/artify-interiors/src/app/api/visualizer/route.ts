import { z } from "zod";
import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { completeStage } from "@/lib/services/workflow";
import { isTeamRole } from "@/lib/auth/token";

const schema = z.object({
  name: z.string().trim().min(1).max(80),
  projectId: z.string().nullable().optional(),
  config: z.record(z.string(), z.unknown()).refine((c) => JSON.stringify(c).length < 200_000, "Configuration is too large"),
});

export const GET = route(
  async (req, { user }) => {
    const projectId = req.nextUrl.searchParams.get("projectId");
    if (projectId) await assertProjectAccess(user, projectId);
    const configs = await prisma.visualizerConfig.findMany({
      where: projectId ? { projectId } : { userId: user.id },
      orderBy: { updatedAt: "desc" },
      take: 50,
      select: { id: true, name: true, projectId: true, config: true, updatedAt: true, user: { select: { name: true } } },
    });
    return { configs };
  },
  { auth: "user" },
);

/** Save a 3D visualizer configuration (room size, finishes, furniture layout, lighting, camera). */
export const POST = route(
  async (req, { user }) => {
    const body = await parseJson(req, schema);
    if (body.projectId) await assertProjectAccess(user, body.projectId);
    const config = await prisma.visualizerConfig.create({ data: { name: body.name, userId: user.id, projectId: body.projectId ?? null, config: body.config as object } });
    if (body.projectId && isTeamRole(user.role)) await completeStage(body.projectId, "DESIGN_3D");
    return { config: { id: config.id, name: config.name } };
  },
  { auth: "user", rateLimit: { key: "viz-save", limit: 60, windowSec: 3600 } },
);
