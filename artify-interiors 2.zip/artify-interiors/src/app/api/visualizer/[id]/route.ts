import { z } from "zod";
import { prisma } from "@/lib/db";
import { forbidden, notFound, parseJson, route } from "@/lib/api";
import { isTeamRole } from "@/lib/auth/token";

async function own(id: string, userId: string, role: string) {
  const c = await prisma.visualizerConfig.findUnique({ where: { id } });
  if (!c) throw notFound("Saved configuration not found.");
  if (c.userId !== userId && !isTeamRole(role)) throw forbidden();
  return c;
}

export const PATCH = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    await own(params.id, user.id, user.role);
    const body = await parseJson(req, z.object({ name: z.string().trim().min(1).max(80).optional(), config: z.record(z.string(), z.unknown()).optional() }));
    const c = await prisma.visualizerConfig.update({ where: { id: params.id }, data: { ...(body.name ? { name: body.name } : {}), ...(body.config ? { config: body.config as object } : {}) } });
    return { config: { id: c.id, name: c.name } };
  },
  { auth: "user" },
);

export const DELETE = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    await own(params.id, user.id, user.role);
    await prisma.visualizerConfig.delete({ where: { id: params.id } });
    return { ok: true };
  },
  { auth: "user" },
);
