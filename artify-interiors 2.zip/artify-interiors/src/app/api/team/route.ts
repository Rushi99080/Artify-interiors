import { prisma } from "@/lib/db";
import { badRequest, conflict, parseJson, route } from "@/lib/api";
import { teamMemberSchema } from "@/lib/validation";
import { hashPassword, passwordProblem } from "@/lib/auth/password";
import { audit } from "@/lib/audit";

/** Admin: add a team member, optionally with a STAFF/ADMIN login. */
export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, teamMemberSchema);
    let userId: string | null = null;
    if (body.createLogin) {
      if (!body.email) throw badRequest("An email is required to create a login.", { email: "Required for login" });
      const problem = passwordProblem(body.password ?? "");
      if (problem) throw badRequest(problem, { password: problem });
      if (await prisma.user.findUnique({ where: { email: body.email } })) throw conflict("A user with this email already exists.");
      const u = await prisma.user.create({ data: { email: body.email, name: body.name, phone: body.phone, role: body.loginRole ?? "STAFF", passwordHash: await hashPassword(body.password!) } });
      userId = u.id;
    }
    const member = await prisma.teamMember.create({
      data: { name: body.name, designation: body.designation, department: body.department, phone: body.phone, email: body.email, isActive: body.isActive, userId },
    });
    await audit({ userId: user.id, action: "team.created", entity: "TeamMember", entityId: member.id, meta: { login: !!userId, role: body.loginRole }, ip });
    return { member };
  },
  { auth: "team.manage" },
);
