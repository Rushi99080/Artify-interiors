import { prisma } from "@/lib/db";
import { badRequest, conflict, notFound, parseJson, route } from "@/lib/api";
import { teamMemberSchema } from "@/lib/validation";
import { hashPassword, passwordProblem } from "@/lib/auth/password";
import { audit } from "@/lib/audit";

export const PATCH = route<{ id: string }, "team.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, teamMemberSchema.partial());
    const member = await prisma.teamMember.findUnique({ where: { id: params.id } });
    if (!member) throw notFound("Team member not found.");
    if (member.userId === user.id && (body.isActive === false || (body.loginRole && body.loginRole !== "ADMIN"))) throw badRequest("You cannot deactivate or demote your own account.");
    if (body.password) {
      const problem = passwordProblem(body.password);
      if (problem) throw badRequest(problem, { password: problem });
    }

    // Give an existing member a login.
    let newUserId: string | null = null;
    if (!member.userId && body.createLogin) {
      const email = body.email ?? member.email;
      if (!email) throw badRequest("An email is required to create a login.", { email: "Required for login" });
      if (!body.password) throw badRequest("Set a password for the new login.", { password: "Required for login" });
      if (await prisma.user.findUnique({ where: { email } })) throw conflict("A user with this email already exists.");
      const u = await prisma.user.create({ data: { email, name: body.name ?? member.name, phone: body.phone ?? member.phone, role: body.loginRole ?? "STAFF", passwordHash: await hashPassword(body.password) } });
      newUserId = u.id;
    }

    await prisma.teamMember.update({
      where: { id: params.id },
      data: { name: body.name, designation: body.designation, department: body.department, phone: body.phone, email: body.email ?? undefined, isActive: body.isActive, ...(newUserId ? { userId: newUserId } : {}) },
    });
    if (member.userId) {
      const data: { isActive?: boolean; role?: "STAFF" | "ADMIN"; passwordHash?: string; name?: string } = {};
      if (body.isActive !== undefined) data.isActive = body.isActive;
      if (body.loginRole) data.role = body.loginRole;
      if (body.name) data.name = body.name;
      if (body.password) data.passwordHash = await hashPassword(body.password);
      if (Object.keys(data).length) await prisma.user.update({ where: { id: member.userId }, data });
    }
    await audit({ userId: user.id, action: newUserId ? "team.login_created" : "team.updated", entity: "TeamMember", entityId: params.id, meta: { ...body, password: body.password ? "(changed)" : undefined }, ip });
    return { ok: true };
  },
  { auth: "team.manage" },
);

export const DELETE = route<{ id: string }, "team.manage">(
  async (_req, { params, user, ip }) => {
    const member = await prisma.teamMember.findUnique({ where: { id: params.id } });
    if (!member) throw notFound("Team member not found.");
    if (member.userId === user.id) throw badRequest("You cannot remove yourself.");
    await prisma.teamMember.delete({ where: { id: params.id } });
    if (member.userId) await prisma.user.update({ where: { id: member.userId }, data: { isActive: false } });
    await audit({ userId: user.id, action: "team.deleted", entity: "TeamMember", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "team.manage" },
);
