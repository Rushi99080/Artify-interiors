import { prisma } from "@/lib/db";
import { badRequest, notFound, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { boqSettingsSchema } from "@/lib/validation";
import { loadBOQ, recalcBOQ } from "@/lib/services/boq";
import { completeStage } from "@/lib/services/workflow";
import { isTeamRole } from "@/lib/auth/token";
import { audit } from "@/lib/audit";

export const GET = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    const boq = await loadBOQ(params.id);
    await assertProjectAccess(user, boq.projectId);
    if (!isTeamRole(user.role)) {
      // customers see the BOQ without internal margin settings
      const { profitMarginPercent: _m, wastagePercent: _w, ...rest } = boq;
      void _m;
      void _w;
      return { boq: rest };
    }
    return { boq };
  },
  { auth: "user" },
);

/** Update charges (GST, wastage, margin, transport, installation, discount), title, notes or status. */
export const PATCH = route<{ id: string }, "boq.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, boqSettingsSchema);
    const boq = await prisma.bOQ.findUnique({ where: { id: params.id } });
    if (!boq) throw notFound("BOQ not found.");
    if (boq.status === "FINAL" && body.status !== "VERIFIED") throw badRequest("This BOQ is final (its quotation was approved). Generate a new version to make changes.");
    await prisma.bOQ.update({
      where: { id: params.id },
      data: {
        ...body,
        ...(body.status === "VERIFIED" && boq.status !== "VERIFIED" ? { verifiedAt: new Date(), verifiedByName: user.name } : {}),
      },
    });
    if (body.status === "VERIFIED") {
      await prisma.bOQItem.updateMany({ where: { boqId: params.id }, data: { isEstimated: false } });
      await completeStage(boq.projectId, "SITE_MEASUREMENT");
      await completeStage(boq.projectId, "FINAL_BOQ");
    }
    const totals = await recalcBOQ(params.id);
    await audit({ userId: user.id, action: "boq.updated", entity: "BOQ", entityId: params.id, meta: body, ip });
    return { totals };
  },
  { auth: "boq.manage" },
);

export const DELETE = route<{ id: string }, "boq.manage">(
  async (_req, { params, user, ip }) => {
    const boq = await prisma.bOQ.findUnique({ where: { id: params.id }, include: { quotations: { where: { status: "APPROVED" }, select: { id: true } } } });
    if (!boq) throw notFound("BOQ not found.");
    if (boq.quotations.length) throw badRequest("This BOQ has an approved quotation and cannot be deleted.");
    await prisma.bOQ.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "boq.deleted", entity: "BOQ", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "boq.manage" },
);
