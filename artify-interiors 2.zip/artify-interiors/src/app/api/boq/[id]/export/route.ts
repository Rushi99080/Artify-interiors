import ExcelJS from "exceljs";
import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { loadBOQ } from "@/lib/services/boq";
import { isTeamRole } from "@/lib/auth/token";
import { getSettings } from "@/lib/settings";

export const runtime = "nodejs";

/** Excel export of a BOQ with live formulas (Amount = Qty × Rate, section subtotals, totals). */
export const GET = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    const boq = await loadBOQ(params.id);
    await assertProjectAccess(user, boq.projectId);
    const team = isTeamRole(user.role);
    const settings = await getSettings();

    const wb = new ExcelJS.Workbook();
    wb.creator = settings.company.legalName;
    const ws = wb.addWorksheet("BOQ", { views: [{ state: "frozen", ySplit: 4 }] });
    ws.columns = [
      { key: "sr", width: 6 },
      { key: "section", width: 16 },
      { key: "item", width: 38 },
      { key: "dims", width: 20 },
      { key: "material", width: 28 },
      { key: "finish", width: 24 },
      { key: "hardware", width: 26 },
      { key: "acc", width: 24 },
      { key: "qty", width: 10 },
      { key: "unit", width: 8 },
      { key: "rate", width: 12 },
      { key: "amount", width: 14 },
    ];
    ws.mergeCells("A1:L1");
    ws.getCell("A1").value = `${settings.company.name} — ${boq.title}`;
    ws.getCell("A1").font = { size: 14, bold: true };
    ws.mergeCells("A2:L2");
    ws.getCell("A2").value = `${boq.project.name} (${boq.project.code}) · Status: ${boq.status}${boq.status === "PRELIMINARY" ? " — quantities are estimates to be verified on site" : ""}`;
    ws.getCell("A2").font = { italic: true, color: { argb: "FF7A7067" } };
    const header = ws.getRow(4);
    header.values = ["Sr. No.", "Section", "Item", "Dimensions", "Primary Material", "Finish / Brand", "Hardware", "Accessories", "Quantity", "Unit", "Rate", "Amount"];
    header.font = { bold: true, color: { argb: "FFFFFFFF" } };
    header.eachCell((c) => (c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF22201D" } }));

    let rowNo = 5;
    const first = rowNo;
    boq.items.forEach((it, i) => {
      const r = ws.getRow(rowNo);
      r.values = [i + 1, it.section, it.item + (it.isEstimated ? " (estimate)" : ""), it.dimensions ?? "", it.primaryMaterial ?? "", it.finishBrand ?? "", it.hardware ?? "", it.accessories ?? "", it.quantity, it.unit, it.rate];
      r.getCell(12).value = { formula: `I${rowNo}*K${rowNo}`, result: it.amount };
      rowNo++;
    });
    const last = rowNo - 1;
    const t = boq.totals;
    const totalRow = (label: string, formula: string, result: number, bold = false) => {
      const r = ws.getRow(rowNo);
      r.getCell(11).value = label;
      r.getCell(12).value = { formula, result };
      if (bold) r.font = { bold: true };
      rowNo++;
      return rowNo - 1;
    };
    rowNo++;
    const sub = totalRow("Subtotal", `SUM(L${first}:L${last})`, t.subtotal, true);
    const extras: number[] = [];
    if (team) {
      extras.push(totalRow(`Wastage ${boq.wastagePercent}% (materials)`, `${t.wastageAmount}`, t.wastageAmount));
    } else if (t.wastageAmount) extras.push(totalRow("Wastage allowance", `${t.wastageAmount}`, t.wastageAmount));
    if (t.transportCharges) extras.push(totalRow("Transportation", `${t.transportCharges}`, t.transportCharges));
    if (t.installationCharges) extras.push(totalRow("Installation", `${t.installationCharges}`, t.installationCharges));
    if (t.profitAmount) extras.push(totalRow(team ? `Profit margin ${boq.profitMarginPercent}%` : settings.boqDefaults.marginLabel, `${t.profitAmount}`, t.profitAmount));
    const disc = t.discountAmount ? totalRow("Discount", `-${t.discountAmount}`, -t.discountAmount) : null;
    const taxable = totalRow("Taxable value", `L${sub}${extras.map((e) => `+L${e}`).join("")}${disc ? `+L${disc}` : ""}`, t.taxableAmount, true);
    const gst = totalRow(`GST ${boq.gstRate}%`, `ROUND(L${taxable}*${boq.gstRate}/100,2)`, t.gstAmount);
    totalRow("Grand Total", `L${taxable}+L${gst}`, t.grandTotal, true);

    for (let r = 5; r < rowNo; r++) {
      ws.getRow(r).getCell(11).numFmt = "#,##,##0.00";
      ws.getRow(r).getCell(12).numFmt = "₹ #,##,##0.00";
    }

    const buffer = Buffer.from(await wb.xlsx.writeBuffer());
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${boq.project.code}-BOQ-v${boq.version}.xlsx"`,
      },
    });
  },
  { auth: "user" },
);
