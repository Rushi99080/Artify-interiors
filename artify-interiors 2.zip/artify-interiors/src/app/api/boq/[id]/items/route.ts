import { prisma } from "@/lib/db";
import { badRequest, notFound, parseJson, route } from "@/lib/api";
import { boqItemSchema } from "@/lib/validation";
import { lineAmount } from "@/lib/calc/boq";
import { recalcBOQ } from "@/lib/services/boq";

/** Add a line item. */
export const POST = route<{ id: string }, "boq.manage">(
  async (req, { params }) => {
    const boq = await prisma.bOQ.findUnique({ where: { id: params.id }, select: { status: true } });
    if (!boq) throw notFound("BOQ not found.");
    if (boq.status === "FINAL") throw badRequest("This BOQ is final. Generate a new version to make changes.");
    const body = await parseJson(req, boqItemSchema);
    const inSection = await prisma.bOQItem.aggregate({ where: { boqId: params.id, section: body.section }, _max: { sortOrder: true } });
    const overall = await prisma.bOQItem.aggregate({ where: { boqId: params.id }, _max: { sortOrder: true } });
    let sortOrder: number;
    if (inSection._max.sortOrder !== null) {
      // insert at the end of its section, shifting later rows down
      sortOrder = inSection._max.sortOrder + 1;
      await prisma.bOQItem.updateMany({ where: { boqId: params.id, sortOrder: { gte: sortOrder } }, data: { sortOrder: { increment: 1 } } });
    } else {
      sortOrder = (overall._max.sortOrder ?? -1) + 1;
    }
    const item = await prisma.bOQItem.create({
      data: { ...body, boqId: params.id, amount: lineAmount(body.quantity, body.rate), isEstimated: false, sortOrder },
    });
    const totals = await recalcBOQ(params.id);
    return { item, totals };
  },
  { auth: "boq.manage" },
);
