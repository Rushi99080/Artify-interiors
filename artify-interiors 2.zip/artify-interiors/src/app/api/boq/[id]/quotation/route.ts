import { z } from "zod";
import { parseJson, route } from "@/lib/api";
import { createQuotation } from "@/lib/services/quotations";
import { audit } from "@/lib/audit";

const schema = z.object({
  send: z.boolean().default(false),
  scopeOfWork: z.string().trim().max(5000).optional(),
  paymentTerms: z.string().trim().max(5000).optional(),
  timelineText: z.string().trim().max(5000).optional(),
  terms: z.string().trim().max(10000).optional(),
  validityDays: z.number().int().min(1).max(180).optional(),
});

/** Team: generate a quotation from this BOQ. */
export const POST = route<{ id: string }, "quotations.manage">(
  async (req, { params, user, ip }) => {
    const { send, ...overrides } = await parseJson(req, schema);
    const q = await createQuotation({ boqId: params.id, user, send, overrides });
    await audit({ userId: user.id, action: "quotation.created", entity: "Quotation", entityId: q.id, meta: { number: q.number, send }, ip });
    return { quotation: { id: q.id, number: q.number, status: q.status } };
  },
  { auth: "quotations.manage" },
);
