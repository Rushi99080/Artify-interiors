import { prisma } from "@/lib/db";
import { badRequest, notFound, parseJson, route } from "@/lib/api";
import { boqItemSchema } from "@/lib/validation";
import { lineAmount } from "@/lib/calc/boq";
import { recalcBOQ } from "@/lib/services/boq";

async function load(itemId: string) {
  const item = await prisma.bOQItem.findUnique({ where: { id: itemId }, include: { boq: { select: { id: true, status: true } } } });
  if (!item) throw notFound("Item not found.");
  if (item.boq.status === "FINAL") throw badRequest("This BOQ is final. Generate a new version to make changes.");
  return item;
}

/** Edit quantity, rate or any column. Editing quantity marks the line as verified (no longer an estimate). */
export const PATCH = route<{ itemId: string }, "boq.manage">(
  async (req, { params }) => {
    const item = await load(params.itemId);
    const body = await parseJson(req, boqItemSchema.partial());
    const quantity = body.quantity ?? item.quantity;
    const rate = body.rate ?? item.rate;
    const updated = await prisma.bOQItem.update({
      where: { id: item.id },
      data: { ...body, amount: lineAmount(quantity, rate), ...(body.quantity !== undefined && body.quantity !== item.quantity ? { isEstimated: false } : {}) },
    });
    const totals = await recalcBOQ(item.boq.id);
    return { item: updated, totals };
  },
  { auth: "boq.manage" },
);

export const DELETE = route<{ itemId: string }, "boq.manage">(
  async (_req, { params }) => {
    const item = await load(params.itemId);
    await prisma.bOQItem.delete({ where: { id: item.id } });
    const totals = await recalcBOQ(item.boq.id);
    return { totals };
  },
  { auth: "boq.manage" },
);
