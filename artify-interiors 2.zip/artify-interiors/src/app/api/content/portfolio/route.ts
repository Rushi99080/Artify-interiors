import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { portfolioSchema } from "@/lib/validation";
import { slugify } from "@/lib/format";
import { audit } from "@/lib/audit";

export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, portfolioSchema);
    let slug = slugify(body.slug || body.title) || `project-${Date.now()}`;
    if (await prisma.portfolioProject.findUnique({ where: { slug } })) slug = `${slug}-${Date.now().toString(36)}`;
    const project = await prisma.portfolioProject.create({ data: { ...body, slug } });
    await audit({ userId: user.id, action: "portfolio.created", entity: "PortfolioProject", entityId: project.id, ip });
    return { project };
  },
  { auth: "content.manage" },
);
