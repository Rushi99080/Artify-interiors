import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { portfolioSchema } from "@/lib/validation";
import { slugify } from "@/lib/format";
import { audit } from "@/lib/audit";

export const PATCH = route<{ id: string }, "content.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, portfolioSchema.partial());
    const project = await prisma.portfolioProject.update({ where: { id: params.id }, data: { ...body, ...(body.slug ? { slug: slugify(body.slug) } : {}) } });
    await audit({ userId: user.id, action: "portfolio.updated", entity: "PortfolioProject", entityId: params.id, ip });
    return { project };
  },
  { auth: "content.manage" },
);

export const DELETE = route<{ id: string }, "content.manage">(
  async (_req, { params, user, ip }) => {
    await prisma.portfolioProject.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "portfolio.deleted", entity: "PortfolioProject", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "content.manage" },
);
