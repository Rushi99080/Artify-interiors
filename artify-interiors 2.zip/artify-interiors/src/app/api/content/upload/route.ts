import { badRequest, route } from "@/lib/api";
import { storeUpload, fileUrl } from "@/lib/services/files";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

/** Admin: upload a public website image (hero, portfolio, logo, material photo). Returns its URL. */
export const POST = route(
  async (req, { user, ip }) => {
    const form = await req.formData().catch(() => null);
    const file = form?.get("file");
    if (!file || typeof file === "string") throw badRequest("Choose an image to upload.");
    const rec = await storeUpload({ buffer: Buffer.from(await file.arrayBuffer()), originalName: file.name, category: "CONTENT", uploadedById: user.id, isPublic: true });
    await audit({ userId: user.id, action: "content.image_uploaded", entity: "UploadedFile", entityId: rec.id, ip });
    return { url: fileUrl(rec.id), id: rec.id };
  },
  { auth: "materials.manage", rateLimit: { key: "content-upload", limit: 60, windowSec: 3600 } },
);
