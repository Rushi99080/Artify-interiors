import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { testimonialSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const PATCH = route<{ id: string }, "content.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, testimonialSchema.partial());
    const testimonial = await prisma.testimonial.update({ where: { id: params.id }, data: body });
    await audit({ userId: user.id, action: "testimonial.updated", entity: "Testimonial", entityId: params.id, ip });
    return { testimonial };
  },
  { auth: "content.manage" },
);

export const DELETE = route<{ id: string }, "content.manage">(
  async (_req, { params, user, ip }) => {
    await prisma.testimonial.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "testimonial.deleted", entity: "Testimonial", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "content.manage" },
);
