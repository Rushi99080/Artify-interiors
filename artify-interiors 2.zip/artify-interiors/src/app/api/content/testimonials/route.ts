import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { testimonialSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, testimonialSchema);
    const testimonial = await prisma.testimonial.create({ data: body });
    await audit({ userId: user.id, action: "testimonial.created", entity: "Testimonial", entityId: testimonial.id, ip });
    return { testimonial };
  },
  { auth: "content.manage" },
);
