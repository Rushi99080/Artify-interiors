import { prisma } from "@/lib/db";
import { badRequest, parseJson, route } from "@/lib/api";
import { projectSchema } from "@/lib/validation";
import { createProject, customerForUser } from "@/lib/services/projects";
import { isTeamRole } from "@/lib/auth/token";
import { audit } from "@/lib/audit";
import { z } from "zod";

/** Step 1 of the AI designer (customer) or "New project" (team, with customerId). */
export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, projectSchema.extend({ customerId: z.string().optional() }));
    if (body.budgetMin && body.budgetMax && body.budgetMin > body.budgetMax) throw badRequest("Minimum budget is higher than maximum budget.", { budgetMax: "Must be at least the minimum budget" });

    let customerId: string;
    if (isTeamRole(user.role)) {
      if (body.customerId) customerId = body.customerId;
      else {
        const existing = await prisma.customer.findFirst({ where: { OR: [...(body.email ? [{ email: body.email }] : []), { phone: body.phone }] } });
        customerId = existing?.id ?? (await prisma.customer.create({ data: { fullName: body.fullName, phone: body.phone, email: body.email, city: body.location } })).id;
      }
    } else {
      customerId = (await customerForUser(user, { fullName: body.fullName, phone: body.phone, city: body.location })).id;
    }

    const project = await createProject({
      draft: {
        name: body.name,
        location: body.location,
        address: body.address,
        propertyType: body.propertyType,
        carpetAreaSqft: body.carpetAreaSqft,
        numberOfRooms: body.numberOfRooms,
        designStyle: body.designStyle,
        budgetMin: body.budgetMin,
        budgetMax: body.budgetMax,
        colorPalette: body.colorPalette,
        materialPreferences: body.materialPreferences,
        timeline: body.timeline,
        notes: body.notes,
        rooms: body.rooms.map((r) => ({ name: r.name, type: r.type, lengthFt: r.lengthFt, widthFt: r.widthFt, heightFt: r.heightFt, preferences: r.preferences })),
      },
      customerId,
      createdBy: user,
    });
    await audit({ userId: user.id, action: "project.created", entity: "Project", entityId: project.id, ip });
    return { project: { id: project.id, code: project.code, rooms: project.rooms.map((r) => ({ id: r.id, name: r.name, type: r.type })) } };
  },
  { auth: "user", rateLimit: { key: "project-create", limit: 15, windowSec: 3600 } },
);

export const GET = route(
  async (_req, { user }) => {
    const projects = await prisma.project.findMany({
      where: isTeamRole(user.role) ? {} : { customerId: user.customerId ?? "__none__" },
      orderBy: { updatedAt: "desc" },
      select: { id: true, code: true, name: true, status: true, location: true, contractValue: true, updatedAt: true },
    });
    return { projects };
  },
  { auth: "user" },
);
