import { route } from "@/lib/api";
import { ensureWorkflow } from "@/lib/services/workflow";

/** Team: add any missing workflow stages to a project (e.g. after new stages were configured). */
export const POST = route<{ id: string }, "projects.manage">(
  async (_req, { params }) => {
    await ensureWorkflow(params.id);
    return { ok: true };
  },
  { auth: "projects.manage" },
);
