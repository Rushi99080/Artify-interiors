import { z } from "zod";
import { prisma } from "@/lib/db";
import { badRequest, notFound, parseJson, route } from "@/lib/api";
import { splitPaymentSchedule } from "@/lib/calc/boq";
import { refreshPaymentMilestones } from "@/lib/services/payments";
import { audit } from "@/lib/audit";

const schema = z.object({
  milestones: z
    .array(z.object({ name: z.string().trim().min(2).max(120), percent: z.coerce.number().min(0.5).max(100), dueDate: z.string().nullable().optional() }))
    .min(1)
    .max(12),
});

/** Replace a project's payment milestones (percentages must total 100%). */
export const PUT = route<{ id: string }, "payments.record">(
  async (req, { params, user, ip }) => {
    const { milestones } = await parseJson(req, schema);
    const project = await prisma.project.findUnique({ where: { id: params.id }, select: { contractValue: true } });
    if (!project) throw notFound("Project not found.");
    if (!project.contractValue) throw badRequest("Set a contract value (approve a quotation) before defining payment milestones.");
    let split;
    try {
      split = splitPaymentSchedule(project.contractValue, milestones);
    } catch (err) {
      throw badRequest((err as Error).message);
    }
    await prisma.$transaction([
      prisma.payment.updateMany({ where: { projectId: params.id }, data: { paymentMilestoneId: null } }),
      prisma.paymentMilestone.deleteMany({ where: { projectId: params.id } }),
      prisma.paymentMilestone.createMany({
        data: split.map((s, i) => ({ projectId: params.id, name: s.name, percent: s.percent, amount: s.amount, sortOrder: i, dueDate: milestones[i]?.dueDate ? new Date(milestones[i]!.dueDate!) : null })),
      }),
    ]);
    await refreshPaymentMilestones(params.id);
    await audit({ userId: user.id, action: "payment.schedule_updated", entity: "Project", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "payments.record" },
);
