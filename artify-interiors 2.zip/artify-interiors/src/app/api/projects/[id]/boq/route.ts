import { z } from "zod";
import { parseJson, route } from "@/lib/api";
import { generateBOQ } from "@/lib/services/boq";
import { PRICE_TIERS } from "@/lib/constants";
import { audit } from "@/lib/audit";

const schema = z.object({ tier: z.enum(PRICE_TIERS).optional() });

/** Team: generate a new preliminary BOQ version for a project. */
export const POST = route<{ id: string }, "boq.manage">(
  async (req, { params, user, ip }) => {
    const { tier } = await parseJson(req, schema);
    const boq = await generateBOQ(params.id, { tier });
    await audit({ userId: user.id, action: "boq.generated", entity: "BOQ", entityId: boq.id, meta: { projectId: params.id, tier: boq.tier }, ip });
    return { boq: { id: boq.id, version: boq.version } };
  },
  { auth: "boq.manage" },
);
