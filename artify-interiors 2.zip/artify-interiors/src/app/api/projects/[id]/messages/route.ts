import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { messageSchema } from "@/lib/validation";
import { isTeamRole } from "@/lib/auth/token";
import { queueNotify, projectCustomerRecipient } from "@/lib/notifications";

export const GET = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    await assertProjectAccess(user, params.id);
    const messages = await prisma.message.findMany({ where: { projectId: params.id }, orderBy: { createdAt: "asc" }, include: { sender: { select: { name: true, role: true } } } });
    return { messages };
  },
  { auth: "user" },
);

export const POST = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    const project = await assertProjectAccess(user, params.id);
    const { body } = await parseJson(req, messageSchema);
    const team = isTeamRole(user.role);
    const message = await prisma.message.create({ data: { projectId: params.id, senderId: user.id, body, fromTeam: team, kind: "MESSAGE" }, include: { sender: { select: { name: true, role: true } } } });
    if (team) {
      const customer = await projectCustomerRecipient(params.id);
      queueNotify({
        event: "NEW_MESSAGE",
        title: `New message from the design team`,
        body: `${user.name}: ${body.slice(0, 400)}`,
        link: `/dashboard/projects/${params.id}/messages`,
        recipients: [customer],
        channels: { whatsapp: false },
        ctaLabel: "Reply",
      });
    } else {
      queueNotify({
        event: "NEW_MESSAGE",
        title: `Message from ${user.name} · ${project.name}`,
        body: body.slice(0, 400),
        link: `/admin/projects/${params.id}/messages`,
        notifyAdmins: true,
        channels: { whatsapp: false, email: false },
      });
    }
    return { message };
  },
  { auth: "user", rateLimit: { key: "message", limit: 60, windowSec: 600 } },
);
