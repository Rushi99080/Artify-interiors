import { prisma } from "@/lib/db";
import { forbidden, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { roomSchema } from "@/lib/validation";
import { ROOM_LABELS } from "@/lib/constants";
import { isTeamRole } from "@/lib/auth/token";

export const POST = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    const project = await assertProjectAccess(user, params.id);
    if (!isTeamRole(user.role) && !["DRAFT", "DESIGN", "QUOTATION"].includes(project.status)) throw forbidden("Rooms can no longer be changed on an active project.");
    const body = await parseJson(req, roomSchema);
    const count = await prisma.room.count({ where: { projectId: params.id } });
    const room = await prisma.room.create({
      data: {
        projectId: params.id,
        name: body.name ?? `${ROOM_LABELS[body.type]}${count ? ` ${count + 1}` : ""}`,
        type: body.type,
        lengthFt: body.lengthFt,
        widthFt: body.widthFt,
        heightFt: body.heightFt ?? 10,
        style: body.style ?? null,
        tier: body.tier ?? null,
        preferences: body.preferences,
        sortOrder: count,
      },
    });
    await prisma.project.update({ where: { id: params.id }, data: { numberOfRooms: count + 1 } });
    return { room };
  },
  { auth: "user" },
);
