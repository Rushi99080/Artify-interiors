import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { expenseSchema } from "@/lib/validation";
import { round2 } from "@/lib/calc/boq";
import { audit } from "@/lib/audit";

/** Admin: record actual project spend (feeds project-wise profit and material cost analytics). */
export const POST = route<{ id: string }, "expenses.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, expenseSchema);
    const expense = await prisma.expense.create({
      data: { projectId: params.id, category: body.category, description: body.description, amount: round2(body.amount), paidTo: body.paidTo, supplierId: body.supplierId ?? null, spentAt: body.spentAt ? new Date(body.spentAt) : new Date() },
    });
    await audit({ userId: user.id, action: "expense.created", entity: "Expense", entityId: expense.id, meta: { amount: expense.amount }, ip });
    return { expense };
  },
  { auth: "expenses.manage" },
);
