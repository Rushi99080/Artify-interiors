import { z } from "zod";
import { prisma } from "@/lib/db";
import { badRequest, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { generateBOQ } from "@/lib/services/boq";
import { createQuotation } from "@/lib/services/quotations";
import { getSettings } from "@/lib/settings";
import { queueNotify } from "@/lib/notifications";
import { PRICE_TIERS } from "@/lib/constants";
import { audit } from "@/lib/audit";

const schema = z.object({ tier: z.enum(PRICE_TIERS).optional() });

/**
 * Customer self-service: generates a preliminary BOQ from the project's rooms and — when the
 * "automatic preliminary quotation" setting is on — an instant preliminary quotation.
 */
export const POST = route<{ id: string }, "user">(
  async (req, { params, user, ip }) => {
    const project = await assertProjectAccess(user, params.id);
    if (!["DRAFT", "DESIGN", "QUOTATION"].includes(project.status)) throw badRequest("This project already has an approved quotation.");
    const { tier } = await parseJson(req, schema);
    const settings = await getSettings();
    const boq = await generateBOQ(params.id, { tier });

    if (settings.automation.autoPreliminaryQuotation) {
      const quotation = await createQuotation({ boqId: boq.id, user: null, send: true });
      await audit({ userId: user.id, action: "quotation.preliminary_auto", entity: "Quotation", entityId: quotation.id, ip });
      return { mode: "quotation", boqId: boq.id, quotationId: quotation.id };
    }

    await prisma.project.update({ where: { id: params.id }, data: { status: "QUOTATION" } });
    queueNotify({
      event: "QUOTATION_CHANGES_REQUESTED",
      title: `Quotation requested — ${project.name}`,
      body: `${user.name} generated a preliminary BOQ (v${boq.version}) and is waiting for a quotation.`,
      link: `/admin/boq/${boq.id}`,
      notifyAdmins: true,
      channels: { whatsapp: false },
    });
    await audit({ userId: user.id, action: "quotation.requested", entity: "BOQ", entityId: boq.id, ip });
    return { mode: "requested", boqId: boq.id };
  },
  { auth: "user", rateLimit: { key: "prelim-quote", limit: 6, windowSec: 3600 } },
);
