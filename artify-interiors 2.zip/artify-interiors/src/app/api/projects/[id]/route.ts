import { prisma } from "@/lib/db";
import { forbidden, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { projectUpdateSchema } from "@/lib/validation";
import { isTeamRole } from "@/lib/auth/token";
import { audit } from "@/lib/audit";
import { rescalePaymentSchedule } from "@/lib/services/payments";

export const GET = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    await assertProjectAccess(user, params.id);
    const project = await prisma.project.findUnique({
      where: { id: params.id },
      include: { rooms: { orderBy: { sortOrder: "asc" } }, customer: { select: { fullName: true, email: true, phone: true } }, milestones: { orderBy: { sortOrder: "asc" } } },
    });
    return { project };
  },
  { auth: "user" },
);

export const PATCH = route<{ id: string }, "user">(
  async (req, { params, user, ip }) => {
    const project = await assertProjectAccess(user, params.id);
    const body = await parseJson(req, projectUpdateSchema.extend({ contractValue: projectUpdateSchema.shape.budgetMax }));
    const team = isTeamRole(user.role);
    // Customers can edit their brief while the project is still in design; status/contract are team-only
    if (!team) {
      if (!["DRAFT", "DESIGN", "QUOTATION"].includes(project.status)) throw forbidden("This project is already active — please message the design team to make changes.");
      delete body.status;
      delete (body as { contractValue?: unknown }).contractValue;
    }
    const { contractValue, ...rest } = body as typeof body & { contractValue?: number | null };
    const updated = await prisma.project.update({ where: { id: params.id }, data: { ...rest, ...(team && contractValue !== undefined ? { contractValue } : {}) } });
    if (team && contractValue) await rescalePaymentSchedule(params.id, contractValue);
    await audit({ userId: user.id, action: "project.updated", entity: "Project", entityId: params.id, meta: body, ip });
    return { project: updated };
  },
  { auth: "user" },
);

export const DELETE = route<{ id: string }, "settings.manage">(
  async (_req, { params, user, ip }) => {
    await prisma.lead.updateMany({ where: { projectId: params.id }, data: { projectId: null } });
    await prisma.project.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "project.deleted", entity: "Project", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "settings.manage" },
);
