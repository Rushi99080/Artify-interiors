import { prisma } from "@/lib/db";
import { badRequest, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { storeUpload, fileUrl } from "@/lib/services/files";
import { UPLOAD_RULES, type UploadCategory } from "@/lib/storage/rules";
import { isTeamRole } from "@/lib/auth/token";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

const CUSTOMER_CATEGORIES: UploadCategory[] = ["ROOM_PHOTO", "FLOOR_PLAN", "DRAWING_PDF", "CAD", "MEASUREMENT", "REFERENCE", "DOCUMENT"];

/** Multipart upload (local storage, or any provider when files are small). Field names: file (repeatable), category, roomId. */
export const POST = route<{ id: string }, "user">(
  async (req, { params, user, ip }) => {
    await assertProjectAccess(user, params.id);
    const form = await req.formData().catch(() => null);
    if (!form) throw badRequest("Expected multipart form data.");
    const category = String(form.get("category") ?? "") as UploadCategory;
    if (!UPLOAD_RULES[category]) throw badRequest("Choose what kind of file you are uploading.");
    if (!isTeamRole(user.role) && !CUSTOMER_CATEGORIES.includes(category)) throw badRequest("This file type cannot be uploaded here.");
    const roomId = (form.get("roomId") as string) || null;
    if (roomId) {
      const room = await prisma.room.findFirst({ where: { id: roomId, projectId: params.id } });
      if (!room) throw badRequest("Room not found in this project.");
    }
    const files = form.getAll("file").filter((f): f is File => typeof f === "object" && "arrayBuffer" in f);
    if (!files.length) throw badRequest("No files received.");
    if (files.length > 10) throw badRequest("Upload up to 10 files at a time.");

    const saved = [];
    for (const f of files) {
      const rec = await storeUpload({ buffer: Buffer.from(await f.arrayBuffer()), originalName: f.name, category, projectId: params.id, roomId, uploadedById: user.id });
      saved.push({ id: rec.id, roomId: rec.roomId, originalName: rec.originalName, category: rec.category, mimeType: rec.mimeType, sizeBytes: rec.sizeBytes, url: fileUrl(rec.id) });
    }
    await audit({ userId: user.id, action: "file.uploaded", entity: "Project", entityId: params.id, meta: { count: saved.length, category }, ip });
    return { files: saved };
  },
  { auth: "user", rateLimit: { key: "upload", limit: 60, windowSec: 3600 } },
);

export const GET = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    await assertProjectAccess(user, params.id);
    const files = await prisma.uploadedFile.findMany({ where: { projectId: params.id }, orderBy: { createdAt: "desc" } });
    return { files: files.map((f) => ({ ...f, url: fileUrl(f.id) })) };
  },
  { auth: "user" },
);

