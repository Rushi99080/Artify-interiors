import { z } from "zod";
import { prisma } from "@/lib/db";
import { badRequest, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { env } from "@/lib/env";
import { verifyCloudinaryUpload } from "@/lib/storage";
import { MIME_BY_EXT, UPLOAD_RULES, checkUploadMeta, extOf, type UploadCategory } from "@/lib/storage/rules";
import { fileUrl } from "@/lib/services/files";

const schema = z.object({
  publicId: z.string().min(3).max(300),
  version: z.union([z.string(), z.number()]),
  signature: z.string().min(10).max(128),
  resourceType: z.enum(["image", "raw"]),
  bytes: z.number().int().positive(),
  originalName: z.string().min(1).max(200),
  category: z.string(),
  roomId: z.string().nullable().optional(),
});

/** Registers a file that was uploaded directly to Cloudinary, after verifying Cloudinary's response signature. */
export const POST = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    await assertProjectAccess(user, params.id);
    const body = await parseJson(req, schema);
    const category = body.category as UploadCategory;
    if (!UPLOAD_RULES[category]) throw badRequest("Unknown file category.");
    const problem = checkUploadMeta(category, body.originalName, body.bytes);
    if (problem) throw badRequest(problem);
    const expectedPrefix = `${env.cloudinary().folder}/projects/${params.id}/`;
    if (!body.publicId.startsWith(expectedPrefix)) throw badRequest("Upload does not belong to this project.");
    if (!verifyCloudinaryUpload(body.publicId, body.version, body.signature)) throw badRequest("Upload signature could not be verified.");
    if (body.roomId && !(await prisma.room.findFirst({ where: { id: body.roomId, projectId: params.id } }))) throw badRequest("Room not found in this project.");

    const ext = extOf(body.originalName);
    const rec = await prisma.uploadedFile.create({
      data: {
        projectId: params.id,
        roomId: body.roomId ?? null,
        uploadedById: user.id,
        category,
        originalName: body.originalName,
        mimeType: MIME_BY_EXT[ext] ?? "application/octet-stream",
        sizeBytes: body.bytes,
        storageProvider: "CLOUDINARY",
        storageKey: body.publicId,
        resourceType: body.resourceType,
      },
    });
    return { file: { id: rec.id, roomId: rec.roomId, originalName: rec.originalName, category: rec.category, mimeType: rec.mimeType, sizeBytes: rec.sizeBytes, url: fileUrl(rec.id) } };
  },
  { auth: "user" },
);
