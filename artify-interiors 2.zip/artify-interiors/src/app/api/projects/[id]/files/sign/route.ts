import { z } from "zod";
import { badRequest, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { activeProvider, signedUploadParams } from "@/lib/storage";
import { UPLOAD_RULES, checkUploadMeta, extOf, type UploadCategory } from "@/lib/storage/rules";

const schema = z.object({ filename: z.string().min(1).max(200), size: z.number().int().positive(), category: z.string() });

/** Signed parameters for a direct browser → Cloudinary upload (avoids serverless request size limits). */
export const POST = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    await assertProjectAccess(user, params.id);
    if (activeProvider() !== "cloudinary") throw badRequest("Direct uploads are only used with Cloudinary storage.");
    const body = await parseJson(req, schema);
    const category = body.category as UploadCategory;
    if (!UPLOAD_RULES[category]) throw badRequest("Unknown file category.");
    const problem = checkUploadMeta(category, body.filename, body.size);
    if (problem) throw badRequest(problem);
    return signedUploadParams(`projects/${params.id}`, extOf(body.filename));
  },
  { auth: "user", rateLimit: { key: "upload-sign", limit: 120, windowSec: 3600 } },
);
