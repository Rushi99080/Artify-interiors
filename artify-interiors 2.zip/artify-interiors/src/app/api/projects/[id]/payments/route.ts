import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { paymentSchema } from "@/lib/validation";
import { getPaymentOverview, recordPayment } from "@/lib/services/payments";
import { audit } from "@/lib/audit";

export const GET = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    await assertProjectAccess(user, params.id);
    return getPaymentOverview(params.id);
  },
  { auth: "user" },
);

/** Team: record an offline payment (cash, UPI, bank transfer, cheque, card). A receipt number is issued. */
export const POST = route<{ id: string }, "payments.record">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, paymentSchema);
    if (body.paymentMilestoneId) {
      const ms = await prisma.paymentMilestone.findFirst({ where: { id: body.paymentMilestoneId, projectId: params.id } });
      if (!ms) body.paymentMilestoneId = null;
    }
    const payment = await recordPayment({
      projectId: params.id,
      amount: body.amount,
      method: body.method,
      reference: body.reference,
      paidAt: body.paidAt ? new Date(body.paidAt) : undefined,
      notes: body.notes,
      paymentMilestoneId: body.paymentMilestoneId ?? null,
      recordedById: user.id,
    });
    await audit({ userId: user.id, action: "payment.recorded", entity: "Payment", entityId: payment.id, meta: { amount: payment.amount, projectId: params.id }, ip });
    return { payment };
  },
  { auth: "payments.record" },
);
