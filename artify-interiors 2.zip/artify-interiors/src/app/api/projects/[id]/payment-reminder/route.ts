import { route } from "@/lib/api";
import { sendPaymentReminder } from "@/lib/services/payments";
import { audit } from "@/lib/audit";

export const POST = route<{ id: string }, "payments.record">(
  async (_req, { params, user, ip }) => {
    const next = await sendPaymentReminder(params.id);
    await audit({ userId: user.id, action: "payment.reminder_sent", entity: "Project", entityId: params.id, meta: { milestone: next.name }, ip });
    return { ok: true, milestone: next.name, amount: next.balance };
  },
  { auth: "payments.record", rateLimit: { key: "pay-reminder", limit: 20, windowSec: 3600 } },
);
