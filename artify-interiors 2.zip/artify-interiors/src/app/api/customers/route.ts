import { prisma } from "@/lib/db";
import { conflict, parseJson, route } from "@/lib/api";
import { customerSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, customerSchema);
    if (body.email && (await prisma.customer.findFirst({ where: { email: body.email } }))) throw conflict("A customer with this email already exists.");
    const customer = await prisma.customer.create({ data: body });
    await audit({ userId: user.id, action: "customer.created", entity: "Customer", entityId: customer.id, ip });
    return { customer };
  },
  { auth: "customers.manage" },
);
