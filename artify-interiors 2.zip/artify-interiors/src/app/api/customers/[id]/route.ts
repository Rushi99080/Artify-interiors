import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { customerSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const PATCH = route<{ id: string }, "customers.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, customerSchema.partial());
    const customer = await prisma.customer.update({ where: { id: params.id }, data: body });
    await audit({ userId: user.id, action: "customer.updated", entity: "Customer", entityId: params.id, ip });
    return { customer };
  },
  { auth: "customers.manage" },
);
