import { z } from "zod";
import { prisma } from "@/lib/db";
import { badRequest, notFound, parseJson, route } from "@/lib/api";
import { createProject } from "@/lib/services/projects";
import { DESIGN_STYLES, PROPERTY_TYPES } from "@/lib/constants";
import { audit } from "@/lib/audit";

const schema = z.object({
  projectName: z.string().trim().min(2).max(120),
  location: z.string().trim().min(2).max(160),
  propertyType: z.enum(PROPERTY_TYPES),
  designStyle: z.enum(DESIGN_STYLES).optional(),
});

/** Converts a lead into a customer + draft project (with a starter living room) so the team can design and quote. */
export const POST = route<{ id: string }, "leads.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, schema);
    const lead = await prisma.lead.findUnique({ where: { id: params.id } });
    if (!lead) throw notFound("Lead not found.");
    if (lead.projectId) throw badRequest("This lead already has a project.");

    const customer =
      (lead.customerId ? await prisma.customer.findUnique({ where: { id: lead.customerId } }) : null) ??
      (lead.email ? await prisma.customer.findFirst({ where: { email: lead.email } }) : null) ??
      (await prisma.customer.findFirst({ where: { phone: lead.phone } })) ??
      (await prisma.customer.create({ data: { fullName: lead.name, phone: lead.phone, email: lead.email, city: lead.city } }));

    const project = await createProject({
      draft: {
        name: body.projectName,
        location: body.location,
        propertyType: body.propertyType,
        designStyle: body.designStyle ?? null,
        notes: lead.message,
        rooms: [{ type: body.propertyType === "OFFICE" ? "OFFICE" : body.propertyType === "COMMERCIAL" ? "COMMERCIAL" : "LIVING_ROOM" }],
      },
      customerId: customer.id,
      createdBy: user,
    });
    await prisma.lead.update({ where: { id: lead.id }, data: { customerId: customer.id, projectId: project.id, status: lead.status === "NEW" ? "CONSULTATION" : lead.status } });
    await prisma.leadNote.create({ data: { leadId: lead.id, authorId: user.id, note: `Project ${project.code} created from this lead.` } });
    await audit({ userId: user.id, action: "lead.converted_to_project", entity: "Lead", entityId: lead.id, meta: { projectId: project.id }, ip });
    return { projectId: project.id };
  },
  { auth: "leads.manage" },
);
