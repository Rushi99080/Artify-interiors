import { prisma } from "@/lib/db";
import { notFound, parseJson, route } from "@/lib/api";
import { leadUpdateSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const PATCH = route<{ id: string }, "leads.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, leadUpdateSchema);
    const lead = await prisma.lead.findUnique({ where: { id: params.id } });
    if (!lead) throw notFound("Lead not found.");
    const updated = await prisma.lead.update({
      where: { id: params.id },
      data: {
        ...(body.status ? { status: body.status } : {}),
        ...(body.followUpDate !== undefined ? { followUpDate: body.followUpDate ? new Date(body.followUpDate) : null } : {}),
        ...(body.assignedToId !== undefined ? { assignedToId: body.assignedToId } : {}),
        ...(body.lostReason !== undefined ? { lostReason: body.lostReason } : {}),
      },
    });
    if (body.note) await prisma.leadNote.create({ data: { leadId: params.id, authorId: user.id, note: body.note } });
    if (body.status && body.status !== lead.status) {
      await prisma.leadNote.create({ data: { leadId: params.id, authorId: user.id, note: `Status changed from ${lead.status} to ${body.status}` } });
    }
    await audit({ userId: user.id, action: "lead.updated", entity: "Lead", entityId: params.id, meta: body, ip });
    return { lead: updated };
  },
  { auth: "leads.manage" },
);

export const DELETE = route<{ id: string }, "settings.manage">(
  async (_req, { params, user, ip }) => {
    await prisma.lead.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "lead.deleted", entity: "Lead", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "settings.manage" },
);
