import { prisma } from "@/lib/db";
import { badRequest, parseJson, route } from "@/lib/api";
import { leadSchema } from "@/lib/validation";
import { createLead } from "@/lib/services/projects";
import { audit } from "@/lib/audit";

/** Public enquiry form (website, cost calculator, AI designer). */
export const POST = route(
  async (req, { ip, user }) => {
    const body = await parseJson(req, leadSchema);
    if (body.website) throw badRequest("Invalid submission."); // honeypot filled → bot
    const lead = await createLead({
      name: body.name,
      phone: body.phone,
      email: body.email,
      city: body.city,
      projectType: body.projectType ?? null,
      budget: body.budget,
      source: body.source ?? "WEBSITE",
      message: body.message,
      meta: { ...(body.meta ?? {}), ip, userId: user?.id ?? null },
    });
    await audit({ userId: user?.id, action: "lead.created", entity: "Lead", entityId: lead.id, ip });
    return { ok: true, leadCode: lead.leadCode };
  },
  { rateLimit: { key: "lead", limit: 6, windowSec: 600 }, skipRateLimitForTeam: true },
);

/** Team: list leads (filters: status, q). */
export const GET = route(
  async (req) => {
    const status = req.nextUrl.searchParams.get("status") ?? undefined;
    const q = req.nextUrl.searchParams.get("q")?.trim();
    const leads = await prisma.lead.findMany({
      where: {
        ...(status ? { status: status as never } : {}),
        ...(q ? { OR: [{ name: { contains: q, mode: "insensitive" } }, { phone: { contains: q } }, { email: { contains: q, mode: "insensitive" } }, { leadCode: { contains: q, mode: "insensitive" } }] } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 200,
    });
    return { leads };
  },
  { auth: "leads.manage" },
);
