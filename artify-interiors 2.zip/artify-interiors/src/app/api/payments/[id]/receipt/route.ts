import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { forbidden, notFound, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { renderReceiptPdf } from "@/lib/pdf/receipt";
import { getSettings } from "@/lib/settings";
import { paymentSummary } from "@/lib/calc/payments";

export const runtime = "nodejs";

/** Payment receipt PDF. */
export const GET = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    const payment = await prisma.payment.findUnique({ where: { id: params.id }, include: { paymentMilestone: true, project: { include: { customer: true, payments: { select: { amount: true, status: true, paidAt: true } } } } } });
    if (!payment) throw notFound("Payment not found.");
    await assertProjectAccess(user, payment.projectId);
    if (payment.status !== "SUCCESS" || !payment.receiptNo) throw forbidden("A receipt is only available for successful payments.");
    const settings = await getSettings();
    const upTo = payment.project.payments.filter((p) => p.paidAt <= payment.paidAt);
    const summary = paymentSummary(payment.project.contractValue, upTo);
    const pdf = await renderReceiptPdf({
      receiptNo: payment.receiptNo,
      paidAt: payment.paidAt,
      amount: payment.amount,
      method: payment.method,
      reference: payment.reference,
      milestoneName: payment.paymentMilestone?.name ?? null,
      company: settings.company,
      client: { name: payment.project.customer.fullName, phone: payment.project.customer.phone, email: payment.project.customer.email },
      project: { name: payment.project.name, code: payment.project.code, contractValue: payment.project.contractValue, totalReceived: summary.received, balance: summary.pending },
    });
    const download = req.nextUrl.searchParams.get("download") === "1";
    return new NextResponse(new Uint8Array(pdf), {
      headers: { "Content-Type": "application/pdf", "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${payment.receiptNo.replace(/\//g, "-")}.pdf"`, "Cache-Control": "private, no-store" },
    });
  },
  { auth: "user" },
);
