import { prisma } from "@/lib/db";
import { notFound, route } from "@/lib/api";
import { refreshPaymentMilestones } from "@/lib/services/payments";
import { audit } from "@/lib/audit";

/** Admin: delete a wrongly recorded payment. */
export const DELETE = route<{ id: string }, "payments.delete">(
  async (_req, { params, user, ip }) => {
    const payment = await prisma.payment.findUnique({ where: { id: params.id } });
    if (!payment) throw notFound("Payment not found.");
    await prisma.payment.delete({ where: { id: params.id } });
    await refreshPaymentMilestones(payment.projectId);
    await audit({ userId: user.id, action: "payment.deleted", entity: "Payment", entityId: params.id, meta: { amount: payment.amount, receiptNo: payment.receiptNo }, ip });
    return { ok: true };
  },
  { auth: "payments.delete" },
);
