import { NextResponse, type NextRequest } from "next/server";
import { env } from "@/lib/env";
import { confirmGatewayPayment, verifyRazorpayWebhook } from "@/lib/services/payments";
import { logError } from "@/lib/logger";

export const runtime = "nodejs";

/** Razorpay webhook (payment.captured / order.paid) — a backup in case the browser closes before verification. */
export async function POST(req: NextRequest) {
  const secret = env.razorpay().webhookSecret;
  if (!secret) return NextResponse.json({ error: "Webhook secret not configured" }, { status: 503 });
  const raw = await req.text();
  const signature = req.headers.get("x-razorpay-signature") ?? "";
  if (!verifyRazorpayWebhook(raw, signature, secret)) return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  try {
    const event = JSON.parse(raw) as { event?: string; payload?: { payment?: { entity?: { id?: string; order_id?: string; status?: string } } } };
    const p = event.payload?.payment?.entity;
    if ((event.event === "payment.captured" || event.event === "order.paid") && p?.order_id && p.id) {
      await confirmGatewayPayment(p.order_id, p.id).catch((err) => logError("razorpay.webhook.confirm", err, { orderId: p.order_id }));
    }
  } catch (err) {
    logError("razorpay.webhook", err);
  }
  return NextResponse.json({ ok: true });
}
