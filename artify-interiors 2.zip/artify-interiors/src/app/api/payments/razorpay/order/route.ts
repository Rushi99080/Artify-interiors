import { z } from "zod";
import { prisma } from "@/lib/db";
import { badRequest, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { createRazorpayOrder, getPaymentOverview } from "@/lib/services/payments";

const schema = z.object({ projectId: z.string(), milestoneId: z.string().nullable().optional(), amount: z.number().positive().optional() });

/** Creates a Razorpay order for the next unpaid milestone (or a chosen amount up to the pending balance). */
export const POST = route(
  async (req, { user }) => {
    const body = await parseJson(req, schema);
    await assertProjectAccess(user, body.projectId);
    const overview = await getPaymentOverview(body.projectId);
    if (overview.summary.pending <= 0) throw badRequest("There is no pending amount on this project.");
    const ms = body.milestoneId ? overview.milestones.find((m) => m.id === body.milestoneId) : overview.milestones.find((m) => m.status !== "PAID");
    const amount = Math.min(body.amount ?? ms?.balance ?? overview.summary.pending, overview.summary.pending);
    const order = await createRazorpayOrder(body.projectId, amount, ms?.id ?? null);
    const customer = await prisma.project.findUnique({ where: { id: body.projectId }, select: { name: true, customer: { select: { fullName: true, email: true, phone: true } } } });
    return { ...order, description: ms?.name ?? "Project payment", projectName: customer?.name, prefill: { name: customer?.customer.fullName, email: customer?.customer.email, contact: customer?.customer.phone } };
  },
  { auth: "user", rateLimit: { key: "rzp-order", limit: 20, windowSec: 3600 } },
);
