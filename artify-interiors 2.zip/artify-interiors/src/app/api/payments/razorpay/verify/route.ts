import { z } from "zod";
import { prisma } from "@/lib/db";
import { notFound, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { verifyAndConfirm } from "@/lib/services/payments";

const schema = z.object({ razorpay_order_id: z.string(), razorpay_payment_id: z.string(), razorpay_signature: z.string() });

/** Called by the checkout handler; verifies the HMAC signature before marking the payment successful. */
export const POST = route(
  async (req, { user }) => {
    const body = await parseJson(req, schema);
    const pending = await prisma.payment.findUnique({ where: { gatewayOrderId: body.razorpay_order_id }, select: { projectId: true } });
    if (!pending) throw notFound("Payment order not found.");
    await assertProjectAccess(user, pending.projectId);
    const payment = await verifyAndConfirm(body.razorpay_order_id, body.razorpay_payment_id, body.razorpay_signature);
    return { ok: true, receiptNo: payment.receiptNo, paymentId: payment.id };
  },
  { auth: "user" },
);
