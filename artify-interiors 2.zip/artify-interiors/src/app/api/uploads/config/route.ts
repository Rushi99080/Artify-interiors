import { route } from "@/lib/api";
import { activeProvider } from "@/lib/storage";
import { UPLOAD_RULES } from "@/lib/storage/rules";

/** Tells the uploader whether to send files to our API (local) or directly to Cloudinary (signed). */
export const GET = route(async () => ({ provider: activeProvider(), rules: UPLOAD_RULES }), { auth: "user" });
