import { z } from "zod";
import { parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { generateConcepts } from "@/lib/services/ai-design";
import { fileUrl } from "@/lib/services/files";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";
export const maxDuration = 300;

const schema = z.object({
  projectId: z.string().min(1),
  roomId: z.string().nullable().optional(),
  fileIds: z.array(z.string()).max(10).default([]),
  instructions: z.string().trim().max(1000).nullable().optional(),
  variations: z.number().int().min(1).max(4).optional(),
});

/** Analyses room photos + preferences and creates design concepts (images are rendered separately per design). */
export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, schema);
    await assertProjectAccess(user, body.projectId);
    const result = await generateConcepts({ projectId: body.projectId, roomId: body.roomId ?? null, fileIds: body.fileIds, instructions: body.instructions, variations: body.variations, user });
    await audit({ userId: user.id, action: "ai.generate", entity: "Project", entityId: body.projectId, meta: { requestId: result.requestId, designs: result.designs.length }, ip });
    return {
      requestId: result.requestId,
      analysis: result.analysis,
      designs: result.designs.map((d) => ({ ...d, imageUrl: fileUrl(d.imageFileId) })),
    };
  },
  { auth: "user", rateLimit: { key: "ai-generate", limit: 12, windowSec: 3600 } },
);
