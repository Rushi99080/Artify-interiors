import { route } from "@/lib/api";
import { aiConfig } from "@/lib/ai";

/** Which AI providers are configured (booleans and model names only — never keys). */
export const GET = route(async () => aiConfig(), { auth: "user" });
