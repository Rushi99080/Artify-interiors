import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { forbidden, notFound, route, unauthorized } from "@/lib/api";
import { canAccessProject } from "@/lib/access";
import { deliveryUrl, readBuffer, removeObject } from "@/lib/storage";
import { isTeamRole } from "@/lib/auth/token";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

/** Serves a stored file after an access check (public website images skip the check). */
export const GET = route<{ id: string }>(async (req, { params, user }) => {
  const file = await prisma.uploadedFile.findUnique({ where: { id: params.id } });
  if (!file) throw notFound("File not found.");
  if (!file.isPublic) {
    if (!user) throw unauthorized();
    const allowed = isTeamRole(user.role) || file.uploadedById === user.id || (file.projectId ? !!(await canAccessProject(user, file.projectId)) : false);
    if (!allowed) throw forbidden();
  }
  const download = req.nextUrl.searchParams.get("download") === "1";
  if (file.storageProvider === "CLOUDINARY") {
    const url = deliveryUrl(file);
    if (!url) throw notFound();
    return NextResponse.redirect(url, { status: 302, headers: { "Cache-Control": "private, max-age=300" } });
  }
  const buffer = await readBuffer(file).catch(() => null);
  if (!buffer) throw notFound("The file is missing from storage.");
  const safeName = file.originalName.replace(/[^\w.\- ]+/g, "_");
  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": file.mimeType,
      "Content-Length": String(buffer.length),
      "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${safeName}"`,
      "Cache-Control": file.isPublic ? "public, max-age=86400, immutable" : "private, max-age=3600",
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
    },
  });
});

export const DELETE = route<{ id: string }, "user">(
  async (_req, { params, user, ip }) => {
    const file = await prisma.uploadedFile.findUnique({ where: { id: params.id } });
    if (!file) throw notFound("File not found.");
    const team = isTeamRole(user.role);
    if (!team && file.uploadedById !== user.id) throw forbidden("You can only delete files you uploaded.");
    if (file.category === "GENERATED" && !team) throw forbidden();
    await prisma.generatedDesign.updateMany({ where: { imageFileId: file.id }, data: { imageFileId: null, imageStatus: "NONE" } });
    await prisma.uploadedFile.delete({ where: { id: file.id } });
    await removeObject(file);
    await audit({ userId: user.id, action: "file.deleted", entity: "UploadedFile", entityId: file.id, meta: { name: file.originalName }, ip });
    return { ok: true };
  },
  { auth: "user" },
);
