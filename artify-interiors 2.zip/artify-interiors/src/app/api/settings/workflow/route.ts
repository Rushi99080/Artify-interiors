import { z } from "zod";
import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { stageKeyFromName } from "@/lib/workflow/stages";
import { audit } from "@/lib/audit";

const schema = z.object({
  stages: z
    .array(
      z.object({
        id: z.string().optional(),
        key: z.string().optional(),
        name: z.string().trim().min(2).max(80),
        defaultDurationDays: z.coerce.number().int().min(0).max(365),
        customerVisible: z.boolean(),
        isActive: z.boolean(),
      }),
    )
    .min(1)
    .max(40),
});

/** Admin: rename, reorder, add or deactivate workflow stages. Existing project milestones are not removed. */
export const PUT = route(
  async (req, { user, ip }) => {
    const { stages } = await parseJson(req, schema);
    const existing = await prisma.workflowStage.findMany();
    const usedKeys = new Set(existing.map((e) => e.key));
    await prisma.$transaction(async (tx) => {
      for (const [i, s] of stages.entries()) {
        const found = s.id ? existing.find((e) => e.id === s.id) : undefined;
        if (found) {
          await tx.workflowStage.update({ where: { id: found.id }, data: { name: s.name, sortOrder: i + 1, defaultDurationDays: s.defaultDurationDays, customerVisible: s.customerVisible, isActive: s.isActive } });
        } else {
          let key = stageKeyFromName(s.name);
          let n = 2;
          while (usedKeys.has(key)) key = `${stageKeyFromName(s.name)}_${n++}`;
          usedKeys.add(key);
          await tx.workflowStage.create({ data: { key, name: s.name, sortOrder: i + 1, defaultDurationDays: s.defaultDurationDays, customerVisible: s.customerVisible, isActive: s.isActive } });
        }
      }
      const keep = new Set(stages.map((s) => s.id).filter(Boolean));
      for (const e of existing) if (!keep.has(e.id)) await tx.workflowStage.update({ where: { id: e.id }, data: { isActive: false } });
    });
    // keep names/order of milestones in sync for open projects
    const fresh = await prisma.workflowStage.findMany();
    for (const st of fresh) {
      await prisma.projectMilestone.updateMany({ where: { stageKey: st.key, project: { status: { notIn: ["COMPLETED", "CANCELLED"] } } }, data: { name: st.name, sortOrder: st.sortOrder, customerVisible: st.customerVisible } });
    }
    await audit({ userId: user.id, action: "workflow.updated", entity: "WorkflowStage", ip });
    return { ok: true };
  },
  { auth: "settings.manage" },
);
