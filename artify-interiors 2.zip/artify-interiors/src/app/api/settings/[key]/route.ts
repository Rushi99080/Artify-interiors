import { z } from "zod";
import { badRequest, forbidden, parseJson, route } from "@/lib/api";
import { can } from "@/lib/auth/permissions";
import { saveSetting, type SettingKey } from "@/lib/settings";
import { PRICE_TIERS } from "@/lib/constants";
import { audit } from "@/lib/audit";

const tierRates = z.object(Object.fromEntries(PRICE_TIERS.map((t) => [t, z.coerce.number().min(0).max(10_000_000)])) as Record<(typeof PRICE_TIERS)[number], z.ZodNumber>);
const text = (max = 5000) => z.string().trim().max(max);

const SCHEMAS: Record<SettingKey, z.ZodType> = {
  company: z.object({
    name: text(80).min(2),
    legalName: text(120).min(2),
    tagline: text(120),
    address: text(400),
    phone: text(40),
    email: text(160),
    website: text(200),
    gstin: text(20),
    logoUrl: text(500),
    bankDetails: text(1000),
    whatsappNumber: text(20),
    instagramUrl: text(200),
  }),
  tax: z.object({ gstRate: z.coerce.number().min(0).max(28) }),
  boqDefaults: z.object({
    wastagePercent: z.coerce.number().min(0).max(50),
    profitMarginPercent: z.coerce.number().min(0).max(200),
    transportCharges: z.coerce.number().min(0),
    installationCharges: z.coerce.number().min(0),
    marginLabel: text(80).min(2),
  }),
  quotation: z.object({
    validityDays: z.coerce.number().int().min(1).max(180),
    prefix: text(12).min(1).regex(/^[A-Z0-9-]+$/i, "Letters, numbers and dashes only"),
    scopeOfWork: text(),
    paymentTerms: text(),
    timelineText: text(),
    terms: text(10000),
  }),
  paymentSchedule: z
    .array(z.object({ name: text(120).min(2), percent: z.coerce.number().min(0.5).max(100) }))
    .min(1)
    .max(12)
    .refine((a) => Math.abs(a.reduce((s, x) => s + x.percent, 0) - 100) < 0.001, "Percentages must add up to 100%"),
  rateCard: z.record(z.string(), z.object({ rates: tierRates })),
  automation: z.object({ autoPreliminaryQuotation: z.boolean(), paymentReminderDays: z.coerce.number().int().min(1).max(30) }),
  hero: z.object({ eyebrow: text(120), headlineLines: z.array(text(40)).min(1).max(4), subtext: text(400), imageUrl: text(500) }),
  about: z.object({ heading: text(160), body: text(4000), imageUrl: text(500), values: z.array(z.object({ title: text(60), text: text(240) })).max(6) }),
  stats: z.array(z.object({ value: text(20).min(1), label: text(60).min(1) })).max(6),
};

const CONTENT_KEYS: SettingKey[] = ["hero", "about", "stats"];

/** Update one settings group. Website content keys need content.manage; business keys need settings.manage. */
export const PUT = route<{ key: string }, "admin.access">(
  async (req, { params, user, ip }) => {
    const key = params.key as SettingKey;
    const schema = SCHEMAS[key];
    if (!schema) throw badRequest("Unknown settings group.");
    if (!can(user.role, CONTENT_KEYS.includes(key) ? "content.manage" : "settings.manage")) throw forbidden();
    const value = await parseJson(req, schema);
    await saveSetting(key, value);
    await audit({ userId: user.id, action: "settings.updated", entity: "Setting", entityId: key, ip });
    return { ok: true };
  },
  { auth: "admin.access" },
);
