import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

/** Liveness + database check for uptime monitors. */
export async function GET() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return NextResponse.json({ ok: true, database: "up", time: new Date().toISOString() });
  } catch {
    return NextResponse.json({ ok: false, database: "down" }, { status: 503 });
  }
}
