import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { supplierSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const GET = route(async () => ({ suppliers: await prisma.supplier.findMany({ orderBy: { name: "asc" } }) }), { auth: "suppliers.manage" });

export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, supplierSchema);
    const supplier = await prisma.supplier.create({ data: body });
    await audit({ userId: user.id, action: "supplier.created", entity: "Supplier", entityId: supplier.id, ip });
    return { supplier };
  },
  { auth: "suppliers.manage" },
);
