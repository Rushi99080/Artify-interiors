import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { supplierSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const PATCH = route<{ id: string }, "suppliers.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, supplierSchema.partial());
    const supplier = await prisma.supplier.update({ where: { id: params.id }, data: body });
    await audit({ userId: user.id, action: "supplier.updated", entity: "Supplier", entityId: params.id, ip });
    return { supplier };
  },
  { auth: "suppliers.manage" },
);

export const DELETE = route<{ id: string }, "materials.delete">(
  async (_req, { params, user, ip }) => {
    await prisma.supplier.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "supplier.deleted", entity: "Supplier", entityId: params.id, ip });
    return { ok: true };
  },
  { auth: "materials.delete" },
);
