import Papa from "papaparse";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { badRequest, route } from "@/lib/api";

const csv = (rows: Record<string, unknown>[], name: string) =>
  new NextResponse("﻿" + Papa.unparse(rows), {
    headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="artify-${name}-${new Date().toISOString().slice(0, 10)}.csv"` },
  });

/** CSV exports for reporting: leads, payments, projects, expenses. */
export const GET = route(
  async (req) => {
    const type = req.nextUrl.searchParams.get("type");
    switch (type) {
      case "leads": {
        const rows = await prisma.lead.findMany({ orderBy: { createdAt: "desc" }, include: { assignedTo: { select: { name: true } } } });
        return csv(
          rows.map((l) => ({ "Lead ID": l.leadCode, Name: l.name, Phone: l.phone, Email: l.email, City: l.city, "Project type": l.projectType, Budget: l.budget, Source: l.source, Status: l.status, "Follow-up": l.followUpDate?.toISOString().slice(0, 10) ?? "", "Assigned to": l.assignedTo?.name ?? "", Created: l.createdAt.toISOString() })),
          "leads",
        );
      }
      case "payments": {
        const rows = await prisma.payment.findMany({ where: { status: "SUCCESS" }, orderBy: { paidAt: "desc" }, include: { project: { select: { code: true, name: true, customer: { select: { fullName: true } } } }, paymentMilestone: { select: { name: true } } } });
        return csv(
          rows.map((p) => ({ Receipt: p.receiptNo, Date: p.paidAt.toISOString().slice(0, 10), Project: p.project.code, "Project name": p.project.name, Client: p.project.customer.fullName, Milestone: p.paymentMilestone?.name ?? "", Method: p.method, Reference: p.reference, Amount: p.amount })),
          "payments",
        );
      }
      case "projects": {
        const rows = await prisma.project.findMany({ orderBy: { createdAt: "desc" }, include: { customer: { select: { fullName: true } }, payments: { where: { status: "SUCCESS" }, select: { amount: true } }, expenses: { select: { amount: true } } } });
        return csv(
          rows.map((p) => {
            const received = p.payments.reduce((s, x) => s + x.amount, 0);
            const spent = p.expenses.reduce((s, x) => s + x.amount, 0);
            return { Code: p.code, Name: p.name, Client: p.customer.fullName, Status: p.status, Location: p.location, "Contract value": p.contractValue ?? "", Received: received, Pending: Math.max(0, (p.contractValue ?? 0) - received), Expenses: spent, Created: p.createdAt.toISOString().slice(0, 10) };
          }),
          "projects",
        );
      }
      case "expenses": {
        const rows = await prisma.expense.findMany({ orderBy: { spentAt: "desc" }, include: { project: { select: { code: true } }, supplier: { select: { name: true } } } });
        return csv(rows.map((e) => ({ Date: e.spentAt.toISOString().slice(0, 10), Project: e.project.code, Category: e.category, Description: e.description, "Paid to": e.paidTo ?? e.supplier?.name ?? "", Amount: e.amount })), "expenses");
      }
      default:
        throw badRequest("Unknown report type. Use leads, payments, projects or expenses.");
    }
  },
  { auth: "reports.view" },
);
