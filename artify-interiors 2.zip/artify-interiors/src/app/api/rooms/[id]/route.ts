import { prisma } from "@/lib/db";
import { forbidden, notFound, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { roomSchema } from "@/lib/validation";
import { isTeamRole } from "@/lib/auth/token";

async function loadRoom(id: string) {
  const room = await prisma.room.findUnique({ where: { id }, include: { project: { select: { status: true } } } });
  if (!room) throw notFound("Room not found.");
  return room;
}

export const PATCH = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    const room = await loadRoom(params.id);
    await assertProjectAccess(user, room.projectId);
    if (!isTeamRole(user.role) && !["DRAFT", "DESIGN", "QUOTATION"].includes(room.project.status)) throw forbidden("Rooms can no longer be changed on an active project.");
    const body = await parseJson(req, roomSchema.partial());
    const updated = await prisma.room.update({
      where: { id: params.id },
      data: {
        ...(body.name !== undefined && body.name !== null ? { name: body.name } : {}),
        ...(body.type ? { type: body.type } : {}),
        ...(body.lengthFt !== undefined ? { lengthFt: body.lengthFt } : {}),
        ...(body.widthFt !== undefined ? { widthFt: body.widthFt } : {}),
        ...(body.heightFt !== undefined ? { heightFt: body.heightFt } : {}),
        ...(body.style !== undefined ? { style: body.style } : {}),
        ...(body.tier !== undefined ? { tier: body.tier } : {}),
        ...(body.preferences !== undefined ? { preferences: body.preferences } : {}),
      },
    });
    return { room: updated };
  },
  { auth: "user" },
);

export const DELETE = route<{ id: string }, "user">(
  async (_req, { params, user }) => {
    const room = await loadRoom(params.id);
    await assertProjectAccess(user, room.projectId);
    if (!isTeamRole(user.role) && !["DRAFT", "DESIGN", "QUOTATION"].includes(room.project.status)) throw forbidden("Rooms can no longer be changed on an active project.");
    const remaining = await prisma.room.count({ where: { projectId: room.projectId } });
    if (remaining <= 1) throw forbidden("A project needs at least one room.");
    await prisma.room.delete({ where: { id: params.id } });
    await prisma.project.update({ where: { id: room.projectId }, data: { numberOfRooms: remaining - 1 } });
    return { ok: true };
  },
  { auth: "user" },
);
