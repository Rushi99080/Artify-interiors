import { z } from "zod";
import { prisma } from "@/lib/db";
import { notFound, parseJson, route } from "@/lib/api";
import { assertProjectAccess } from "@/lib/access";
import { completeStage } from "@/lib/services/workflow";
import { queueNotify } from "@/lib/notifications";
import { isTeamRole } from "@/lib/auth/token";

const schema = z.object({
  selections: z.array(z.object({ materialId: z.string(), application: z.string().trim().max(120).nullable().optional() })).max(40),
});

/** Replaces the materials selected for a room (one per category is used by the BOQ engine). */
export const PUT = route<{ id: string }, "user">(
  async (req, { params, user }) => {
    const room = await prisma.room.findUnique({ where: { id: params.id }, include: { project: { select: { name: true } } } });
    if (!room) throw notFound("Room not found.");
    await assertProjectAccess(user, room.projectId);
    const { selections } = await parseJson(req, schema);
    const valid = await prisma.material.findMany({ where: { id: { in: selections.map((s) => s.materialId) }, isActive: true }, select: { id: true } });
    const ok = new Set(valid.map((v) => v.id));
    await prisma.$transaction([
      prisma.roomMaterial.deleteMany({ where: { roomId: params.id } }),
      prisma.roomMaterial.createMany({ data: selections.filter((s) => ok.has(s.materialId)).map((s) => ({ roomId: params.id, materialId: s.materialId, application: s.application ?? null })), skipDuplicates: true }),
    ]);
    if (ok.size) {
      await completeStage(room.projectId, "MATERIAL_SELECTION");
      if (!isTeamRole(user.role)) {
        queueNotify({
          event: "MATERIAL_APPROVAL",
          title: `Materials selected for ${room.name}`,
          body: `The client selected ${ok.size} material(s) for ${room.name} in ${room.project.name}. Review them before finalising the BOQ.`,
          link: `/admin/projects/${room.projectId}/rooms`,
          notifyAdmins: true,
          channels: { whatsapp: false, email: false },
        });
      }
    }
    return { count: ok.size };
  },
  { auth: "user" },
);
