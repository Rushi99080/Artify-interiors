import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { materialSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const PATCH = route<{ id: string }, "materials.manage">(
  async (req, { params, user, ip }) => {
    const body = await parseJson(req, materialSchema.partial());
    const material = await prisma.material.update({ where: { id: params.id }, data: { ...body, ...(body.supplierId !== undefined ? { supplierId: body.supplierId || null } : {}) } });
    await audit({ userId: user.id, action: "material.updated", entity: "Material", entityId: params.id, meta: body, ip });
    return { material };
  },
  { auth: "materials.manage" },
);

/** Deletes a material; if it is referenced by BOQs or room selections it is deactivated instead. */
export const DELETE = route<{ id: string }, "materials.delete">(
  async (_req, { params, user, ip }) => {
    const used = (await prisma.bOQItem.count({ where: { materialId: params.id } })) + (await prisma.roomMaterial.count({ where: { materialId: params.id } }));
    if (used > 0) {
      await prisma.material.update({ where: { id: params.id }, data: { isActive: false } });
      await audit({ userId: user.id, action: "material.deactivated", entity: "Material", entityId: params.id, ip });
      return { ok: true, deactivated: true, message: "This material is used in BOQs or room selections, so it was deactivated instead of deleted." };
    }
    await prisma.material.delete({ where: { id: params.id } });
    await audit({ userId: user.id, action: "material.deleted", entity: "Material", entityId: params.id, ip });
    return { ok: true, deactivated: false };
  },
  { auth: "materials.delete" },
);
