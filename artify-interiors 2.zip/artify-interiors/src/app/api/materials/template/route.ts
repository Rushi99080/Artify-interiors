import ExcelJS from "exceljs";
import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { IMPORT_COLUMNS } from "@/lib/materials/import";
import { DESIGN_STYLES, MATERIAL_CATEGORY_LABELS, PRICE_TIERS } from "@/lib/constants";

export const runtime = "nodejs";

/** Blank import template with an example row and a reference sheet of allowed values. */
export const GET = route(
  async () => {
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("Materials");
    ws.addRow([...IMPORT_COLUMNS]);
    ws.getRow(1).font = { bold: true };
    ws.addRow(["BWP Plywood 18mm", "Plywood", "Greenply", "PLY-101", "", "", "sqft", 125, "", "IS:710 marine grade", "IN_STOCK", "", "STANDARD", 4, 4, "MODERN, JAPANDI"]);
    ws.columns.forEach((c) => (c.width = 20));
    const ref = wb.addWorksheet("Allowed values");
    ref.addRow(["Category", "Tier", "Availability", "Styles"]);
    ref.getRow(1).font = { bold: true };
    const cats = Object.values(MATERIAL_CATEGORY_LABELS);
    const avail = ["IN_STOCK", "LIMITED", "ON_ORDER", "DISCONTINUED"];
    for (let i = 0; i < Math.max(cats.length, DESIGN_STYLES.length); i++) ref.addRow([cats[i] ?? "", PRICE_TIERS[i] ?? "", avail[i] ?? "", DESIGN_STYLES[i] ?? ""]);
    ref.columns.forEach((c) => (c.width = 20));
    const buffer = Buffer.from(await wb.xlsx.writeBuffer());
    return new NextResponse(new Uint8Array(buffer), {
      headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Content-Disposition": 'attachment; filename="artify-material-import-template.xlsx"' },
    });
  },
  { auth: "materials.manage" },
);
