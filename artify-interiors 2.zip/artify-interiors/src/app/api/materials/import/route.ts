import ExcelJS from "exceljs";
import Papa from "papaparse";
import { prisma } from "@/lib/db";
import { badRequest, route } from "@/lib/api";
import { parseMaterialRows } from "@/lib/materials/import";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

async function readRows(file: File): Promise<Record<string, unknown>[]> {
  const name = file.name.toLowerCase();
  if (name.endsWith(".csv")) {
    const text = await file.text();
    const res = Papa.parse<Record<string, unknown>>(text, { header: true, skipEmptyLines: true });
    return res.data;
  }
  if (name.endsWith(".xlsx")) {
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(new Uint8Array(await file.arrayBuffer()) as unknown as ArrayBuffer);
    const ws = wb.worksheets[0];
    if (!ws) return [];
    const headers: string[] = [];
    ws.getRow(1).eachCell({ includeEmpty: true }, (cell, col) => (headers[col] = String(cell.text ?? "").trim()));
    const rows: Record<string, unknown>[] = [];
    ws.eachRow((row, rowNo) => {
      if (rowNo === 1) return;
      const obj: Record<string, unknown> = {};
      headers.forEach((h, col) => {
        if (!h) return;
        const cell = row.getCell(col);
        const v = cell.value as unknown;
        obj[h] = typeof v === "object" && v !== null && "result" in (v as object) ? (v as { result: unknown }).result : typeof v === "number" ? v : cell.text;
      });
      rows.push(obj);
    });
    return rows;
  }
  throw badRequest("Upload a .csv or .xlsx file (use the template for the column names).");
}

/**
 * Bulk import. Form fields: file, mode = "preview" | "import".
 * Rows with a Product Code update the existing material with that code; others are created.
 */
export const POST = route(
  async (req, { user, ip }) => {
    const form = await req.formData().catch(() => null);
    const file = form?.get("file");
    if (!file || typeof file === "string") throw badRequest("Choose a CSV or Excel file.");
    if (file.size > 5 * 1024 * 1024) throw badRequest("The file is larger than 5 MB.");
    const mode = String(form?.get("mode") ?? "preview");
    const rows = await readRows(file);
    if (rows.length > 3000) throw badRequest("Import up to 3,000 rows at a time.");
    const { valid, errors } = parseMaterialRows(rows);

    if (mode !== "import") return { total: rows.length, valid: valid.length, errors, sample: valid.slice(0, 8) };

    const suppliers = await prisma.supplier.findMany({ select: { id: true, name: true } });
    const supplierId = (name: string | null) => (name ? (suppliers.find((s) => s.name.toLowerCase() === name.toLowerCase())?.id ?? null) : null);

    let created = 0;
    let updated = 0;
    for (const m of valid) {
      const { supplierName, ...data } = m;
      const payload = { ...data, supplierId: supplierId(supplierName), isActive: data.availability !== "DISCONTINUED" };
      if (m.productCode) {
        const existing = await prisma.material.findUnique({ where: { productCode: m.productCode } });
        if (existing) {
          await prisma.material.update({ where: { id: existing.id }, data: payload });
          updated++;
          continue;
        }
      }
      await prisma.material.create({ data: payload });
      created++;
    }
    await audit({ userId: user.id, action: "material.imported", entity: "Material", meta: { created, updated, skipped: errors.length, file: file.name }, ip });
    return { created, updated, skipped: errors.length, errors };
  },
  { auth: "materials.manage", rateLimit: { key: "material-import", limit: 20, windowSec: 3600 } },
);
