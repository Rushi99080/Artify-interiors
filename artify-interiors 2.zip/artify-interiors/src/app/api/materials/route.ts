import { prisma } from "@/lib/db";
import { parseJson, route } from "@/lib/api";
import { materialSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

/** Public catalogue (active materials). Filters: category, q, tier. */
export const GET = route(async (req, { user }) => {
  const sp = req.nextUrl.searchParams;
  const category = sp.get("category") ?? undefined;
  const q = sp.get("q")?.trim();
  const includeInactive = sp.get("all") === "1" && !!user && user.role !== "CUSTOMER";
  const materials = await prisma.material.findMany({
    where: {
      ...(includeInactive ? {} : { isActive: true }),
      ...(category ? { category: category as never } : {}),
      ...(sp.get("tier") ? { tier: sp.get("tier") as never } : {}),
      ...(q ? { OR: [{ name: { contains: q, mode: "insensitive" } }, { brand: { contains: q, mode: "insensitive" } }, { productCode: { contains: q, mode: "insensitive" } }, { color: { contains: q, mode: "insensitive" } }] } : {}),
    },
    orderBy: [{ category: "asc" }, { rate: "asc" }],
    include: { supplier: { select: { name: true } } },
    take: 500,
  });
  return { materials };
});

export const POST = route(
  async (req, { user, ip }) => {
    const body = await parseJson(req, materialSchema);
    const material = await prisma.material.create({ data: { ...body, supplierId: body.supplierId || null } });
    await audit({ userId: user.id, action: "material.created", entity: "Material", entityId: material.id, ip });
    return { material };
  },
  { auth: "materials.manage" },
);
