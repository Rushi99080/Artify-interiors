import ExcelJS from "exceljs";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { route } from "@/lib/api";
import { IMPORT_COLUMNS } from "@/lib/materials/import";
import { MATERIAL_CATEGORY_LABELS } from "@/lib/constants";

export const runtime = "nodejs";

/** Exports the full material library in the same column layout as the import template (round-trip friendly). */
export const GET = route(
  async () => {
    const materials = await prisma.material.findMany({ orderBy: [{ category: "asc" }, { name: "asc" }], include: { supplier: { select: { name: true } } } });
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("Materials");
    ws.addRow([...IMPORT_COLUMNS, "Active", "Last Updated"]);
    ws.getRow(1).font = { bold: true };
    for (const m of materials) {
      ws.addRow([m.name, MATERIAL_CATEGORY_LABELS[m.category], m.brand, m.productCode, m.finish, m.color, m.unit, m.rate, m.imageUrl, m.specifications, m.availability, m.supplier?.name, m.tier, m.durability, m.maintenance, m.styles.join(", "), m.isActive ? "Yes" : "No", m.updatedAt]);
    }
    ws.columns.forEach((c) => (c.width = 18));
    const buffer = Buffer.from(await wb.xlsx.writeBuffer());
    return new NextResponse(new Uint8Array(buffer), {
      headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Content-Disposition": `attachment; filename="artify-materials-${new Date().toISOString().slice(0, 10)}.xlsx"` },
    });
  },
  { auth: "materials.manage" },
);
