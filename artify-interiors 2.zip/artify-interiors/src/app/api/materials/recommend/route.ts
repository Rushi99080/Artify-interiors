import { z } from "zod";
import { parseJson, route } from "@/lib/api";
import { DESIGN_STYLES, MATERIAL_CATEGORIES, PRICE_TIERS } from "@/lib/constants";
import { recommendMaterials } from "@/lib/materials/recommend";
import { loadActiveMaterials } from "@/lib/services/materials";

const schema = z.object({
  style: z.enum(DESIGN_STYLES).nullable().optional(),
  tier: z.enum(PRICE_TIERS).nullable().optional(),
  durabilityWeight: z.number().min(0).max(1).optional(),
  maintenanceWeight: z.number().min(0).max(1).optional(),
  preferences: z.string().max(500).nullable().optional(),
  categories: z.array(z.enum(MATERIAL_CATEGORIES)).optional(),
  perCategory: z.number().int().min(1).max(10).optional(),
});

/** Recommendation engine: scores materials by style, budget level, durability, maintenance and stated preferences. */
export const POST = route(
  async (req) => {
    const body = await parseJson(req, schema);
    const materials = await loadActiveMaterials();
    const recs = recommendMaterials(materials, body, { perCategory: body.perCategory ?? 3, categories: body.categories });
    return { recommendations: recs };
  },
  { rateLimit: { key: "recommend", limit: 60, windowSec: 600 } },
);
