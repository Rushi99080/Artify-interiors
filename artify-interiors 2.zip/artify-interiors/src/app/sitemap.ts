import type { MetadataRoute } from "next";
import { prisma } from "@/lib/db";
import { ROOM_MODULES } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");
  const now = new Date();
  const pages = ["", "/designs", "/ai-designer", "/services", "/materials", "/cost-calculator", "/visualizer", "/about", "/contact"].map((p) => ({ url: `${base}${p}`, lastModified: now }));
  const services = ROOM_MODULES.filter((m) => m.showInServices).map((m) => ({ url: `${base}/services/${m.slug}`, lastModified: now }));
  let portfolio: MetadataRoute.Sitemap = [];
  try {
    const items = await prisma.portfolioProject.findMany({ where: { isPublished: true }, select: { slug: true, updatedAt: true } });
    portfolio = items.map((p) => ({ url: `${base}/designs/${p.slug}`, lastModified: p.updatedAt }));
  } catch {
    portfolio = [];
  }
  return [...pages, ...services, ...portfolio];
}
