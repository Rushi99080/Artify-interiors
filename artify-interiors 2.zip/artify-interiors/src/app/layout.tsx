import type { Metadata, Viewport } from "next";
import "./globals.css";
import { ToastProvider } from "@/components/ui/toast";

const appUrl = process.env.APP_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(appUrl),
  title: {
    default: "Artify Interiors — Luxury Interior Design Studio, Pune",
    template: "%s · Artify Interiors",
  },
  description:
    "Luxury interior design for homes, offices and commercial spaces. Generate AI design concepts, explore materials, get an itemised estimate and track your project with Artify Interiors.",
  keywords: ["interior designer Pune", "luxury interiors", "modular kitchen", "wardrobe design", "AI interior design", "home interiors cost calculator"],
  openGraph: {
    type: "website",
    siteName: "Artify Interiors",
    title: "Artify Interiors — Luxury Interior Design Studio",
    description: "Design concepts, transparent estimates and project tracking — from first sketch to handover.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#f4f2ee",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[200] focus:rounded focus:bg-charcoal focus:px-3 focus:py-2 focus:text-paper">
          Skip to content
        </a>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
