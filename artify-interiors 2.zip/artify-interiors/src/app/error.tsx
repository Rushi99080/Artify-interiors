"use client";

import Link from "next/link";
import { useEffect } from "react";
import { buttonClass } from "@/components/ui/button";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <main id="main" className="grid min-h-[70vh] place-items-center bg-plaster px-4 py-16">
      <div className="max-w-md text-center">
        <h1 className="text-3xl">Something went wrong on our side</h1>
        <p className="mt-3 text-smoke">The page could not be loaded. Try again — if it keeps happening, the error reference below helps us find the cause.</p>
        {error.digest ? <p className="mt-3 font-mono text-xs text-mist">Reference: {error.digest}</p> : null}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button type="button" onClick={reset} className={buttonClass("primary")}>
            Try again
          </button>
          <Link href="/" className={buttonClass("secondary")}>
            Go to the homepage
          </Link>
        </div>
      </div>
    </main>
  );
}
