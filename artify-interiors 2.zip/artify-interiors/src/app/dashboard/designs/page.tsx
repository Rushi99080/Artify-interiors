import Link from "next/link";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { toDesignView } from "@/lib/views";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { ButtonLink } from "@/components/ui/button";
import { DesignCard } from "@/components/designs/design-card";

export default async function SavedDesignsPage() {
  const user = await requireUser("/dashboard/designs");
  const designs = await prisma.generatedDesign.findMany({
    where: { project: { customerId: user.customerId ?? "__none__" }, OR: [{ isSaved: true }, { isFavorite: true }, { status: "APPROVED" }] },
    orderBy: [{ isFavorite: "desc" }, { updatedAt: "desc" }],
    include: { room: { select: { name: true } }, project: { select: { id: true, name: true } } },
  });
  const byProject = new Map<string, { name: string; items: typeof designs }>();
  for (const d of designs) {
    const g = byProject.get(d.project.id) ?? { name: d.project.name, items: [] };
    g.items.push(d);
    byProject.set(d.project.id, g);
  }
  return (
    <>
      <PageHeader title="Saved designs" description="Concepts you saved, favourited or approved, across all your projects." />
      {designs.length === 0 ? (
        <EmptyState title="No saved designs yet" description="Save concepts you like from a project's Designs tab and they will appear here." action={<ButtonLink href="/ai-designer">Generate concepts</ButtonLink>} />
      ) : (
        <div className="space-y-10">
          {[...byProject.entries()].map(([pid, g]) => (
            <section key={pid}>
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-2xl">{g.name}</h2>
                <Link href={`/dashboard/projects/${pid}/designs`} className="text-sm text-smoke hover:text-charcoal">
                  Compare in project
                </Link>
              </div>
              <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {g.items.map((d) => (
                  <DesignCard key={d.id} design={toDesignView(d, { hideAdminNotes: true })} mode="customer" />
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </>
  );
}
