import Link from "next/link";
import { requireUser } from "@/lib/auth/session";
import { isTeamRole } from "@/lib/auth/token";
import { Logo } from "@/components/brand/logo";
import { NotificationBell, UserMenu } from "@/components/app/header-widgets";
import { DashboardNav } from "@/components/app/dashboard-nav";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser("/dashboard");
  return (
    <div className="min-h-screen bg-plaster">
      <header className="sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur">
        <div className="container-page flex h-16 items-center justify-between gap-4">
          <Link href="/" aria-label="Artify Interiors — website">
            <Logo />
          </Link>
          <div className="flex items-center gap-1">
            {isTeamRole(user.role) ? (
              <Link href="/admin" className="mr-2 rounded-full bg-charcoal px-3 py-1.5 text-xs text-paper">
                Admin
              </Link>
            ) : null}
            <NotificationBell />
            <UserMenu name={user.name} email={user.email} profileHref="/dashboard/profile" />
          </div>
        </div>
        <DashboardNav />
      </header>
      <main id="main" className="container-page py-8 md:py-10">
        {children}
      </main>
    </div>
  );
}
