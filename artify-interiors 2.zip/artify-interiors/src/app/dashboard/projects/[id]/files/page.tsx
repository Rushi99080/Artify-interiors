import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth/session";
import { FilesPanel } from "@/components/projects/files-panel";

export default async function CustomerFilesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser();
  const [files, rooms] = await Promise.all([
    prisma.uploadedFile.findMany({ where: { projectId: id, category: { notIn: ["GENERATED"] } }, orderBy: { createdAt: "desc" }, include: { room: { select: { name: true } } } }),
    prisma.room.findMany({ where: { projectId: id }, orderBy: { sortOrder: "asc" }, select: { id: true, name: true } }),
  ]);
  return (
    <FilesPanel
      projectId={id}
      rooms={rooms}
      categories={["ROOM_PHOTO", "FLOOR_PLAN", "DRAWING_PDF", "CAD", "MEASUREMENT", "REFERENCE", "DOCUMENT"]}
      files={files.map((f) => ({ id: f.id, originalName: f.originalName, category: f.category, mimeType: f.mimeType, sizeBytes: f.sizeBytes, createdAt: f.createdAt.toISOString(), roomName: f.room?.name ?? null, canDelete: f.uploadedById === user.id }))}
    />
  );
}
