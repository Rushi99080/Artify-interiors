import { env } from "@/lib/env";
import { loadPaymentsData } from "@/lib/services/payment-views";
import { PaymentsPanel } from "@/components/payments/payments-panel";

export default async function CustomerPaymentsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const data = await loadPaymentsData(id);
  const r = env.razorpay();
  return <PaymentsPanel projectId={id} data={data} mode="customer" onlinePayments={!!(r.keyId && r.keySecret)} />;
}
