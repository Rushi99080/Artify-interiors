import { prisma } from "@/lib/db";
import { loadRoomsData } from "@/lib/services/project-views";
import { RoomsPanel } from "@/components/projects/rooms-panel";
import { Notice } from "@/components/ui/notice";

export default async function CustomerRoomsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const project = await prisma.project.findUniqueOrThrow({ where: { id }, select: { status: true, designStyle: true } });
  const { rooms, materials } = await loadRoomsData(id);
  const editable = ["DRAFT", "DESIGN", "QUOTATION"].includes(project.status);
  return (
    <div className="space-y-5">
      {!editable ? <Notice kind="info">Your project is active, so rooms are locked. Message the design team if something needs to change.</Notice> : null}
      <RoomsPanel projectId={id} rooms={rooms} materials={materials} editable={editable} projectStyle={project.designStyle} />
    </div>
  );
}
