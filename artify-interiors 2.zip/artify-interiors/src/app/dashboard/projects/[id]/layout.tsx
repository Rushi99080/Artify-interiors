import { notFound, redirect } from "next/navigation";
import { requireUser } from "@/lib/auth/session";
import { canAccessProject } from "@/lib/access";
import { prisma } from "@/lib/db";
import { PROJECT_STATUS_LABELS } from "@/lib/constants";
import { TabNav } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/ui/badge";
import Link from "next/link";

export default async function CustomerProjectLayout({ children, params }: { children: React.ReactNode; params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser(`/dashboard/projects/${id}`);
  if (user.role !== "CUSTOMER") redirect(`/admin/projects/${id}`);
  if (!(await canAccessProject(user, id))) notFound();
  const project = await prisma.project.findUnique({
    where: { id },
    select: { name: true, code: true, status: true, location: true, _count: { select: { designs: true, quotations: { where: { status: { not: "DRAFT" } } }, messages: true, files: true, rooms: true } } },
  });
  if (!project) notFound();
  const base = `/dashboard/projects/${id}`;
  return (
    <>
      <div className="mb-6">
        <Link href="/dashboard/projects" className="link-underline text-sm text-smoke">
          My projects
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="text-3xl md:text-[2.4rem]">{project.name}</h1>
          <StatusBadge status={project.status} label={PROJECT_STATUS_LABELS[project.status]} />
        </div>
        <p className="mt-1 text-sm text-smoke">
          {project.code} · {project.location}
        </p>
      </div>
      <TabNav
        tabs={[
          { href: base, label: "Overview", exact: true },
          { href: `${base}/rooms`, label: "Rooms & materials", count: project._count.rooms },
          { href: `${base}/files`, label: "Photos & files", count: project._count.files },
          { href: `${base}/designs`, label: "Designs", count: project._count.designs },
          { href: `${base}/boq`, label: "Estimate (BOQ)" },
          { href: `${base}/quotations`, label: "Quotations", count: project._count.quotations },
          { href: `${base}/payments`, label: "Payments" },
          { href: `${base}/messages`, label: "Messages" },
        ]}
      />
      {children}
    </>
  );
}
