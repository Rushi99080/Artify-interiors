import { Download } from "lucide-react";
import { prisma } from "@/lib/db";
import { totalsFor } from "@/lib/services/boq";
import { getSettings } from "@/lib/settings";
import { formatDate } from "@/lib/format";
import { BOQTable } from "@/components/boq/boq-table";
import { PreliminaryQuoteButton } from "@/components/boq/preliminary-quote-button";
import { EmptyState, Panel } from "@/components/ui/panel";
import { Notice } from "@/components/ui/notice";
import { StatusBadge } from "@/components/ui/badge";
import { buttonClass } from "@/components/ui/button";

export default async function CustomerBOQPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [project, boq, settings] = await Promise.all([
    prisma.project.findUniqueOrThrow({ where: { id }, select: { status: true } }),
    prisma.bOQ.findFirst({ where: { projectId: id }, orderBy: { version: "desc" }, include: { items: { orderBy: { sortOrder: "asc" } } } }),
    getSettings(),
  ]);
  const canGenerate = ["DRAFT", "DESIGN", "QUOTATION"].includes(project.status);

  if (!boq) {
    return (
      <EmptyState
        title="No estimate yet"
        description="We'll calculate an itemised Bill of Quantities from your room sizes and selected materials — in seconds."
        action={canGenerate ? <PreliminaryQuoteButton projectId={id} hasBoq={false} /> : undefined}
      />
    );
  }
  const totals = totalsFor(boq);
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl">{boq.title}</h2>
            <StatusBadge status={boq.status} />
          </div>
          <p className="text-xs text-smoke">
            Updated {formatDate(boq.updatedAt, true)}
            {boq.verifiedAt ? ` · verified by ${boq.verifiedByName} on ${formatDate(boq.verifiedAt)}` : ""}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <a href={`/api/boq/${boq.id}/export`} className={buttonClass("secondary")}>
            <Download className="size-4" /> Excel
          </a>
          {canGenerate ? <PreliminaryQuoteButton projectId={id} defaultTier={boq.tier} hasBoq /> : null}
        </div>
      </div>
      {boq.status === "PRELIMINARY" ? (
        <Notice kind="warning" title="Preliminary estimate">
          Quantities marked “estimate” are calculated from the room dimensions you entered. They will be verified against site measurements and approved drawings before your final quotation.
        </Notice>
      ) : null}
      <Panel padded={false} className="border-0 bg-transparent">
        <BOQTable items={boq.items} totals={totals} marginLabel={settings.boqDefaults.marginLabel} />
      </Panel>
    </div>
  );
}
