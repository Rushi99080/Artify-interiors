import { prisma } from "@/lib/db";
import { loadQuotationRows } from "@/lib/services/quotation-views";
import { QuotationsPanel } from "@/components/quotations/quotations-panel";
import { PreliminaryQuoteButton } from "@/components/boq/preliminary-quote-button";

export default async function CustomerQuotationsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [project, rows, boqCount] = await Promise.all([
    prisma.project.findUniqueOrThrow({ where: { id }, select: { status: true, customer: { select: { fullName: true } } } }),
    loadQuotationRows(id, { includeDrafts: false }),
    prisma.bOQ.count({ where: { projectId: id } }),
  ]);
  const canGenerate = ["DRAFT", "DESIGN", "QUOTATION"].includes(project.status) && !rows.some((r) => r.status === "APPROVED");
  return (
    <div className="space-y-5">
      {canGenerate && rows.length === 0 ? (
        <div className="rounded-[var(--radius-md)] border border-line bg-paper p-6">
          <p className="font-display text-2xl text-charcoal">Get an instant preliminary quotation</p>
          <p className="mt-1 text-sm text-smoke">Calculated from your rooms, dimensions and selected materials. Our team verifies it on site before the final quotation.</p>
          <div className="mt-4">
            <PreliminaryQuoteButton projectId={id} hasBoq={boqCount > 0} label="Generate preliminary quotation" />
          </div>
        </div>
      ) : null}
      <QuotationsPanel quotations={rows} mode="customer" projectActive={project.status === "ACTIVE"} customerName={project.customer.fullName} />
    </div>
  );
}
