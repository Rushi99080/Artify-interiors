import Link from "next/link";
import { Box, MessageSquare, Sparkles, FileText } from "lucide-react";
import { prisma } from "@/lib/db";
import { paymentSummary } from "@/lib/calc/payments";
import { formatINR, formatRelative } from "@/lib/format";
import { Panel, PanelHeader, StatCard } from "@/components/ui/panel";
import { ProjectBrief } from "@/components/projects/project-brief";
import { WorkflowTimeline } from "@/components/projects/workflow-timeline";

export default async function CustomerProjectOverview({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const project = await prisma.project.findUniqueOrThrow({
    where: { id },
    include: {
      milestones: { where: { customerVisible: true }, orderBy: { sortOrder: "asc" } },
      payments: { select: { amount: true, status: true } },
      messages: { where: { kind: { in: ["UPDATE", "SYSTEM"] } }, orderBy: { createdAt: "desc" }, take: 5 },
      quotations: { where: { status: { notIn: ["DRAFT", "SUPERSEDED"] } }, orderBy: { createdAt: "desc" }, take: 1 },
    },
  });
  const pay = paymentSummary(project.contractValue, project.payments);
  const base = `/dashboard/projects/${id}`;
  const actions = [
    { href: `${base}/designs`, icon: Sparkles, title: "Design concepts", text: "Generate, compare and approve AI concepts" },
    { href: `${base}/quotations`, icon: FileText, title: "Estimate & quotation", text: project.quotations[0] ? `Latest: ${project.quotations[0].number}` : "Get an instant preliminary quotation" },
    { href: `/visualizer?project=${id}`, icon: Box, title: "3D visualizer", text: "Try finishes and furniture layouts" },
    { href: `${base}/messages`, icon: MessageSquare, title: "Message the team", text: "Questions, changes, site visits" },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-6">
        <div className="grid gap-3 sm:grid-cols-4">
          {actions.map((a) => (
            <Link key={a.title} href={a.href} className="group rounded-[var(--radius-md)] border border-line bg-paper p-4 transition-colors hover:border-sand">
              <a.icon className="size-5 text-brass" />
              <p className="mt-2 text-sm font-semibold text-charcoal group-hover:text-brass-deep">{a.title}</p>
              <p className="mt-0.5 text-xs text-smoke">{a.text}</p>
            </Link>
          ))}
        </div>
        {project.contractValue ? (
          <div className="grid gap-3 sm:grid-cols-3">
            <StatCard label="Contract value" value={formatINR(pay.contract)} />
            <StatCard label="Paid" value={formatINR(pay.received)} tone="moss" hint={`${pay.percent}% of contract`} />
            <StatCard label="Balance" value={formatINR(pay.pending)} tone="amber" />
          </div>
        ) : null}
        <Panel>
          <PanelHeader title="Project brief" actions={<Link href={`${base}/rooms`} className="text-sm text-smoke hover:text-charcoal">Edit rooms</Link>} />
          <ProjectBrief p={project} />
        </Panel>
        <Panel>
          <PanelHeader title="Latest updates" />
          {project.messages.length ? (
            <ul className="space-y-3 text-sm">
              {project.messages.map((m) => (
                <li key={m.id} className="flex gap-3">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brass" />
                  <span>
                    <span className="text-ink">{m.body}</span>
                    <span className="block text-xs text-smoke">{formatRelative(m.createdAt)}</span>
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-smoke">Stage updates from the team will appear here.</p>
          )}
        </Panel>
      </div>
      <Panel>
        <PanelHeader title="Project progress" />
        <WorkflowTimeline milestones={project.milestones} compact />
      </Panel>
    </div>
  );
}
