import Link from "next/link";
import { FolderPlus } from "lucide-react";
import { requireUser } from "@/lib/auth/session";
import { customerDashboard } from "@/lib/services/dashboard";
import { formatDate, formatINRCompact } from "@/lib/format";
import { PROJECT_STATUS_LABELS } from "@/lib/constants";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { ButtonLink } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/badge";

export default async function MyProjectsPage() {
  const user = await requireUser("/dashboard/projects");
  const { projects } = await customerDashboard(user.customerId);
  return (
    <>
      <PageHeader
        title="My projects"
        actions={
          <ButtonLink href="/ai-designer">
            <FolderPlus className="size-4" /> New project
          </ButtonLink>
        }
      />
      {projects.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {projects.map((p) => (
            <Link key={p.id} href={`/dashboard/projects/${p.id}`} className="group rounded-[var(--radius-md)] border border-line bg-paper p-5 transition-colors hover:border-sand">
              <div className="flex items-start justify-between gap-3">
                <p className="font-display text-2xl leading-tight text-charcoal group-hover:text-brass-deep">{p.name}</p>
                <StatusBadge status={p.status} label={PROJECT_STATUS_LABELS[p.status]} />
              </div>
              <p className="mt-1 text-xs text-smoke">
                {p.code} · {p.location}
              </p>
              <dl className="mt-5 grid grid-cols-3 gap-3 text-sm">
                <div>
                  <dt className="text-xs text-smoke">Rooms</dt>
                  <dd className="text-charcoal">{p.rooms}</dd>
                </div>
                <div>
                  <dt className="text-xs text-smoke">Saved designs</dt>
                  <dd className="text-charcoal">{p.savedDesigns}</dd>
                </div>
                <div>
                  <dt className="text-xs text-smoke">Estimate</dt>
                  <dd className="text-charcoal">{p.estimate ? formatINRCompact(p.estimate) : "—"}</dd>
                </div>
              </dl>
              <div className="mt-5">
                <div className="flex justify-between text-xs text-smoke">
                  <span>{p.currentStage ?? "Completed"}</span>
                  <span>{p.progress.percent}%</span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-line-soft">
                  <div className="h-full bg-brass" style={{ width: `${p.progress.percent}%` }} />
                </div>
              </div>
              <p className="mt-4 text-xs text-mist">Updated {formatDate(p.updatedAt)}</p>
            </Link>
          ))}
        </div>
      ) : (
        <EmptyState title="No projects yet" description="Create your first project with the AI interior designer." action={<ButtonLink href="/ai-designer">Start your design</ButtonLink>} />
      )}
    </>
  );
}
