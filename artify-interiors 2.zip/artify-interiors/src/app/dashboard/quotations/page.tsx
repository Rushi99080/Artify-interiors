import Link from "next/link";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { QUOTATION_STATUS_LABELS } from "@/lib/constants";
import { formatDate, formatINR } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { Badge, StatusBadge } from "@/components/ui/badge";

export default async function CustomerQuotationsIndex() {
  const user = await requireUser("/dashboard/quotations");
  const quotations = await prisma.quotation.findMany({
    where: { project: { customerId: user.customerId ?? "__none__" }, status: { not: "DRAFT" } },
    orderBy: { createdAt: "desc" },
    include: { project: { select: { id: true, name: true } } },
  });
  return (
    <>
      <PageHeader title="Quotations" description="Every quotation and revision issued to you." />
      {quotations.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[720px]">
            <thead>
              <tr>
                <th>Quotation</th>
                <th>Project</th>
                <th>Issued</th>
                <th>Valid until</th>
                <th>Status</th>
                <th className="num">Total</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {quotations.map((q) => (
                <tr key={q.id}>
                  <td className="text-charcoal">
                    {q.number} {q.isPreliminary ? <Badge tone="amber" className="ml-1">Preliminary</Badge> : null}
                  </td>
                  <td>
                    <Link href={`/dashboard/projects/${q.project.id}/quotations`} className="underline decoration-sand underline-offset-4">
                      {q.project.name}
                    </Link>
                  </td>
                  <td>{formatDate(q.createdAt)}</td>
                  <td>{formatDate(q.validUntil)}</td>
                  <td>
                    <StatusBadge status={q.status} label={QUOTATION_STATUS_LABELS[q.status]} />
                  </td>
                  <td className="num text-charcoal">{formatINR(q.grandTotal)}</td>
                  <td className="text-right">
                    <a href={`/api/quotations/${q.id}/pdf`} target="_blank" rel="noopener noreferrer" className="text-sm underline decoration-sand underline-offset-4">
                      PDF
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No quotations yet" description="Generate an estimate from any project to receive a preliminary quotation." />
      )}
    </>
  );
}
