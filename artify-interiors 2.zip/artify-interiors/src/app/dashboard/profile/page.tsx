import { requireUser } from "@/lib/auth/session";
import { PageHeader } from "@/components/ui/panel";
import { ProfileForms } from "@/components/app/profile-forms";

export default async function ProfilePage() {
  const user = await requireUser("/dashboard/profile");
  return (
    <>
      <PageHeader title="Profile" />
      <ProfileForms name={user.name} phone={user.phone} email={user.email} />
    </>
  );
}
