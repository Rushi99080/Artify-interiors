import Link from "next/link";
import { FolderPlus } from "lucide-react";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { customerDashboard } from "@/lib/services/dashboard";
import { formatINRCompact, formatRelative } from "@/lib/format";
import { PROJECT_STATUS_LABELS } from "@/lib/constants";
import { EmptyState, PageHeader, Panel, PanelHeader, StatCard } from "@/components/ui/panel";
import { ButtonLink } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/badge";

export default async function DashboardHome() {
  const user = await requireUser("/dashboard");
  const { projects, stats } = await customerDashboard(user.customerId);
  const messages = user.customerId
    ? await prisma.message.findMany({ where: { project: { customerId: user.customerId }, fromTeam: true }, orderBy: { createdAt: "desc" }, take: 4, include: { project: { select: { id: true, name: true } } } })
    : [];

  return (
    <>
      <PageHeader
        title={`Hello, ${user.name.split(" ")[0]}`}
        description="Your designs, estimates and project progress in one place."
        actions={
          <ButtonLink href="/ai-designer">
            <FolderPlus className="size-4" /> New project
          </ButtonLink>
        }
      />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total projects" value={stats.total} />
        <StatCard label="Active projects" value={stats.active} tone="moss" />
        <StatCard label="Saved designs" value={stats.savedDesigns} tone="brass" />
        <StatCard label="Pending quotations" value={stats.pendingQuotes} tone="amber" />
        <StatCard label="Approved quotations" value={stats.approvedQuotes} tone="moss" />
        <StatCard label="Total estimated budget" value={formatINRCompact(stats.estimatedBudget)} hint="Contract value, latest quotation or estimate" />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Panel>
          <PanelHeader title="Your projects" actions={<Link href="/dashboard/projects" className="text-sm text-smoke hover:text-charcoal">View all</Link>} />
          {projects.length ? (
            <ul className="divide-y divide-line-soft">
              {projects.slice(0, 5).map((p) => (
                <li key={p.id}>
                  <Link href={`/dashboard/projects/${p.id}`} className="group flex flex-col gap-3 py-4 sm:flex-row sm:items-center">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-display text-xl text-charcoal group-hover:text-brass-deep">{p.name}</p>
                        <StatusBadge status={p.status} label={PROJECT_STATUS_LABELS[p.status]} />
                      </div>
                      <p className="mt-0.5 text-xs text-smoke">
                        {p.code} · {p.rooms} rooms · {p.location}
                      </p>
                    </div>
                    <div className="w-full sm:w-56">
                      <div className="flex justify-between text-xs text-smoke">
                        <span className="truncate">{p.currentStage ?? "Completed"}</span>
                        <span className="tabular-nums">{p.progress.percent}%</span>
                      </div>
                      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-line-soft">
                        <div className="h-full bg-brass" style={{ width: `${p.progress.percent}%` }} />
                      </div>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="No projects yet" description="Start with the AI designer — add your rooms, upload photos and get design concepts in minutes." action={<ButtonLink href="/ai-designer">Start your design</ButtonLink>} />
          )}
        </Panel>

        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Waiting for you" />
            <ul className="space-y-3 text-sm">
              {projects
                .filter((p) => p.latestQuote && (p.latestQuote.status === "SENT" || p.latestQuote.status === "CHANGES_REQUESTED"))
                .map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3">
                    <span>
                      <span className="text-charcoal">{p.latestQuote!.isPreliminary ? "Preliminary quotation" : "Quotation"} {p.latestQuote!.number}</span>
                      <span className="block text-xs text-smoke">{p.name} · {formatINRCompact(p.latestQuote!.grandTotal)}</span>
                    </span>
                    <ButtonLink href={`/dashboard/projects/${p.id}/quotations`} size="sm" variant="secondary">
                      Review
                    </ButtonLink>
                  </li>
                ))}
              {projects.filter((p) => p.status === "DRAFT" && p.savedDesigns === 0).map((p) => (
                <li key={`d-${p.id}`} className="flex items-center justify-between gap-3">
                  <span>
                    <span className="text-charcoal">Generate design concepts</span>
                    <span className="block text-xs text-smoke">{p.name}</span>
                  </span>
                  <ButtonLink href={`/dashboard/projects/${p.id}/designs`} size="sm" variant="secondary">
                    Open
                  </ButtonLink>
                </li>
              ))}
              {!projects.some((p) => (p.latestQuote && ["SENT", "CHANGES_REQUESTED"].includes(p.latestQuote.status)) || (p.status === "DRAFT" && p.savedDesigns === 0)) ? <li className="text-smoke">Nothing needs your attention right now.</li> : null}
            </ul>
          </Panel>
          <Panel>
            <PanelHeader title="Latest from the design team" />
            {messages.length ? (
              <ul className="space-y-3">
                {messages.map((m) => (
                  <li key={m.id} className="text-sm">
                    <Link href={`/dashboard/projects/${m.project.id}/messages`} className="block hover:text-charcoal">
                      <span className="line-clamp-2 text-ink">{m.body}</span>
                      <span className="text-xs text-smoke">
                        {m.project.name} · {formatRelative(m.createdAt)}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-smoke">Messages and updates from your designer will appear here.</p>
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
