import type { Metadata } from "next";
import { Suspense } from "react";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { AuthShell } from "@/components/auth/auth-shell";
import { RegisterForm } from "@/components/auth/auth-forms";

export const metadata: Metadata = { title: "Create an account" };

export default async function RegisterPage() {
  const user = await getCurrentUser();
  if (user) redirect(user.role === "CUSTOMER" ? "/dashboard" : "/admin");
  return (
    <AuthShell title="Start your project" subtitle="One account for your design concepts, estimates, quotations and project updates.">
      <Suspense>
        <RegisterForm />
      </Suspense>
    </AuthShell>
  );
}
