import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { ROOM_MODULES } from "@/lib/constants";
import { estimateRooms } from "@/lib/boq/engine";
import { getEstimatorData } from "@/lib/services/estimator";
import { formatINRCompact } from "@/lib/format";
import { ButtonLink } from "@/components/ui/button";

export const metadata: Metadata = { title: "Our Services", description: "Room-by-room interior design services — living rooms, bedrooms, modular kitchens, wardrobes, false ceilings, offices and commercial interiors." };
export const dynamic = "force-dynamic";

const PROCESS = [
  ["Consultation & measurement", "We visit, measure every wall and understand how you live."],
  ["Concepts & 3D", "AI-assisted concepts refined by a designer into 3D views."],
  ["Materials & BOQ", "Pick finishes from our library; every item is priced line by line."],
  ["Production", "Modules are made in our partner factories with quality checks."],
  ["Installation & handover", "Supervised installation, snag list closure and a deep clean."],
];

export default async function ServicesPage() {
  const data = await getEstimatorData();
  const modules = ROOM_MODULES;
  return (
    <div className="container-page py-14 md:py-20">
      <header className="grid gap-6 lg:grid-cols-[1.2fr_1fr] lg:items-end">
        <h1 className="text-5xl md:text-6xl">Interior design, room by room</h1>
        <p className="text-smoke">Choose a room to see what is included, adjust its dimensions and finishes, and get an instant estimate — or bring them all together in one project.</p>
      </header>

      <div className="mt-12 grid gap-px overflow-hidden rounded-[var(--radius-md)] border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
        {modules.map((m) => {
          const est = estimateRooms([{ name: m.label, type: m.type, ...m.defaults }], "STANDARD", { rateCard: data.rateCard, ctx: { byTier: data.byTier }, charges: data.charges, includeExtras: false });
          return (
            <Link key={m.type} href={`/services/${m.slug}`} className="group flex flex-col justify-between bg-paper p-6 transition-colors hover:bg-white md:p-7">
              <div>
                <div className="flex items-start justify-between gap-3">
                  <h2 className="text-[1.9rem] transition-colors group-hover:text-brass-deep">{m.label}</h2>
                  <ArrowUpRight className="mt-2 size-5 text-mist transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brass-deep" />
                </div>
                <p className="mt-2 text-sm text-smoke">{m.short}</p>
                <ul className="mt-5 space-y-1.5 text-sm text-ink">
                  {m.includes.slice(0, 4).map((i) => (
                    <li key={i} className="flex gap-2">
                      <span className="mt-2 h-px w-3 shrink-0 bg-brass" aria-hidden />
                      {i}
                    </li>
                  ))}
                </ul>
              </div>
              <p className="mt-6 border-t border-line-soft pt-4 text-sm text-smoke">
                Typical {m.defaults.lengthFt}′ × {m.defaults.widthFt}′ at Signature finish: <span className="text-charcoal tabular-nums">{formatINRCompact(est.totals.grandTotal)}</span>
              </p>
            </Link>
          );
        })}
      </div>

      <section className="mt-24 grid gap-10 lg:grid-cols-[1fr_1.6fr]">
        <div>
          <h2 className="text-4xl md:text-5xl">How we deliver</h2>
          <p className="mt-3 text-smoke">One accountable team from the first visit to the final handover, with every stage visible in your dashboard.</p>
          <ButtonLink href="/ai-designer" className="mt-6">
            Start your design
          </ButtonLink>
        </div>
        <ol className="border-t border-line">
          {PROCESS.map(([t, d], i) => (
            <li key={t} className="grid grid-cols-[3rem_1fr] gap-4 border-b border-line py-5">
              <span className="font-display text-3xl text-brass">{i + 1}</span>
              <div>
                <p className="font-semibold text-charcoal">{t}</p>
                <p className="mt-1 text-sm text-smoke">{d}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
