import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { ROOM_MODULE_BY_SLUG, ROOM_MODULES, type MaterialCategoryKey } from "@/lib/constants";
import { getEstimatorData } from "@/lib/services/estimator";
import { RoomModuleTool } from "@/components/services/room-module-tool";
import { SmartImage } from "@/components/ui/smart-image";

export const dynamic = "force-dynamic";

export function generateStaticParams() {
  return ROOM_MODULES.map((m) => ({ slug: m.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const m = ROOM_MODULE_BY_SLUG[slug];
  return m ? { title: `${m.label} interior design`, description: m.description } : {};
}

export default async function RoomModulePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const module = ROOM_MODULE_BY_SLUG[slug];
  if (!module) notFound();
  const [data, materials, example] = await Promise.all([
    getEstimatorData(),
    prisma.material.findMany({
      where: { isActive: true, category: { in: module.materialCategories as MaterialCategoryKey[] } },
      orderBy: [{ category: "asc" }, { rate: "asc" }],
      select: { id: true, name: true, brand: true, category: true, rate: true, unit: true, finish: true, tier: true },
    }),
    prisma.portfolioProject.findFirst({ where: { isPublished: true, roomType: module.type } }),
  ]);

  return (
    <div className="pb-6">
      <section className="container-page grid gap-10 py-12 md:py-16 lg:grid-cols-[1.1fr_1fr] lg:items-center">
        <div>
          <Link href="/services" className="link-underline text-sm text-smoke">
            All services
          </Link>
          <h1 className="mt-4 text-5xl md:text-6xl">{module.label}</h1>
          <p className="prose-body mt-4 text-smoke">{module.description}</p>
          <ul className="mt-6 grid gap-2 text-sm text-ink sm:grid-cols-2">
            {module.includes.map((i) => (
              <li key={i} className="flex gap-2">
                <span className="mt-2 h-px w-3 shrink-0 bg-brass" aria-hidden />
                {i}
              </li>
            ))}
          </ul>
        </div>
        <SmartImage src={example?.coverImageUrl} alt={example?.title ?? module.label} className="aspect-[4/3]" fallbackLabel={module.label} />
      </section>
      <section className="container-page">
        <RoomModuleTool module={module} data={data} materials={materials} />
      </section>
    </div>
  );
}
