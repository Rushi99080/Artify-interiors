import type { Metadata } from "next";
import Link from "next/link";
import { Camera, Layers, Ruler, Sparkles } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { aiConfig } from "@/lib/ai";
import { prisma } from "@/lib/db";
import { parsePrefill } from "@/lib/prefill";
import { ProjectWizard } from "@/components/designs/project-wizard";
import { ButtonLink } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/badge";

export const metadata: Metadata = { title: "AI Interior Designer", description: "Upload a photo of your room and get AI interior design concepts with materials, furniture layout, lighting and an estimated budget." };
export const dynamic = "force-dynamic";

const FEATURES = [
  { icon: Camera, title: "Reads your room", text: "Light, openings, proportions and existing finishes from your photos." },
  { icon: Layers, title: "Real materials", text: "Concepts pick from our library, so every suggestion has a brand and a rate." },
  { icon: Ruler, title: "Sized to your space", text: "Furniture layouts and budgets use your actual room dimensions." },
  { icon: Sparkles, title: "Several directions", text: "Compare concepts side by side, save favourites and ask for changes." },
];

export default async function AIDesignerPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  const prefill = parsePrefill(sp);
  const qs = new URLSearchParams(Object.entries(sp).flatMap(([k, v]) => (typeof v === "string" ? [[k, v]] : []))).toString();
  const next = `/ai-designer${qs ? `?${qs}` : ""}`;

  if (!user) {
    return (
      <div className="container-page py-14 md:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center">
          <div>
            <h1 className="text-5xl md:text-6xl">The AI interior designer</h1>
            <p className="prose-body mt-5 text-smoke">Describe your home, upload a photo of each room and receive complete design concepts — palette, materials, furniture layout, lighting, flooring and an estimated budget — with a visualization of the finished space. Our designers then refine your favourite into drawings and a final quotation.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ButtonLink href={`/register?next=${encodeURIComponent(next)}`} size="lg">
                Create a free account to start
              </ButtonLink>
              <ButtonLink href={`/login?next=${encodeURIComponent(next)}`} size="lg" variant="secondary">
                I have an account
              </ButtonLink>
            </div>
          </div>
          <ul className="grid gap-px overflow-hidden rounded-[var(--radius-md)] border border-line bg-line sm:grid-cols-2">
            {FEATURES.map((f) => (
              <li key={f.title} className="bg-paper p-6">
                <f.icon className="size-5 text-brass" />
                <p className="mt-3 font-semibold text-charcoal">{f.title}</p>
                <p className="mt-1 text-sm text-smoke">{f.text}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  }

  const recent = user.customerId
    ? await prisma.project.findMany({ where: { customerId: user.customerId }, orderBy: { updatedAt: "desc" }, take: 3, select: { id: true, name: true, code: true, status: true } })
    : [];

  return (
    <div className="container-page py-12 md:py-16">
      <header className="mb-10 flex flex-wrap items-end justify-between gap-6">
        <div>
          <h1 className="text-5xl md:text-6xl">Start your design</h1>
          <p className="mt-3 max-w-xl text-smoke">Three steps: tell us about the space, add photos, then generate concepts. Your project is saved after step one.</p>
        </div>
        {recent.length ? (
          <div className="text-sm">
            <p className="text-smoke">Or continue a project</p>
            <ul className="mt-1 space-y-1">
              {recent.map((p) => (
                <li key={p.id} className="flex items-center gap-2">
                  <Link href={`/dashboard/projects/${p.id}/designs`} className="link-underline text-charcoal">
                    {p.name}
                  </Link>
                  <StatusBadge status={p.status} />
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </header>
      <ProjectWizard user={{ name: user.name, email: user.email, phone: user.phone }} aiStatus={aiConfig()} prefill={prefill} />
    </div>
  );
}
