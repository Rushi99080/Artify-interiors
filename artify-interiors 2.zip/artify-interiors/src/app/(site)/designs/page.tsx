import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db";
import { DESIGN_STYLES, ROOM_LABELS, STYLE_INFO, type DesignStyleKey, type RoomTypeKey } from "@/lib/constants";
import { cn } from "@/lib/format";
import { SmartImage } from "@/components/ui/smart-image";
import { Badge } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/panel";

export const metadata: Metadata = { title: "Explore Designs", description: "Interior design projects by Artify Interiors — living rooms, bedrooms, kitchens, offices and more, by style." };
export const dynamic = "force-dynamic";

export default async function DesignsPage({ searchParams }: { searchParams: Promise<{ room?: string; style?: string }> }) {
  const sp = await searchParams;
  const room = sp.room && sp.room in ROOM_LABELS ? (sp.room as RoomTypeKey) : undefined;
  const style = sp.style && (DESIGN_STYLES as readonly string[]).includes(sp.style) ? (sp.style as DesignStyleKey) : undefined;
  const [projects, roomsInUse] = await Promise.all([
    prisma.portfolioProject.findMany({ where: { isPublished: true, ...(room ? { roomType: room } : {}), ...(style ? { style } : {}) }, orderBy: [{ isFeatured: "desc" }, { sortOrder: "asc" }] }),
    prisma.portfolioProject.groupBy({ by: ["roomType"], where: { isPublished: true }, _count: true }),
  ]);
  const roomOptions = roomsInUse.map((r) => r.roomType).filter(Boolean) as RoomTypeKey[];
  const link = (next: { room?: string; style?: string }) => {
    const q = new URLSearchParams();
    const r = "room" in next ? next.room : room;
    const s = "style" in next ? next.style : style;
    if (r) q.set("room", r);
    if (s) q.set("style", s);
    const str = q.toString();
    return `/designs${str ? `?${str}` : ""}`;
  };

  return (
    <div className="container-page py-14 md:py-20">
      <header className="max-w-2xl">
        <h1 className="text-5xl md:text-6xl">Explore designs</h1>
        <p className="mt-4 text-smoke">Browse spaces by room and style. When something speaks to you, start a project and our AI designer will build concepts around your own room.</p>
      </header>

      <div className="mt-10 flex flex-col gap-4 border-y border-line py-4">
        <FilterRow label="Room">
          <Chip href={link({ room: undefined })} active={!room}>
            All rooms
          </Chip>
          {roomOptions.map((r) => (
            <Chip key={r} href={link({ room: r })} active={room === r}>
              {ROOM_LABELS[r]}
            </Chip>
          ))}
        </FilterRow>
        <FilterRow label="Style">
          <Chip href={link({ style: undefined })} active={!style}>
            All styles
          </Chip>
          {DESIGN_STYLES.map((s) => (
            <Chip key={s} href={link({ style: s })} active={style === s}>
              {STYLE_INFO[s].label}
            </Chip>
          ))}
        </FilterRow>
      </div>

      {projects.length ? (
        <div className="mt-10 grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Link key={p.id} href={`/designs/${p.slug}`} className="group">
              <SmartImage src={p.coverImageUrl} alt={p.title} className="aspect-[4/5]" imgClassName="transition-transform duration-700 group-hover:scale-[1.03]" />
              <div className="mt-4 flex items-start justify-between gap-3">
                <div>
                  <p className="font-display text-2xl text-charcoal">{p.title}</p>
                  <p className="mt-0.5 text-sm text-smoke">{[p.roomType ? ROOM_LABELS[p.roomType as RoomTypeKey] : null, p.style ? STYLE_INFO[p.style as DesignStyleKey].label : null, p.location].filter(Boolean).join(", ")}</p>
                </div>
                {p.isSample ? <Badge>Sample</Badge> : null}
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="mt-10">
          <EmptyState title="No projects match these filters" description="Try another room or style." action={<ButtonLink href="/designs" variant="secondary">Clear filters</ButtonLink>} />
        </div>
      )}

      <section className="mt-24">
        <h2 className="text-4xl md:text-5xl">Find your style</h2>
        <p className="mt-3 max-w-xl text-smoke">Nine directions our designers work in. Pick one in the AI designer and every concept, material and estimate follows it.</p>
        <div className="mt-10 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {DESIGN_STYLES.map((s) => (
            <div key={s}>
              <div className="flex h-16 overflow-hidden rounded-[3px]">
                {STYLE_INFO[s].palette.map((c) => (
                  <span key={c} className="flex-1" style={{ background: c }} />
                ))}
              </div>
              <p className="mt-4 font-display text-2xl text-charcoal">{STYLE_INFO[s].label}</p>
              <p className="mt-1 text-sm text-smoke">{STYLE_INFO[s].description}</p>
              <Link href={link({ style: s })} className="link-underline mt-2 inline-block text-sm text-charcoal">
                See {STYLE_INFO[s].label.toLowerCase()} projects
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function FilterRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2 md:flex-row md:items-center">
      <span className="w-16 shrink-0 text-sm text-smoke">{label}</span>
      <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 md:flex-wrap md:pb-0">{children}</div>
    </div>
  );
}

function Chip({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link href={href} scroll={false} className={cn("shrink-0 rounded-full border px-3.5 py-1.5 text-sm transition-colors", active ? "border-charcoal bg-charcoal text-paper" : "border-line bg-paper text-ink hover:border-sand")}>
      {children}
    </Link>
  );
}
