import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { ROOM_LABELS, ROOM_MODULE_BY_TYPE, STYLE_INFO, type DesignStyleKey, type RoomTypeKey } from "@/lib/constants";
import { SmartImage } from "@/components/ui/smart-image";
import { Badge } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const p = await prisma.portfolioProject.findUnique({ where: { slug } });
  return p ? { title: p.title, description: p.description.slice(0, 160), openGraph: { images: [p.coverImageUrl] } } : { title: "Design not found" };
}

export default async function DesignDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = await prisma.portfolioProject.findUnique({ where: { slug } });
  if (!p || !p.isPublished) notFound();
  const related = await prisma.portfolioProject.findMany({ where: { isPublished: true, id: { not: p.id }, OR: [{ style: p.style }, { roomType: p.roomType }] }, take: 3 });
  const module = p.roomType ? ROOM_MODULE_BY_TYPE[p.roomType as RoomTypeKey] : null;
  const gallery = p.images.filter((i) => i !== p.coverImageUrl);

  return (
    <article className="pb-10">
      <div className="container-page pt-10">
        <Link href="/designs" className="link-underline text-sm text-smoke">
          All designs
        </Link>
      </div>
      <header className="container-page mt-6 grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-end">
        <h1 className="text-5xl md:text-7xl">{p.title}</h1>
        <dl className="grid grid-cols-2 gap-4 border-t border-line pt-4 text-sm">
          {p.roomType ? (
            <div>
              <dt className="text-smoke">Room</dt>
              <dd className="text-charcoal">{ROOM_LABELS[p.roomType as RoomTypeKey]}</dd>
            </div>
          ) : null}
          {p.style ? (
            <div>
              <dt className="text-smoke">Style</dt>
              <dd className="text-charcoal">{STYLE_INFO[p.style as DesignStyleKey].label}</dd>
            </div>
          ) : null}
          {p.location ? (
            <div>
              <dt className="text-smoke">Location</dt>
              <dd className="text-charcoal">{p.location}</dd>
            </div>
          ) : null}
          {p.areaSqft ? (
            <div>
              <dt className="text-smoke">Area</dt>
              <dd className="text-charcoal">{p.areaSqft} sqft</dd>
            </div>
          ) : null}
        </dl>
      </header>
      <div className="container-page mt-10">
        <SmartImage src={p.coverImageUrl} alt={p.title} eager className="aspect-[16/9] w-full" />
        {p.isSample ? <p className="mt-3 text-xs text-smoke"><Badge>Sample</Badge> This is sample content. Replace it with your own project in Admin → Website Content.</p> : null}
      </div>
      <div className="container-page mt-12 grid gap-10 lg:grid-cols-[1.4fr_1fr]">
        <div className="prose-body text-[1.05rem] whitespace-pre-line">{p.description}</div>
        <aside className="rounded-[var(--radius-md)] border border-line bg-paper p-6">
          <p className="font-display text-2xl text-charcoal">Want something like this?</p>
          <p className="mt-2 text-sm text-smoke">Start a project with your room&apos;s photos and dimensions. We&apos;ll generate concepts in this style and an itemised estimate.</p>
          <div className="mt-5 flex flex-wrap gap-2">
            <ButtonLink href="/ai-designer">Start your design</ButtonLink>
            {module ? (
              <ButtonLink href={`/services/${module.slug}`} variant="secondary">
                {module.label} costs
              </ButtonLink>
            ) : null}
          </div>
        </aside>
      </div>
      {gallery.length ? (
        <div className="container-page mt-12 grid gap-5 sm:grid-cols-2">
          {gallery.map((g, i) => (
            <SmartImage key={i} src={g} alt={`${p.title} — view ${i + 2}`} className="aspect-[4/3]" />
          ))}
        </div>
      ) : null}
      {related.length ? (
        <section className="container-page mt-20">
          <h2 className="text-3xl md:text-4xl">Related spaces</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-3">
            {related.map((r) => (
              <Link key={r.id} href={`/designs/${r.slug}`} className="group">
                <SmartImage src={r.coverImageUrl} alt={r.title} className="aspect-[4/3]" imgClassName="transition-transform duration-700 group-hover:scale-[1.03]" />
                <p className="mt-3 font-display text-xl text-charcoal">{r.title}</p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </article>
  );
}
