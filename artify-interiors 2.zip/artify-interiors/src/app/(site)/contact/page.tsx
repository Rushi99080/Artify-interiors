import type { Metadata } from "next";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { getSettings } from "@/lib/settings";
import { LeadForm } from "@/components/site/lead-form";

export const metadata: Metadata = { title: "Contact", description: "Book a consultation with Artify Interiors — at the studio, on video or at your site." };
export const dynamic = "force-dynamic";

export default async function ContactPage() {
  const { company } = await getSettings();
  const wa = company.whatsappNumber.replace(/\D/g, "");
  return (
    <div className="container-page grid gap-12 py-14 md:py-20 lg:grid-cols-[1fr_1.4fr]">
      <div>
        <h1 className="text-5xl md:text-6xl">Book a consultation</h1>
        <p className="mt-4 max-w-md text-smoke">Tell us about your space. A designer will call within one working day to understand your brief and plan a site visit or studio meeting.</p>
        <ul className="mt-10 space-y-5 text-ink">
          <li className="flex gap-3">
            <MapPin className="mt-0.5 size-5 shrink-0 text-brass" />
            <span>{company.address}</span>
          </li>
          {company.phone ? (
            <li className="flex gap-3">
              <Phone className="mt-0.5 size-5 shrink-0 text-brass" />
              <a href={`tel:${company.phone.replace(/\s/g, "")}`} className="link-underline">
                {company.phone}
              </a>
            </li>
          ) : null}
          {company.email ? (
            <li className="flex gap-3">
              <Mail className="mt-0.5 size-5 shrink-0 text-brass" />
              <a href={`mailto:${company.email}`} className="link-underline">
                {company.email}
              </a>
            </li>
          ) : null}
          {wa ? (
            <li className="flex gap-3">
              <MessageCircle className="mt-0.5 size-5 shrink-0 text-brass" />
              <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer" className="link-underline">
                Chat on WhatsApp
              </a>
            </li>
          ) : null}
        </ul>
      </div>
      <div className="rounded-[var(--radius-md)] border border-line bg-paper p-6 md:p-10">
        <LeadForm />
      </div>
    </div>
  );
}
