import type { Metadata } from "next";
import { getEstimatorData } from "@/lib/services/estimator";
import { CostCalculator } from "@/components/estimate/cost-calculator";

export const metadata: Metadata = { title: "Interior Cost Calculator", description: "Estimate the cost of your home interiors room by room — materials, labour, wastage and GST included." };
export const dynamic = "force-dynamic";

export default async function CostCalculatorPage() {
  const data = await getEstimatorData();
  return (
    <div className="container-page py-14 md:py-20">
      <header className="max-w-2xl">
        <h1 className="text-5xl md:text-6xl">Cost calculator</h1>
        <p className="mt-4 text-smoke">Start from a typical layout, then rename rooms, change sizes or add spaces. Estimates use our current rate card and the same BOQ formulas as a real quotation.</p>
      </header>
      <div className="mt-10">
        <CostCalculator data={data} />
      </div>
    </div>
  );
}
