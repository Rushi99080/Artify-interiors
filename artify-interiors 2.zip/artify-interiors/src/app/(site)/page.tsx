import Link from "next/link";
import { ArrowUpRight, Star } from "lucide-react";
import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { getEstimatorData } from "@/lib/services/estimator";
import { estimateRooms } from "@/lib/boq/engine";
import { MATERIAL_CATEGORY_LABELS, ROOM_LABELS, ROOM_MODULES, STYLE_INFO, type DesignStyleKey, type MaterialCategoryKey, type RoomTypeKey } from "@/lib/constants";
import { formatINR, formatINRCompact } from "@/lib/format";
import { ButtonLink } from "@/components/ui/button";
import { SmartImage } from "@/components/ui/smart-image";
import { Badge } from "@/components/ui/badge";
import { EstimatePreview } from "@/components/home/estimate-preview";
import { LeadForm } from "@/components/site/lead-form";
import { MaterialSwatch } from "@/components/materials/material-swatch";

export const dynamic = "force-dynamic";

const STEPS = [
  { title: "Tell us about your space", text: "Create a project with your rooms, budget, style and timeline. It takes about three minutes." },
  { title: "Upload photos and plans", text: "Room photographs, floor plans or drawings help the AI and our designers understand the site." },
  { title: "Compare design concepts", text: "Get several AI concepts per room — palette, materials, furniture layout and a visualization — and save the ones you like." },
  { title: "Review your estimate", text: "An itemised BOQ is generated from your room sizes and chosen materials, then turned into a branded quotation." },
  { title: "Approve and track", text: "Approve online and follow every stage — production, delivery, execution — through to handover." },
];

export default async function HomePage() {
  const settings = await getSettings();
  const [featured, testimonials, materials, estimator] = await Promise.all([
    prisma.portfolioProject.findMany({ where: { isPublished: true }, orderBy: [{ isFeatured: "desc" }, { sortOrder: "asc" }], take: 3 }).catch(() => []),
    prisma.testimonial.findMany({ where: { isPublished: true }, orderBy: { sortOrder: "asc" }, take: 3 }).catch(() => []),
    prisma.material.findMany({ where: { isActive: true, tier: { in: ["PREMIUM", "LUXURY"] }, category: { in: ["VENEER", "QUARTZ", "MARBLE", "ACRYLIC", "FLOORING", "TILES"] } }, orderBy: { updatedAt: "desc" }, take: 6, include: { supplier: false } }).catch(() => []),
    getEstimatorData(),
  ]);

  const hero = settings.hero;
  const modules = ROOM_MODULES.filter((m) => m.showInServices);

  return (
    <>
      {/* ── Hero ── */}
      <section className="relative">
        <div className="grid min-h-[calc(100svh-72px)] lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
          <div className="order-2 flex flex-col justify-center px-5 py-12 md:px-10 lg:order-1 lg:py-16 lg:pl-[max(2rem,calc((100vw-1240px)/2+2rem))] lg:pr-12">
            <p className="hero-line text-sm text-brass-deep" style={{ animationDelay: "0.05s" }}>
              {hero.eyebrow}
            </p>
            <h1 className="mt-5 text-[clamp(3rem,5.6vw,5.6rem)] font-normal leading-[0.98] tracking-[-0.02em]">
              {hero.headlineLines.map((line, i) => (
                <span key={i} className="hero-line" style={{ animationDelay: `${0.15 + i * 0.14}s` }}>
                  {line}
                </span>
              ))}
            </h1>
            <span className="hero-draw mt-8 block h-px w-40 bg-brass" aria-hidden />
            <p className="hero-line mt-8 max-w-md text-[1.02rem] leading-relaxed text-smoke" style={{ animationDelay: "0.7s" }}>
              {hero.subtext}
            </p>
            <div className="hero-line mt-9 flex flex-wrap gap-3" style={{ animationDelay: "0.85s" }}>
              <ButtonLink href="/ai-designer" size="lg">
                Start your design
              </ButtonLink>
              <ButtonLink href="/designs" size="lg" variant="secondary">
                Explore our projects
              </ButtonLink>
            </div>
            <p className="hero-line mt-6 text-sm text-smoke" style={{ animationDelay: "1s" }}>
              Or{" "}
              <Link href="/cost-calculator" className="link-underline text-charcoal">
                estimate your cost in two minutes
              </Link>
              .
            </p>
          </div>
          <div className="relative order-1 min-h-[52svh] lg:order-2">
            <SmartImage src={hero.imageUrl} alt="Interior designed by Artify" eager className="absolute inset-0" imgClassName="fade-in" fallbackLabel="Artify Interiors" />
          </div>
        </div>
      </section>

      {/* ── Explore our projects ── */}
      <section className="container-page pt-24 md:pt-32">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-4xl md:text-5xl">Recent spaces</h2>
            <p className="mt-3 max-w-lg text-smoke">Homes, kitchens and workplaces from the studio. Every one started as a brief like yours.</p>
          </div>
          <Link href="/designs" className="link-underline text-sm text-charcoal">
            View all designs
          </Link>
        </div>
        {featured.length ? (
          <div className="mt-10 grid gap-5 md:grid-cols-12">
            {featured.map((p, i) => (
              <Link key={p.id} href={`/designs/${p.slug}`} className={i === 0 ? "group md:col-span-7 md:row-span-2" : "group md:col-span-5"}>
                <SmartImage src={p.coverImageUrl} alt={p.title} className={i === 0 ? "aspect-[4/5] md:aspect-auto md:h-full md:min-h-[560px]" : "aspect-[16/10]"} imgClassName="transition-transform duration-700 group-hover:scale-[1.03]" />
                <div className="mt-3 flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-2xl text-charcoal">{p.title}</p>
                    <p className="text-sm text-smoke">
                      {[p.roomType ? ROOM_LABELS[p.roomType as RoomTypeKey] : null, p.style ? STYLE_INFO[p.style as DesignStyleKey].label : null, p.location].filter(Boolean).join(", ")}
                    </p>
                  </div>
                  {p.isSample ? <Badge>Sample</Badge> : null}
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <p className="mt-8 text-smoke">Portfolio projects added in Admin → Website Content appear here.</p>
        )}
      </section>

      {/* ── Categories (room modules) ── */}
      <section className="container-page pt-24 md:pt-32">
        <div className="grid gap-10 lg:grid-cols-[1fr_2fr]">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <h2 className="text-4xl md:text-5xl">Every room, planned to the inch</h2>
            <p className="mt-4 max-w-sm text-smoke">Each module starts from your room&apos;s real dimensions. Prices shown are for a typical room at our Essential finish level.</p>
            <ButtonLink href="/services" variant="secondary" className="mt-6">
              All services
            </ButtonLink>
          </div>
          <ul className="border-t border-line">
            {modules.map((m) => {
              const est = estimateRooms([{ name: m.label, type: m.type, ...m.defaults }], "ECONOMY", { rateCard: estimator.rateCard, ctx: { byTier: estimator.byTier }, charges: estimator.charges, includeExtras: false });
              return (
                <li key={m.type}>
                  <Link href={`/services/${m.slug}`} className="group grid grid-cols-[1fr_auto] items-center gap-x-6 gap-y-1 border-b border-line py-5 md:grid-cols-[1.1fr_1.4fr_auto]">
                    <span className="font-display text-[1.75rem] leading-tight text-charcoal transition-colors group-hover:text-brass-deep">{m.label}</span>
                    <span className="order-3 col-span-2 text-sm text-smoke md:order-none md:col-span-1">
                      {m.short}
                      <span className="mt-1.5 block text-xs tabular-nums text-mist">
                        Typical {m.defaults.lengthFt}′ × {m.defaults.widthFt}′{m.type === "WARDROBE" || m.type === "TV_UNIT" ? ` × ${m.defaults.heightFt}′ H` : ""}
                      </span>
                    </span>
                    <span className="flex items-center gap-3 text-right">
                      <span className="text-sm tabular-nums text-ink">from {formatINRCompact(est.totals.grandTotal)}</span>
                      <ArrowUpRight className="size-4 text-mist transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brass-deep" />
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      {/* ── How it works ── */}
      <section className="mt-24 bg-travertine/55 py-20 md:mt-32 md:py-28">
        <div className="container-page">
          <h2 className="max-w-xl text-4xl md:text-5xl">From first idea to handover</h2>
          <ol className="mt-12 grid gap-8 md:grid-cols-5 md:gap-6">
            {STEPS.map((s, i) => (
              <li key={s.title} className="relative border-t border-charcoal/30 pt-5">
                <span className="font-display text-4xl text-brass">{i + 1}</span>
                <p className="mt-3 font-semibold text-charcoal">{s.title}</p>
                <p className="mt-2 text-sm leading-relaxed text-smoke">{s.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ── AI design assistant ── */}
      <section className="container-page pt-24 md:pt-32">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <h2 className="text-4xl md:text-5xl">An AI design assistant, guided by our designers</h2>
            <p className="prose-body mt-5 text-smoke">
              Upload a photo of your room and the assistant studies its light, openings and proportions, then proposes complete concepts: a colour palette, materials from our library, a furniture layout, wall and ceiling treatments, a lighting plan and an estimated budget — with a visualization of the finished room.
            </p>
            <p className="prose-body mt-4 text-smoke">Save the concepts you like, ask for changes, and a designer takes it from there with site measurements and final drawings.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ButtonLink href="/ai-designer" size="lg">
                Try the AI designer
              </ButtonLink>
              <ButtonLink href="/visualizer" size="lg" variant="secondary">
                Open the 3D visualizer
              </ButtonLink>
            </div>
          </div>
          <ConceptPreview />
        </div>
      </section>

      {/* ── Popular materials ── */}
      {materials.length ? (
        <section className="container-page pt-24 md:pt-32">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-4xl md:text-5xl">Materials our clients choose</h2>
              <p className="mt-3 max-w-lg text-smoke">Every concept and estimate draws from the same library, with current rates.</p>
            </div>
            <Link href="/materials" className="link-underline text-sm text-charcoal">
              Browse the materials library
            </Link>
          </div>
          <div className="mt-10 grid grid-cols-2 gap-x-5 gap-y-8 md:grid-cols-3 lg:grid-cols-6">
            {materials.map((m) => (
              <Link key={m.id} href={`/materials?category=${m.category}`} className="group">
                <MaterialSwatch name={m.name} color={m.color} category={m.category} imageUrl={m.imageUrl} className="aspect-square" />
                <p className="mt-3 text-[0.8rem] text-smoke">{MATERIAL_CATEGORY_LABELS[m.category as MaterialCategoryKey]}</p>
                <p className="text-sm font-medium leading-snug text-charcoal">{m.name}</p>
                <p className="mt-1 text-xs text-smoke">
                  {m.brand} — {formatINR(m.rate)}/{m.unit}
                </p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      {/* ── Cost estimation preview ── */}
      <section className="container-page pt-24 md:pt-32">
        <EstimatePreview data={estimator} />
      </section>

      {/* ── Testimonials ── */}
      {testimonials.length ? (
        <section className="container-page pt-24 md:pt-32">
          <h2 className="text-4xl md:text-5xl">In our clients&apos; words</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {testimonials.map((t) => (
              <figure key={t.id} className="flex flex-col justify-between border-l border-brass pl-6">
                <blockquote className="font-display text-[1.45rem] leading-snug text-charcoal">“{t.quote}”</blockquote>
                <figcaption className="mt-6 flex flex-wrap items-center gap-2 text-sm text-smoke">
                  <span className="flex" aria-label={`${t.rating} out of 5`}>
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="size-3.5 fill-brass text-brass" />
                    ))}
                  </span>
                  <span className="text-charcoal">{t.name}</span>
                  <span>{[t.projectType, t.location].filter(Boolean).join(", ")}</span>
                  {t.isSample ? <Badge>Sample</Badge> : null}
                </figcaption>
              </figure>
            ))}
          </div>
        </section>
      ) : null}

      {/* ── Contact ── */}
      <section className="container-page pt-24 md:pt-32">
        <div className="grid gap-12 rounded-[var(--radius-md)] border border-line bg-paper p-6 md:p-12 lg:grid-cols-[1fr_1.3fr]">
          <div>
            <h2 className="text-4xl md:text-5xl">Let&apos;s talk about your space</h2>
            <p className="mt-4 max-w-sm text-smoke">Share a few details and a designer will call you to plan a consultation — at the studio, on video or at your site.</p>
            <div className="mt-8 space-y-1 text-sm text-ink">
              <p>{settings.company.address}</p>
              {settings.company.phone ? <p>{settings.company.phone}</p> : null}
              {settings.company.email ? <p>{settings.company.email}</p> : null}
            </div>
          </div>
          <LeadForm />
        </div>
      </section>
    </>
  );
}

/** Static example of what a generated concept contains (illustrative, labelled as an example). */
function ConceptPreview() {
  const palette = STYLE_INFO.JAPANDI.palette;
  return (
    <div className="relative rounded-[var(--radius-md)] border border-line bg-paper p-6 md:p-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs text-smoke">Example concept · Master Bedroom</p>
          <p className="mt-1 font-display text-3xl text-charcoal">Quiet Oak Retreat</p>
        </div>
        <Badge tone="brass">Japandi</Badge>
      </div>
      <div className="mt-5 flex h-10 overflow-hidden rounded-[3px]">
        {palette.map((c) => (
          <span key={c} className="flex-1" style={{ background: c }} />
        ))}
      </div>
      <dl className="mt-6 grid gap-4 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-smoke">Wardrobe</dt>
          <dd className="text-charcoal">Linen oak laminate, leather pulls</dd>
        </div>
        <div>
          <dt className="text-smoke">Ceiling</dt>
          <dd className="text-charcoal">Gypsum tray with warm cove light</dd>
        </div>
        <div>
          <dt className="text-smoke">Flooring</dt>
          <dd className="text-charcoal">Engineered walnut, oiled</dd>
        </div>
        <div>
          <dt className="text-smoke">Estimated budget</dt>
          <dd className="text-charcoal">Calculated from your room size</dd>
        </div>
      </dl>
      <div className="mt-6 flex gap-2 border-t border-line-soft pt-5 text-xs text-smoke">
        <span className="rounded-full border border-line px-3 py-1">Regenerate</span>
        <span className="rounded-full border border-line px-3 py-1">Save design</span>
        <span className="rounded-full border border-line px-3 py-1">Compare</span>
      </div>
    </div>
  );
}
