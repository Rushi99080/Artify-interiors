import type { Metadata } from "next";
import { getSettings } from "@/lib/settings";
import { SmartImage } from "@/components/ui/smart-image";
import { ButtonLink } from "@/components/ui/button";

export const metadata: Metadata = { title: "About Us", description: "Artify Interiors — a design-led interior studio in Pune delivering homes, offices and commercial spaces." };
export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const { about, stats, company } = await getSettings();
  return (
    <div className="py-14 md:py-20">
      <section className="container-page grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center">
        <div>
          <h1 className="text-5xl md:text-6xl">{about.heading}</h1>
          <div className="prose-body mt-6 space-y-4 text-[1.05rem] text-ink">
            {about.body.split(/\n{2,}/).map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </div>
        <SmartImage src={about.imageUrl} alt={`${company.legalName} studio`} className="aspect-[4/5]" />
      </section>

      {stats.length ? (
        <section className="container-page mt-20 grid grid-cols-2 gap-8 border-y border-line py-10 md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label}>
              <p className="font-display text-5xl text-charcoal">{s.value}</p>
              <p className="mt-1 text-sm text-smoke">{s.label}</p>
            </div>
          ))}
        </section>
      ) : null}

      {about.values.length ? (
        <section className="container-page mt-20">
          <h2 className="text-4xl md:text-5xl">What we stand for</h2>
          <div className="mt-10 grid gap-10 md:grid-cols-3">
            {about.values.map((v) => (
              <div key={v.title} className="border-t border-charcoal/30 pt-5">
                <p className="font-display text-3xl text-charcoal">{v.title}</p>
                <p className="mt-2 text-smoke">{v.text}</p>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section className="container-page mt-20 flex flex-col items-start justify-between gap-6 rounded-[var(--radius-md)] bg-charcoal p-8 text-paper md:flex-row md:items-center md:p-12">
        <div>
          <p className="font-display text-4xl">Have a space in mind?</p>
          <p className="mt-2 text-sand">Start with a brief and a few photos — we&apos;ll take it from there.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <ButtonLink href="/ai-designer" variant="brass" size="lg">
            Start your design
          </ButtonLink>
          <ButtonLink href="/contact" variant="light" size="lg">
            Contact the studio
          </ButtonLink>
        </div>
      </section>
    </div>
  );
}
