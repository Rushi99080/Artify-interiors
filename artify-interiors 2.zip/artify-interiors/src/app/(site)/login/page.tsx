import type { Metadata } from "next";
import { Suspense } from "react";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "@/components/auth/auth-forms";

export const metadata: Metadata = { title: "Log in" };

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect(user.role === "CUSTOMER" ? "/dashboard" : "/admin");
  return (
    <AuthShell title="Welcome back" subtitle="Log in to see your designs, quotations and project progress.">
      <Suspense>
        <LoginForm />
      </Suspense>
    </AuthShell>
  );
}
