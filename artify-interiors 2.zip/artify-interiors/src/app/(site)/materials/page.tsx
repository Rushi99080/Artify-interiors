import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { MaterialsLibrary } from "@/components/materials/materials-library";

export const metadata: Metadata = { title: "Materials Library", description: "Plywood, laminates, veneers, quartz, marble, tiles, hardware and lighting — with brands, finishes and current rates." };
export const dynamic = "force-dynamic";

export default async function MaterialsPage({ searchParams }: { searchParams: Promise<{ category?: string }> }) {
  const sp = await searchParams;
  const rows = await prisma.material.findMany({
    where: { isActive: true },
    orderBy: [{ category: "asc" }, { rate: "asc" }],
    include: { supplier: { select: { name: true } } },
  });
  const materials = rows.map((m) => ({
    id: m.id,
    name: m.name,
    category: m.category,
    brand: m.brand,
    productCode: m.productCode,
    finish: m.finish,
    color: m.color,
    unit: m.unit,
    rate: m.rate,
    imageUrl: m.imageUrl,
    specifications: m.specifications,
    availability: m.availability,
    tier: m.tier,
    durability: m.durability,
    maintenance: m.maintenance,
    styles: m.styles,
    updatedAt: m.updatedAt.toISOString(),
    supplierName: m.supplier?.name ?? null,
  }));
  return (
    <div className="container-page py-14 md:py-20">
      <header className="grid gap-6 lg:grid-cols-[1.2fr_1fr] lg:items-end">
        <h1 className="text-5xl md:text-6xl">Materials library</h1>
        <p className="text-smoke">Every board, finish, stone and fitting we specify — with brand, finish, unit rate and durability. Our design concepts and estimates use these exact rates.</p>
      </header>
      <div className="mt-10">
        <MaterialsLibrary materials={materials} initialCategory={sp.category} />
      </div>
    </div>
  );
}
