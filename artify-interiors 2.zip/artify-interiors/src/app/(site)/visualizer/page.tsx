import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth/session";
import { isTeamRole } from "@/lib/auth/token";
import { ROOM_TYPES, ROOM_MODULE_BY_TYPE, type RoomTypeKey } from "@/lib/constants";
import { VisualizerLoader } from "@/components/visualizer/visualizer-loader";

export const metadata: Metadata = { title: "3D Room Visualizer", description: "Plan your room in 3D — change wall colours, flooring, lighting and furniture placement." };
export const dynamic = "force-dynamic";

export default async function VisualizerPage({ searchParams }: { searchParams: Promise<{ project?: string; room?: string }> }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  const projects = user
    ? await prisma.project.findMany({
        where: isTeamRole(user.role) ? { status: { notIn: ["CANCELLED"] } } : { customerId: user.customerId ?? "__none__" },
        orderBy: { updatedAt: "desc" },
        take: 50,
        select: { id: true, name: true, rooms: { orderBy: { sortOrder: "asc" }, select: { id: true, name: true, type: true, lengthFt: true, widthFt: true, heightFt: true } } },
      })
    : [];

  const project = projects.find((p) => p.id === sp.project);
  const room = project?.rooms.find((r) => r.id === sp.room) ?? project?.rooms[0];
  const roomType = room?.type ?? (sp.room && (ROOM_TYPES as readonly string[]).includes(sp.room) ? sp.room : "LIVING_ROOM");
  const defaults = ROOM_MODULE_BY_TYPE[roomType as RoomTypeKey]?.defaults ?? { lengthFt: 16, widthFt: 12, heightFt: 10 };
  const dims = room ? { lengthFt: room.lengthFt ?? defaults.lengthFt, widthFt: room.widthFt ?? defaults.widthFt, heightFt: room.heightFt ?? defaults.heightFt } : { ...defaults, heightFt: Math.max(defaults.heightFt, 8) };

  return (
    <div className="container-page py-8 md:py-10">
      <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-4xl md:text-5xl">3D room visualizer</h1>
          <p className="mt-1 text-sm text-smoke">Set your room size, try wall colours, flooring and lighting, and arrange furniture. Save layouts to your project.</p>
        </div>
      </header>
      <VisualizerLoader signedIn={!!user} projects={projects} initialProjectId={project?.id ?? null} initialRoomType={roomType} initialDims={dims} />
    </div>
  );
}
