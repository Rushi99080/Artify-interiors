import Link from "next/link";
import { requireTeam } from "@/lib/auth/session";
import { adminAnalytics } from "@/lib/services/analytics";
import { LEAD_SOURCE_LABELS, LEAD_STATUS_LABELS, PROJECT_STATUS_LABELS } from "@/lib/constants";
import { formatDate, formatINR, formatINRCompact, formatRelative } from "@/lib/format";
import { PageHeader, Panel, PanelHeader, StatCard } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { BarsChart, HBars } from "@/components/charts/charts";
import { Notice } from "@/components/ui/notice";
import { integrationStatus } from "@/lib/env";

export default async function AdminOverview({ searchParams }: { searchParams: Promise<{ denied?: string }> }) {
  const sp = await searchParams;
  const user = await requireTeam();
  const a = await adminAnalytics();
  const integ = integrationStatus();
  const missing = [!integ.aiText.configured && "AI text provider", !integ.aiImage.configured && "AI image provider", !integ.email.configured && "email", integ.storage.provider === "local" && "cloud file storage"].filter(Boolean) as string[];

  return (
    <>
      <PageHeader title="Overview" description={`Welcome back, ${user.name.split(" ")[0]}. Figures are live from your records.`} />
      {sp.denied ? <Notice kind="warning" className="mb-6">You do not have permission to open that page.</Notice> : null}
      {missing.length && user.role === "ADMIN" ? (
        <Notice kind="config" className="mb-6" title="Some integrations are not configured" action={<Link href="/admin/settings?tab=integrations" className="text-sm underline">Review</Link>}>
          Not yet connected: {missing.join(", ")}. The platform keeps working; these features show a configuration message until keys are added.
        </Notice>
      ) : null}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total revenue" value={formatINRCompact(a.kpis.totalRevenue)} hint="All payments received" tone="moss" />
        <StatCard label="Pending payments" value={formatINRCompact(a.kpis.pendingPayments)} hint="Contracts minus receipts" tone="amber" />
        <StatCard label="Active projects" value={a.kpis.activeProjects} />
        <StatCard label="New leads" value={a.kpis.newLeads} hint={`${a.kpis.leads30} enquiries in 30 days`} tone="brass" />
        <StatCard label="Quotation conversion" value={`${a.kpis.conversion}%`} hint={`${a.kpis.approved} of ${a.kpis.quoted} quoted`} />
        <StatCard label="Material cost" value={formatINRCompact(a.kpis.materialCostActual)} hint={`Estimated in approved BOQs: ${formatINRCompact(a.kpis.materialCostEstimated)}`} />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <Panel>
          <PanelHeader title="Monthly revenue and expenses" description="Payments received vs recorded project expenses, last 12 months" />
          <BarsChart
            data={a.revenueMonthly}
            xKey="month"
            money
            series={[
              { key: "revenue", label: "Revenue" },
              { key: "expenses", label: "Expenses" },
            ]}
          />
        </Panel>
        <Panel>
          <PanelHeader title="Customer enquiries by source" description="Last 12 months" actions={<Link href="/admin/leads" className="text-sm text-smoke hover:text-charcoal">Open CRM</Link>} />
          <HBars rows={a.leadsBySource.map((l) => ({ label: LEAD_SOURCE_LABELS[l.source], value: l.count }))} />
          <div className="mt-6 border-t border-line-soft pt-4">
            <p className="mb-2 text-xs text-smoke">Enquiries per month</p>
            <BarsChart data={a.leadsMonthly} xKey="month" series={[{ key: "leads", label: "Enquiries" }]} height={140} />
          </div>
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Panel className="xl:col-span-2">
          <PanelHeader title="Project-wise profit" description="Contract value excludes GST; actual profit appears once expenses are recorded." />
          {a.projectProfit.length ? (
            <div className="overflow-x-auto">
              <table className="data-table min-w-[720px]">
                <thead>
                  <tr>
                    <th>Project</th>
                    <th>Status</th>
                    <th className="num">Contract</th>
                    <th className="num">Received</th>
                    <th className="num">Expenses</th>
                    <th className="num">Planned margin</th>
                    <th className="num">Final profit</th>
                  </tr>
                </thead>
                <tbody>
                  {a.projectProfit.slice(0, 10).map((p) => (
                    <tr key={p.id}>
                      <td>
                        <Link href={`/admin/projects/${p.id}`} className="text-charcoal underline decoration-sand underline-offset-4">
                          {p.name}
                        </Link>
                        <span className="block text-xs text-smoke">{p.code}</span>
                      </td>
                      <td>
                        <StatusBadge status={p.status} label={PROJECT_STATUS_LABELS[p.status]} />
                      </td>
                      <td className="num">{formatINR(p.contract)}</td>
                      <td className="num">{formatINR(p.received)}</td>
                      <td className="num">{formatINR(p.expenses)}</td>
                      <td className="num">{formatINR(p.estimatedMargin)}</td>
                      <td className={`num ${p.actualProfit !== null && p.actualProfit < 0 ? "text-brick" : "text-charcoal"}`}>{p.actualProfit === null ? <span className="text-smoke">{p.expenses > 0 && p.costShare != null ? `Running · ${p.costShare}% spent` : "Running"}</span> : formatINR(p.actualProfit)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-smoke">Projects with an approved quotation appear here.</p>
          )}
        </Panel>
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Follow-ups due" actions={<Link href="/admin/leads?due=1" className="text-sm text-smoke hover:text-charcoal">All</Link>} />
            {a.followUps.length ? (
              <ul className="space-y-2.5 text-sm">
                {a.followUps.map((l) => (
                  <li key={l.id} className="flex items-center justify-between gap-2">
                    <Link href={`/admin/leads/${l.id}`} className="min-w-0">
                      <span className="block truncate text-charcoal">{l.name}</span>
                      <span className="text-xs text-smoke">
                        {l.leadCode} · {l.phone}
                      </span>
                    </Link>
                    <span className={`shrink-0 text-xs ${l.followUpDate && l.followUpDate < new Date() ? "text-brick" : "text-smoke"}`}>{formatDate(l.followUpDate)}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-smoke">No follow-ups due.</p>
            )}
          </Panel>
          <Panel>
            <PanelHeader title="Latest enquiries" />
            <ul className="space-y-2.5 text-sm">
              {a.recentLeads.map((l) => (
                <li key={l.id} className="flex items-center justify-between gap-2">
                  <Link href={`/admin/leads/${l.id}`} className="min-w-0">
                    <span className="block truncate text-charcoal">{l.name}</span>
                    <span className="text-xs text-smoke">
                      {LEAD_SOURCE_LABELS[l.source]} · {formatRelative(l.createdAt)}
                    </span>
                  </Link>
                  <StatusBadge status={l.status} label={LEAD_STATUS_LABELS[l.status]} />
                </li>
              ))}
              {a.recentLeads.length === 0 ? <li className="text-smoke">No enquiries yet.</li> : null}
            </ul>
          </Panel>
          <Panel>
            <PanelHeader title="Projects by status" />
            <HBars rows={a.projectsByStatus.map((p) => ({ label: PROJECT_STATUS_LABELS[p.status], value: p.count }))} />
          </Panel>
        </div>
      </div>
    </>
  );
}
