import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { PROJECT_STATUS_LABELS } from "@/lib/constants";
import { formatINR, formatRelative } from "@/lib/format";
import { computeProgress } from "@/lib/workflow/stages";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";

export default async function AdminProjectsPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  await requireTeam("projects.manage");
  const sp = await searchParams;
  const projects = await prisma.project.findMany({
    where: {
      ...(sp.status ? { status: sp.status as never } : {}),
      ...(sp.q ? { OR: [{ name: { contains: sp.q, mode: "insensitive" } }, { code: { contains: sp.q, mode: "insensitive" } }, { location: { contains: sp.q, mode: "insensitive" } }, { customer: { fullName: { contains: sp.q, mode: "insensitive" } } }] } : {}),
    },
    orderBy: { updatedAt: "desc" },
    take: 300,
    include: { customer: { select: { fullName: true } }, milestones: { select: { stageKey: true, sortOrder: true, status: true, name: true } }, payments: { where: { status: "SUCCESS" }, select: { amount: true } }, _count: { select: { designs: true, rooms: true } } },
  });
  return (
    <>
      <PageHeader title="Projects" description="All client projects, from first brief to handover." />
      <ListFilters placeholder="Search project, code, client, location" filters={[{ name: "status", label: "Status", options: Object.entries(PROJECT_STATUS_LABELS).map(([value, label]) => ({ value, label })) }]} />
      {projects.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[960px]">
            <thead>
              <tr>
                <th>Project</th>
                <th>Client</th>
                <th>Status</th>
                <th>Current stage</th>
                <th className="num">Rooms</th>
                <th className="num">Designs</th>
                <th className="num">Contract</th>
                <th className="num">Received</th>
                <th>Updated</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((p) => {
                const prog = computeProgress(p.milestones);
                const cur = prog.current as { name?: string } | null;
                return (
                  <tr key={p.id}>
                    <td>
                      <Link href={`/admin/projects/${p.id}`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                        {p.name}
                      </Link>
                      <span className="block text-xs text-smoke">
                        {p.code} · {p.location}
                      </span>
                    </td>
                    <td>{p.customer.fullName}</td>
                    <td>
                      <StatusBadge status={p.status} label={PROJECT_STATUS_LABELS[p.status]} />
                    </td>
                    <td>
                      <span className="text-ink">{cur?.name ?? "Completed"}</span>
                      <span className="mt-1 block h-1 w-28 overflow-hidden rounded-full bg-line-soft">
                        <span className="block h-full bg-brass" style={{ width: `${prog.percent}%` }} />
                      </span>
                    </td>
                    <td className="num">{p._count.rooms}</td>
                    <td className="num">{p._count.designs}</td>
                    <td className="num">{p.contractValue ? formatINR(p.contractValue) : "—"}</td>
                    <td className="num">{formatINR(p.payments.reduce((s, x) => s + x.amount, 0))}</td>
                    <td className="text-smoke">{formatRelative(p.updatedAt)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No projects found" description="Projects are created by clients in the AI designer, or by the team from a lead or customer." />
      )}
    </>
  );
}
