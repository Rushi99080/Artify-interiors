import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { can } from "@/lib/auth/permissions";
import { paymentSummary } from "@/lib/calc/payments";
import { formatINR } from "@/lib/format";
import { Panel, PanelHeader, StatCard } from "@/components/ui/panel";
import { ProjectBrief } from "@/components/projects/project-brief";
import { WorkflowEditor } from "@/components/admin/workflow-editor";
import { ProjectAdminForm } from "@/components/admin/project-admin-form";

export default async function AdminProjectOverview({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireTeam("projects.manage");
  const { id } = await params;
  const [p, team] = await Promise.all([
    prisma.project.findUniqueOrThrow({
      where: { id },
      include: { milestones: { orderBy: { sortOrder: "asc" } }, payments: { select: { amount: true, status: true } }, expenses: { select: { amount: true } }, leads: { select: { id: true, leadCode: true } }, approvedQuotation: { select: { id: true, number: true } } },
    }),
    prisma.teamMember.findMany({ where: { isActive: true }, select: { id: true, name: true }, orderBy: { name: "asc" } }),
  ]);
  const pay = paymentSummary(p.contractValue, p.payments);
  const spent = p.expenses.reduce((s, e) => s + e.amount, 0);
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Contract value" value={p.contractValue ? formatINR(p.contractValue) : "—"} hint={p.approvedQuotation ? `Quotation ${p.approvedQuotation.number}` : "No approved quotation yet"} />
        <StatCard label="Received" value={formatINR(pay.received)} tone="moss" hint={`${pay.percent}%`} />
        <StatCard label="Pending" value={formatINR(pay.pending)} tone="amber" />
        <StatCard label="Expenses recorded" value={formatINR(spent)} />
      </div>
      <Panel>
        <PanelHeader title="Workflow" description="Stage changes are posted to the client's project feed and notified when visible to them." />
        <WorkflowEditor
          projectId={id}
          team={team}
          milestones={p.milestones.map((m) => ({ id: m.id, stageKey: m.stageKey, name: m.name, sortOrder: m.sortOrder, status: m.status, assigneeId: m.assigneeId, dueDate: m.dueDate?.toISOString() ?? null, completedAt: m.completedAt?.toISOString() ?? null, notes: m.notes, customerVisible: m.customerVisible }))}
        />
      </Panel>
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Project settings" />
          <ProjectAdminForm p={p} canDelete={can(user.role, "settings.manage")} />
        </Panel>
        <Panel>
          <PanelHeader title="Client brief" actions={p.leads[0] ? <Link href={`/admin/leads/${p.leads[0].id}`} className="text-sm text-smoke hover:text-charcoal">Lead {p.leads[0].leadCode}</Link> : null} />
          <ProjectBrief p={p} />
        </Panel>
      </div>
    </div>
  );
}
