import Link from "next/link";
import { prisma } from "@/lib/db";
import { tierFromBudget } from "@/lib/boq/engine";
import { formatDate, formatINR } from "@/lib/format";
import { TIER_LABELS } from "@/lib/constants";
import { Panel, PanelHeader, EmptyState } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { GenerateBOQButton, CreateQuotationButton } from "@/components/boq/boq-actions";
import { ButtonLink } from "@/components/ui/button";

export default async function AdminProjectBOQPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [project, boqs] = await Promise.all([
    prisma.project.findUniqueOrThrow({ where: { id }, select: { budgetMax: true, carpetAreaSqft: true } }),
    prisma.bOQ.findMany({ where: { projectId: id }, orderBy: { version: "desc" }, include: { _count: { select: { items: true } }, quotations: { select: { id: true, number: true, status: true } } } }),
  ]);
  return (
    <Panel>
      <PanelHeader title="Bill of Quantities versions" description="Generate from rooms, dimensions and selected materials, then edit, verify and quote." actions={<GenerateBOQButton projectId={id} defaultTier={boqs[0]?.tier ?? tierFromBudget(project.budgetMax, project.carpetAreaSqft)} />} />
      {boqs.length ? (
        <div className="overflow-x-auto">
          <table className="data-table min-w-[900px]">
            <thead>
              <tr>
                <th>Version</th>
                <th>Status</th>
                <th>Finish</th>
                <th className="num">Items</th>
                <th className="num">Subtotal</th>
                <th className="num">Grand total</th>
                <th>Quotations</th>
                <th>Updated</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {boqs.map((b) => (
                <tr key={b.id}>
                  <td>
                    <Link href={`/admin/boq/${b.id}`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                      v{b.version}
                    </Link>
                    <span className="block text-xs text-smoke">{b.title}</span>
                  </td>
                  <td>
                    <StatusBadge status={b.status} />
                  </td>
                  <td>{TIER_LABELS[b.tier]}</td>
                  <td className="num">{b._count.items}</td>
                  <td className="num">{formatINR(b.subtotal)}</td>
                  <td className="num text-charcoal">{formatINR(b.grandTotal)}</td>
                  <td className="text-xs">{b.quotations.map((q) => q.number).join(", ") || "—"}</td>
                  <td className="text-smoke">{formatDate(b.updatedAt)}</td>
                  <td className="whitespace-nowrap">
                    <div className="flex items-center justify-end gap-2">
                      <ButtonLink href={`/admin/boq/${b.id}`} size="sm" variant="secondary">
                        Edit
                      </ButtonLink>
                      {b.status !== "FINAL" ? <CreateQuotationButton boqId={b.id} preliminary={b.status === "PRELIMINARY"} /> : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No BOQ yet" description="Generate one from this project's rooms. You can edit every line afterwards." />
      )}
    </Panel>
  );
}
