import { prisma } from "@/lib/db";
import { loadRoomsData } from "@/lib/services/project-views";
import { RoomsPanel } from "@/components/projects/rooms-panel";

export default async function AdminRoomsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const project = await prisma.project.findUniqueOrThrow({ where: { id }, select: { designStyle: true } });
  const { rooms, materials } = await loadRoomsData(id);
  return <RoomsPanel projectId={id} rooms={rooms} materials={materials} editable projectStyle={project.designStyle} />;
}
