import { prisma } from "@/lib/db";
import { formatDate } from "@/lib/format";
import { Panel, PanelHeader } from "@/components/ui/panel";

export default async function AdminActivityPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [designIds, quoteIds, boqIds, payIds] = await Promise.all([
    prisma.generatedDesign.findMany({ where: { projectId: id }, select: { id: true } }),
    prisma.quotation.findMany({ where: { projectId: id }, select: { id: true } }),
    prisma.bOQ.findMany({ where: { projectId: id }, select: { id: true } }),
    prisma.payment.findMany({ where: { projectId: id }, select: { id: true } }),
  ]);
  const ids = [id, ...designIds, ...quoteIds, ...boqIds, ...payIds].map((x) => (typeof x === "string" ? x : x.id));
  const logs = await prisma.auditLog.findMany({ where: { entityId: { in: ids } }, orderBy: { createdAt: "desc" }, take: 200, include: { user: { select: { name: true } } } });
  return (
    <Panel>
      <PanelHeader title="Audit trail" description="Who changed what on this project." />
      {logs.length ? (
        <table className="data-table">
          <thead>
            <tr>
              <th>When</th>
              <th>Who</th>
              <th>Action</th>
              <th>Record</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id}>
                <td className="whitespace-nowrap text-smoke">{formatDate(l.createdAt, true)}</td>
                <td>{l.user?.name ?? "System"}</td>
                <td className="text-charcoal">{l.action}</td>
                <td className="text-smoke">{l.entity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="text-sm text-smoke">No recorded activity yet.</p>
      )}
    </Panel>
  );
}
