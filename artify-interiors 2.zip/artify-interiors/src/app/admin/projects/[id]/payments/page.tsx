import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { can } from "@/lib/auth/permissions";
import { env } from "@/lib/env";
import { loadPaymentsData } from "@/lib/services/payment-views";
import { PaymentsPanel } from "@/components/payments/payments-panel";
import { ExpensesPanel } from "@/components/admin/expenses-panel";

export default async function AdminPaymentsPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireTeam("payments.record");
  const { id } = await params;
  const [data, expenses, suppliers] = await Promise.all([
    loadPaymentsData(id),
    prisma.expense.findMany({ where: { projectId: id }, orderBy: { spentAt: "desc" }, include: { supplier: { select: { name: true } } } }),
    prisma.supplier.findMany({ where: { isActive: true }, select: { id: true, name: true }, orderBy: { name: "asc" } }),
  ]);
  const r = env.razorpay();
  return (
    <div className="space-y-6">
      <PaymentsPanel projectId={id} data={data} mode="team" onlinePayments={!!(r.keyId && r.keySecret)} canDelete={can(user.role, "payments.delete")} />
      {can(user.role, "expenses.manage") ? (
        <ExpensesPanel
          projectId={id}
          canManage
          suppliers={suppliers}
          expenses={expenses.map((e) => ({ id: e.id, category: e.category, description: e.description, amount: e.amount, paidTo: e.paidTo, spentAt: e.spentAt.toISOString(), supplierName: e.supplier?.name ?? null }))}
        />
      ) : null}
    </div>
  );
}
