import { aiConfig } from "@/lib/ai";
import { loadDesignsData } from "@/lib/services/designs-view";
import { DesignsBoard } from "@/components/designs/designs-board";

export default async function AdminDesignsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { designs, rooms, photos } = await loadDesignsData(id);
  return <DesignsBoard projectId={id} designs={designs} rooms={rooms} photos={photos} aiStatus={aiConfig()} mode="team" />;
}
