import { prisma } from "@/lib/db";
import { MessagesThread } from "@/components/projects/messages-thread";

export default async function AdminMessagesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const messages = await prisma.message.findMany({ where: { projectId: id }, orderBy: { createdAt: "asc" }, include: { sender: { select: { name: true } } } });
  return <MessagesThread projectId={id} viewer="team" initial={messages.map((m) => ({ id: m.id, body: m.body, kind: m.kind, fromTeam: m.fromTeam, createdAt: m.createdAt.toISOString(), senderName: m.sender?.name ?? null }))} />;
}
