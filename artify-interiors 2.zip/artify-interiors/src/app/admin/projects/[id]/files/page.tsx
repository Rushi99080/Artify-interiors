import { prisma } from "@/lib/db";
import { FilesPanel } from "@/components/projects/files-panel";

export default async function AdminFilesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [files, rooms] = await Promise.all([
    prisma.uploadedFile.findMany({ where: { projectId: id }, orderBy: { createdAt: "desc" }, include: { room: { select: { name: true } } } }),
    prisma.room.findMany({ where: { projectId: id }, orderBy: { sortOrder: "asc" }, select: { id: true, name: true } }),
  ]);
  return (
    <FilesPanel
      projectId={id}
      rooms={rooms}
      categories={["SITE_PHOTO", "ROOM_PHOTO", "FLOOR_PLAN", "DRAWING_PDF", "CAD", "MEASUREMENT", "DOCUMENT", "REFERENCE"]}
      files={files.map((f) => ({ id: f.id, originalName: f.originalName, category: f.category, mimeType: f.mimeType, sizeBytes: f.sizeBytes, createdAt: f.createdAt.toISOString(), roomName: f.room?.name ?? null, canDelete: true }))}
    />
  );
}
