import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { PROJECT_STATUS_LABELS } from "@/lib/constants";
import { TabNav } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/ui/badge";

export default async function AdminProjectLayout({ children, params }: { children: React.ReactNode; params: Promise<{ id: string }> }) {
  await requireTeam("projects.manage");
  const { id } = await params;
  const p = await prisma.project.findUnique({
    where: { id },
    select: { name: true, code: true, status: true, location: true, customer: { select: { id: true, fullName: true, phone: true } }, _count: { select: { designs: true, quotations: true, files: true, rooms: true, boqs: true } } },
  });
  if (!p) notFound();
  const base = `/admin/projects/${id}`;
  return (
    <>
      <div className="mb-6">
        <Link href="/admin/projects" className="link-underline text-sm text-smoke">
          Projects
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="text-3xl md:text-[2.4rem]">{p.name}</h1>
          <StatusBadge status={p.status} label={PROJECT_STATUS_LABELS[p.status]} />
        </div>
        <p className="mt-1 text-sm text-smoke">
          {p.code} · {p.location} ·{" "}
          <Link href={`/admin/customers/${p.customer.id}`} className="underline decoration-sand underline-offset-4">
            {p.customer.fullName}
          </Link>{" "}
          · {p.customer.phone}
        </p>
      </div>
      <TabNav
        tabs={[
          { href: base, label: "Overview & workflow", exact: true },
          { href: `${base}/rooms`, label: "Rooms", count: p._count.rooms },
          { href: `${base}/files`, label: "Files", count: p._count.files },
          { href: `${base}/designs`, label: "Designs", count: p._count.designs },
          { href: `${base}/boq`, label: "BOQ", count: p._count.boqs },
          { href: `${base}/quotations`, label: "Quotations", count: p._count.quotations },
          { href: `${base}/payments`, label: "Payments & expenses" },
          { href: `${base}/messages`, label: "Messages" },
          { href: `${base}/activity`, label: "Activity" },
        ]}
      />
      {children}
    </>
  );
}
