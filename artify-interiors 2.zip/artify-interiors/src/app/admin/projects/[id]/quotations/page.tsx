import { prisma } from "@/lib/db";
import { loadQuotationRows } from "@/lib/services/quotation-views";
import { QuotationsPanel } from "@/components/quotations/quotations-panel";
import { Notice } from "@/components/ui/notice";
import Link from "next/link";

export default async function AdminQuotationsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [project, rows] = await Promise.all([prisma.project.findUniqueOrThrow({ where: { id }, select: { status: true, customer: { select: { fullName: true } } } }), loadQuotationRows(id, { includeDrafts: true })]);
  return (
    <div className="space-y-5">
      <Notice kind="info">
        Quotations are generated from a BOQ version. Open the{" "}
        <Link href={`/admin/projects/${id}/boq`} className="underline">
          BOQ tab
        </Link>{" "}
        to verify quantities, then create a final (non-preliminary) quotation.
      </Notice>
      <QuotationsPanel quotations={rows} mode="team" projectActive={project.status === "ACTIVE"} customerName={project.customer.fullName} />
    </div>
  );
}
