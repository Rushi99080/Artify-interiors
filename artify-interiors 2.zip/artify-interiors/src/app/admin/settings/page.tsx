import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { getSettings } from "@/lib/settings";
import { env, integrationStatus } from "@/lib/env";
import { DEFAULT_RATE_CARD } from "@/lib/boq/engine";
import { PageHeader } from "@/components/ui/panel";
import { TabNav } from "@/components/ui/tabs";
import { AutomationForm, BoqDefaultsForm, CompanyForm, IntegrationsPanel, PaymentScheduleForm, QuotationForm, RateCardEditor, TestMessageForm, WorkflowStagesEditor, type IntegrationRow } from "@/components/admin/settings-forms";

const TABS = {
  company: "Company & tax",
  quotations: "Quotations & payments",
  pricing: "BOQ & rate card",
  workflow: "Workflow",
  automation: "Automation",
  integrations: "Integrations",
} as const;

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const user = await requireTeam("settings.manage");
  const sp = await searchParams;
  const tab = (sp.tab && sp.tab in TABS ? sp.tab : "company") as keyof typeof TABS;
  const s = await getSettings();

  return (
    <>
      <PageHeader title="Settings" description="Business rules used across the platform. Changes apply to new BOQs, quotations and projects; existing documents keep their values." />
      <TabNav tabs={Object.entries(TABS).map(([key, label]) => ({ href: key === "company" ? "/admin/settings" : `/admin/settings?tab=${key}`, label, active: key === tab }))} />

      {tab === "company" ? <CompanyForm company={s.company} gstRate={s.tax.gstRate} /> : null}

      {tab === "quotations" ? (
        <div className="grid gap-6 xl:grid-cols-[3fr_2fr]">
          <QuotationForm initial={s.quotation} />
          <div className="content-start">
            <PaymentScheduleForm initial={s.paymentSchedule} />
          </div>
        </div>
      ) : null}

      {tab === "pricing" ? (
        <div className="grid gap-6">
          <BoqDefaultsForm initial={s.boqDefaults} />
          <RateCardEditor rateCard={s.rateCard} defaults={DEFAULT_RATE_CARD} />
        </div>
      ) : null}

      {tab === "workflow" ? <WorkflowTab /> : null}

      {tab === "automation" ? <AutomationForm initial={s.automation} /> : null}

      {tab === "integrations" ? <IntegrationsTab adminEmail={user.email} companyPhone={s.company.whatsappNumber || s.company.phone} /> : null}
    </>
  );
}

async function WorkflowTab() {
  const stages = await prisma.workflowStage.findMany({ orderBy: [{ isActive: "desc" }, { sortOrder: "asc" }] });
  return <WorkflowStagesEditor stages={stages.map((st) => ({ id: st.id, key: st.key, name: st.name, defaultDurationDays: st.defaultDurationDays, customerVisible: st.customerVisible, isActive: st.isActive }))} />;
}

function IntegrationsTab({ adminEmail, companyPhone }: { adminEmail: string; companyPhone: string }) {
  const i = integrationStatus();
  const cronReady = !!process.env.CRON_SECRET;
  const rows: IntegrationRow[] = [
    { key: "db", label: "Database", configured: true, detail: "PostgreSQL via Prisma", env: "DATABASE_URL", required: true },
    { key: "auth", label: "Sign-in sessions", configured: env.authSecret().length >= 32, detail: env.authSecret().length >= 32 ? "Signed session cookies (7 days)" : "AUTH_SECRET is shorter than 32 characters — generate a long random value", env: "AUTH_SECRET", required: true },
    { key: "aiText", label: "AI design concepts", configured: i.aiText.configured, detail: i.aiText.detail, env: "AI_TEXT_PROVIDER · OPENAI_API_KEY / GEMINI_API_KEY / ANTHROPIC_API_KEY" },
    { key: "aiImage", label: "AI visualisations", configured: i.aiImage.configured, detail: i.aiImage.detail, env: "AI_IMAGE_PROVIDER · OPENAI_API_KEY / GEMINI_API_KEY / REPLICATE_API_TOKEN" },
    { key: "storage", label: "File storage", configured: i.storage.configured, detail: i.storage.detail, env: "STORAGE_PROVIDER · CLOUDINARY_CLOUD_NAME / CLOUDINARY_API_KEY / CLOUDINARY_API_SECRET" },
    { key: "email", label: "Email", configured: i.email.configured, detail: i.email.detail, env: "EMAIL_PROVIDER · SMTP_HOST / SMTP_USER / SMTP_PASS or RESEND_API_KEY · EMAIL_FROM" },
    { key: "whatsapp", label: "WhatsApp", configured: i.whatsapp.configured, detail: i.whatsapp.detail, env: "WHATSAPP_ACCESS_TOKEN · WHATSAPP_PHONE_NUMBER_ID · WHATSAPP_TEMPLATES" },
    { key: "razorpay", label: "Online payments", configured: i.razorpay.configured, detail: i.razorpay.detail, env: "RAZORPAY_KEY_ID · RAZORPAY_KEY_SECRET · RAZORPAY_WEBHOOK_SECRET" },
    { key: "cron", label: "Scheduled reminders", configured: cronReady, detail: cronReady ? "Daily payment-reminder job is protected and ready (vercel.json)" : "Set CRON_SECRET so the daily payment-reminder job can run on Vercel", env: "CRON_SECRET" },
    { key: "rate", label: "Rate limiting", configured: true, detail: i.rateLimit.detail, env: "UPSTASH_REDIS_REST_URL · UPSTASH_REDIS_REST_TOKEN (optional)" },
  ];
  return (
    <div className="grid gap-6 xl:grid-cols-[3fr_2fr]">
      <IntegrationsPanel rows={rows} />
      <div className="content-start">
        <TestMessageForm emailReady={i.email.configured} whatsappReady={i.whatsapp.configured} defaultEmail={adminEmail} defaultPhone={companyPhone} />
      </div>
    </div>
  );
}
