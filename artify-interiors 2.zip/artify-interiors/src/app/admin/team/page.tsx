import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { formatRelative } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { RemoveTeamMemberButton, TeamMemberFormButton, type TeamMemberView } from "@/components/admin/team-actions";

export default async function TeamPage() {
  const me = await requireTeam("team.manage");
  const members = await prisma.teamMember.findMany({
    orderBy: [{ isActive: "desc" }, { name: "asc" }],
    include: {
      user: { select: { id: true, email: true, role: true, isActive: true, lastLoginAt: true } },
      _count: { select: { milestones: { where: { status: { in: ["PENDING", "IN_PROGRESS", "BLOCKED"] } } }, assignedLeads: { where: { status: { notIn: ["CONVERTED", "LOST"] } } } } },
    },
  });

  return (
    <>
      <PageHeader title="Team" description="Designers, supervisors and sales staff. Assign them to workflow stages on each project and to leads in the CRM." actions={<TeamMemberFormButton />} />
      {members.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[960px]">
            <thead>
              <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Admin access</th>
                <th className="num">Open stages</th>
                <th className="num">Open leads</th>
                <th>Last sign-in</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {members.map((m) => {
                const view: TeamMemberView = {
                  id: m.id,
                  name: m.name,
                  designation: m.designation,
                  department: m.department,
                  phone: m.phone,
                  email: m.email,
                  isActive: m.isActive,
                  login: m.user ? { role: m.user.role, email: m.user.email, isActive: m.user.isActive } : null,
                  isSelf: m.userId === me.id,
                };
                return (
                  <tr key={m.id} className={m.isActive ? undefined : "opacity-60"}>
                    <td>
                      <span className="font-medium text-charcoal">{m.name}</span>
                      {view.isSelf ? <Badge className="ml-2">You</Badge> : null}
                      {!m.isActive ? <Badge className="ml-2">Inactive</Badge> : null}
                      <span className="block text-xs text-smoke">
                        {m.designation}
                        {m.department ? ` · ${m.department}` : ""}
                      </span>
                    </td>
                    <td className="text-sm">
                      {m.phone ? <a href={`tel:${m.phone}`}>{m.phone}</a> : "—"}
                      {m.email ? <span className="block text-xs text-smoke">{m.email}</span> : null}
                    </td>
                    <td>
                      {m.user ? (
                        <>
                          <Badge tone={m.user.role === "ADMIN" ? "dark" : "slate"}>{m.user.role === "ADMIN" ? "Admin" : "Staff"}</Badge>
                          {!m.user.isActive ? <Badge tone="brick" className="ml-1">Login disabled</Badge> : null}
                        </>
                      ) : (
                        <span className="text-xs text-smoke">No login</span>
                      )}
                    </td>
                    <td className="num">{m._count.milestones}</td>
                    <td className="num">{m._count.assignedLeads}</td>
                    <td className="text-smoke">{m.user?.lastLoginAt ? formatRelative(m.user.lastLoginAt) : "—"}</td>
                    <td className="whitespace-nowrap text-right">
                      <TeamMemberFormButton member={view} />
                      {!view.isSelf ? <RemoveTeamMemberButton id={m.id} name={m.name} /> : null}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No team members yet" description="Add your designers and site supervisors so you can assign workflow stages." action={<TeamMemberFormButton />} />
      )}
    </>
  );
}
