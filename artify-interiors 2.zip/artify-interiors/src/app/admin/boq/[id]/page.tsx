import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { getSettings } from "@/lib/settings";
import { BOQEditor } from "@/components/boq/boq-editor";

export default async function BOQEditorPage({ params }: { params: Promise<{ id: string }> }) {
  await requireTeam("boq.manage");
  const { id } = await params;
  const [boq, materials, settings] = await Promise.all([
    prisma.bOQ.findUnique({ where: { id }, include: { items: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] }, project: { select: { id: true, name: true, code: true } } } }),
    prisma.material.findMany({ where: { isActive: true }, orderBy: [{ category: "asc" }, { name: "asc" }], select: { id: true, name: true, brand: true, category: true, rate: true, unit: true, finish: true } }),
    getSettings(),
  ]);
  if (!boq) notFound();
  return (
    <BOQEditor
      marginLabel={settings.boqDefaults.marginLabel}
      materials={materials}
      boq={{
        id: boq.id,
        title: boq.title,
        version: boq.version,
        status: boq.status,
        tier: boq.tier,
        gstRate: boq.gstRate,
        wastagePercent: boq.wastagePercent,
        profitMarginPercent: boq.profitMarginPercent,
        transportCharges: boq.transportCharges,
        installationCharges: boq.installationCharges,
        discountAmount: boq.discountAmount,
        notes: boq.notes,
        verifiedAt: boq.verifiedAt?.toISOString() ?? null,
        verifiedByName: boq.verifiedByName,
        project: boq.project,
        items: boq.items.map((i) => ({ id: i.id, section: i.section, item: i.item, dimensions: i.dimensions, primaryMaterial: i.primaryMaterial, finishBrand: i.finishBrand, hardware: i.hardware, accessories: i.accessories, quantity: i.quantity, unit: i.unit, rate: i.rate, amount: i.amount, itemType: i.itemType, isEstimated: i.isEstimated })),
      }}
    />
  );
}
