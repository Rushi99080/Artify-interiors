import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { formatDate, formatINR } from "@/lib/format";
import { TIER_LABELS } from "@/lib/constants";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";

export default async function BOQListPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  await requireTeam("boq.manage");
  const sp = await searchParams;
  const boqs = await prisma.bOQ.findMany({
    where: {
      ...(sp.status ? { status: sp.status as never } : {}),
      ...(sp.q ? { project: { OR: [{ name: { contains: sp.q, mode: "insensitive" } }, { code: { contains: sp.q, mode: "insensitive" } }] } } : {}),
    },
    orderBy: { updatedAt: "desc" },
    take: 200,
    include: { project: { select: { id: true, name: true, code: true, customer: { select: { fullName: true } } } }, _count: { select: { items: true } }, items: { where: { isEstimated: true }, select: { id: true } } },
  });
  return (
    <>
      <PageHeader title="BOQ management" description="All Bills of Quantities. Generate new versions from a project's BOQ tab." />
      <ListFilters
        placeholder="Search project or code"
        filters={[
          {
            name: "status",
            label: "Status",
            options: [
              { value: "PRELIMINARY", label: "Preliminary" },
              { value: "VERIFIED", label: "Verified" },
              { value: "FINAL", label: "Final" },
            ],
          },
        ]}
      />
      {boqs.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[900px]">
            <thead>
              <tr>
                <th>BOQ</th>
                <th>Project</th>
                <th>Status</th>
                <th>Finish</th>
                <th className="num">Lines</th>
                <th className="num">Unverified</th>
                <th className="num">Grand total</th>
                <th>Updated</th>
              </tr>
            </thead>
            <tbody>
              {boqs.map((b) => (
                <tr key={b.id}>
                  <td>
                    <Link href={`/admin/boq/${b.id}`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                      v{b.version}
                    </Link>
                  </td>
                  <td>
                    <Link href={`/admin/projects/${b.project.id}/boq`} className="text-ink">
                      {b.project.name}
                    </Link>
                    <span className="block text-xs text-smoke">
                      {b.project.code} · {b.project.customer.fullName}
                    </span>
                  </td>
                  <td>
                    <StatusBadge status={b.status} />
                  </td>
                  <td>{TIER_LABELS[b.tier]}</td>
                  <td className="num">{b._count.items}</td>
                  <td className={`num ${b.items.length ? "text-amber" : ""}`}>{b.items.length}</td>
                  <td className="num text-charcoal">{formatINR(b.grandTotal)}</td>
                  <td className="text-smoke">{formatDate(b.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No BOQs yet" description="BOQs are generated from project rooms — by clients (preliminary) or by the team." />
      )}
    </>
  );
}
