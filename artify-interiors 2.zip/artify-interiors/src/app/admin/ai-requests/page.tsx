import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { aiConfig } from "@/lib/ai";
import { formatDate, formatRelative } from "@/lib/format";
import { PageHeader, Panel, StatCard, EmptyState } from "@/components/ui/panel";
import { StatusBadge, Badge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";
import { Notice } from "@/components/ui/notice";

const STATUS_LABELS: Record<string, string> = { PENDING: "Queued", PROCESSING: "Processing", COMPLETED: "Completed", FAILED: "Failed", NOT_CONFIGURED: "Not configured" };

export default async function AIRequestsPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  await requireTeam("designs.manage");
  const sp = await searchParams;
  const where = {
    ...(sp.status ? { status: sp.status as never } : {}),
    ...(sp.q ? { project: { OR: [{ name: { contains: sp.q, mode: "insensitive" as const } }, { code: { contains: sp.q, mode: "insensitive" as const } }] } } : {}),
  };
  const since = new Date(Date.now() - 30 * 86_400_000);
  const [requests, grouped, durations, imageStats] = await Promise.all([
    prisma.aIDesignRequest.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 150,
      include: { project: { select: { id: true, name: true, code: true } }, room: { select: { name: true } }, requestedBy: { select: { name: true, role: true } }, _count: { select: { designs: true } } },
    }),
    prisma.aIDesignRequest.groupBy({ by: ["status"], where: { createdAt: { gte: since } }, _count: { _all: true } }),
    prisma.aIDesignRequest.aggregate({ where: { status: "COMPLETED", createdAt: { gte: since } }, _avg: { durationMs: true } }),
    prisma.generatedDesign.groupBy({ by: ["imageStatus"], where: { createdAt: { gte: since } }, _count: { _all: true } }),
  ]);
  const count = (s: string) => grouped.find((g) => g.status === s)?._count._all ?? 0;
  const total = grouped.reduce((s, g) => s + g._count._all, 0);
  const images = (s: string) => imageStats.find((g) => g.imageStatus === s)?._count._all ?? 0;
  const ai = aiConfig();

  return (
    <>
      <PageHeader title="AI design requests" description="Every concept-generation run: who asked, which provider answered, how long it took and what failed." />

      {!ai.text.configured || !ai.image.configured ? (
        <Notice kind="config" className="mb-5">
          {!ai.text.configured ? <>Concept generation is not configured: {ai.text.detail}. </> : null}
          {!ai.image.configured ? <>Image rendering is not configured: {ai.image.detail}. </> : null}
          See <Link href="/admin/settings?tab=integrations" className="underline">Settings → Integrations</Link>.
        </Notice>
      ) : null}

      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Requests, last 30 days" value={total} hint={`${count("COMPLETED")} completed`} />
        <StatCard label="Failed or not configured" value={count("FAILED") + count("NOT_CONFIGURED")} tone={count("FAILED") ? "amber" : "default"} hint={`${count("FAILED")} failed · ${count("NOT_CONFIGURED")} missing keys`} />
        <StatCard label="Average generation time" value={durations._avg.durationMs ? `${(durations._avg.durationMs / 1000).toFixed(1)}s` : "—"} hint="Completed concept runs" />
        <StatCard label="Images rendered" value={images("COMPLETED")} tone="brass" hint={`${images("FAILED")} failed · ${images("NOT_CONFIGURED")} skipped`} />
      </div>

      <Panel padded={false} className="mb-5 px-5 py-4">
        <dl className="grid gap-3 text-sm sm:grid-cols-3">
          <div>
            <dt className="text-xs text-smoke">Concept provider</dt>
            <dd className="mt-0.5 text-ink">{ai.text.configured ? `${ai.text.provider} · ${ai.text.model}` : <Badge tone="amber">Not configured</Badge>}</dd>
          </div>
          <div>
            <dt className="text-xs text-smoke">Image provider</dt>
            <dd className="mt-0.5 text-ink">{ai.image.configured ? `${ai.image.provider} · ${ai.image.model}` : <Badge tone="amber">Not configured</Badge>}</dd>
          </div>
          <div>
            <dt className="text-xs text-smoke">Variations per request</dt>
            <dd className="mt-0.5 text-ink">{ai.variations}</dd>
          </div>
        </dl>
      </Panel>

      <ListFilters placeholder="Search project or code" filters={[{ name: "status", label: "Status", options: Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label })) }]} />

      {requests.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[1040px]">
            <thead>
              <tr>
                <th>Requested</th>
                <th>Project / room</th>
                <th>By</th>
                <th>Status</th>
                <th>Provider</th>
                <th className="num">Concepts</th>
                <th className="num">Time</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {requests.map((r) => (
                <tr key={r.id}>
                  <td className="whitespace-nowrap">
                    <span className="text-ink">{formatRelative(r.createdAt)}</span>
                    <span className="block text-xs text-smoke">{formatDate(r.createdAt, true)}</span>
                  </td>
                  <td>
                    <Link href={`/admin/projects/${r.project.id}/designs`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                      {r.project.name}
                    </Link>
                    <span className="block text-xs text-smoke">
                      {r.project.code}
                      {r.room ? ` · ${r.room.name}` : " · Whole home"}
                    </span>
                  </td>
                  <td>
                    {r.requestedBy?.name ?? "—"}
                    {r.requestedBy ? <span className="block text-xs text-smoke">{r.requestedBy.role === "CUSTOMER" ? "Client" : "Team"}</span> : null}
                  </td>
                  <td>
                    <StatusBadge status={r.status} label={STATUS_LABELS[r.status]} />
                  </td>
                  <td className="text-xs">
                    {r.textProvider ? (
                      <>
                        {r.textProvider}
                        <span className="block text-smoke">{r.textModel}</span>
                      </>
                    ) : (
                      "—"
                    )}
                    {r.imageProvider ? <span className="block text-smoke">Images: {r.imageProvider}</span> : null}
                  </td>
                  <td className="num">
                    {r._count.designs}/{r.variationsRequested}
                  </td>
                  <td className="num">{r.durationMs ? `${(r.durationMs / 1000).toFixed(1)}s` : "—"}</td>
                  <td className="max-w-80 text-xs">
                    {r.errorMessage ? <span className="text-brick">{r.errorMessage}</span> : null}
                    {r.instructions ? <span className="block text-smoke">“{r.instructions.slice(0, 140)}{r.instructions.length > 140 ? "…" : ""}”</span> : null}
                    {r.inputFileIds.length ? <span className="block text-smoke">{r.inputFileIds.length} reference image{r.inputFileIds.length === 1 ? "" : "s"}</span> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No AI requests yet" description="Requests appear here when a client or the team generates design concepts." />
      )}
    </>
  );
}
