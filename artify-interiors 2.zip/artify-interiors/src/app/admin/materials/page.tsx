import { Download } from "lucide-react";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { can } from "@/lib/auth/permissions";
import { AVAILABILITY_LABELS, MATERIAL_CATEGORIES, MATERIAL_CATEGORY_LABELS, PRICE_TIERS, TIER_LABELS } from "@/lib/constants";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { buttonClass } from "@/components/ui/button";
import { ListFilters } from "@/components/admin/list-filters";
import { ImportMaterialsButton, MaterialsSummary, MaterialsTable, NewMaterialButton, type AdminMaterial } from "@/components/admin/materials-admin";

export default async function AdminMaterialsPage({ searchParams }: { searchParams: Promise<{ q?: string; category?: string; tier?: string; availability?: string; active?: string; supplier?: string }> }) {
  const user = await requireTeam("materials.manage");
  const sp = await searchParams;
  const [materials, suppliers, totals, usedCats] = await Promise.all([
    prisma.material.findMany({
      where: {
        ...(sp.category ? { category: sp.category as never } : {}),
        ...(sp.tier ? { tier: sp.tier as never } : {}),
        ...(sp.availability ? { availability: sp.availability as never } : {}),
        ...(sp.supplier ? { supplierId: sp.supplier } : {}),
        ...(sp.active === "yes" ? { isActive: true } : sp.active === "no" ? { isActive: false } : {}),
        ...(sp.q ? { OR: [{ name: { contains: sp.q, mode: "insensitive" } }, { brand: { contains: sp.q, mode: "insensitive" } }, { productCode: { contains: sp.q, mode: "insensitive" } }, { color: { contains: sp.q, mode: "insensitive" } }] } : {}),
      },
      orderBy: [{ category: "asc" }, { name: "asc" }],
      take: 600,
      include: { supplier: { select: { name: true } }, _count: { select: { boqItems: true, roomMaterials: true } } },
    }),
    prisma.supplier.findMany({ where: { isActive: true }, orderBy: { name: "asc" }, select: { id: true, name: true } }),
    prisma.material.groupBy({ by: ["isActive"], _count: { _all: true } }),
    prisma.material.groupBy({ by: ["category"], where: { isActive: true } }),
  ]);
  const total = totals.reduce((s, t) => s + t._count._all, 0);
  const active = totals.find((t) => t.isActive)?._count._all ?? 0;

  const rows: AdminMaterial[] = materials.map((m) => ({
    id: m.id,
    name: m.name,
    category: m.category,
    brand: m.brand,
    productCode: m.productCode,
    finish: m.finish,
    color: m.color,
    unit: m.unit,
    rate: m.rate,
    imageUrl: m.imageUrl,
    specifications: m.specifications,
    availability: m.availability,
    supplierId: m.supplierId,
    supplierName: m.supplier?.name ?? null,
    tier: m.tier,
    durability: m.durability,
    maintenance: m.maintenance,
    styles: m.styles,
    isActive: m.isActive,
    usage: m._count.boqItems + m._count.roomMaterials,
  }));

  return (
    <>
      <PageHeader
        title="Material library"
        description="Rates here drive every BOQ, cost estimate and AI material recommendation. Click a rate to edit it in place."
        actions={
          <>
            <a href="/api/materials/export" className={buttonClass("ghost")}>
              <Download className="size-4" /> Export
            </a>
            <ImportMaterialsButton />
            <NewMaterialButton suppliers={suppliers} />
          </>
        }
      />
      <MaterialsSummary total={total} active={active} categories={usedCats.length} />
      <ListFilters
        placeholder="Search name, brand, code, colour"
        filters={[
          { name: "category", label: "Category", options: MATERIAL_CATEGORIES.map((c) => ({ value: c, label: MATERIAL_CATEGORY_LABELS[c] })) },
          { name: "tier", label: "Finish level", options: PRICE_TIERS.map((t) => ({ value: t, label: TIER_LABELS[t] })) },
          { name: "availability", label: "Availability", options: Object.entries(AVAILABILITY_LABELS).map(([value, label]) => ({ value, label })) },
          { name: "supplier", label: "Supplier", options: suppliers.map((s) => ({ value: s.id, label: s.name })) },
          { name: "active", label: "Visibility", options: [{ value: "yes", label: "Active" }, { value: "no", label: "Hidden" }] },
        ]}
      />
      {rows.length ? (
        <MaterialsTable key={JSON.stringify(sp)} materials={rows} suppliers={suppliers} canDelete={can(user.role, "materials.delete")} />
      ) : (
        <EmptyState title="No materials match" description="Add materials one by one, or import your supplier price list with the CSV / Excel template." />
      )}
    </>
  );
}
