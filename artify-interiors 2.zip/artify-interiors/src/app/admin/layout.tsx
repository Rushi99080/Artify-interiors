import { requireTeam } from "@/lib/auth/session";
import { PERMISSIONS, can, type Permission } from "@/lib/auth/permissions";
import { AdminSidebar } from "@/components/admin/sidebar";
import { NotificationBell, UserMenu } from "@/components/app/header-widgets";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await requireTeam();
  const permissions = (Object.keys(PERMISSIONS) as Permission[]).filter((p) => can(user.role, p));
  return (
    <div className="min-h-screen bg-plaster">
      <AdminSidebar permissions={permissions} />
      <div className="lg:pl-60">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-line bg-paper/95 pl-14 pr-4 backdrop-blur md:pr-8 lg:pl-8">
          <div className="flex items-center gap-2">
            <p className="text-sm text-smoke">
              {user.role === "ADMIN" ? "Administrator" : "Team member"} · <span className="text-charcoal">Artify Interiors</span>
            </p>
          </div>
          <div className="flex items-center gap-1">
            <NotificationBell />
            <UserMenu name={user.name} email={user.email} profileHref="/admin/profile" />
          </div>
        </header>
        <main id="main" className="px-4 py-6 md:px-8 md:py-8">
          {children}
        </main>
      </div>
    </div>
  );
}
