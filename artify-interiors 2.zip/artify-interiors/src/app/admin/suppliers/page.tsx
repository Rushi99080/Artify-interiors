import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { can } from "@/lib/auth/permissions";
import { MATERIAL_CATEGORY_LABELS, type MaterialCategoryKey } from "@/lib/constants";
import { formatINR } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";
import { DeleteSupplierButton, SupplierFormButton } from "@/components/admin/supplier-actions";

export default async function SuppliersPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const user = await requireTeam("suppliers.manage");
  const sp = await searchParams;
  const [suppliers, spend] = await Promise.all([
    prisma.supplier.findMany({
      where: sp.q ? { OR: [{ name: { contains: sp.q, mode: "insensitive" } }, { contactPerson: { contains: sp.q, mode: "insensitive" } }, { phone: { contains: sp.q } }, { gstin: { contains: sp.q, mode: "insensitive" } }] } : {},
      orderBy: [{ isActive: "desc" }, { name: "asc" }],
      include: { _count: { select: { materials: true } } },
    }),
    prisma.expense.groupBy({ by: ["supplierId"], where: { supplierId: { not: null } }, _sum: { amount: true } }),
  ]);
  const spendOf = (id: string) => spend.find((s) => s.supplierId === id)?._sum.amount ?? 0;
  const canDelete = can(user.role, "materials.delete");

  return (
    <>
      <PageHeader title="Suppliers" description="Vendors behind your material rates. Link materials to a supplier from the material library; project expenses can be tagged to a supplier too." actions={<SupplierFormButton />} />
      <ListFilters placeholder="Search name, contact, phone, GSTIN" />
      {suppliers.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[980px]">
            <thead>
              <tr>
                <th>Supplier</th>
                <th>Contact</th>
                <th>GSTIN</th>
                <th>Supplies</th>
                <th className="num">Materials</th>
                <th className="num">Spend recorded</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {suppliers.map((s) => (
                <tr key={s.id} className={s.isActive ? undefined : "opacity-60"}>
                  <td>
                    <span className="font-medium text-charcoal">{s.name}</span>
                    {!s.isActive ? <Badge className="ml-2">Inactive</Badge> : null}
                    {s.address ? <span className="block max-w-64 truncate text-xs text-smoke">{s.address}</span> : null}
                  </td>
                  <td>
                    {s.contactPerson ?? "—"}
                    <span className="block text-xs text-smoke">
                      {s.phone ? <a href={`tel:${s.phone}`}>{s.phone}</a> : null}
                      {s.phone && s.email ? " · " : null}
                      {s.email ? <a href={`mailto:${s.email}`}>{s.email}</a> : null}
                    </span>
                  </td>
                  <td className="font-mono text-xs">{s.gstin ?? "—"}</td>
                  <td className="max-w-72">
                    <span className="flex flex-wrap gap-1">
                      {s.categories.slice(0, 5).map((c) => (
                        <Badge key={c}>{MATERIAL_CATEGORY_LABELS[c as MaterialCategoryKey] ?? c}</Badge>
                      ))}
                      {s.categories.length > 5 ? <Badge>+{s.categories.length - 5}</Badge> : null}
                    </span>
                  </td>
                  <td className="num">
                    {s._count.materials ? (
                      <Link href={`/admin/materials?supplier=${s.id}`} className="text-ink underline decoration-sand underline-offset-4">
                        {s._count.materials}
                      </Link>
                    ) : (
                      0
                    )}
                  </td>
                  <td className="num">{formatINR(spendOf(s.id))}</td>
                  <td className="whitespace-nowrap text-right">
                    <SupplierFormButton supplier={{ id: s.id, name: s.name, contactPerson: s.contactPerson, phone: s.phone, email: s.email, address: s.address, gstin: s.gstin, categories: s.categories, notes: s.notes, isActive: s.isActive }} />
                    {canDelete ? <DeleteSupplierButton id={s.id} name={s.name} materials={s._count.materials} /> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No suppliers yet" description="Add the vendors you buy plywood, laminates, hardware and finishes from." action={<SupplierFormButton />} />
      )}
    </>
  );
}
