import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { formatDate, formatINR } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";
import { CustomerFormButton } from "@/components/admin/customer-actions";

export default async function CustomersPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  await requireTeam("customers.manage");
  const { q } = await searchParams;
  const customers = await prisma.customer.findMany({
    where: q ? { OR: [{ fullName: { contains: q, mode: "insensitive" } }, { phone: { contains: q } }, { email: { contains: q, mode: "insensitive" } }, { city: { contains: q, mode: "insensitive" } }] } : {},
    orderBy: { createdAt: "desc" },
    take: 300,
    include: { projects: { select: { contractValue: true, status: true } }, user: { select: { lastLoginAt: true } } },
  });
  return (
    <>
      <PageHeader title="Customers" description="Clients with projects or accounts." actions={<CustomerFormButton />} />
      <ListFilters placeholder="Search name, phone, email, city" />
      {customers.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[800px]">
            <thead>
              <tr>
                <th>Customer</th>
                <th>Contact</th>
                <th>City</th>
                <th className="num">Projects</th>
                <th className="num">Contract value</th>
                <th>Account</th>
                <th>Since</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.id}>
                  <td>
                    <Link href={`/admin/customers/${c.id}`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                      {c.fullName}
                    </Link>
                  </td>
                  <td>
                    {c.phone}
                    <span className="block text-xs text-smoke">{c.email}</span>
                  </td>
                  <td>{c.city ?? "—"}</td>
                  <td className="num">{c.projects.length}</td>
                  <td className="num">{formatINR(c.projects.reduce((s, p) => s + (p.contractValue ?? 0), 0))}</td>
                  <td>{c.userId ? <Badge tone="moss">Online account</Badge> : <Badge>Offline</Badge>}</td>
                  <td className="text-smoke">{formatDate(c.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No customers found" />
      )}
    </>
  );
}
