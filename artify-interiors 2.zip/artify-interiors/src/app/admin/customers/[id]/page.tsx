import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { LEAD_STATUS_LABELS, PROJECT_STATUS_LABELS } from "@/lib/constants";
import { formatDate, formatINR } from "@/lib/format";
import { paymentSummary } from "@/lib/calc/payments";
import { PageHeader, Panel, PanelHeader, StatCard } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { CustomerFormButton, TeamNewProjectButton } from "@/components/admin/customer-actions";

export default async function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  await requireTeam("customers.manage");
  const { id } = await params;
  const c = await prisma.customer.findUnique({
    where: { id },
    include: { projects: { orderBy: { createdAt: "desc" }, include: { payments: { select: { amount: true, status: true } } } }, leads: { orderBy: { createdAt: "desc" } }, user: { select: { email: true, lastLoginAt: true, createdAt: true } } },
  });
  if (!c) notFound();
  const totals = c.projects.reduce(
    (acc, p) => {
      const s = paymentSummary(p.contractValue, p.payments);
      return { contract: acc.contract + s.contract, received: acc.received + s.received, pending: acc.pending + s.pending };
    },
    { contract: 0, received: 0, pending: 0 },
  );
  return (
    <>
      <PageHeader
        back={
          <Link href="/admin/customers" className="link-underline text-smoke">
            Customers
          </Link>
        }
        title={c.fullName}
        description={[c.phone, c.email, c.city].filter(Boolean).join(" · ")}
        actions={
          <>
            <CustomerFormButton customer={c} />
            <TeamNewProjectButton customer={c} />
          </>
        }
      />
      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="Contract value" value={formatINR(totals.contract)} />
        <StatCard label="Received" value={formatINR(totals.received)} tone="moss" />
        <StatCard label="Pending" value={formatINR(totals.pending)} tone="amber" />
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <Panel>
          <PanelHeader title="Projects" />
          {c.projects.length ? (
            <ul className="divide-y divide-line-soft">
              {c.projects.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-3">
                  <Link href={`/admin/projects/${p.id}`} className="min-w-0">
                    <span className="block text-charcoal underline decoration-sand underline-offset-4">{p.name}</span>
                    <span className="text-xs text-smoke">
                      {p.code} · {p.location} · created {formatDate(p.createdAt)}
                    </span>
                  </Link>
                  <div className="flex items-center gap-3">
                    <span className="text-sm tabular-nums">{p.contractValue ? formatINR(p.contractValue) : "—"}</span>
                    <StatusBadge status={p.status} label={PROJECT_STATUS_LABELS[p.status]} />
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-smoke">No projects yet.</p>
          )}
        </Panel>
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Account" />
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-smoke">Online account</dt>
                <dd>{c.user ? c.user.email : "No login"}</dd>
              </div>
              {c.user ? (
                <div className="flex justify-between">
                  <dt className="text-smoke">Last login</dt>
                  <dd>{formatDate(c.user.lastLoginAt, true)}</dd>
                </div>
              ) : null}
              <div className="flex justify-between">
                <dt className="text-smoke">Address</dt>
                <dd className="text-right">{c.address ?? "—"}</dd>
              </div>
            </dl>
            {c.notes ? <p className="mt-4 whitespace-pre-line rounded-[var(--radius-sm)] bg-plaster px-3 py-2 text-sm">{c.notes}</p> : null}
          </Panel>
          <Panel>
            <PanelHeader title="Leads" />
            {c.leads.length ? (
              <ul className="space-y-2 text-sm">
                {c.leads.map((l) => (
                  <li key={l.id} className="flex items-center justify-between">
                    <Link href={`/admin/leads/${l.id}`} className="underline decoration-sand underline-offset-4">
                      {l.leadCode}
                    </Link>
                    <StatusBadge status={l.status} label={LEAD_STATUS_LABELS[l.status]} />
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-smoke">No leads linked.</p>
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
