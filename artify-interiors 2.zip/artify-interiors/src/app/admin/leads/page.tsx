import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { LEAD_SOURCE_LABELS, LEAD_STATUS_LABELS, PROPERTY_TYPE_LABELS } from "@/lib/constants";
import { formatDate, formatRelative } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";
import { NewLeadButton } from "@/components/admin/lead-actions";
import { cn } from "@/lib/format";

const STATUSES = Object.keys(LEAD_STATUS_LABELS) as (keyof typeof LEAD_STATUS_LABELS)[];

export default async function LeadsPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string; source?: string; due?: string }> }) {
  await requireTeam("leads.manage");
  const sp = await searchParams;
  const where = {
    ...(sp.status ? { status: sp.status as never } : {}),
    ...(sp.source ? { source: sp.source as never } : {}),
    ...(sp.due ? { followUpDate: { lte: new Date(Date.now() + 86400000) }, status: { notIn: ["CONVERTED", "LOST"] as never[] } } : {}),
    ...(sp.q
      ? { OR: [{ name: { contains: sp.q, mode: "insensitive" as const } }, { phone: { contains: sp.q } }, { email: { contains: sp.q, mode: "insensitive" as const } }, { leadCode: { contains: sp.q, mode: "insensitive" as const } }, { city: { contains: sp.q, mode: "insensitive" as const } }] }
      : {}),
  };
  const [leads, counts, team] = await Promise.all([
    prisma.lead.findMany({ where, orderBy: { createdAt: "desc" }, take: 200, include: { assignedTo: { select: { name: true } } } }),
    prisma.lead.groupBy({ by: ["status"], _count: true }),
    prisma.teamMember.findMany({ where: { isActive: true }, select: { id: true, name: true } }),
  ]);
  const count = (s: string) => counts.find((c) => c.status === s)?._count ?? 0;

  return (
    <>
      <PageHeader title="Leads & CRM" description="Every enquiry from the website, calculator and AI designer — with status, follow-ups and notes." actions={<NewLeadButton team={team} />} />
      <div className="mb-5 grid grid-cols-3 gap-2 sm:grid-cols-6">
        {STATUSES.map((s) => (
          <Link key={s} href={`/admin/leads?status=${s}`} className={cn("rounded-[var(--radius-sm)] border px-3 py-2.5 transition-colors", sp.status === s ? "border-charcoal bg-charcoal text-paper" : "border-line bg-paper hover:border-sand")}>
            <span className={cn("block text-xs", sp.status === s ? "text-sand" : "text-smoke")}>{LEAD_STATUS_LABELS[s]}</span>
            <span className="font-display text-2xl">{count(s)}</span>
          </Link>
        ))}
      </div>
      <ListFilters
        placeholder="Search name, phone, email, lead ID"
        filters={[
          { name: "status", label: "Status", options: STATUSES.map((s) => ({ value: s, label: LEAD_STATUS_LABELS[s] })) },
          { name: "source", label: "Source", options: Object.entries(LEAD_SOURCE_LABELS).map(([value, label]) => ({ value, label })) },
          { name: "due", label: "Follow-up", options: [{ value: "1", label: "Due today or overdue" }] },
        ]}
      />
      {leads.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[900px]">
            <thead>
              <tr>
                <th>Lead</th>
                <th>Contact</th>
                <th>Project</th>
                <th>Source</th>
                <th>Status</th>
                <th>Follow-up</th>
                <th>Assigned</th>
                <th>Received</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((l) => (
                <tr key={l.id}>
                  <td>
                    <Link href={`/admin/leads/${l.id}`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                      {l.name}
                    </Link>
                    <span className="block text-xs text-smoke">{l.leadCode}</span>
                  </td>
                  <td>
                    <a href={`tel:${l.phone}`} className="block text-ink">
                      {l.phone}
                    </a>
                    <span className="text-xs text-smoke">{l.email}</span>
                  </td>
                  <td>
                    {l.projectType ? PROPERTY_TYPE_LABELS[l.projectType] : "—"}
                    <span className="block text-xs text-smoke">{[l.city, l.budget].filter(Boolean).join(" · ")}</span>
                  </td>
                  <td>{LEAD_SOURCE_LABELS[l.source]}</td>
                  <td>
                    <StatusBadge status={l.status} label={LEAD_STATUS_LABELS[l.status]} />
                  </td>
                  <td className={l.followUpDate && l.followUpDate < new Date() && !["CONVERTED", "LOST"].includes(l.status) ? "text-brick" : ""}>{formatDate(l.followUpDate)}</td>
                  <td>{l.assignedTo?.name ?? "—"}</td>
                  <td className="text-smoke">{formatRelative(l.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No leads found" description="Enquiries from the website appear here automatically." />
      )}
    </>
  );
}
