import Link from "next/link";
import { notFound } from "next/navigation";
import { MessageCircle, Phone, Mail } from "lucide-react";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { LEAD_SOURCE_LABELS, LEAD_STATUS_LABELS, PROPERTY_TYPE_LABELS } from "@/lib/constants";
import { formatDate } from "@/lib/format";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { ConvertLeadButton, LeadEditor } from "@/components/admin/lead-actions";
import { ButtonLink } from "@/components/ui/button";

export default async function LeadDetailPage({ params }: { params: Promise<{ id: string }> }) {
  await requireTeam("leads.manage");
  const { id } = await params;
  const lead = await prisma.lead.findUnique({
    where: { id },
    include: { notes: { orderBy: { createdAt: "desc" }, include: { author: { select: { name: true } } } }, project: { select: { id: true, name: true, code: true, status: true } }, customer: { select: { id: true, fullName: true } } },
  });
  if (!lead) notFound();
  const team = await prisma.teamMember.findMany({ where: { isActive: true }, select: { id: true, name: true }, orderBy: { name: "asc" } });
  const wa = lead.phone.replace(/\D/g, "");
  const meta = (lead.meta ?? {}) as Record<string, unknown>;

  return (
    <>
      <PageHeader
        back={
          <Link href="/admin/leads" className="link-underline text-smoke">
            Leads
          </Link>
        }
        title={lead.name}
        description={`${lead.leadCode} · received ${formatDate(lead.createdAt, true)} via ${LEAD_SOURCE_LABELS[lead.source]}`}
        actions={
          lead.project ? (
            <ButtonLink href={`/admin/projects/${lead.project.id}`} variant="secondary">
              Open project {lead.project.code}
            </ButtonLink>
          ) : (
            <ConvertLeadButton leadId={lead.id} defaultName={`${lead.name} — ${lead.projectType ? PROPERTY_TYPE_LABELS[lead.projectType] : "Interiors"}`} defaultLocation={lead.city ?? ""} defaultType={lead.projectType} />
          )
        }
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Enquiry" actions={<StatusBadge status={lead.status} label={LEAD_STATUS_LABELS[lead.status]} />} />
            <div className="flex flex-wrap gap-2">
              <a href={`tel:${lead.phone}`} className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-sm hover:border-sand">
                <Phone className="size-3.5" /> {lead.phone}
              </a>
              {wa ? (
                <a href={`https://wa.me/${wa.length === 10 ? `91${wa}` : wa}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-sm hover:border-sand">
                  <MessageCircle className="size-3.5" /> WhatsApp
                </a>
              ) : null}
              {lead.email ? (
                <a href={`mailto:${lead.email}`} className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-sm hover:border-sand">
                  <Mail className="size-3.5" /> {lead.email}
                </a>
              ) : null}
            </div>
            <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-xs text-smoke">Property</dt>
                <dd className="text-charcoal">{lead.projectType ? PROPERTY_TYPE_LABELS[lead.projectType] : "—"}</dd>
              </div>
              <div>
                <dt className="text-xs text-smoke">City / area</dt>
                <dd className="text-charcoal">{lead.city ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-xs text-smoke">Budget</dt>
                <dd className="text-charcoal">{lead.budget ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-xs text-smoke">Customer record</dt>
                <dd className="text-charcoal">{lead.customer ? <Link href={`/admin/customers/${lead.customer.id}`} className="underline decoration-sand underline-offset-4">{lead.customer.fullName}</Link> : "—"}</dd>
              </div>
            </dl>
            {lead.message ? <p className="mt-5 whitespace-pre-line rounded-[var(--radius-sm)] bg-plaster px-4 py-3 text-sm text-ink">{lead.message}</p> : null}
            {typeof meta.estimate === "number" ? <p className="mt-3 text-xs text-smoke">Online estimate shown to the visitor: ₹{Number(meta.estimate).toLocaleString("en-IN")}</p> : null}
          </Panel>
          <Panel>
            <PanelHeader title="Update lead" />
            <LeadEditor lead={{ id: lead.id, status: lead.status, followUpDate: lead.followUpDate?.toISOString() ?? null, assignedToId: lead.assignedToId, lostReason: lead.lostReason }} team={team} />
          </Panel>
        </div>
        <Panel>
          <PanelHeader title="Activity & notes" />
          {lead.notes.length ? (
            <ol className="space-y-4">
              {lead.notes.map((n) => (
                <li key={n.id} className="border-l-2 border-line pl-4">
                  <p className="whitespace-pre-line text-sm text-ink">{n.note}</p>
                  <p className="mt-1 text-xs text-smoke">
                    {n.author?.name ?? "System"} · {formatDate(n.createdAt, true)}
                  </p>
                </li>
              ))}
            </ol>
          ) : (
            <p className="text-sm text-smoke">No notes yet. Log calls and next steps here.</p>
          )}
        </Panel>
      </div>
    </>
  );
}
