import Link from "next/link";
import { FileDown } from "lucide-react";
import { requireTeam } from "@/lib/auth/session";
import { buildReports, REPORT_PERIODS, type ReportPeriod } from "@/lib/services/reports";
import { EXPENSE_CATEGORY_LABELS, LEAD_SOURCE_LABELS, LEAD_STATUS_LABELS, MATERIAL_CATEGORY_LABELS, PAYMENT_METHOD_LABELS, PROJECT_STATUS_LABELS, type MaterialCategoryKey } from "@/lib/constants";
import { formatDate, formatINR, formatINRCompact } from "@/lib/format";
import { PageHeader, Panel, PanelHeader, StatCard } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { TabNav } from "@/components/ui/tabs";
import { BarsChart, HBars } from "@/components/charts/charts";
import { buttonClass } from "@/components/ui/button";

const EXPORTS = [
  { type: "projects", label: "Projects" },
  { type: "payments", label: "Payments" },
  { type: "expenses", label: "Expenses" },
  { type: "leads", label: "Leads" },
];

export default async function ReportsPage({ searchParams }: { searchParams: Promise<{ period?: string }> }) {
  await requireTeam("reports.view");
  const sp = await searchParams;
  const period = (sp.period && sp.period in REPORT_PERIODS ? sp.period : "fy") as ReportPeriod;
  const r = await buildReports(period);
  const k = r.kpis;

  return (
    <>
      <PageHeader
        title="Reports"
        description={r.from ? `${formatDate(r.from)} – ${formatDate(r.to)}. All figures come from recorded payments, expenses, leads and quotations.` : "All recorded payments, expenses, leads and quotations."}
        actions={
          <div className="flex flex-wrap items-center gap-1">
            <span className="mr-1 text-xs text-smoke">Export CSV:</span>
            {EXPORTS.map((e) => (
              <a key={e.type} href={`/api/reports/export?type=${e.type}`} className={buttonClass("secondary", "sm")}>
                <FileDown className="size-3.5" /> {e.label}
              </a>
            ))}
          </div>
        }
      />
      <TabNav tabs={Object.entries(REPORT_PERIODS).map(([key, label]) => ({ href: key === "fy" ? "/admin/reports" : `/admin/reports?period=${key}`, label, active: key === period }))} />

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Payments received" value={formatINRCompact(k.revenue)} tone="moss" hint={formatINR(k.revenue)} />
        <StatCard label="Expenses recorded" value={formatINRCompact(k.spend)} hint={`Cash margin ${formatINRCompact(k.cashMargin)}`} />
        <StatCard label="Quotations approved" value={k.approvedProposals} tone="brass" hint={`${formatINRCompact(k.approvedValue)} · ${k.proposals ? Math.round((k.approvedProposals / k.proposals) * 100) : 0}% of ${k.proposals} proposals`} />
        <StatCard label="Leads converted" value={`${k.convertedLeads} / ${k.leads}`} hint={k.leads ? `${Math.round((k.convertedLeads / k.leads) * 100)}% conversion` : "No leads in this period"} />
      </div>

      <div className="mb-6 grid gap-6 xl:grid-cols-[2fr_1fr]">
        <Panel>
          <PanelHeader title="Payments received vs expenses" description="By month, inclusive of GST collected." />
          <BarsChart data={r.monthly} xKey="month" money series={[{ key: "revenue", label: "Received" }, { key: "expenses", label: "Expenses" }]} />
        </Panel>
        <div className="grid content-start gap-6">
          <Panel>
            <PanelHeader title="Expenses by category" />
            <HBars rows={r.expensesByCategory.map((e) => ({ label: EXPENSE_CATEGORY_LABELS[e.category as keyof typeof EXPENSE_CATEGORY_LABELS] ?? e.category, value: e.amount }))} money />
          </Panel>
          <Panel>
            <PanelHeader title="Payments by method" />
            <HBars rows={r.paymentsByMethod.map((p) => ({ label: PAYMENT_METHOD_LABELS[p.method as keyof typeof PAYMENT_METHOD_LABELS] ?? p.method, value: p.amount }))} money />
          </Panel>
        </div>
      </div>

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Lead pipeline" description="Current status of leads received in this period." />
          <HBars rows={r.leadFunnel.map((l) => ({ label: LEAD_STATUS_LABELS[l.status as keyof typeof LEAD_STATUS_LABELS], value: l.count }))} />
        </Panel>
        <Panel>
          <PanelHeader title="Lead sources" description="Which channels bring clients who sign." />
          {r.leadSources.length ? (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Source</th>
                  <th className="num">Leads</th>
                  <th className="num">Converted</th>
                  <th className="num">Rate</th>
                </tr>
              </thead>
              <tbody>
                {r.leadSources.map((s) => (
                  <tr key={s.source}>
                    <td>{LEAD_SOURCE_LABELS[s.source as keyof typeof LEAD_SOURCE_LABELS] ?? s.source}</td>
                    <td className="num">{s.total}</td>
                    <td className="num">{s.converted}</td>
                    <td className="num">{s.rate}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="text-sm text-smoke">No leads in this period.</p>
          )}
        </Panel>
      </div>

      <Panel className="mb-6">
        <PanelHeader title="Project profitability" description="Final profit = contract value excluding GST − recorded expenses, shown once a project is completed. Running projects show spend so far as a share of the contract. Planned margin comes from the approved quotation." />
        {r.projects.length ? (
          <div className="overflow-x-auto">
            <table className="data-table min-w-[1000px]">
              <thead>
                <tr>
                  <th>Project</th>
                  <th>Status</th>
                  <th className="num">Contract</th>
                  <th className="num">Received</th>
                  <th className="num">Pending</th>
                  <th className="num">Expenses</th>
                  <th className="num">Planned margin</th>
                  <th className="num">Final profit</th>
                </tr>
              </thead>
              <tbody>
                {r.projects.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <Link href={`/admin/projects/${p.id}`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                        {p.name}
                      </Link>
                      <span className="block text-xs text-smoke">
                        {p.code} · {p.customer}
                      </span>
                    </td>
                    <td>
                      <StatusBadge status={p.status} label={PROJECT_STATUS_LABELS[p.status]} />
                    </td>
                    <td className="num">{formatINR(p.contract)}</td>
                    <td className="num">{formatINR(p.received)}</td>
                    <td className={`num ${p.pending > 0 ? "text-amber" : ""}`}>{formatINR(p.pending)}</td>
                    <td className="num">{formatINR(p.expenses)}</td>
                    <td className="num">{p.plannedMargin ? formatINR(p.plannedMargin) : "—"}</td>
                    <td className={`num ${p.actualProfit != null && p.actualProfit < 0 ? "text-brick" : "text-charcoal"}`}>
                      {p.actualProfit == null ? <span className="text-smoke">{p.expenses > 0 && p.costShare != null ? `Running · ${p.costShare}% spent` : "Running"}</span> : `${formatINR(p.actualProfit)}${p.marginPct != null ? ` (${p.marginPct}%)` : ""}`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-smoke">No contracted projects in this period.</p>
        )}
      </Panel>

      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <Panel>
          <PanelHeader title="Most-specified materials" description="By value in approved quotations." />
          {r.topMaterials.length ? (
            <div className="overflow-x-auto">
              <table className="data-table min-w-[620px]">
                <thead>
                  <tr>
                    <th>Material</th>
                    <th>Category</th>
                    <th className="num">Quantity</th>
                    <th className="num">Value</th>
                  </tr>
                </thead>
                <tbody>
                  {r.topMaterials.map((m, i) => (
                    <tr key={i}>
                      <td>
                        {m.name}
                        {m.brand ? <span className="block text-xs text-smoke">{m.brand}</span> : null}
                      </td>
                      <td>{MATERIAL_CATEGORY_LABELS[m.category as MaterialCategoryKey] ?? m.category}</td>
                      <td className="num">
                        {m.quantity.toLocaleString("en-IN")} {m.unit}
                      </td>
                      <td className="num text-charcoal">{formatINR(m.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-smoke">No approved quotations with library materials in this period.</p>
          )}
        </Panel>
        <Panel>
          <PanelHeader title="AI design activity" />
          <dl className="grid grid-cols-2 gap-4">
            <div>
              <dt className="text-xs text-smoke">Concepts generated</dt>
              <dd className="font-display text-3xl text-charcoal">{k.conceptsGenerated}</dd>
            </div>
            <div>
              <dt className="text-xs text-smoke">Concepts approved</dt>
              <dd className="font-display text-3xl text-charcoal">{k.conceptsApproved}</dd>
            </div>
          </dl>
          <Link href="/admin/ai-requests" className="mt-4 inline-block text-sm text-ink underline decoration-sand underline-offset-4">
            View AI request log
          </Link>
        </Panel>
      </div>
    </>
  );
}
