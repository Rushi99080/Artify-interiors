import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { DESIGN_STATUS_LABELS, DESIGN_STYLES, STYLE_INFO } from "@/lib/constants";
import { PageHeader, EmptyState } from "@/components/ui/panel";
import { ListFilters } from "@/components/admin/list-filters";
import { TabNav } from "@/components/ui/tabs";
import { DesignApprovalList, type ApprovalRow } from "@/components/admin/design-approval-list";

const VIEWS = {
  review: { label: "Needs review", statuses: ["SAVED", "CHANGES_REQUESTED"] },
  approved: { label: "Approved", statuses: ["APPROVED"] },
  rejected: { label: "Rejected", statuses: ["REJECTED"] },
  all: { label: "All concepts", statuses: null },
} as const;

export default async function DesignApprovalPage({ searchParams }: { searchParams: Promise<{ view?: string; q?: string; style?: string; status?: string }> }) {
  await requireTeam("designs.manage");
  const sp = await searchParams;
  const viewKey = (sp.view && sp.view in VIEWS ? sp.view : "review") as keyof typeof VIEWS;
  const view = VIEWS[viewKey];
  const statusFilter = sp.status ? [sp.status] : view.statuses;

  const [designs, counts] = await Promise.all([
    prisma.generatedDesign.findMany({
      where: {
        ...(statusFilter ? { status: { in: statusFilter as never[] } } : {}),
        ...(sp.style ? { style: sp.style as never } : {}),
        ...(sp.q ? { OR: [{ name: { contains: sp.q, mode: "insensitive" } }, { project: { name: { contains: sp.q, mode: "insensitive" } } }, { project: { customer: { fullName: { contains: sp.q, mode: "insensitive" } } } }] } : {}),
      },
      orderBy: { updatedAt: "desc" },
      take: 120,
      include: { room: { select: { name: true } }, project: { select: { id: true, name: true, code: true, customer: { select: { fullName: true } } } } },
    }),
    prisma.generatedDesign.groupBy({ by: ["status"], _count: { _all: true } }),
  ]);
  const countOf = (statuses: readonly string[] | null) => counts.filter((c) => !statuses || statuses.includes(c.status)).reduce((s, c) => s + c._count._all, 0);

  const rows: ApprovalRow[] = designs.map((d) => ({
    id: d.id,
    name: d.name,
    style: d.style,
    tier: d.tier,
    status: d.status,
    imageUrl: d.imageFileId ? `/api/files/${d.imageFileId}` : null,
    palette: Array.isArray(d.colorPalette) ? (d.colorPalette as { hex?: string }[]).map((c) => c?.hex).filter((h): h is string => typeof h === "string") : [],
    budgetMin: d.estimatedBudgetMin,
    budgetMax: d.estimatedBudgetMax,
    customerComment: d.customerComment,
    adminNotes: d.adminNotes,
    updatedAt: d.updatedAt.toISOString(),
    project: { id: d.project.id, name: d.project.name, code: d.project.code, customer: d.project.customer.fullName },
    roomName: d.room?.name ?? null,
  }));

  return (
    <>
      <PageHeader title="Design approval" description="Concepts clients have saved or asked to change. Approving a concept completes the project's design-approval stage and notifies the client." />
      <TabNav tabs={Object.entries(VIEWS).map(([key, v]) => ({ href: key === "review" ? "/admin/designs" : `/admin/designs?view=${key}`, label: v.label, count: countOf(v.statuses), active: key === viewKey }))}
      />
      <ListFilters
        placeholder="Search concept, project or client"
        filters={[
          { name: "style", label: "Style", options: DESIGN_STYLES.map((s) => ({ value: s, label: STYLE_INFO[s].label })) },
          ...(viewKey === "all" ? [{ name: "status", label: "Status", options: Object.entries(DESIGN_STATUS_LABELS).map(([value, label]) => ({ value, label })) }] : []),
        ]}
      />
      {rows.length ? (
        <DesignApprovalList key={`${viewKey}-${sp.q ?? ""}-${sp.style ?? ""}-${sp.status ?? ""}`} rows={rows} />
      ) : (
        <EmptyState title={viewKey === "review" ? "Nothing waiting for review" : "No concepts here"} description="Concepts appear in review when a client saves one or requests changes." />
      )}
    </>
  );
}
