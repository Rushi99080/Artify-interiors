import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { MILESTONE_STATUS_LABELS } from "@/lib/constants";
import { cn, formatDate } from "@/lib/format";
import { computeProgress } from "@/lib/workflow/stages";
import { PageHeader, Panel, PanelHeader, EmptyState } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";

const DAY = 86_400_000;

const SEGMENT_TONE: Record<string, string> = {
  COMPLETED: "bg-charcoal/80",
  IN_PROGRESS: "bg-brass",
  PENDING: "bg-sand/70",
  BLOCKED: "bg-brick",
  SKIPPED: "bg-line",
};

type Segment = { id: string; name: string; status: string; start: number; end: number; overdue: boolean; assignee: string | null; projected: boolean };

export default async function TimelinePage({ searchParams }: { searchParams: Promise<{ q?: string; assignee?: string; scope?: string }> }) {
  await requireTeam("projects.manage");
  const sp = await searchParams;
  const scope = sp.scope === "all" ? undefined : { notIn: ["COMPLETED", "CANCELLED"] as ("COMPLETED" | "CANCELLED")[] };
  const [projects, team, stageDefs] = await Promise.all([
    prisma.project.findMany({
      where: {
        ...(scope ? { status: scope } : {}),
        ...(sp.q ? { OR: [{ name: { contains: sp.q, mode: "insensitive" } }, { code: { contains: sp.q, mode: "insensitive" } }, { customer: { fullName: { contains: sp.q, mode: "insensitive" } } }] } : {}),
        ...(sp.assignee ? { milestones: { some: { assigneeId: sp.assignee } } } : {}),
      },
      orderBy: [{ startDate: "asc" }, { createdAt: "asc" }],
      take: 60,
      include: {
        customer: { select: { fullName: true } },
        milestones: { orderBy: { sortOrder: "asc" }, include: { assignee: { select: { id: true, name: true } } } },
      },
    }),
    prisma.teamMember.findMany({ where: { isActive: true }, orderBy: { name: "asc" }, select: { id: true, name: true } }),
    prisma.workflowStage.findMany({ select: { key: true, defaultDurationDays: true } }),
  ]);
  const durationOf = new Map(stageDefs.map((s) => [s.key, s.defaultDurationDays]));

  const now = Date.now();
  const todayStart = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
  const rows = projects.map((p) => {
    let cursor = (p.startDate ?? p.createdAt).getTime();
    const segments: Segment[] = [];
    for (const m of p.milestones) {
      if (m.status === "SKIPPED") continue;
      // Not started and no due date: project it forward from the previous stage (never into the past).
      const projected = !m.startedAt && !m.completedAt && !m.dueDate;
      const start = m.startedAt?.getTime() ?? (projected || m.status === "PENDING" ? Math.max(cursor, todayStart) : cursor);
      const end = m.completedAt?.getTime() ?? m.dueDate?.getTime() ?? start + Math.max(1, durationOf.get(m.stageKey) ?? 3) * DAY;
      const s = Math.min(start, end);
      segments.push({ id: m.id, name: m.name, status: m.status, start: s, end: Math.max(end, s + DAY / 2), overdue: m.status !== "COMPLETED" && !!m.dueDate && m.dueDate.getTime() < now, assignee: m.assignee?.name ?? null, projected });
      cursor = Math.max(cursor, end);
    }
    return { project: p, segments, progress: computeProgress(p.milestones) };
  });

  const allTimes = rows.flatMap((r) => r.segments.flatMap((s) => [s.start, s.end]));
  const minT = allTimes.length ? Math.max(Math.min(...allTimes), now - 120 * DAY) : now - 30 * DAY;
  const maxT = allTimes.length ? Math.min(Math.max(...allTimes, now + 14 * DAY), now + 365 * DAY) : now + 120 * DAY;
  const startT = startOfWeek(minT - 3 * DAY);
  const endT = startOfWeek(maxT) + 7 * DAY;
  const span = endT - startT;
  const weeks: number[] = [];
  for (let t = startT; t < endT; t += 7 * DAY) weeks.push(t);
  const pct = (t: number) => `${(((Math.min(Math.max(t, startT), endT) - startT) / span) * 100).toFixed(3)}%`;
  const width = (a: number, b: number) => `${(((Math.min(b, endT) - Math.max(a, startT)) / span) * 100).toFixed(3)}%`;

  const upcoming = projects
    .flatMap((p) => p.milestones.filter((m) => m.dueDate && m.status !== "COMPLETED" && m.status !== "SKIPPED" && (!sp.assignee || m.assigneeId === sp.assignee)).map((m) => ({ ...m, project: p })))
    .filter((m) => m.dueDate!.getTime() < now + 14 * DAY)
    .sort((a, b) => a.dueDate!.getTime() - b.dueDate!.getTime())
    .slice(0, 25);

  return (
    <>
      <PageHeader title="Project timeline" description="Every running project's workflow stages on one calendar. Completed stages use actual dates, scheduled stages their due dates, and the rest are projected from each stage's standard duration." />
      <ListFilters
        placeholder="Search project or client"
        filters={[
          { name: "assignee", label: "Assigned to", options: team.map((t) => ({ value: t.id, label: t.name })) },
          { name: "scope", label: "Projects", allLabel: "Running projects", options: [{ value: "all", label: "All projects, incl. completed" }] },
        ]}
      />

      {rows.length ? (
        <Panel padded={false} className="mb-6 overflow-hidden">
          <div className="flex flex-wrap items-center gap-4 border-b border-line px-5 py-3 text-xs text-smoke">
            {(["COMPLETED", "IN_PROGRESS", "PENDING", "BLOCKED"] as const).map((s) => (
              <span key={s} className="inline-flex items-center gap-1.5">
                <span className={cn("h-2.5 w-5 rounded-sm", SEGMENT_TONE[s])} />
                {MILESTONE_STATUS_LABELS[s]}
              </span>
            ))}
            <span className="inline-flex items-center gap-1.5">
              <span className="h-2.5 w-5 rounded-sm bg-sand/70 ring-2 ring-brick ring-inset" /> Overdue
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-3 w-px bg-brick" /> Today
            </span>
          </div>
          <div className="overflow-x-auto">
            <div style={{ minWidth: Math.max(960, 240 + weeks.length * 46), minHeight: rows.length < 3 ? 200 : undefined }}>
              <div className="grid grid-cols-[240px_1fr] border-b border-line bg-plaster/60 text-[0.7rem] text-smoke">
                <div className="px-4 py-2 font-semibold">Project</div>
                <div className="relative h-8">
                  {weeks.map((w, i) =>
                    i % (weeks.length > 30 ? 2 : 1) === 0 ? (
                      <span key={w} className="absolute top-2 -translate-x-1/2 whitespace-nowrap" style={{ left: pct(w + 3.5 * DAY) }}>
                        {new Date(w).toLocaleDateString("en-IN", { day: "numeric", month: "short", timeZone: "Asia/Kolkata" })}
                      </span>
                    ) : null,
                  )}
                </div>
              </div>
              {rows.map(({ project: p, segments, progress }, rowIndex) => (
                <div key={p.id} className="grid grid-cols-[240px_1fr] border-b border-line-soft last:border-b-0">
                  <div className="px-4 py-3">
                    <Link href={`/admin/projects/${p.id}`} className="block truncate text-sm font-medium text-charcoal hover:underline">
                      {p.name}
                    </Link>
                    <span className="block truncate text-xs text-smoke">
                      {p.customer.fullName} · {progress.percent}% done
                    </span>
                  </div>
                  <div className="relative">
                    {weeks.map((w) => (
                      <span key={w} aria-hidden className="absolute inset-y-0 w-px bg-line-soft" style={{ left: pct(w) }} />
                    ))}
                    <span aria-hidden className="absolute inset-y-0 z-10 w-px bg-brick" style={{ left: pct(now) }} />
                    {segments.length ? (
                      <ul className="relative h-full" aria-label={`${p.name} stages`}>
                        {segments.map((s) => (
                          <li
                            key={s.id}
                            className={cn("group absolute top-1/2 h-4 -translate-y-1/2 rounded-[3px] border-r-2 border-paper", SEGMENT_TONE[s.status] ?? "bg-sand", s.projected && "opacity-70", s.overdue && "ring-2 ring-brick ring-inset")}
                            style={{ left: pct(s.start), width: width(s.start, s.end) }}
                            tabIndex={0}
                          >
                            <span className="sr-only">
                              {s.name}: {MILESTONE_STATUS_LABELS[s.status as keyof typeof MILESTONE_STATUS_LABELS]}, {formatDate(new Date(s.start))} to {formatDate(new Date(s.end))}
                            </span>
                            <span role="tooltip" className={cn("pointer-events-none absolute left-1/2 z-20 hidden", rowIndex === 0 ? "top-full mt-2" : "bottom-full mb-2", " w-max max-w-64 -translate-x-1/2 rounded-[var(--radius-sm)] bg-charcoal px-3 py-2 text-xs text-paper shadow-lg group-hover:block group-focus:block")}>
                              <span className="block font-semibold">{s.name}</span>
                              <span className="block text-sand">
                                {MILESTONE_STATUS_LABELS[s.status as keyof typeof MILESTONE_STATUS_LABELS]}
                                {s.overdue ? " · overdue" : ""}
                              </span>
                              <span className="block text-sand">
                                {s.projected ? "Projected " : ""}
                                {formatDate(new Date(s.start))} – {formatDate(new Date(s.end))}
                              </span>
                              {s.assignee ? <span className="block text-sand">Assigned: {s.assignee}</span> : null}
                            </span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="relative px-3 py-4 text-xs text-smoke">No planned dates yet — set a start date on the project to plan stages.</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      ) : (
        <EmptyState title="No projects to show" description="Running projects appear here once they have workflow stages." />
      )}

      <Panel>
        <PanelHeader title="Due in the next 14 days" description="Includes anything already overdue." />
        {upcoming.length ? (
          <div className="overflow-x-auto">
            <table className="data-table min-w-[760px]">
              <thead>
                <tr>
                  <th>Stage</th>
                  <th>Project</th>
                  <th>Status</th>
                  <th>Assigned to</th>
                  <th>Due</th>
                </tr>
              </thead>
              <tbody>
                {upcoming.map((m) => {
                  const overdue = m.dueDate!.getTime() < now;
                  return (
                    <tr key={m.id}>
                      <td className="font-medium text-charcoal">{m.name}</td>
                      <td>
                        <Link href={`/admin/projects/${m.project.id}`} className="text-ink hover:underline">
                          {m.project.name}
                        </Link>
                      </td>
                      <td>
                        <StatusBadge status={m.status} label={MILESTONE_STATUS_LABELS[m.status]} />
                      </td>
                      <td>{m.assignee?.name ?? <span className="text-smoke">Unassigned</span>}</td>
                      <td className={overdue ? "font-semibold text-brick" : "text-ink"}>
                        {formatDate(m.dueDate!)}
                        {overdue ? " · overdue" : ""}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-smoke">Nothing due in the next two weeks.</p>
        )}
      </Panel>
    </>
  );
}

function startOfWeek(t: number) {
  const d = new Date(t);
  d.setUTCHours(0, 0, 0, 0);
  const day = (d.getUTCDay() + 6) % 7; // Monday = 0
  return d.getTime() - day * DAY;
}
