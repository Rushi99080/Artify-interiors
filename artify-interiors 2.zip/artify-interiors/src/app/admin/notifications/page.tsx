import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { integrationStatus } from "@/lib/env";
import { formatDate, formatRelative } from "@/lib/format";
import { PageHeader, Panel, EmptyState } from "@/components/ui/panel";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";

const CHANNEL_LABELS = { IN_APP: "In-app", EMAIL: "Email", WHATSAPP: "WhatsApp" } as const;
const STATUS_LABELS = { SENT: "Sent", PENDING: "Pending", FAILED: "Failed", SKIPPED: "Skipped" } as const;
const EVENT_LABELS: Record<string, string> = {
  NEW_ENQUIRY: "New enquiry",
  DESIGN_COMPLETED: "Design concepts ready",
  DESIGN_APPROVED: "Design decision",
  QUOTATION_GENERATED: "Quotation sent",
  QUOTATION_APPROVED: "Quotation approved",
  QUOTATION_CHANGES_REQUESTED: "Quotation changes requested",
  PAYMENT_RECEIVED: "Payment received",
  PAYMENT_REMINDER: "Payment reminder",
  MILESTONE_UPDATE: "Milestone update",
  MATERIAL_APPROVAL: "Material approval",
  PROJECT_HANDOVER: "Project handover",
  NEW_MESSAGE: "New message",
  TEST: "Test message",
};

export default async function NotificationLogPage({ searchParams }: { searchParams: Promise<{ q?: string; channel?: string; status?: string; event?: string }> }) {
  await requireTeam("settings.manage");
  const sp = await searchParams;
  const since = new Date(Date.now() - 30 * 86_400_000);
  const [rows, summary] = await Promise.all([
    prisma.notification.findMany({
      where: {
        ...(sp.channel ? { channel: sp.channel as never } : { channel: { in: ["EMAIL", "WHATSAPP"] } }),
        ...(sp.status ? { status: sp.status as never } : {}),
        ...(sp.event ? { event: sp.event } : {}),
        ...(sp.q ? { OR: [{ recipient: { contains: sp.q, mode: "insensitive" } }, { title: { contains: sp.q, mode: "insensitive" } }] } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 300,
      include: { user: { select: { name: true } } },
    }),
    prisma.notification.groupBy({ by: ["channel", "status"], where: { createdAt: { gte: since }, channel: { in: ["EMAIL", "WHATSAPP"] } }, _count: { _all: true } }),
  ]);
  const integrations = integrationStatus();
  const count = (channel: string, status: string) => summary.find((s) => s.channel === channel && s.status === status)?._count._all ?? 0;

  return (
    <>
      <PageHeader title="Notification log" description="Every email and WhatsApp message the platform tried to send. A message is marked Sent only when the provider confirmed it." />
      <div className="mb-6 grid gap-3 md:grid-cols-2">
        {(["EMAIL", "WHATSAPP"] as const).map((ch) => {
          const st = ch === "EMAIL" ? integrations.email : integrations.whatsapp;
          return (
            <Panel key={ch} padded={false} className="px-5 py-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-semibold text-charcoal">{CHANNEL_LABELS[ch]}</p>
                {st.configured ? <Badge tone="moss">Configured</Badge> : <Badge tone="amber">Not configured</Badge>}
              </div>
              <p className="mt-1 text-sm text-smoke">{st.detail}</p>
              <p className="mt-3 text-sm text-ink">
                Last 30 days: <strong>{count(ch, "SENT")}</strong> sent · {count(ch, "FAILED")} failed · {count(ch, "SKIPPED")} skipped
              </p>
            </Panel>
          );
        })}
      </div>
      <p className="mb-4 text-sm text-smoke">
        Configure providers and send a test message from{" "}
        <Link href="/admin/settings?tab=integrations" className="text-ink underline decoration-sand underline-offset-4">
          Settings → Integrations
        </Link>
        .
      </p>
      <ListFilters
        placeholder="Search recipient or subject"
        filters={[
          { name: "channel", label: "Channel", options: Object.entries(CHANNEL_LABELS).map(([value, label]) => ({ value, label })) },
          { name: "status", label: "Status", options: Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label })) },
          { name: "event", label: "Event", options: Object.entries(EVENT_LABELS).map(([value, label]) => ({ value, label })) },
        ]}
      />
      {rows.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[1000px]">
            <thead>
              <tr>
                <th>When</th>
                <th>Channel</th>
                <th>Event</th>
                <th>Recipient</th>
                <th>Subject</th>
                <th>Status</th>
                <th>Provider response</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((n) => (
                <tr key={n.id}>
                  <td className="whitespace-nowrap">
                    {formatRelative(n.createdAt)}
                    <span className="block text-xs text-smoke">{formatDate(n.createdAt, true)}</span>
                  </td>
                  <td>{CHANNEL_LABELS[n.channel]}</td>
                  <td className="text-smoke">{EVENT_LABELS[n.event] ?? n.event}</td>
                  <td>
                    {n.recipient ?? "—"}
                    {n.user ? <span className="block text-xs text-smoke">{n.user.name}</span> : null}
                  </td>
                  <td className="max-w-72 truncate" title={n.title}>
                    {n.title}
                  </td>
                  <td>
                    <StatusBadge status={n.status} label={STATUS_LABELS[n.status]} />
                  </td>
                  <td className="max-w-72 text-xs">
                    {n.providerMessageId ? <span className="block truncate font-mono text-smoke" title={n.providerMessageId}>ID {n.providerMessageId}</span> : null}
                    {n.error ? <span className="block text-brick">{n.error}</span> : null}
                    {!n.providerMessageId && !n.error ? "—" : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No messages logged" description="Emails and WhatsApp messages appear here when quotations, payments and milestones trigger them." />
      )}
    </>
  );
}
