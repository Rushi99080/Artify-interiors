import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { getSettings } from "@/lib/settings";
import { PageHeader } from "@/components/ui/panel";
import { TabNav } from "@/components/ui/tabs";
import { AboutEditor, HeroEditor, PortfolioManager, StatsEditor, TestimonialsManager } from "@/components/admin/content-editors";

const TABS = { homepage: "Homepage & about", portfolio: "Portfolio", testimonials: "Testimonials" } as const;

export default async function ContentPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  await requireTeam("content.manage");
  const sp = await searchParams;
  const tab = (sp.tab && sp.tab in TABS ? sp.tab : "homepage") as keyof typeof TABS;

  return (
    <>
      <PageHeader title="Website content" description="Edit what visitors see on the public site. Changes go live as soon as you save." />
      <TabNav tabs={Object.entries(TABS).map(([key, label]) => ({ href: key === "homepage" ? "/admin/content" : `/admin/content?tab=${key}`, label, active: key === tab }))} />
      {tab === "homepage" ? <HomepageTab /> : tab === "portfolio" ? <PortfolioTab /> : <TestimonialsTab />}
    </>
  );
}

async function HomepageTab() {
  const s = await getSettings();
  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <HeroEditor initial={s.hero} />
      <div className="grid content-start gap-6">
        <StatsEditor initial={s.stats} />
        <AboutEditor initial={s.about} />
      </div>
    </div>
  );
}

async function PortfolioTab() {
  const items = await prisma.portfolioProject.findMany({ orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }] });
  return <PortfolioManager items={items.map((p) => ({ id: p.id, slug: p.slug, title: p.title, roomType: p.roomType, style: p.style, location: p.location, areaSqft: p.areaSqft, description: p.description, coverImageUrl: p.coverImageUrl, images: p.images, isPublished: p.isPublished, isFeatured: p.isFeatured, isSample: p.isSample, sortOrder: p.sortOrder }))} />;
}

async function TestimonialsTab() {
  const items = await prisma.testimonial.findMany({ orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }] });
  return <TestimonialsManager items={items.map((t) => ({ id: t.id, name: t.name, location: t.location, projectType: t.projectType, quote: t.quote, rating: t.rating, isPublished: t.isPublished, isSample: t.isSample, sortOrder: t.sortOrder }))} />;
}
