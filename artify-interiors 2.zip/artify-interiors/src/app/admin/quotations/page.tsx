import Link from "next/link";
import { Download } from "lucide-react";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { QUOTATION_STATUS_LABELS } from "@/lib/constants";
import { formatDate, formatINR, formatINRCompact } from "@/lib/format";
import { PageHeader, StatCard, EmptyState } from "@/components/ui/panel";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";

export default async function AdminQuotationsListPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string; kind?: string }> }) {
  await requireTeam("quotations.manage");
  const sp = await searchParams;
  const [quotations, byStatus] = await Promise.all([
    prisma.quotation.findMany({
      where: {
        ...(sp.status ? { status: sp.status as never } : {}),
        ...(sp.kind === "preliminary" ? { isPreliminary: true } : sp.kind === "final" ? { isPreliminary: false } : {}),
        ...(sp.q ? { OR: [{ number: { contains: sp.q, mode: "insensitive" } }, { project: { name: { contains: sp.q, mode: "insensitive" } } }, { project: { customer: { fullName: { contains: sp.q, mode: "insensitive" } } } }] } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 250,
      include: { project: { select: { id: true, name: true, code: true, customer: { select: { fullName: true } } } }, boq: { select: { version: true } } },
    }),
    prisma.quotation.groupBy({ by: ["status"], _count: { _all: true }, _sum: { grandTotal: true } }),
  ]);
  const stat = (s: string) => byStatus.find((x) => x.status === s);
  const decided = (stat("APPROVED")?._count._all ?? 0) + (stat("REJECTED")?._count._all ?? 0);
  const now = Date.now();

  return (
    <>
      <PageHeader title="Quotations" description="Every quotation and revision across projects. Create new ones from a project's BOQ; revise or convert from the project's Quotations tab." />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Awaiting client" value={(stat("SENT")?._count._all ?? 0) + (stat("CHANGES_REQUESTED")?._count._all ?? 0)} hint={`${formatINRCompact((stat("SENT")?._sum.grandTotal ?? 0) + (stat("CHANGES_REQUESTED")?._sum.grandTotal ?? 0))} in play`} tone="brass" />
        <StatCard label="Approved" value={stat("APPROVED")?._count._all ?? 0} hint={formatINRCompact(stat("APPROVED")?._sum.grandTotal ?? 0)} tone="moss" />
        <StatCard label="Approval rate" value={decided ? `${Math.round(((stat("APPROVED")?._count._all ?? 0) / decided) * 100)}%` : "—"} hint="Approved ÷ (approved + rejected)" />
        <StatCard label="Drafts" value={stat("DRAFT")?._count._all ?? 0} hint="Not yet sent to clients" />
      </div>
      <ListFilters
        placeholder="Search number, project or client"
        filters={[
          { name: "status", label: "Status", options: Object.entries(QUOTATION_STATUS_LABELS).map(([value, label]) => ({ value, label })) },
          { name: "kind", label: "Type", options: [{ value: "preliminary", label: "Preliminary" }, { value: "final", label: "Final (site verified)" }] },
        ]}
      />
      {quotations.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[1000px]">
            <thead>
              <tr>
                <th>Quotation</th>
                <th>Project / client</th>
                <th>Status</th>
                <th className="num">GST</th>
                <th className="num">Grand total</th>
                <th>Created</th>
                <th>Valid until</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {quotations.map((q) => {
                const expired = q.validUntil.getTime() < now && (q.status === "SENT" || q.status === "DRAFT");
                return (
                  <tr key={q.id}>
                    <td>
                      <Link href={`/admin/projects/${q.project.id}/quotations`} className="font-medium text-charcoal underline decoration-sand underline-offset-4">
                        {q.number}
                      </Link>
                      <span className="mt-1 flex flex-wrap gap-1">
                        {q.isPreliminary ? <Badge tone="amber">Preliminary</Badge> : <Badge tone="moss">Site verified</Badge>}
                        {q.boq ? <Badge>BOQ v{q.boq.version}</Badge> : null}
                      </span>
                    </td>
                    <td>
                      {q.project.name}
                      <span className="block text-xs text-smoke">
                        {q.project.code} · {q.project.customer.fullName}
                      </span>
                    </td>
                    <td>
                      <StatusBadge status={q.status} label={QUOTATION_STATUS_LABELS[q.status]} />
                      {q.approvedAt ? <span className="mt-1 block text-xs text-smoke">by {q.approvedByName ?? "client"} · {formatDate(q.approvedAt)}</span> : null}
                      {q.clientComment && q.status === "CHANGES_REQUESTED" ? <span className="mt-1 block max-w-56 text-xs text-smoke">“{q.clientComment.slice(0, 90)}”</span> : null}
                    </td>
                    <td className="num">{formatINR(q.gstAmount)}</td>
                    <td className="num text-charcoal">{formatINR(q.grandTotal)}</td>
                    <td className="text-smoke">{formatDate(q.createdAt)}</td>
                    <td className={expired ? "font-medium text-brick" : "text-smoke"}>
                      {formatDate(q.validUntil)}
                      {expired ? " · expired" : ""}
                    </td>
                    <td>
                      <a href={`/api/quotations/${q.id}/pdf`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm text-ink hover:text-charcoal" aria-label={`Download ${q.number} PDF`}>
                        <Download className="size-3.5" /> PDF
                      </a>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="No quotations found" description="Quotations are created from a BOQ version on a project." />
      )}
    </>
  );
}
