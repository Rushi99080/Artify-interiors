import { requireTeam } from "@/lib/auth/session";
import { PageHeader } from "@/components/ui/panel";
import { ProfileForms } from "@/components/app/profile-forms";

export default async function AdminProfilePage() {
  const user = await requireTeam();
  return (
    <>
      <PageHeader title="Your profile" description={`Signed in as ${user.email} · ${user.role === "ADMIN" ? "Admin" : "Staff"}`} />
      <ProfileForms name={user.name} phone={user.phone} email={user.email} />
    </>
  );
}
