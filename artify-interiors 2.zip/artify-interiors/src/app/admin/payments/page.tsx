import Link from "next/link";
import { Download, FileDown } from "lucide-react";
import { prisma } from "@/lib/db";
import { requireTeam } from "@/lib/auth/session";
import { can } from "@/lib/auth/permissions";
import { PAYMENT_METHOD_LABELS } from "@/lib/constants";
import { formatDate, formatINR, formatINRCompact } from "@/lib/format";
import { allocatePayments, paymentSummary } from "@/lib/calc/payments";
import { round2 } from "@/lib/calc/boq";
import { PageHeader, Panel, PanelHeader, StatCard, EmptyState } from "@/components/ui/panel";
import { StatusBadge } from "@/components/ui/badge";
import { ListFilters } from "@/components/admin/list-filters";
import { buttonClass } from "@/components/ui/button";

function fyStart(d = new Date()) {
  const y = d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
  return new Date(y, 3, 1);
}

export default async function AdminPaymentsListPage({ searchParams }: { searchParams: Promise<{ q?: string; method?: string; status?: string }> }) {
  const user = await requireTeam("payments.record");
  const sp = await searchParams;
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const [payments, monthSum, fySum, projects] = await Promise.all([
    prisma.payment.findMany({
      where: {
        ...(sp.method ? { method: sp.method as never } : {}),
        ...(sp.status ? { status: sp.status as never } : {}),
        ...(sp.q ? { OR: [{ receiptNo: { contains: sp.q, mode: "insensitive" } }, { reference: { contains: sp.q, mode: "insensitive" } }, { project: { name: { contains: sp.q, mode: "insensitive" } } }, { project: { customer: { fullName: { contains: sp.q, mode: "insensitive" } } } }] } : {}),
      },
      orderBy: { paidAt: "desc" },
      take: 300,
      include: { project: { select: { id: true, name: true, code: true, customer: { select: { fullName: true } } } }, paymentMilestone: { select: { name: true } }, recordedBy: { select: { name: true } } },
    }),
    prisma.payment.aggregate({ where: { status: "SUCCESS", paidAt: { gte: monthStart } }, _sum: { amount: true }, _count: true }),
    prisma.payment.aggregate({ where: { status: "SUCCESS", paidAt: { gte: fyStart() } }, _sum: { amount: true } }),
    prisma.project.findMany({
      where: { contractValue: { gt: 0 }, status: { notIn: ["CANCELLED"] } },
      select: { id: true, name: true, code: true, contractValue: true, customer: { select: { fullName: true, phone: true } }, payments: { select: { amount: true, status: true } }, paymentMilestones: { orderBy: { sortOrder: "asc" } } },
    }),
  ]);

  // Outstanding & overdue are computed from the same allocation the project pages use.
  let outstanding = 0;
  const overdue: { projectId: string; project: string; code: string; customer: string; phone: string; milestone: string; balance: number; dueDate: Date }[] = [];
  for (const p of projects) {
    const s = paymentSummary(p.contractValue, p.payments);
    outstanding += s.pending;
    for (const m of allocatePayments(p.paymentMilestones, s.received)) {
      const src = p.paymentMilestones.find((x) => x.id === m.id)!;
      if (m.overdue && src.dueDate) overdue.push({ projectId: p.id, project: p.name, code: p.code, customer: p.customer.fullName, phone: p.customer.phone, milestone: src.name, balance: m.balance, dueDate: src.dueDate });
    }
  }
  overdue.sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());
  const listed = round2(payments.filter((p) => p.status === "SUCCESS").reduce((s, p) => s + p.amount, 0));

  return (
    <>
      <PageHeader
        title="Payments"
        description="Receipts across all projects. Record new payments and edit schedules from a project's Payments tab."
        actions={
          can(user.role, "reports.view") ? (
            <a href="/api/reports/export?type=payments" className={buttonClass("secondary", "sm")}>
              <FileDown className="size-3.5" /> Export CSV
            </a>
          ) : null
        }
      />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Received this month" value={formatINRCompact(monthSum._sum.amount ?? 0)} hint={`${monthSum._count} payment${monthSum._count === 1 ? "" : "s"}`} tone="moss" />
        <StatCard label="Received this financial year" value={formatINRCompact(fySum._sum.amount ?? 0)} hint={`Since ${formatDate(fyStart())}`} />
        <StatCard label="Outstanding on contracts" value={formatINRCompact(round2(outstanding))} hint={`${projects.length} contracted project${projects.length === 1 ? "" : "s"}`} tone="brass" />
        <StatCard label="Overdue instalments" value={overdue.length} hint={overdue.length ? formatINRCompact(round2(overdue.reduce((s, o) => s + o.balance, 0))) : "Nothing overdue"} tone={overdue.length ? "amber" : "default"} />
      </div>

      {overdue.length ? (
        <Panel className="mb-6">
          <PanelHeader title="Overdue instalments" description="Send a reminder from the project's Payments tab — the client gets an email (and WhatsApp, if configured)." />
          <div className="overflow-x-auto">
            <table className="data-table min-w-[720px]">
              <thead>
                <tr>
                  <th>Project</th>
                  <th>Milestone</th>
                  <th>Due</th>
                  <th className="num">Balance</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {overdue.slice(0, 20).map((o) => (
                  <tr key={`${o.projectId}-${o.milestone}`}>
                    <td>
                      {o.project}
                      <span className="block text-xs text-smoke">
                        {o.customer} · {o.phone}
                      </span>
                    </td>
                    <td>{o.milestone}</td>
                    <td className="font-medium text-brick">{formatDate(o.dueDate)}</td>
                    <td className="num text-charcoal">{formatINR(o.balance)}</td>
                    <td className="text-right">
                      <Link href={`/admin/projects/${o.projectId}/payments`} className="text-sm text-ink underline decoration-sand underline-offset-4">
                        Open payments
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      ) : null}

      <ListFilters
        placeholder="Search receipt, reference, project or client"
        filters={[
          { name: "method", label: "Method", options: Object.entries(PAYMENT_METHOD_LABELS).map(([value, label]) => ({ value, label })) },
          { name: "status", label: "Status", options: [{ value: "SUCCESS", label: "Successful" }, { value: "PENDING", label: "Pending" }, { value: "FAILED", label: "Failed" }] },
        ]}
      />
      {payments.length ? (
        <div className="overflow-x-auto rounded-[var(--radius-md)] border border-line bg-paper">
          <table className="data-table min-w-[1000px]">
            <thead>
              <tr>
                <th>Date</th>
                <th>Receipt</th>
                <th>Project / client</th>
                <th>Method</th>
                <th>Milestone</th>
                <th>Status</th>
                <th className="num">Amount</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id}>
                  <td className="whitespace-nowrap text-ink">{formatDate(p.paidAt)}</td>
                  <td>
                    <span className="font-medium text-charcoal">{p.receiptNo ?? "—"}</span>
                    {p.reference ? <span className="block text-xs text-smoke">Ref: {p.reference}</span> : null}
                  </td>
                  <td>
                    <Link href={`/admin/projects/${p.project.id}/payments`} className="text-ink underline decoration-sand underline-offset-4">
                      {p.project.name}
                    </Link>
                    <span className="block text-xs text-smoke">
                      {p.project.code} · {p.project.customer.fullName}
                    </span>
                  </td>
                  <td>
                    {PAYMENT_METHOD_LABELS[p.method]}
                    {p.recordedBy ? <span className="block text-xs text-smoke">by {p.recordedBy.name}</span> : null}
                  </td>
                  <td className="text-smoke">{p.paymentMilestone?.name ?? "—"}</td>
                  <td>
                    <StatusBadge status={p.status} label={p.status === "SUCCESS" ? "Received" : p.status === "PENDING" ? "Pending" : "Failed"} />
                  </td>
                  <td className="num text-charcoal">{formatINR(p.amount)}</td>
                  <td>
                    {p.status === "SUCCESS" && p.receiptNo ? (
                      <a href={`/api/payments/${p.id}/receipt`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm text-ink hover:text-charcoal" aria-label={`Download receipt ${p.receiptNo}`}>
                        <Download className="size-3.5" /> Receipt
                      </a>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={6} className="text-right text-sm text-smoke">
                  Successful payments in this list
                </td>
                <td className="num font-semibold text-charcoal">{formatINR(listed)}</td>
                <td />
              </tr>
            </tfoot>
          </table>
        </div>
      ) : (
        <EmptyState title="No payments found" description="Payments recorded by the team or paid online by clients appear here." />
      )}
    </>
  );
}
