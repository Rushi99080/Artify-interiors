import Link from "next/link";
import { Logo } from "@/components/brand/logo";
import { buttonClass } from "@/components/ui/button";

export const metadata = { title: "Page not found" };

export default function NotFound() {
  return (
    <main id="main" className="grid min-h-screen place-items-center bg-plaster px-4 py-16">
      <div className="max-w-md text-center">
        <Link href="/" className="inline-block">
          <Logo />
        </Link>
        <p className="mt-10 font-display text-7xl text-charcoal" aria-hidden>
          404
        </p>
        <h1 className="mt-2 text-3xl">This room hasn&apos;t been built yet</h1>
        <p className="mt-3 text-smoke">The page you were looking for doesn&apos;t exist or has moved. Check the address, or head back to a page that does.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/" className={buttonClass("primary")}>
            Go to the homepage
          </Link>
          <Link href="/dashboard" className={buttonClass("secondary")}>
            Open my dashboard
          </Link>
        </div>
      </div>
    </main>
  );
}
