import { describe, expect, it } from "vitest";
import { parseMaterialRows, IMPORT_COLUMNS } from "@/lib/materials/import";
import { recommendMaterials, scoreMaterial, type RecMaterial } from "@/lib/materials/recommend";

describe("material import parsing", () => {
  it("accepts template rows, normalises values and reports bad rows with row numbers", () => {
    const rows = [
      { "Material Name": "Oak Laminate 1mm", Category: "Laminate", Brand: "Greenlam", "Product Code": "LAM-9", Unit: "sheet", Rate: "₹2,450", Tier: "Signature", "Durability (1-5)": "4", Styles: "Japandi, Scandinavian, Disco" },
      { "Material Name": "", Category: "Laminate", Unit: "sheet", Rate: "10" },
      { "Material Name": "Mystery", Category: "Unobtainium", Unit: "nos", Rate: "abc" },
      { "Material Name": "Dup", Category: "Laminate", "Product Code": "lam-9", Unit: "sheet", Rate: "1" },
      { "Material Name": "", Category: "", Unit: "", Rate: "" },
    ];
    const { valid, errors } = parseMaterialRows(rows);
    expect(valid).toHaveLength(1);
    expect(valid[0]).toMatchObject({ name: "Oak Laminate 1mm", category: "LAMINATE", rate: 2450, tier: "STANDARD", durability: 4, maintenance: 3, styles: ["JAPANDI", "SCANDINAVIAN"], availability: "IN_STOCK" });
    expect(errors.map((e) => e.row)).toEqual([3, 4, 5]);
    expect(errors[1]!.message).toMatch(/Unknown category/);
    expect(errors[1]!.message).toMatch(/Rate/);
    expect(errors[2]!.message).toMatch(/Duplicate product code/);
  });

  it("exposes the template columns", () => {
    expect(IMPORT_COLUMNS).toContain("Material Name");
    expect(IMPORT_COLUMNS).toContain("Rate");
  });
});

describe("material recommendations", () => {
  const base: Omit<RecMaterial, "id" | "name" | "tier" | "styles"> = { category: "LAMINATE", brand: null, finish: null, color: null, unit: "sheet", rate: 2000, durability: 3, maintenance: 3, availability: "IN_STOCK" };
  const lib: RecMaterial[] = [
    { ...base, id: "1", name: "Walnut matte laminate", tier: "STANDARD", styles: ["MODERN"], color: "Walnut", finish: "Matte" },
    { ...base, id: "2", name: "High gloss white", tier: "LUXURY", styles: ["CONTEMPORARY"] },
    { ...base, id: "3", name: "Oak suede laminate", tier: "STANDARD", styles: ["JAPANDI"] },
    { ...base, id: "4", name: "Discontinued walnut", tier: "STANDARD", styles: ["MODERN"], availability: "DISCONTINUED" },
  ];

  it("never recommends discontinued or inactive materials", () => {
    expect(scoreMaterial(lib[3]!, { style: "MODERN" })).toBeNull();
    expect(scoreMaterial({ ...lib[0]!, isActive: false }, {})).toBeNull();
  });

  it("ranks by style, finish level and stated preferences", () => {
    const recs = recommendMaterials(lib, { style: "MODERN", tier: "STANDARD", preferences: "walnut, matte" });
    expect(recs.LAMINATE?.map((r) => r.material.id)).toEqual(["1", "3", "2"]);
    expect(recs.LAMINATE?.[0]!.reasons.length).toBeGreaterThan(0);
    expect(recommendMaterials(lib, {}, { perCategory: 1 }).LAMINATE).toHaveLength(1);
  });
});
