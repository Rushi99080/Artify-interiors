import { describe, expect, it } from "vitest";
import { estimateRooms, generateRoomLines, mergeRateCard, resolveDims, tierFromBudget, DEFAULT_RATE_CARD, BOQ_SECTIONS } from "@/lib/boq/engine";
import { LAYOUT_PRESETS } from "@/lib/boq/presets";
import { lineAmount } from "@/lib/calc/boq";

describe("BOQ engine", () => {
  it("falls back to module defaults for missing or invalid dimensions", () => {
    const d = resolveDims({ name: "Kitchen", type: "KITCHEN", lengthFt: null, widthFt: -3, heightFt: 0 });
    expect(d.lengthFt).toBeGreaterThan(0);
    expect(d.widthFt).toBeGreaterThan(0);
    expect(d.heightFt).toBeGreaterThan(0);
  });

  it("generates priced, sectioned lines whose amounts are quantity × rate", () => {
    const lines = generateRoomLines({ name: "Kitchen", type: "KITCHEN", lengthFt: 10, widthFt: 8, heightFt: 10 }, "STANDARD");
    expect(lines.length).toBeGreaterThan(3);
    for (const l of lines) {
      expect(BOQ_SECTIONS as readonly string[]).toContain(l.section);
      expect(l.quantity).toBeGreaterThan(0);
      expect(l.rate).toBeGreaterThanOrEqual(0);
      expect(l.amount).toBe(lineAmount(l.quantity, l.rate));
    }
  });

  it("marks AI/dimension-derived quantities as preliminary estimates", () => {
    const lines = generateRoomLines({ name: "Bedroom", type: "MASTER_BEDROOM" }, "STANDARD");
    expect(lines.every((l) => l.isEstimated)).toBe(true);
  });

  it("costs more at higher finish levels", () => {
    const rooms = LAYOUT_PRESETS.find((p) => p.key === "2BHK")!.rooms;
    const totals = (["ECONOMY", "STANDARD", "PREMIUM", "LUXURY"] as const).map((t) => estimateRooms(rooms, t).totals.grandTotal);
    for (let i = 1; i < totals.length; i++) expect(totals[i]!).toBeGreaterThan(totals[i - 1]!);
  });

  it("produces a realistic 2BHK estimate (₹8L–₹35L at Signature level incl. GST)", () => {
    const rooms = LAYOUT_PRESETS.find((p) => p.key === "2BHK")!.rooms;
    const g = estimateRooms(rooms, "STANDARD").totals.grandTotal;
    expect(g).toBeGreaterThan(800000);
    expect(g).toBeLessThan(3500000);
  });

  it("merges admin rate-card overrides onto defaults and ignores invalid values", () => {
    const key = Object.keys(DEFAULT_RATE_CARD)[0]!;
    const merged = mergeRateCard({ [key]: { rates: { STANDARD: 9999, PREMIUM: -5 } }, NOT_A_KEY: { rates: { STANDARD: 1 } } });
    expect(merged[key]!.rates.STANDARD).toBe(9999);
    expect(merged[key]!.rates.PREMIUM).toBe(DEFAULT_RATE_CARD[key]!.rates.PREMIUM);
    expect(merged).not.toHaveProperty("NOT_A_KEY");
  });

  it("maps budget per sqft to a finish level", () => {
    expect(tierFromBudget(null, 1000)).toBe("STANDARD");
    expect(tierFromBudget(900000, 1000)).toBe("ECONOMY");
    expect(tierFromBudget(1500000, 1000)).toBe("STANDARD");
    expect(tierFromBudget(2500000, 1000)).toBe("PREMIUM");
    expect(tierFromBudget(5000000, 1000)).toBe("LUXURY");
  });
});
