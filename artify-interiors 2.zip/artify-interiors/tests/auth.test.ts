import { describe, expect, it } from "vitest";
import { hashPassword, passwordProblem, verifyPassword } from "@/lib/auth/password";
import { signSession, verifySession, isTeamRole } from "@/lib/auth/token";
import { can, PERMISSIONS } from "@/lib/auth/permissions";

describe("passwords", () => {
  it("hashes with bcrypt and verifies only the right password", async () => {
    const hash = await hashPassword("Artify2026secure");
    expect(hash).not.toContain("Artify2026secure");
    expect(hash.startsWith("$2")).toBe(true);
    expect(await verifyPassword("Artify2026secure", hash)).toBe(true);
    expect(await verifyPassword("artify2026secure", hash)).toBe(false);
    expect(await verifyPassword("anything", "")).toBe(false);
  });
  it("enforces the password policy", () => {
    expect(passwordProblem("short1")).toMatch(/8 characters/);
    expect(passwordProblem("onlyletters")).toMatch(/letters and numbers/);
    expect(passwordProblem("12345678")).toMatch(/letters and numbers/);
    expect(passwordProblem("Interior2026")).toBeNull();
  });
});

describe("session tokens", () => {
  it("round-trips a signed session", async () => {
    const token = await signSession({ sub: "user_1", role: "CUSTOMER", name: "Asha" });
    const s = await verifySession(token);
    expect(s).toMatchObject({ sub: "user_1", role: "CUSTOMER", name: "Asha" });
  });
  it("rejects tampered, expired and garbage tokens", async () => {
    const token = await signSession({ sub: "user_1", role: "CUSTOMER", name: "Asha" });
    const [h, p, sig] = token.split(".");
    const forged = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(p!, "base64url").toString()), role: "ADMIN" })).toString("base64url");
    expect(await verifySession(`${h}.${forged}.${sig}`)).toBeNull();
    expect(await verifySession(await signSession({ sub: "u", role: "ADMIN", name: "x" }, -10))).toBeNull();
    expect(await verifySession("not-a-token")).toBeNull();
    expect(await verifySession(undefined)).toBeNull();
  });
});

describe("role-based access", () => {
  it("keeps customers out of every team permission", () => {
    for (const perm of Object.keys(PERMISSIONS) as (keyof typeof PERMISSIONS)[]) expect(can("CUSTOMER", perm)).toBe(false);
  });
  it("gives staff operations but not admin-only areas", () => {
    expect(can("STAFF", "leads.manage")).toBe(true);
    expect(can("STAFF", "boq.manage")).toBe(true);
    expect(can("STAFF", "settings.manage")).toBe(false);
    expect(can("STAFF", "team.manage")).toBe(false);
    expect(can("STAFF", "payments.delete")).toBe(false);
    expect(can("STAFF", "reports.view")).toBe(false);
  });
  it("gives admins everything", () => {
    for (const perm of Object.keys(PERMISSIONS) as (keyof typeof PERMISSIONS)[]) expect(can("ADMIN", perm)).toBe(true);
    expect(can(null, "admin.access")).toBe(false);
    expect(isTeamRole("STAFF")).toBe(true);
    expect(isTeamRole("CUSTOMER")).toBe(false);
  });
});
