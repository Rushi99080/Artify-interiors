import { describe, expect, it } from "vitest";
import { computeBOQTotals, lineAmount, paymentMilestoneStatus, round2, splitPaymentSchedule, type BOQCharges } from "@/lib/calc/boq";
import { allocatePayments, paymentSummary } from "@/lib/calc/payments";

const NO_CHARGES: BOQCharges = { gstRate: 0, wastagePercent: 0, profitMarginPercent: 0, transportCharges: 0, installationCharges: 0, discountAmount: 0 };

describe("round2 & lineAmount", () => {
  it("rounds to paise without floating point drift", () => {
    expect(round2(1.005)).toBe(1.01);
    expect(round2(2.675)).toBe(2.68);
    expect(round2(-1.005)).toBe(-1.01);
    expect(round2(0.1 + 0.2)).toBe(0.3);
    expect(round2(Number.NaN)).toBe(0);
  });
  it("Amount = Quantity × Rate", () => {
    expect(lineAmount(12.5, 1650)).toBe(20625);
    expect(lineAmount(3.33, 3.33)).toBe(11.09);
    expect(lineAmount(Number.NaN, 10)).toBe(0);
  });
});

describe("computeBOQTotals", () => {
  const items = [
    { section: "Kitchen", quantity: 10, rate: 1000, itemType: "MATERIAL" as const }, // 10,000
    { section: "Kitchen", quantity: 2, rate: 2500, itemType: "LABOUR" as const }, //  5,000
    { section: "Painting", quantity: 100, rate: 50, itemType: "SERVICE" as const }, // 5,000
  ];

  it("sums line amounts into subtotal and cost buckets", () => {
    const t = computeBOQTotals(items, NO_CHARGES);
    expect(t.subtotal).toBe(20000);
    expect(t.materialCost).toBe(10000);
    expect(t.labourCost).toBe(5000);
    expect(t.serviceCost).toBe(5000);
    expect(t.grandTotal).toBe(20000);
  });

  it("applies wastage on material only, margin on the loaded cost, GST on the taxable value", () => {
    const t = computeBOQTotals(items, { gstRate: 18, wastagePercent: 5, profitMarginPercent: 10, transportCharges: 1000, installationCharges: 500, discountAmount: 2000 });
    expect(t.wastageAmount).toBe(500); // 5% of 10,000 material
    expect(t.profitAmount).toBe(2200); // 10% of (20,000 + 500 + 1,000 + 500)
    expect(t.additionalCharges).toBe(4200); // 500 + 1,000 + 500 + 2,200
    expect(t.taxableAmount).toBe(22200); // 20,000 + 4,200 − 2,000
    expect(t.gstAmount).toBe(3996); // 18% of 22,200
    // Grand Total = Subtotal + GST + Additional charges − Discount
    expect(t.grandTotal).toBe(20000 + 3996 + 4200 - 2000);
  });

  it("orders sections and counts items", () => {
    const t = computeBOQTotals(items, NO_CHARGES, ["Painting", "Kitchen"]);
    expect(t.sections.map((s) => s.section)).toEqual(["Painting", "Kitchen"]);
    expect(t.sections[1]).toEqual({ section: "Kitchen", amount: 15000, items: 2 });
  });

  it("never lets the discount exceed the bill or accepts negative inputs", () => {
    const t = computeBOQTotals([{ section: "A", quantity: -5, rate: 100, itemType: "MATERIAL" }, { section: "A", quantity: 1, rate: 100, itemType: "MATERIAL" }], { ...NO_CHARGES, discountAmount: 1e9, gstRate: 18 });
    expect(t.subtotal).toBe(100);
    expect(t.discountAmount).toBe(100);
    expect(t.grandTotal).toBe(0);
  });

  it("keeps paise-accurate totals across many fractional lines", () => {
    const many = Array.from({ length: 333 }, () => ({ section: "X", quantity: 1.1, rate: 3.03, itemType: "MATERIAL" as const }));
    const t = computeBOQTotals(many, { ...NO_CHARGES, gstRate: 18 });
    expect(t.subtotal).toBe(round2(333 * 3.33));
    expect(t.gstAmount).toBe(round2(t.subtotal * 0.18));
  });
});

describe("payment schedule", () => {
  it("splits a contract so the instalments add up exactly", () => {
    const split = splitPaymentSchedule(1354294.61, [
      { name: "Booking", percent: 10 },
      { name: "Production", percent: 40 },
      { name: "Delivery", percent: 40 },
      { name: "Handover", percent: 10 },
    ]);
    expect(split.map((s) => s.amount)).toEqual([135429.46, 541717.84, 541717.84, 135429.47]);
    expect(round2(split.reduce((s, x) => s + x.amount, 0))).toBe(1354294.61);
  });
  it("rejects schedules that do not total 100%", () => {
    expect(() => splitPaymentSchedule(1000, [{ name: "A", percent: 60 }])).toThrow(/100%/);
  });
  it("derives milestone status", () => {
    expect(paymentMilestoneStatus(1000, 0)).toBe("PENDING");
    expect(paymentMilestoneStatus(1000, 400)).toBe("PARTIAL");
    expect(paymentMilestoneStatus(1000, 999.995)).toBe("PAID");
  });
});

describe("payment allocation", () => {
  const ms = [
    { id: "a", amount: 100000, sortOrder: 0, dueDate: new Date("2026-01-01") },
    { id: "b", amount: 400000, sortOrder: 1, dueDate: new Date("2026-02-01") },
    { id: "c", amount: 500000, sortOrder: 2, dueDate: null },
  ];
  it("allocates receipts to the oldest milestone first and flags overdue balances", () => {
    const out = allocatePayments(ms, 150000, new Date("2026-03-01"));
    expect(out.map((m) => [m.id, m.received, m.balance, m.status, m.overdue])).toEqual([
      ["a", 100000, 0, "PAID", false],
      ["b", 50000, 350000, "PARTIAL", true],
      ["c", 0, 500000, "PENDING", false],
    ]);
  });
  it("summarises contract, received and pending", () => {
    const s = paymentSummary(1000000, [
      { amount: 150000, status: "SUCCESS" },
      { amount: 50000, status: "FAILED" },
    ]);
    expect(s).toMatchObject({ contract: 1000000, received: 150000, pending: 850000, percent: 15, status: "PARTIAL" });
    expect(paymentSummary(null, []).status).toBe("NO_CONTRACT");
  });
});
