import { describe, expect, it } from "vitest";
import { amountInWordsINR, buildQuotationSnapshot, numberToIndianWords, type SnapshotInput } from "@/lib/quotation/snapshot";
import { renderQuotationPdf } from "@/lib/pdf/quotation";
import { renderReceiptPdf } from "@/lib/pdf/receipt";

const input: SnapshotInput = {
  company: { name: "ARTIFY INTERIORS", legalName: "Artify Interiors", tagline: "Luxury Interior Design Studio", address: "Pune", phone: "", email: "", website: "", gstin: "", logoUrl: "", bankDetails: "" },
  client: { name: "Test Client", email: "client@example.com", phone: "9800000000", address: "Baner, Pune" },
  project: { name: "Test 2BHK", code: "ART-2026-0001", location: "Baner, Pune", address: null, propertyType: "APARTMENT", carpetAreaSqft: 850 },
  marginLabel: "Design, supervision & project management",
  boq: {
    id: "boq1",
    title: "BOQ v1",
    version: 1,
    status: "PRELIMINARY",
    tier: "STANDARD",
    gstRate: 18,
    wastagePercent: 5,
    profitMarginPercent: 15,
    transportCharges: 5000,
    installationCharges: 0,
    discountAmount: 10000,
    items: [
      { section: "Painting", item: "Wall painting — Living", dimensions: "14×12×10 ft", primaryMaterial: "Royale Matt", finishBrand: "Asian Paints", hardware: null, accessories: null, quantity: 520, unit: "sqft", rate: 32, itemType: "SERVICE", isEstimated: true, materialId: null, sortOrder: 2 },
      { section: "Kitchen", item: "Base cabinets", dimensions: "10 ft run", primaryMaterial: "BWP Plywood 18mm", finishBrand: "Matte laminate", hardware: "Hettich soft-close", accessories: null, quantity: 25, unit: "sqft", rate: 1800, itemType: "MATERIAL", isEstimated: true, materialId: "m1", sortOrder: 1 },
      { section: "Kitchen", item: "Quartz countertop", dimensions: "10 × 2 ft", primaryMaterial: "Quartz 15mm", finishBrand: "Kalinga Stone", hardware: null, accessories: null, quantity: 20, unit: "sqft", rate: 320, itemType: "MATERIAL", isEstimated: false, materialId: "m2", sortOrder: 0 },
    ],
  },
  specs: { m2: "15mm engineered quartz, polished edge" },
  now: new Date("2026-10-01T10:00:00Z"),
};

describe("quotation snapshot", () => {
  const snap = buildQuotationSnapshot(input);

  it("groups items by section in BOQ order and numbers them", () => {
    expect(snap.sections.map((s) => s.section)).toEqual(["Kitchen", "Painting"]);
    expect(snap.sections[0]!.items.map((i) => i.item)).toEqual(["Quartz countertop", "Base cabinets"]);
    expect(snap.sections.flatMap((s) => s.items).map((i) => i.srNo)).toEqual([1, 2, 3]);
  });

  it("computes the same totals as the BOQ calculator", () => {
    expect(snap.totals.subtotal).toBe(16640 + 6400 + 45000);
    expect(snap.totals.grandTotal).toBe(snap.totals.subtotal + snap.totals.gstAmount + snap.totals.additionalCharges - snap.totals.discountAmount);
  });

  it("flags preliminary quotations and carries library specifications", () => {
    expect(snap.boq.isPreliminary).toBe(true);
    expect(snap.materialSpecs.find((m) => m.name === "Quartz 15mm")?.specifications).toMatch(/engineered quartz/);
    expect(buildQuotationSnapshot({ ...input, boq: { ...input.boq, status: "VERIFIED" } }).boq.isPreliminary).toBe(false);
  });

  it("is immutable data (plain JSON round-trip)", () => {
    expect(JSON.parse(JSON.stringify(snap))).toEqual(snap);
  });
});

describe("amount in words (Indian numbering)", () => {
  it.each([
    [0, "Zero"],
    [15, "Fifteen"],
    [101, "One Hundred One"],
    [1500, "One Thousand Five Hundred"],
    [150000, "One Lakh Fifty Thousand"],
    [1354294, "Thirteen Lakh Fifty-Four Thousand Two Hundred Ninety-Four"],
    [25000000, "Two Crore Fifty Lakh"],
  ])("%d → %s", (n, words) => expect(numberToIndianWords(n)).toBe(words));

  it("adds paise and handles rounding at the paise boundary", () => {
    expect(amountInWordsINR(1354294.61)).toBe("Rupees Thirteen Lakh Fifty-Four Thousand Two Hundred Ninety-Four and Sixty-One Paise Only");
    expect(amountInWordsINR(0.999)).toBe("Rupees One Only");
  });
});

describe("PDF generation", () => {
  it("renders a branded quotation PDF", async () => {
    const pdf = await renderQuotationPdf({
      number: "AIQ/2026-27/0001",
      revision: 0,
      status: "SENT",
      isPreliminary: true,
      createdAt: new Date("2026-10-01"),
      validUntil: new Date("2026-10-16"),
      scopeOfWork: "Design and execution.",
      paymentTerms: "10% booking",
      timelineText: "45 days",
      terms: "1. Test terms.",
      snapshot: buildQuotationSnapshot(input),
    });
    expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
    expect(pdf.length).toBeGreaterThan(10000);
  });

  it("renders a payment receipt PDF", async () => {
    const pdf = await renderReceiptPdf({
      receiptNo: "RCPT/2026-27/00001",
      paidAt: new Date("2026-10-02"),
      amount: 150000,
      method: "UPI",
      reference: "UPI-1",
      milestoneName: "Booking advance",
      company: { name: "ARTIFY INTERIORS", legalName: "Artify Interiors", tagline: "Studio", address: "Pune", phone: "", email: "", gstin: "" },
      client: { name: "Test Client", phone: null, email: null },
      project: { name: "Test 2BHK", code: "ART-2026-0001", contractValue: 1000000, totalReceived: 150000, balance: 850000 },
    });
    expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
  });
});
