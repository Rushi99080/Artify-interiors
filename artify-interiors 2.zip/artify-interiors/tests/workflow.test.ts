import { describe, expect, it } from "vitest";
import { computeProgress, DEFAULT_STAGES, nextStageToStart, planDueDates, stageKeyFromName, type MilestoneLike } from "@/lib/workflow/stages";

const ms = (statuses: MilestoneLike["status"][]): MilestoneLike[] => statuses.map((status, i) => ({ stageKey: `S${i}`, sortOrder: i, status }));

describe("workflow", () => {
  it("ships the 15 standard stages in order", () => {
    expect(DEFAULT_STAGES).toHaveLength(15);
    expect(DEFAULT_STAGES[0]!.key).toBe("LEAD_RECEIVED");
    expect(DEFAULT_STAGES.at(-1)!.key).toBe("FINAL_HANDOVER");
    expect(new Set(DEFAULT_STAGES.map((s) => s.key)).size).toBe(15);
  });

  it("computes progress ignoring skipped stages", () => {
    const p = computeProgress(ms(["COMPLETED", "COMPLETED", "SKIPPED", "IN_PROGRESS", "PENDING"]));
    expect(p).toMatchObject({ done: 2, total: 4, percent: 50 });
    expect(p.current?.stageKey).toBe("S3");
    expect(computeProgress([]).percent).toBe(0);
  });

  it("starts the next pending stage only when nothing is in progress", () => {
    expect(nextStageToStart(ms(["COMPLETED", "IN_PROGRESS", "PENDING"]))).toBeNull();
    expect(nextStageToStart(ms(["COMPLETED", "COMPLETED", "PENDING", "PENDING"]))?.stageKey).toBe("S2");
    expect(nextStageToStart(ms(["COMPLETED"]))).toBeNull();
  });

  it("plans sequential due dates for open stages", () => {
    const start = new Date("2026-10-01T00:00:00Z");
    const plan = planDueDates(
      ms(["COMPLETED", "PENDING", "PENDING"]).map((m, i) => ({ ...m, durationDays: [5, 3, 0][i]! })),
      start,
    );
    expect(plan.map((p) => [p.stageKey, p.dueDate.toISOString().slice(0, 10)])).toEqual([
      ["S1", "2026-10-04"],
      ["S2", "2026-10-05"], // zero-day stages still take one day
    ]);
  });

  it("derives stable keys from stage names", () => {
    expect(stageKeyFromName("Site Measurement")).toBe("SITE_MEASUREMENT");
    expect(stageKeyFromName("  3D design & render! ")).toBe("3D_DESIGN_RENDER");
    expect(stageKeyFromName("@@@")).toBe("STAGE");
  });
});
