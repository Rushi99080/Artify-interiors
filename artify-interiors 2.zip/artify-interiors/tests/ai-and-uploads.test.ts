import { describe, expect, it } from "vitest";
import { extractJson, normaliseStyle, normaliseTier, parseDesignOutput } from "@/lib/ai/schema";
import { checkUploadMeta, sniffMatches } from "@/lib/storage/rules";

const concept = {
  name: "Warm Teak Retreat",
  style: "japandi",
  tier: "Signature",
  colorPalette: [{ name: "Ivory", hex: "f2ede4" }, { name: "Bad", hex: "not-a-colour" }],
  materials: [{ category: "LAMINATE", materialId: "abc", name: "Oak laminate" }],
  furniture: [{ item: "Bed" }],
  imagePrompt: "Photorealistic bedroom with teak and linen",
};

describe("AI output parsing", () => {
  it("extracts JSON from fenced or chatty responses", () => {
    expect(extractJson('Sure! ```json\n{"a":1}\n``` hope that helps')).toEqual({ a: 1 });
    expect(extractJson('prefix {"a":{"b":2}} suffix')).toEqual({ a: { b: 2 } });
    expect(() => extractJson("no json here")).toThrow(/JSON/);
  });

  it("validates concepts leniently and normalises colours", () => {
    const out = parseDesignOutput(JSON.stringify({ concepts: [concept] }));
    expect(out.concepts[0]!.colorPalette.map((c) => c.hex)).toEqual(["#F2EDE4", "#CCCCCC"]);
    expect(out.concepts[0]!.decor).toEqual([]);
  });

  it("rejects responses without usable concepts instead of inventing designs", () => {
    expect(() => parseDesignOutput(JSON.stringify({ concepts: [] }))).toThrow(/expected format/);
    expect(() => parseDesignOutput(JSON.stringify({ concepts: [{ ...concept, imagePrompt: "" }] }))).toThrow(/expected format/);
  });

  it("maps free-text styles and finish levels to known values", () => {
    expect(normaliseStyle("japandi", "MODERN")).toBe("JAPANDI");
    expect(normaliseStyle("Neo-classical", "MODERN")).toBe("NEO_CLASSICAL");
    expect(normaliseStyle("space-age", "MODERN")).toBe("MODERN");
    expect(normaliseTier("Signature", "ECONOMY")).toBe("STANDARD");
    expect(normaliseTier("Luxe", "STANDARD")).toBe("LUXURY");
    expect(normaliseTier("??", "PREMIUM")).toBe("PREMIUM");
  });
});

describe("upload validation", () => {
  const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
  const PDF = new TextEncoder().encode("%PDF-1.7\n");
  const JPG = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0, 0x10]);

  it("checks extension and size per category", () => {
    expect(checkUploadMeta("ROOM_PHOTO", "room.jpg", 2_000_000)).toBeNull();
    expect(checkUploadMeta("ROOM_PHOTO", "room.exe", 1000)).toMatch(/./);
    expect(checkUploadMeta("ROOM_PHOTO", "room.jpg", 500 * 1024 * 1024)).toMatch(/./);
    expect(checkUploadMeta("FLOOR_PLAN", "plan.pdf", 1_000_000)).toBeNull();
  });

  it("verifies file signatures so renamed files are rejected", () => {
    expect(sniffMatches("png", PNG)).toBe(true);
    expect(sniffMatches("jpg", JPG)).toBe(true);
    expect(sniffMatches("pdf", PDF)).toBe(true);
    expect(sniffMatches("png", PDF)).toBe(false);
    expect(sniffMatches("pdf", PNG)).toBe(false);
  });
});
