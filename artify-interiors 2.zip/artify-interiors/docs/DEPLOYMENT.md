# Deployment (Vercel + Neon + Cloudinary)

## 1. Prerequisites

| Service | Why | Required |
| --- | --- | --- |
| GitHub repository | Vercel deploys from Git | Yes |
| [Vercel](https://vercel.com) project | Hosting | Yes |
| PostgreSQL ([Neon](https://neon.tech), Supabase, RDS…) | Database | Yes |
| [Cloudinary](https://cloudinary.com) | File storage — Vercel's disk is temporary | Yes for production |
| AI provider key (Gemini / OpenAI / Anthropic / Replicate) | Design concepts & visualizations | Recommended |
| SMTP mailbox or [Resend](https://resend.com) | Email notifications, quotation emails | Recommended |
| WhatsApp Cloud API (Meta) | WhatsApp notifications | Optional |
| Razorpay | Online payments | Optional |
| Upstash Redis | Shared rate limiting across serverless instances | Optional |

## 2. Environment variables

Copy every key from `.env.example` into Vercel → Project → Settings → Environment Variables (Production and Preview). Production minimum:

```env
DATABASE_URL=postgresql://...            # use the pooled connection string on Neon
AUTH_SECRET=<48+ random characters>
APP_URL=https://www.yourdomain.com
STORAGE_PROVIDER=cloudinary
CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...
CRON_SECRET=<random string>
```

Never put secrets in variables that start with `NEXT_PUBLIC_`.

## 3. First deploy

1. Push the code to GitHub and **Import Project** in Vercel (framework: Next.js; build command `npm run build` is already set in `package.json`).
2. Add the environment variables, then deploy.
3. From your computer, point a shell at the production database once and create the schema and admin:
   ```bash
   DATABASE_URL="postgresql://...prod..." npm run db:deploy
   DATABASE_URL="postgresql://...prod..." SEED_DEMO_DATA=false \
     SEED_ADMIN_EMAIL=you@yourstudio.in SEED_ADMIN_PASSWORD='A-strong-passphrase-2026' npm run db:seed
   ```
   (Use `SEED_DEMO_DATA=true` on a staging database if you want the sample catalogue and demo project.)
4. Sign in at `/login`, open **Admin → Settings → Integrations** and check every row.
5. Fill **Settings → Company & tax** (GSTIN, bank details, logo), **Quotations & payments**, and import your supplier price list in **Material library**.

For later schema changes run `npm run db:deploy` against production before (or as part of) deploying the new code.

## 4. Integrations

### AI
Set `AI_TEXT_PROVIDER` / `AI_IMAGE_PROVIDER` and the matching key. Model names are configurable (`GEMINI_TEXT_MODEL`, `OPENAI_IMAGE_MODEL`, …) so you can move to newer models without code changes. Generation routes allow up to 300 s (`maxDuration`) — on Vercel Hobby the function limit is lower; use Pro for reliable image rendering.

### Email
* **SMTP** (Google Workspace, Zoho, Hostinger…): `EMAIL_PROVIDER=smtp`, `SMTP_HOST`, `SMTP_PORT` (587 or 465), `SMTP_SECURE` (`true` for 465), `SMTP_USER`, `SMTP_PASS`, `EMAIL_FROM`.
* **Resend**: `EMAIL_PROVIDER=resend`, `RESEND_API_KEY`, and a verified sending domain in `EMAIL_FROM`.
Use **Settings → Integrations → Send a test message** to confirm.

### WhatsApp (Meta Cloud API)
1. Create a Meta app with WhatsApp, add a phone number, create a permanent access token.
2. Create and get approval for message templates (one per event you want, with body variables).
3. Set `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_TEMPLATE_LANGUAGE`, and map events to template names in `WHATSAPP_TEMPLATES`, e.g.
   `{"QUOTATION_GENERATED":"quotation_ready","PAYMENT_REMINDER":"payment_due","PAYMENT_RECEIVED":"payment_received"}`.
Events without a template are logged as *Skipped* — the app never claims a WhatsApp message was sent unless Meta returns a message ID.

### Razorpay
Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`. In the Razorpay dashboard add a webhook to `https://<your-domain>/api/payments/razorpay/webhook` for `payment.captured` with secret `RAZORPAY_WEBHOOK_SECRET`. Clients then see **Pay online** on their payments page.

### Cron (payment reminders)
`vercel.json` schedules `/api/cron/payment-reminders` daily at 03:30 UTC (09:00 IST). Vercel sends `Authorization: Bearer $CRON_SECRET`; requests without it are rejected. The reminder window is set in **Settings → Automation**.

## 5. Backups and recovery

* **Database:** Neon keeps point-in-time history (restore to any moment within your plan's retention) — also take a nightly logical dump for off-site copies:
  ```bash
  pg_dump --format=custom --no-owner "$DATABASE_URL" > artify-$(date +%F).dump
  # restore into an empty database
  pg_restore --no-owner --dbname "$NEW_DATABASE_URL" artify-YYYY-MM-DD.dump
  ```
  A GitHub Action or any server cron can run the dump and upload it to Google Drive/S3.
* **Files:** Cloudinary stores originals redundantly; enable Cloudinary backups (Settings → Backup) for versioned copies.
* **Exports:** Admin → Reports offers CSV exports (projects, payments, expenses, leads) and Material library → Export gives a re-importable Excel file.

## 6. Production checklist

- [ ] `AUTH_SECRET` is long and random; default admin password changed
- [ ] `APP_URL` is the real domain (used in emails and payment links)
- [ ] `STORAGE_PROVIDER=cloudinary`
- [ ] Settings → Integrations shows AI, storage and email configured
- [ ] Company details, GSTIN, bank details, quotation terms reviewed
- [ ] Sample portfolio/testimonials replaced or hidden; demo materials replaced with real rates
- [ ] `CRON_SECRET` set; Razorpay webhook configured (if used)
- [ ] Database backups scheduled
