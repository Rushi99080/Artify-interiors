# Architecture

## Overview

```
                 ┌──────────────────────── Next.js 16 (App Router, Node runtime) ────────────────────────┐
 Browser ──────▶ │  (site) public pages     dashboard/ client area     admin/ studio panel                │
  (React 19)     │        │                         │                           │                         │
                 │        └──────── server components read via src/lib/services ┘                         │
                 │                                                                                         │
 fetch() ──────▶ │  /api/* route handlers ── route() wrapper: same-origin check · rate limit · auth/RBAC  │
                 │        │                  · zod validation · error mapping                            │
                 │        ▼                                                                                │
                 │  src/lib/services  (projects, ai-design, boq, quotations, payments, workflow, files…)  │
                 │        │             pure logic: lib/calc, lib/boq/engine, lib/workflow, lib/quotation  │
                 └────────┼────────────────────────────────────────────────────────────────────────────────┘
                          ├──▶ PostgreSQL (Prisma 7 + @prisma/adapter-pg)
                          ├──▶ Storage: local disk (dev) or Cloudinary (authenticated assets, signed URLs)
                          ├──▶ AI: OpenAI · Gemini · Anthropic · Replicate (server-side only)
                          ├──▶ Email: SMTP (nodemailer) or Resend · WhatsApp Cloud API
                          ├──▶ Razorpay (optional) · Upstash Redis (optional rate limiting)
                          └──◀ Vercel Cron → /api/cron/payment-reminders
```

* **Server components** render pages straight from the database (no client-side data fetching for first paint).
* **Client components** call the app's own REST API (`src/lib/client/api.ts`) for mutations, then `router.refresh()`.
* **Business rules live in `src/lib`**, never in pages, so the API, the seed script and the tests share them.

## Key modules

| Path | Responsibility |
| --- | --- |
| `lib/api.ts` | `route()` wrapper used by every API handler: CSRF origin check on mutations, rate limiting, session + permission check, zod/Prisma error mapping, consistent JSON errors (`{ error, code, details }`) |
| `lib/auth/*` | bcrypt passwords (12 rounds), HS256 JWT session in an `httpOnly`, `SameSite=Lax`, `Secure` (prod) cookie, role → permission map, `requireUser` / `requireTeam` |
| `proxy.ts` | Edge-level redirect of signed-out users away from `/dashboard` and `/admin` (pages re-check against the database) |
| `lib/calc/boq.ts` | Pure money maths: paise rounding, line amounts, BOQ totals, payment schedule split |
| `lib/boq/engine.ts` | Room templates → BOQ lines from dimensions, finish level, rate card and material library |
| `lib/quotation/snapshot.ts` | Immutable quotation snapshot + Indian-format amount in words |
| `lib/pdf/*` | React-PDF quotation (A4, multi-page) and receipt (A5) with bundled fonts (₹ glyph) |
| `lib/ai/*` | Provider-independent AI layer: `TextProvider` / `ImageProvider` interfaces, prompts, lenient zod parsing |
| `lib/materials/*` | Recommendation scoring and CSV/Excel import parsing |
| `lib/notifications/*` | In-app, email and WhatsApp delivery with per-attempt logging |
| `lib/storage/*` | Upload rules, magic-byte sniffing, local/Cloudinary drivers |
| `lib/settings.ts` | Admin-editable settings (company, tax, BOQ defaults, rate card, quotation text, payment schedule, automation, website content) stored as JSON rows with typed defaults |

## Data model (PostgreSQL)

30 tables, created by `prisma/migrations/20261002000000_init`.

* **People:** `User` (login, role CUSTOMER/STAFF/ADMIN) · `Customer` (client profile, may exist without login) · `TeamMember` (assignable staff, optional login)
* **Projects:** `Project` · `Room` · `RoomMaterial` · `UploadedFile` · `ProjectMilestone` (workflow instance) · `WorkflowStage` (template) · `Message`
* **AI:** `AIDesignRequest` (one generation run, provider, duration, errors) · `GeneratedDesign` (concept) · `DesignRevision` · `VisualizerConfig`
* **Catalogue:** `Material` (20 categories, rate, tier, durability, maintenance, styles) · `Supplier`
* **Commercial:** `BOQ` · `BOQItem` · `Quotation` (number, revision chain, JSON snapshot) · `PaymentMilestone` · `Payment` · `Expense`
* **CRM & content:** `Lead` · `LeadNote` · `PortfolioProject` · `Testimonial`
* **System:** `Notification` (every delivery attempt) · `Setting` · `Counter` (atomic numbering) · `AuditLog`

Human-readable numbers come from `Counter` rows inside transactions: projects `ART-2026-0001`, leads `LD-2026-0001`, quotations `AIQ/2026-27/0001` (+ `-R1` revisions), receipts `RCPT/2026-27/00001` (Indian financial year).

## AI design pipeline

1. **Brief** — the wizard (or dashboard) stores project details, rooms with dimensions, and uploads (photos, plans, references).
2. **Shortlist** — `recommendMaterials()` scores the active material library against style, finish level and the client's preferences; the top items per relevant category (with IDs and rates) go into the prompt.
3. **Concepts** — the text provider (OpenAI/Gemini/Claude) receives the brief, room photos (vision) and shortlist, and must return JSON (`designOutputSchema`). Material IDs not in the library are dropped; style/tier are normalised.
4. **Budget** — each concept's budget range comes from the BOQ engine for that room at the concept's finish level using real library rates — not from the model.
5. **Visualization** — each concept is rendered separately (`/api/designs/:id/render`) with the image provider; when a room photo exists it is used as the reference image (image edit), otherwise text-to-image.
6. **Failure handling** — missing keys return `503 NOT_CONFIGURED` and the UI shows a configuration notice; provider errors are stored on the request/design and shown to the user. Nothing is substituted with stock images.

## BOQ calculation

```
Amount            = Quantity × Rate                       (each line, rounded to paise)
Subtotal          = Σ Amount
Wastage           = Material lines × wastage %
Margin            = (Subtotal + Wastage + Transport + Installation) × margin %   (label configurable)
Additional charges= Wastage + Transport + Installation + Margin
Taxable value     = Subtotal + Additional charges − Discount
GST               = Taxable value × GST %
Grand Total       = Subtotal + GST + Additional charges − Discount
```

Lines generated from dimensions are `isEstimated = true`. A BOQ stays **Preliminary** until the team marks it **Verified** (after site measurement); quotations from a preliminary BOQ carry a banner. Approving a quotation makes its BOQ **Final** (read-only) and supersedes other open quotations for the project.

## Workflow

15 default stages (Lead received → Final handover) are copied to each project as `ProjectMilestone` rows. Admins can rename, reorder, add, hide from clients or deactivate stages (Settings → Workflow). Completing a stage starts the next one; due dates are planned from each stage's standard duration; key events (design approval, quotation approval, advance payment) complete stages automatically. Clients see only customer-visible stages.

## Security

* Session cookie is `httpOnly` + `SameSite=Lax` (+ `Secure` in production); JWT is re-checked against the database (deactivated users lose access immediately).
* RBAC on every API route (`auth: "<permission>"`) and page (`requireTeam(permission)`); customers can only reach their own projects (`assertProjectAccess`).
* Mutating requests from another origin are rejected; rate limits on login, registration, leads, AI, uploads, messages, imports and payment actions (Upstash Redis when configured, in-memory otherwise).
* Uploads: extension + size allow-list per category, magic-byte check, images re-encoded with sharp (strips EXIF/GPS, max 4096 px); files are served through `/api/files/:id` after an access check (Cloudinary assets are `authenticated` and served with short-lived signed URLs).
* All provider keys are read only on the server (`lib/env.ts`); nothing secret is exposed via `NEXT_PUBLIC_*`.
* Razorpay payments are confirmed only after HMAC signature verification (checkout callback and webhook).
* Security headers (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`), `poweredByHeader: false`.
* Audit log for logins, settings, payments, quotations, deletions and imports; structured JSON logging (`lib/logger.ts`).
