# Testing

## Automated tests

```bash
npm test            # run once
npm run test:watch  # re-run on change
npm run typecheck   # TypeScript
```

The Vitest suite (`tests/`) needs no database or API keys:

| File | Covers |
| --- | --- |
| `calc.test.ts` | Paise rounding, Amount = Qty × Rate, BOQ totals (wastage, margin, transport, installation, discount, GST, grand total), discount caps, payment schedule split, payment allocation & overdue detection |
| `boq-engine.test.ts` | Dimension fallbacks, line generation, preliminary flags, tier ordering, realistic 2BHK range, rate-card overrides, budget → finish level |
| `auth.test.ts` | bcrypt hashing, password policy, session signing/verification (tampered and expired tokens), role permissions |
| `quotation.test.ts` | Quotation snapshot (section order, totals, preliminary flag, specs), amount in words (lakh/crore, paise), quotation and receipt PDF rendering |
| `workflow.test.ts` | 15 default stages, progress, next stage, due-date planning, stage keys |
| `materials.test.ts` | CSV/Excel row parsing and validation, recommendation ranking |
| `ai-and-uploads.test.ts` | AI JSON extraction and validation, style/tier normalisation, upload size/extension rules, magic-byte checks |

## Manual end-to-end checklist

With `npm run dev` and the demo seed:

1. **Public:** home → Start Your Design → complete the wizard as a new user (account created, project + rooms + uploads saved).
2. **AI:** with an AI key set, generate concepts, render visualizations, save/favourite, request changes, regenerate. Without keys you should see the *not configured* notice.
3. **Cost calculator / services:** estimates change with rooms and finish level; *Get a detailed quote* creates a lead.
4. **Admin:** lead appears in Leads & CRM → convert → project. Generate BOQ, edit lines, mark verified, create and send a quotation, download PDF.
5. **Client:** approve the quotation (dashboard) → admin converts → payment schedule appears → record a payment → client downloads the receipt.
6. **Settings → Integrations → Send a test message** shows *Sent* (configured) or *Skipped* with the reason; check **Notification log**.
7. **Reports** reflect the recorded payment and expense.

## Testing AI without paid keys

Any OpenAI-compatible endpoint works via `OPENAI_BASE_URL`, e.g. a local model server or a recorded mock. Set `AI_TEXT_PROVIDER=openai`, `AI_IMAGE_PROVIDER=openai`, `OPENAI_API_KEY=<anything>` and `OPENAI_BASE_URL=http://localhost:4010/v1`. The full pipeline (prompting with photos and the material shortlist, JSON parsing, budgets, image edits, storage) runs exactly as in production.
