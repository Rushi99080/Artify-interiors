# API reference

All endpoints live under `/api`, accept and return JSON (uploads use `multipart/form-data`), and use the session cookie set by `/api/auth/login`. Errors have the shape:

```json
{ "error": "Human-readable message", "code": "VALIDATION | UNAUTHORIZED | FORBIDDEN | NOT_FOUND | CONFLICT | RATE_LIMITED | NOT_CONFIGURED | BAD_REQUEST", "details": { "field": "message" } }
```

`NOT_CONFIGURED` (HTTP 503) means an integration has no keys yet. Mutating requests must come from the same origin.

**Access** column: *public* · *user* (any signed-in user; customers only for their own projects) · otherwise the permission required (see `src/lib/auth/permissions.ts`).

## Auth & profile

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| POST | `/auth/register` | public | Create a client account |
| POST | `/auth/login` | public | Sign in (sets cookie) |
| POST | `/auth/logout` | public | Sign out |
| GET | `/auth/me` | user | Current user |
| PATCH | `/users/me` | user | Update name/phone/password |

## Leads & customers

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| POST | `/leads` | public | Website/calculator enquiry (honeypot + rate limit) |
| GET | `/leads` | leads.manage | List leads |
| PATCH / DELETE | `/leads/:id` | leads.manage / settings.manage | Update status, follow-up, owner, notes / delete |
| POST | `/leads/:id/convert` | leads.manage | Create customer + project |
| POST | `/customers` · PATCH `/customers/:id` | customers.manage | Manage customers |

## Projects, rooms, files, messages

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| GET / POST | `/projects` | user | List / create (wizard) |
| GET / PATCH / DELETE | `/projects/:id` | user / settings.manage | Read, update, delete |
| POST | `/projects/:id/rooms` · PATCH/DELETE `/rooms/:id` | user | Rooms & dimensions |
| PUT | `/rooms/:id/materials` | user | Room material selections |
| GET | `/uploads/config` | user | Upload limits and storage mode |
| GET / POST | `/projects/:id/files` | user | List / upload (multipart) |
| POST | `/projects/:id/files/sign` · `/projects/:id/files/register` | user | Direct-to-Cloudinary signed upload |
| GET / DELETE | `/files/:id` | user | Serve (access-checked) / delete |
| GET / POST | `/projects/:id/messages` | user | Project conversation |
| POST | `/projects/:id/workflow` · PATCH `/milestones/:id` | projects.manage | Initialise / update workflow stages |

## AI design & visualizer

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| GET | `/ai/status` | user | Which providers are configured |
| POST | `/ai/generate` | user | Generate concepts `{ projectId, roomId?, fileIds[], instructions?, variations? }` |
| POST | `/designs/:id/render` | user | Render the concept's visualization |
| POST | `/designs/:id/regenerate` | user | New revision with instructions |
| PATCH / DELETE | `/designs/:id` | user / designs.manage | save, favorite, approve, request_changes, reject*, reset*, adminNotes* (*team) |
| GET / POST | `/visualizer` · PATCH/DELETE `/visualizer/:id` | user | Saved 3D configurations |

## Materials & suppliers

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| GET | `/materials` | public | Active catalogue (filters `category`, `q`, `tier`) |
| POST · PATCH `/materials/:id` | `/materials` | materials.manage | Create / update |
| DELETE | `/materials/:id` | materials.delete | Delete (deactivates if in use) |
| POST | `/materials/import` | materials.manage | CSV/XLSX import, `mode=preview|import` |
| GET | `/materials/export` · `/materials/template` | materials.manage | Excel export / blank template |
| POST | `/materials/recommend` | public | Scored recommendations |
| GET / POST · PATCH/DELETE `/suppliers/:id` | `/suppliers` | suppliers.manage | Supplier directory |

## BOQ & quotations

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| POST | `/projects/:id/boq` | boq.manage | Generate a BOQ version `{ tier }` |
| POST | `/projects/:id/quotations/preliminary` | user | Client self-serve preliminary quotation (if enabled) |
| GET / PATCH / DELETE | `/boq/:id` | user / boq.manage | Read; update charges, status (`VERIFIED`) |
| POST | `/boq/:id/items` · PATCH/DELETE `/boq/items/:itemId` | boq.manage | Line items |
| GET | `/boq/:id/export` | user | Excel with live formulas |
| POST | `/boq/:id/quotation` | quotations.manage | Create quotation `{ send }` |
| GET | `/quotations/:id/pdf` | user | Branded PDF |
| POST | `/quotations/:id/send` · `/email` · `/revise` · `/convert` | quotations.manage | Publish, email PDF, new revision, activate project |
| POST | `/quotations/:id/approve` · `/request-changes` | user | Client decision (approve requires `accept: true`) |

## Payments & expenses

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| GET / POST | `/projects/:id/payments` | user / payments.record | Overview / record payment |
| PUT | `/projects/:id/payment-schedule` | payments.record | Edit milestones and due dates |
| POST | `/projects/:id/payment-reminder` | payments.record | Send reminder now |
| GET | `/payments/:id/receipt` | user | Receipt PDF |
| DELETE | `/payments/:id` | payments.delete | Remove a payment |
| POST | `/payments/razorpay/order` · `/verify` | user | Online payment (signature verified) |
| POST | `/payments/razorpay/webhook` | Razorpay signature | Server-to-server confirmation |
| POST | `/projects/:id/expenses` · DELETE `/expenses/:id` | expenses.manage | Project expenses |

## Admin, content, notifications

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| POST · PATCH/DELETE `/team/:id` | `/team` | team.manage | Team members and logins |
| PUT | `/settings/:key` | settings.manage (content keys: content.manage) | `company`, `tax`, `boqDefaults`, `quotation`, `paymentSchedule`, `rateCard`, `automation`, `hero`, `about`, `stats` |
| PUT | `/settings/workflow` | settings.manage | Workflow stages |
| POST · PATCH/DELETE `/content/portfolio/:id` | `/content/portfolio` | content.manage | Portfolio |
| POST · PATCH/DELETE `/content/testimonials/:id` | `/content/testimonials` | content.manage | Testimonials |
| POST | `/content/upload` | materials.manage | Upload a public image |
| GET | `/notifications` · POST `/notifications/read` | user | In-app notifications |
| POST | `/notifications/test` | settings.manage | Send a real test email/WhatsApp |
| GET | `/reports/export?type=projects|payments|expenses|leads` | reports.view | CSV export |
| GET | `/cron/payment-reminders` | `Bearer CRON_SECRET` | Daily reminders (Vercel Cron) |
| GET | `/health` | public | Liveness + database check |
