# Admin guide

Sign in at `/login` with an Admin or Staff account — you land on `/admin`. Staff see day-to-day modules; Admins also see Team, Website content, Reports, Notification log and Settings.

## Daily flow: enquiry → handover

1. **Leads & CRM** — every website enquiry, cost-calculator request and AI-designer sign-up becomes a lead (`LD-2026-0001`). Set status (New → Contacted → Consultation → Quotation sent → Converted / Lost), follow-up date, owner and notes. Overview shows follow-ups due today.
2. **Convert** a lead to a customer + project (or create one from **Customers → New project**). The project gets the 15 workflow stages.
3. **Project → Rooms** — confirm room list and site dimensions; pick materials per room from the library.
4. **Project → Designs** — generate AI concepts from the client's photos (or let the client do it from their dashboard). Review in **Design approval**: approve, reject, or add a team note (team notes are never shown to clients).
5. **Project → BOQ → Generate new BOQ version** at the right finish level. Open it in the **BOQ editor**:
   * edit quantity or rate inline, edit any line, add items from the library or as custom lines, delete lines;
   * set GST, wastage, margin, transport, installation and discount — totals update live;
   * after site measurement click **Mark verified on site** (removes the *preliminary* flag).
6. **Create quotation** (tick *Send to client now* to publish it in their dashboard). From **Project → Quotations**: download/print the PDF, email it as an attachment, **Revise** (creates `-R1`, `-R2` … and supersedes the old one), or approve on the client's behalf.
7. When the client approves, **Convert to project**: status becomes Active, the contract value is set and the payment schedule is created from Settings.
8. **Project → Payments** — record payments (cash/UPI/bank/cheque/card), download receipts, edit the schedule and due dates, send a reminder; clients can pay online when Razorpay is configured. Admins also record **expenses** for profit tracking.
9. **Project → Overview** — move workflow stages (start, complete, block, skip), assign team members and due dates, and choose whether the client is notified. **Timeline** shows all projects on one calendar.
10. **Messages** — one thread per project shared with the client.

## Catalogue

* **Material library** — add/edit materials (category, brand, code, finish, colour, unit, rate, finish level, durability, maintenance, styles, supplier, photo). Click a rate to change it in place. **Import CSV / Excel**: download the template, fill it, upload, check the preview, then import — rows with an existing product code update that material. **Export** gives the same format.
* **Suppliers** — vendor directory linked to materials and expenses.

Rates in the library drive the BOQ engine, the cost calculator and AI material suggestions. Fabricated items (wardrobes, TV units, ceilings, painting, electrical) are priced from the **rate card** in Settings → BOQ & rate card.

## Studio settings (Admin only)

| Tab | What you control |
| --- | --- |
| Company & tax | Name, legal name, address, contact, GSTIN, bank details, logo for PDFs, GST rate |
| Quotations & payments | Number prefix, validity, scope of work, payment terms, timeline, T&C, payment schedule (must total 100%) |
| BOQ & rate card | Default wastage / margin / transport / installation, how the margin is labelled to clients, rates per finish level |
| Workflow | Rename, reorder, add or deactivate stages; standard durations; client visibility |
| Automation | Client self-serve preliminary quotations, payment-reminder window |
| Integrations | Live status of every integration and a **Send a test message** tool |

**Team** — add staff, give them a Staff or Admin login, reset passwords, deactivate (blocks login).
**Website content** — homepage hero, studio figures, About page, portfolio projects (with image upload), testimonials. Seeded items are marked *Sample*; replace them with your own.
**Reports** — revenue vs expenses, expenses by category, payment methods, lead pipeline and source conversion, project profitability, most-specified materials; CSV exports.
**Notification log** — every email/WhatsApp attempt with provider message ID or the exact error.
