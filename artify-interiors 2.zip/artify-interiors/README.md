# Artify Interiors — AI Interior Design Platform

A complete web platform for **Artify Interiors**: a luxury public website, an AI interior designer, a material library, an automatic BOQ (Bill of Quantities) and quotation system, a client dashboard, and an admin panel that runs the studio — leads, projects, workflow, payments, team, website content and reports.

Built with **Next.js 16 (App Router) + TypeScript**, **Tailwind CSS 4**, **PostgreSQL + Prisma 7**, **Three.js (React Three Fiber)**, **Recharts** and **React-PDF**. Deploys to **Vercel**.

> Nothing in the app is faked. When an integration (AI, email, WhatsApp, Cloudinary, Razorpay) has no keys yet, the feature shows a clear **"not configured"** message instead of pretending to work. Messages are marked *Sent* only when the provider confirms them.

---

## What's inside

| Area | Highlights |
| --- | --- |
| **Public website** | Animated hero, portfolio (Explore Designs), 14 room services, material library, cost calculator, 3D visualizer, About, Contact with lead capture, SEO (metadata, sitemap, robots) |
| **AI Interior Designer** | 3-step wizard → project, rooms & uploads → real AI concepts (3 variations) with palette, materials from *your* library, furniture, lighting, budget from the BOQ engine, and a rendered visualization from your room photo |
| **3D visualizer** | Orbit/zoom, room dimensions, wall colour, flooring, furniture placement (drag), material switching, lighting presets, camera angles, screenshot, saved configurations |
| **BOQ & quotations** | Room-wise BOQ from dimensions + materials, wastage, margin, transport, installation, discount, GST; preliminary vs site-verified; branded multi-page PDF; send, email, revise (history), client approval, convert to project; Excel export |
| **Client dashboard** | Projects, workflow tracker, designs (save/favourite/approve/request changes), files, BOQ, quotations, payments (receipts, optional Razorpay), messages, notifications |
| **Admin panel** | Overview analytics, Leads & CRM, Customers, Projects, Timeline (Gantt), AI requests, Design approval, BOQ editor, Quotations, Payments, Material library (CSV/Excel import), Suppliers, Team & logins, Website content, Reports, Notification log, Settings |
| **Automation** | 15-stage configurable workflow, payment schedules, daily payment reminders (Vercel Cron), email (SMTP/Resend) + WhatsApp Cloud API notifications |

Detailed docs live in [`docs/`](docs):
[Architecture](docs/ARCHITECTURE.md) · [Deployment](docs/DEPLOYMENT.md) · [Admin guide](docs/ADMIN-GUIDE.md) · [API reference](docs/API.md) · [Testing](docs/TESTING.md)

---

## Run it on your computer (step by step)

You need **Node.js 20.9 or newer** (22 LTS recommended) and a **PostgreSQL** database.

### 1. Get a database

Pick one:

- **Easiest (free, online):** create a project at [neon.tech](https://neon.tech) and copy its connection string (`postgresql://...`).
- **Local:** install PostgreSQL 15+ and create a database:
  ```bash
  createuser -P artify          # password: artify
  createdb -O artify artify
  ```

### 2. Install and configure

```bash
npm install
cp .env.example .env
```

Open `.env` and set at least:

```env
DATABASE_URL="postgresql://artify:artify@localhost:5432/artify"   # or your Neon URL
AUTH_SECRET="<paste a long random string>"
```

Generate a good `AUTH_SECRET` with:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

### 3. Create the tables and sample data

```bash
npm run db:deploy     # creates all tables (runs the migrations)
npm run db:seed       # workflow stages + admin login (+ demo data when SEED_DEMO_DATA="true")
```

### 4. Start

```bash
npm run dev
```

Open <http://localhost:3000>.

| Login | Email | Password |
| --- | --- | --- |
| Admin | `admin@artifyinteriors.in` | `Artify@Admin2026` |
| Demo client (demo data only) | `demo.customer@example.com` | `Demo@12345` |

**Change the admin password straight away** (Admin → your name → Profile), or create your own admin:

```bash
npm run admin:create -- --email you@yourstudio.in --name "Your Name" --password "A-long-passphrase-2026"
```

### 5. Turn on AI (optional but recommended)

Add one provider's key to `.env` and restart `npm run dev`:

```env
# Google Gemini — concepts + visualizations with one key
AI_TEXT_PROVIDER="gemini"
AI_IMAGE_PROVIDER="gemini"
GEMINI_API_KEY="..."
```

or OpenAI (`AI_TEXT_PROVIDER="openai"`, `AI_IMAGE_PROVIDER="openai"`, `OPENAI_API_KEY`), or Anthropic Claude for concepts (`AI_TEXT_PROVIDER="anthropic"`, `ANTHROPIC_API_KEY`) with Gemini/OpenAI/Replicate for images. Admin → Settings → Integrations shows what is configured.

---

## Useful commands

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the development server |
| `npm run build` / `npm start` | Production build / run it |
| `npm test` | Run the automated tests (calculations, auth, quotations, workflow, imports, AI parsing, uploads) |
| `npm run typecheck` | TypeScript check |
| `npm run db:deploy` | Apply database migrations |
| `npm run db:seed` | Seed workflow stages, admin and (optionally) demo data |
| `npm run db:studio` | Browse the database in Prisma Studio |
| `npm run admin:create -- --email … --password …` | Create or reset an admin login |

---

## Deploy to Vercel (short version)

1. Push this folder to a GitHub repository and import it in Vercel.
2. Create a Postgres database (Neon via the Vercel Marketplace works well).
3. Add the environment variables from `.env.example` in Vercel → Settings → Environment Variables. For production you need `DATABASE_URL`, `AUTH_SECRET`, `APP_URL`, **`STORAGE_PROVIDER="cloudinary"` with Cloudinary keys** (Vercel has no permanent disk), and `CRON_SECRET`.
4. Deploy, then run once from your computer with the production `DATABASE_URL`:
   ```bash
   npm run db:deploy && SEED_DEMO_DATA=false npm run db:seed
   ```

Full checklist, email/WhatsApp/Razorpay setup and backups: [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md).

---

## Project structure

```
prisma/              schema.prisma, migrations, seed.ts
scripts/             create-admin.ts
src/app/(site)/      public website pages
src/app/dashboard/   client dashboard
src/app/admin/       admin panel
src/app/api/         REST API (route handlers)
src/components/      UI components (ui, site, designs, boq, payments, visualizer, admin…)
src/lib/             business logic — auth, ai, boq, calc, pdf, notifications, services, storage
tests/               Vitest test suite
docs/                architecture, deployment, admin, API and testing guides
```

## Important notes

- **AI quantities are preliminary.** Every BOQ line generated from room dimensions is marked as an estimate; quotations from an unverified BOQ carry a *Preliminary estimate* banner until your team verifies measurements on site.
- **Demo content is labelled.** Seeded portfolio projects and testimonials are flagged *Sample* on the site — replace them with your own work from Admin → Website content. Demo material brands/rates are realistic placeholders; update them with your supplier prices (Admin → Material library → Import CSV/Excel).
- **API keys stay on the server.** No key is ever sent to the browser.
